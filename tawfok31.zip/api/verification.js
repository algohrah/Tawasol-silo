import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, member_id, status } = req.query;
      if (id) {
        const { data, error } = await supabase.from('verification_docs').select('*').eq('id', id).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      let query = supabase.from('verification_docs').select('*');
      if (member_id) query = query.eq('member_id', member_id);
      if (status) query = query.eq('status', status);
      query = query.order('submitted_at', { ascending: false });
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const doc = {
        ...req.body,
        id: 'vdoc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8),
        status: 'pending',
        submitted_at: new Date().toISOString()
      };
      const { data, error } = await supabase.from('verification_docs').insert(doc).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (updates.status === 'approved' || updates.status === 'rejected') {
        updates.reviewed_at = new Date().toISOString();
      }
      const { data, error } = await supabase.from('verification_docs').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase.from('verification_docs').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Verification API error:', err);
    res.status(500).json({ error: err.message });
  }
}
