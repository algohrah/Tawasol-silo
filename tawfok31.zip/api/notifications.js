import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { user_id, request_id, unread_only } = req.query;
      let query = supabase.from('notifications').select('*');
      if (user_id) query = query.eq('user_id', user_id);
      if (request_id) query = query.eq('request_id', parseInt(request_id));
      if (unread_only === 'true') query = query.eq('read', false);
      query = query.order('created_at', { ascending: false });
      
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    
    if (req.method === 'POST') {
      const notif = { ...req.body, created_at: new Date().toISOString() };
      const { data, error } = await supabase.from('notifications').insert(notif).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    
    if (req.method === 'PUT') {
      const { id, read, mark_all_read, user_id } = req.body;
      
      if (mark_all_read && user_id) {
        const { error } = await supabase.from('notifications')
          .update({ read: true }).eq('user_id', user_id).eq('read', false);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      
      if (id) {
        const { data, error } = await supabase.from('notifications')
          .update({ read: read !== undefined ? read : true }).eq('id', id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      
      return res.status(400).json({ error: 'id or mark_all_read+user_id required' });
    }
    
    if (req.method === 'DELETE') {
      const { id, user_id } = req.body;
      if (id) {
        const { error } = await supabase.from('notifications').delete().eq('id', id);
        if (error) throw error;
      } else if (user_id) {
        const { error } = await supabase.from('notifications').delete().eq('user_id', user_id);
        if (error) throw error;
      }
      return res.status(200).json({ ok: true });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Notifications API error:', err);
    res.status(500).json({ error: err.message });
  }
}
