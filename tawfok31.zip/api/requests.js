import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, sender_id, receiver_id, journey_stage } = req.query;
      
      if (id) {
        const { data, error } = await supabase
          .from('requests')
          .select('*')
          .eq('id', id)
          .single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      
      let query = supabase.from('requests').select('*');
      if (sender_id) query = query.eq('sender_id', sender_id);
      if (receiver_id) query = query.eq('receiver_id', receiver_id);
      if (journey_stage) query = query.eq('journey_stage', journey_stage);
      query = query.order('created_at', { ascending: false });
      
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    
    if (req.method === 'POST') {
      const request = { ...req.body, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      const { data, error } = await supabase
        .from('requests')
        .insert(request)
        .select()
        .single();
      if (error) throw error;
      
      // Create event
      await supabase.from('events').insert({
        request_id: data.id,
        actor_id: data.sender_id,
        type: 'sent',
        note: 'تم إرسال طلب الاهتمام'
      });
      
      // Create notification for receiver
      await supabase.from('notifications').insert({
        user_id: data.receiver_id,
        request_id: data.id,
        type: 'request',
        text: 'وصلك طلب اهتمام جديد بانتظار قرارك',
        read: false
      });
      
      return res.status(201).json(data);
    }
    
    if (req.method === 'PUT') {
      const { id, action, actor_id, payload = {}, ...directUpdates } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      
      // If action-based update (journey actions)
      if (action) {
        return await handleAction(supabase, res, id, action, actor_id, payload);
      }
      
      // Direct field update
      const { data, error } = await supabase
        .from('requests')
        .update({ ...directUpdates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      
      await supabase.from('events').delete().eq('request_id', id);
      await supabase.from('notifications').delete().eq('request_id', id);
      await supabase.from('inquiry_messages').delete().eq('request_id', id);
      
      const { error } = await supabase.from('requests').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Requests API error:', err);
    res.status(500).json({ error: err.message });
  }
}

async function handleAction(sb, res, requestId, action, actorId, payload) {
  const { data: req_data, error: fetchErr } = await sb
    .from('requests').select('*').eq('id', requestId).single();
  if (fetchErr) throw fetchErr;
  
  const now = new Date().toISOString();
  let updates = { updated_at: now };
  let evType = action, evNote = '';
  
  switch (action) {
    case 'accept':
      updates.journey_stage = 'accepted';
      const deadline = new Date(); deadline.setDate(deadline.getDate() + 15);
      updates.deadline_date = deadline.toISOString();
      evNote = 'قبِل الطرف الآخر طلب الاهتمام';
      break;
    case 'decline':
      updates.journey_stage = 'declined';
      updates.decline_reason = payload.reason || 'عدم التوافق';
      evNote = 'تم الاعتذار: ' + (payload.reason || '');
      break;
    case 'cancel':
      updates.journey_stage = 'cancelled';
      updates.cancel_reason = payload.reason || 'تم الإلغاء';
      evNote = 'تم إلغاء الطلب: ' + (payload.reason || '');
      break;
    case 'pay_deposit': {
      const isSender = actorId === req_data.sender_id;
      if (isSender) { updates.sender_paid = true; updates.sender_paid_at = now; }
      else { updates.receiver_paid = true; updates.receiver_paid_at = now; }
      const bothPaid = (isSender ? true : req_data.sender_paid) && (isSender ? req_data.receiver_paid : true);
      if (bothPaid) { updates.journey_stage = 'coordination'; updates.paid_at = now; }
      else if (req_data.journey_stage === 'accepted') updates.journey_stage = 'seriousness';
      evNote = 'تم سداد رسوم الجدية (' + (isSender ? 'المرسِل' : 'المستقبِل') + ')';
      break;
    }
    case 'submit_contact': {
      if (payload.guardianPhone) {
        updates.guardian_phone = payload.guardianPhone;
        updates.guardian_name = payload.guardianName || null;
        updates.guardian_relation = payload.guardianRelation || null;
        updates.contact_time = payload.contactTime || null;
        updates.contact_note = payload.contactNote || null;
        updates.contact_by = actorId;
      }
      if (payload.malePhone) {
        updates.male_phone = payload.malePhone;
        updates.male_name = payload.maleName || null;
        updates.male_relation = payload.maleRelation || null;
        updates.male_contact_time = payload.maleContactTime || null;
        updates.male_contact_note = payload.maleContactNote || null;
      }
      evType = 'coordination';
      evNote = 'تمت مشاركة معلومات التواصل';
      break;
    }
    case 'male_pledge':
      updates.male_pledged = true;
      evNote = 'أقسم الطرف الذكر بعدم نشر المعلومات';
      evType = 'coordination';
      break;
    case 'female_pledge':
      updates.female_pledged = true;
      evNote = 'أقسمت الطرف الأنثى بعدم نشر المعلومات';
      evType = 'coordination';
      break;
    case 'set_stage':
      updates.journey_stage = payload.stage;
      if (payload.stage === 'cancelled') updates.cancel_reason = payload.note || 'إلغاء إداري';
      if (payload.stage === 'declined') updates.decline_reason = payload.note || 'رفض إداري';
      evNote = payload.note || ('تعديل إداري للمرحلة إلى ' + payload.stage);
      break;
    case 'freeze_request':
      updates.frozen = true;
      updates.frozen_reason = payload.note || 'تجميد مؤقت';
      updates.frozen_at = now;
      evNote = 'تجميد الطلب: ' + (payload.note || '');
      evType = 'system';
      break;
    case 'unfreeze_request':
      updates.frozen = false;
      evNote = 'إلغاء تجميد الطلب';
      evType = 'system';
      break;
    case 'update_coordination':
      if (payload.meetingDate !== undefined) updates.meeting_date = payload.meetingDate;
      if (payload.meetingNotes !== undefined) updates.meeting_notes = payload.meetingNotes;
      if (payload.advance) updates.journey_stage = 'sharia_viewing';
      evNote = 'تحديث التنسيق';
      evType = 'coordination';
      break;
    case 'record_result': {
      const isSender = actorId === req_data.sender_id;
      if (payload.result === 'failed') {
        updates.journey_stage = 'declined';
        updates.decline_reason = payload.note || 'تم الاعتذار بعد النظرة';
        updates.evaluation_result = 'failed';
        updates.evaluation_note = payload.note || '';
        evNote = 'الاعتذار بعد النظرة الشرعية';
        evType = 'decline';
      } else {
        if (isSender) { updates.sender_viewing_result = 'success'; updates.sender_viewing_note = payload.note || ''; }
        else { updates.receiver_viewing_result = 'success'; updates.receiver_viewing_note = payload.note || ''; }
        if (req_data.sender_viewing_result === 'success' && req_data.receiver_viewing_result === 'success') {
          updates.journey_stage = 'engagement';
          evNote = 'توافق ثنائي مبارك — الانتقال للملكة 🎉';
        } else {
          evNote = 'تسجيل توافق من ' + (isSender ? 'المرسِل' : 'المستقبِل');
        }
        evType = 'sharia_viewing';
      }
      break;
    }
    case 'complete_engagement':
      updates.journey_stage = 'completed';
      updates.evaluation_result = 'success';
      if (payload.note) updates.evaluation_note = payload.note;
      evNote = 'تم إتمام الملكة وعقد القران 🎉';
      evType = 'completed';
      break;
    case 'defer_payment':
      updates.defer_date = payload.deferDate;
      updates.defer_by = actorId;
      evNote = 'تأجيل سداد الرسوم';
      evType = 'defer_payment';
      break;
    default:
      return res.status(400).json({ error: 'Unknown action: ' + action });
  }
  
  const { data: updated, error: updErr } = await sb
    .from('requests').update(updates).eq('id', requestId).select().single();
  if (updErr) throw updErr;
  
  await sb.from('events').insert({ request_id: requestId, actor_id: actorId || 'system', type: evType, note: evNote });
  
  // Notify other party
  const otherId = actorId === req_data.sender_id ? req_data.receiver_id : req_data.sender_id;
  if (otherId && ['accept','decline','cancel','pay_deposit','submit_contact'].includes(action)) {
    await sb.from('notifications').insert({
      user_id: otherId, request_id: requestId, type: 'request',
      text: `تم تحديث طلب الاهتمام — تابع رحلتك الآن`, read: false
    });
  }
  
  return res.status(200).json(updated);
}
