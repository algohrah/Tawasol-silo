import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { type, country } = req.query;
      
      if (type === 'countries') {
        const { data, error } = await supabase.from('geo_countries').select('*').order('name');
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      
      if (type === 'cities' && country) {
        const { data, error } = await supabase.from('geo_cities').select('*').eq('country', country).order('name');
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      
      if (type === 'pending') {
        const { data, error } = await supabase.from('geo_pending_cities').select('*').eq('status', 'pending').order('created_at', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      
      // Default: return countries + cities map
      const { data: countries, error: cErr } = await supabase.from('geo_countries').select('*').order('name');
      if (cErr) throw cErr;
      const { data: cities, error: ciErr } = await supabase.from('geo_cities').select('*').order('name');
      if (ciErr) throw ciErr;
      
      const citiesByCountry = {};
      (cities || []).forEach(c => {
        if (!citiesByCountry[c.country]) citiesByCountry[c.country] = [];
        citiesByCountry[c.country].push(c.name);
      });
      
      return res.status(200).json({ countries: countries || [], citiesByCountry });
    }
    
    if (req.method === 'POST') {
      const { type } = req.body;
      
      if (type === 'country') {
        const { name, code, flag } = req.body;
        const { data, error } = await supabase.from('geo_countries').insert({ name, code, flag }).select().single();
        if (error) throw error;
        return res.status(201).json(data);
      }
      
      if (type === 'city') {
        const { country, name } = req.body;
        const { data, error } = await supabase.from('geo_cities').insert({ country, name }).select().single();
        if (error) throw error;
        return res.status(201).json(data);
      }
      
      if (type === 'pending_city') {
        const { id, name, country, suggested_by, suggested_by_id, source } = req.body;
        const { data, error } = await supabase.from('geo_pending_cities').insert({
          id: id || `pc_${Date.now()}`, name, country, suggested_by, suggested_by_id, source: source || 'register', status: 'pending'
        }).select().single();
        if (error) throw error;
        return res.status(201).json(data);
      }
      
      return res.status(400).json({ error: 'type is required (country, city, pending_city)' });
    }
    
    if (req.method === 'PUT') {
      const { type, id, ...updates } = req.body;
      
      if (type === 'pending_city') {
        const { data, error } = await supabase.from('geo_pending_cities')
          .update({ ...updates, reviewed_at: new Date().toISOString() })
          .eq('id', id).select().single();
        if (error) throw error;
        
        if (updates.status === 'approved') {
          await supabase.from('geo_cities').insert({ country: data.country, name: data.name });
        }
        return res.status(200).json(data);
      }
      
      return res.status(400).json({ error: 'type required' });
    }
    
    if (req.method === 'DELETE') {
      const { type, id, country, name } = req.body;
      
      if (type === 'country') {
        await supabase.from('geo_cities').delete().eq('name', country);
        const { error } = await supabase.from('geo_countries').delete().eq('name', name || country);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      
      if (type === 'city') {
        const { error } = await supabase.from('geo_cities').delete().eq('id', id);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      
      if (type === 'pending_city') {
        const { error } = await supabase.from('geo_pending_cities').delete().eq('id', id);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      
      return res.status(400).json({ error: 'type required' });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Geo API error:', err);
    res.status(500).json({ error: err.message });
  }
}
