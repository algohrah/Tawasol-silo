import { BarChart3, Users, Heart, CreditCard, TrendingUp, Activity } from 'lucide-react';
import { useAdminStats } from '../../lib/useAdminData';
import { useApp } from '../../lib/AppContext';

export default function AdminAnalytics() {
  const { stats, loading } = useAdminStats();
  const { adminMembers } = useApp();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-slate-400">
        <div className="w-9 h-9 border-2 border-slate-300 border-t-amber-500 rounded-full animate-spin mb-3" />
        <p className="font-cairo text-sm">جارٍ تحميل التحليلات...</p>
      </div>
    );
  }

  const statCards = [
    { label: 'إجمالي الأعضاء', value: stats?.totalMembers || 0, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'الأعضاء الموثقون', value: stats?.verified || 0, icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'طلبات الاهتمام', value: stats?.totalRequests || 0, icon: Heart, color: 'text-rose-600', bg: 'bg-rose-50' },
    { label: 'الإيرادات التقريرية', value: (stats?.revenue || 0) + ' ر.س', icon: CreditCard, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  const cities = adminMembers.reduce((acc: Record<string, number>, m) => {
    acc[m.city] = (acc[m.city] || 0) + 1;
    return acc;
  }, {});

  const topCities = Object.entries(cities)
    .sort((a, b) => (b[1] as number) - (a[1] as number))
    .slice(0, 5);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-amber-500" /> التحليلات المتقدمة
        </h2>
        <p className="text-sm text-slate-500 font-tajawal">إحصائيات وتقارير مفصلة عن أداء المنصة</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {statCards.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className={`${s.bg} rounded-2xl p-4`}>
              <Icon className={`w-6 h-6 ${s.color} mb-2`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value.toLocaleString('ar-SA')}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        {/* Stage breakdown */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
          <h3 className="font-cairo font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-500" /> توزيع رحلات الاهتمام
          </h3>
          <div className="space-y-3">
            {stats?.stageBreakdown &&
              Object.entries(stats.stageBreakdown).map(([stage, count]) => (
                <div key={stage} className="flex items-center gap-3">
                  <span className="text-xs font-cairo font-bold text-slate-600 w-24 truncate">{stage}</span>
                  <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded-full"
                      style={{
                        width: `${Math.max(2, ((count as number) / (stats.totalRequests || 1)) * 100)}%`,
                      }}
                    />
                  </div>
                  <span className="text-xs font-cairo font-bold text-slate-900 w-8 text-left">{count as any}</span>
                </div>
              ))}
          </div>
        </div>

        {/* Top cities */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
          <h3 className="font-cairo font-bold text-slate-900 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-500" /> أكثر المدن نشاطاً
          </h3>
          <div className="space-y-3">
            {topCities.map(([city, count]) => (
              <div key={city} className="flex items-center gap-3">
                <span className="text-xs font-cairo font-bold text-slate-600 w-24 truncate">{city}</span>
                <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{
                      width: `${Math.max(2, ((count as number) / adminMembers.length) * 100)}%`,
                    }}
                  />
                </div>
                <span className="text-xs font-cairo font-bold text-slate-900 w-8 text-left">{count as any}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Gender distribution */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Users className="w-5 h-5 text-amber-500" /> توزيع الأعضاء حسب الجنس
        </h3>
        <div className="flex items-center gap-4">
          {(() => {
            const males = adminMembers.filter(m => m.gender === 'male').length;
            const females = adminMembers.filter(m => m.gender === 'female').length;
            const total = males + females || 1;
            return (
              <>
                <div className="flex-1">
                  <div className="flex h-8 rounded-lg overflow-hidden">
                    <div className="bg-blue-500 flex items-center justify-center text-white text-xs font-bold" style={{ width: `${(males / total) * 100}%` }}>
                      {males > 0 && `${Math.round((males / total) * 100)}%`}
                    </div>
                    <div className="bg-rose-500 flex items-center justify-center text-white text-xs font-bold" style={{ width: `${(females / total) * 100}%` }}>
                      {females > 0 && `${Math.round((females / total) * 100)}%`}
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 text-xs font-cairo font-bold">
                  <span className="text-blue-600">♂ {males} ذكر</span>
                  <span className="text-rose-600">♀ {females} أنثى</span>
                </div>
              </>
            );
          })()}
        </div>
      </div>
    </div>
  );
}
