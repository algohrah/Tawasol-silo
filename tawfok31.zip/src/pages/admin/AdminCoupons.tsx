import { useState, useEffect } from 'react';
import { Tag, Plus, Trash2, Copy, Check, Percent, Pencil, Power, AlertCircle } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { type LocalCoupon } from '../../lib/localStore';
import { dataService } from '../../lib/data/DataService';

import Modal from '../../components/ui/Modal';
const { getCoupons, saveCoupon, deleteCoupon, toggleCouponActive } = dataService.api;


export default function AdminCoupons() {
  const { showToast } = useApp();
  const [coupons, setCoupons] = useState<LocalCoupon[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteFor, setDeleteFor] = useState<LocalCoupon | null>(null);
  const [form, setForm] = useState<Partial<LocalCoupon>>({
    code: '',
    discount: 0,
    type: 'percent',
    usageLimit: 100,
    expiryDate: '',
    active: true,
  });

  const refresh = () => setCoupons(getCoupons());

  useEffect(() => { refresh(); }, []);

  const openCreate = () => {
    setEditingId(null);
    setForm({ code: '', discount: 0, type: 'percent', usageLimit: 100, expiryDate: '', active: true });
    setIsOpen(true);
  };

  const openEdit = (coupon: LocalCoupon) => {
    setEditingId(coupon.id);
    setForm({ ...coupon });
    setIsOpen(true);
  };

  const handleSave = () => {
    if (!form.code || !form.discount || !form.expiryDate) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
      return;
    }
    // التحقق من عدم تكرار الكود (عند الإنشاء)
    if (!editingId) {
      const exists = coupons.some((c) => c.code.toUpperCase() === form.code!.toUpperCase().trim());
      if (exists) {
        showToast('كود الكوبون موجود مسبقاً', 'error');
        return;
      }
    }
    const coupon: LocalCoupon = {
      id: editingId || 'c' + Date.now(),
      code: form.code!.toUpperCase().trim(),
      discount: form.discount!,
      type: form.type as 'percent' | 'fixed',
      usageLimit: form.usageLimit || 100,
      usageCount: editingId ? (coupons.find((c) => c.id === editingId)?.usageCount || 0) : 0,
      expiryDate: form.expiryDate!,
      active: form.active ?? true,
      createdAt: editingId ? (coupons.find((c) => c.id === editingId)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
      createdBy: 'الإدارة',
    };
    saveCoupon(coupon);
    refresh();
    setIsOpen(false);
    showToast(editingId ? 'تم تعديل الكوبون بنجاح ✓' : 'تم إنشاء الكوبون بنجاح ✓', 'success');
  };

  const handleToggle = (id: string) => {
    toggleCouponActive(id);
    refresh();
    showToast('تم تحديث حالة الكوبون', 'info');
  };

  const handleDelete = () => {
    if (!deleteFor) return;
    deleteCoupon(deleteFor.id);
    refresh();
    setDeleteFor(null);
    showToast('تم حذف الكوبون', 'info');
  };

  const inputClass =
    'w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm';
  const labelClass = 'block text-xs font-cairo font-bold text-slate-700 mb-1.5';

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
            <Tag className="w-5 h-5 text-amber-500" /> الكوبونات والعروض
          </h2>
          <p className="text-sm text-slate-500 font-tajawal">إنشاء وتعديل وإدارة أكواد الخصم — مرتبطة بصفحة الدفع</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors"
        >
          <Plus className="w-4 h-4" /> كوبون جديد
        </button>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'إجمالي الكوبونات', value: coupons.length, color: 'text-slate-700', bg: 'bg-slate-50' },
          { label: 'مفعّلة', value: coupons.filter((c) => c.active).length, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'معطّلة', value: coupons.filter((c) => !c.active).length, color: 'text-slate-500', bg: 'bg-slate-100' },
          { label: 'منتهية الصلاحية', value: coupons.filter((c) => new Date(c.expiryDate) < new Date()).length, color: 'text-rose-600', bg: 'bg-rose-50' },
        ].map((s) => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-3`}>
            <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
            <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.map((coupon) => {
          const isExpired = new Date(coupon.expiryDate) < new Date();
          const usagePct = Math.min(100, (coupon.usageCount / coupon.usageLimit) * 100);
          return (
            <div
              key={coupon.id}
              className={`bg-white rounded-2xl p-5 shadow-sm border-2 transition-all ${
                coupon.active && !isExpired ? 'border-slate-200' : 'border-slate-100 opacity-70'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600">
                    <Tag className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-cairo font-bold text-slate-900 text-sm">{coupon.code}</h3>
                    <p className="text-[10px] text-slate-400 font-tajawal">
                      {coupon.type === 'percent' ? `خصم ${coupon.discount}%` : `خصم ${coupon.discount} ر.س`}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard?.writeText(coupon.code);
                    showToast('تم نسخ الكود', 'success');
                  }}
                  className="p-2 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
                  title="نسخ"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-tajawal">الاستخدام</span>
                  <span className="font-cairo font-bold text-slate-700">
                    {coupon.usageCount} / {coupon.usageLimit}
                  </span>
                </div>
                <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${usagePct >= 80 ? 'bg-rose-500' : 'bg-amber-500'}`}
                    style={{ width: `${usagePct}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-tajawal">انتهاء الصلاحية</span>
                  <span className={`font-tajawal ${isExpired ? 'text-rose-600 font-bold' : 'text-slate-600'}`}>
                    {coupon.expiryDate} {isExpired && '⚠️'}
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => openEdit(coupon)}
                  className="flex-1 py-2 rounded-xl text-xs font-cairo font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors flex items-center justify-center gap-1"
                >
                  <Pencil className="w-3.5 h-3.5" /> تعديل
                </button>
                <button
                  onClick={() => handleToggle(coupon.id)}
                  className={`flex-1 py-2 rounded-xl text-xs font-cairo font-bold transition-colors flex items-center justify-center gap-1 ${
                    coupon.active
                      ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {coupon.active ? <><Check className="w-3.5 h-3.5" /> مفعّل</> : <><Power className="w-3.5 h-3.5" /> معطّل</>}
                </button>
                <button
                  onClick={() => setDeleteFor(coupon)}
                  className="px-3 py-2 rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {coupons.length === 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
          <Tag className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-slate-400 font-cairo text-sm">لا توجد كوبونات بعد — أنشئ أول كوبون</p>
        </div>
      )}

      {/* مودال الإنشاء/التعديل */}
      <Modal open={isOpen} onClose={() => setIsOpen(false)} title={editingId ? 'تعديل الكوبون' : 'كوبون جديد'}>
        <div className="space-y-4">
          <div>
            <label className={labelClass}>كود الكوبون</label>
            <input
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
              className={inputClass}
              placeholder="مثال: WELCOME20"
              dir="ltr"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>قيمة الخصم</label>
              <input
                type="number"
                value={form.discount}
                onChange={(e) => setForm({ ...form, discount: Number(e.target.value) })}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>نوع الخصم</label>
              <select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value as 'percent' | 'fixed' })}
                className={inputClass}
              >
                <option value="percent">نسبة %</option>
                <option value="fixed">قيمة ثابتة (ر.س)</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>حد الاستخدام</label>
              <input
                type="number"
                value={form.usageLimit}
                onChange={(e) => setForm({ ...form, usageLimit: Number(e.target.value) })}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>تاريخ الانتهاء</label>
              <input
                type="date"
                value={form.expiryDate}
                onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                className={inputClass}
                dir="ltr"
              />
            </div>
          </div>
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={form.active ?? true}
              onChange={(e) => setForm({ ...form, active: e.target.checked })}
              className="accent-emerald-500 w-4 h-4"
            />
            <span className="text-sm font-cairo font-bold text-slate-700">الكوبون مفعّل</span>
          </label>
          <button
            onClick={handleSave}
            disabled={!form.code || !form.discount || !form.expiryDate}
            className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Percent className="w-4 h-4" /> {editingId ? 'حفظ التعديلات' : 'إنشاء الكوبون'}
          </button>
        </div>
      </Modal>

      {/* تأكيد الحذف */}
      <Modal open={!!deleteFor} onClose={() => setDeleteFor(null)} title="حذف الكوبون">
        <div className="flex items-start gap-2.5 bg-rose-50 border border-rose-100 rounded-2xl p-3 mb-4">
          <AlertCircle className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-slate-600 font-cairo leading-relaxed">
            هل أنت متأكد من حذف كوبون <strong>{deleteFor?.code}</strong>؟ لا يمكن التراجع.
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setDeleteFor(null)} className="flex-1 bg-slate-100 text-slate-600 font-cairo font-bold py-3 rounded-xl hover:bg-slate-200 transition-colors">
            تراجع
          </button>
          <button onClick={handleDelete} className="flex-1 bg-rose-600 text-white font-cairo font-bold py-3 rounded-xl hover:bg-rose-700 transition-colors flex items-center justify-center gap-2">
            <Trash2 className="w-4 h-4" /> حذف
          </button>
        </div>
      </Modal>
    </div>
  );
}
