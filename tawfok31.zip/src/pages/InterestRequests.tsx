import { useState, useMemo, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Heart, Send, Inbox, Archive, Search, X, Loader2, AlertCircle,
  ShieldCheck, CalendarClock, MapPin, BadgeCheck, ChevronLeft, Info, Sparkles, Ban,
  Zap, CreditCard, UserCheck, Compass, Mail, Clock,
} from 'lucide-react';
import { getAvatar, getGenderColors } from '../lib/types';
import {
  useInterestRequests, fetchRequestEvents, getCurrentUserId,
  isRequestUnseen,
  type ApiRequest, type RequestEvent,
} from '../lib/useInterestRequests';
import { useApp } from '../lib/AppContext';
import {
  STAGE_META, ACCENT_CLASSES, getPrimaryAction, isTerminal,
  requiresMyAction, actionUrgency,
  getJourneyStage, getJourneyStatusSummary,
  DECLINE_REASONS, CANCEL_REASONS, DEPOSIT_AMOUNT, type JourneyState, type RequestRole,
} from '../lib/journey';
import { JourneyTimeline } from '../components/JourneyTimeline';
import AcceptedCelebrationModal from '../components/AcceptedCelebrationModal';
import Modal from '../components/ui/Modal';
import RequestStatusPanel from '../components/requests/RequestStatusPanel';

// ============================================================
//  صفحة طلبات الاهتمام — مسار واحد واضح، بيانات حقيقية
// ============================================================

type Tab = 'active' | 'incoming' | 'archive';

function stageOf(r: ApiRequest): JourneyState {
  return getJourneyStage(r, getCurrentUserId());
}

export default function InterestRequests() {
  const { user } = useApp();
  const activeId = user?.memberId || getCurrentUserId();
  const {
    requests, loading, error, actionLoading,
    getMember, runAction, refresh,
  } = useInterestRequests(activeId);

  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('active');
  const [query, setQuery] = useState('');
  // فلترة فرعية داخل تبويب النشطة: الكل / أرسلتها / وردتني
  const [subFilter, setSubFilter] = useState<'all' | 'sent' | 'received'>('all');

  // تحديث الطلبات تلقائياً عند العودة للصفحة (مثلاً بعد إرسال طلب من صفحة العضو)
  useEffect(() => { refresh(); }, [refresh]);

  // المودالات
  const [acceptModal, setAcceptModal] = useState<{ req: ApiRequest; name: string } | null>(null);
  const [declineModal, setDeclineModal] = useState<ApiRequest | null>(null);
  const [declineReason, setDeclineReason] = useState('');
  const [declineCustom, setDeclineCustom] = useState('');
  const [payModal, setPayModal] = useState<ApiRequest | null>(null);
  const [pledge, setPledge] = useState(false);
  const [resultModal, setResultModal] = useState<ApiRequest | null>(null);
  const [resultChoice, setResultChoice] = useState<'success' | 'failed'>('success');
  const [resultNote, setResultNote] = useState('');
  const [coordModal, setCoordModal] = useState<ApiRequest | null>(null);
  // إلغاء الطلب (متاح في أي مرحلة) مع ذكر السبب
  const [cancelModal, setCancelModal] = useState<ApiRequest | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelCustom, setCancelCustom] = useState('');
  const [toast, setToast] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3200);
  };

  // تصنيف الطلبات
  const buckets = useMemo(() => {
    const active: ApiRequest[] = [];
    const incoming: ApiRequest[] = [];
    const archive: ApiRequest[] = [];
    for (const r of requests) {
      const stage = stageOf(r);
      if (isTerminal(stage)) { archive.push(r); continue; }
      if (stage === 'completed') { archive.push(r); continue; }
      // وارد = طلب مُرسل لي بانتظار ردي
      if (stage === 'sent' && r.receiver_id === activeId) { incoming.push(r); continue; }
      active.push(r);
    }
    return { active, incoming, archive };
  }, [requests, activeId]);

  // هل يتطلّب الطلب إجراءً مني الآن؟
  const needsAction = (r: ApiRequest): boolean => {
    const stage = stageOf(r);
    const isSender = r.sender_id === activeId;
    const role: RequestRole = isSender ? 'sender' : 'receiver';
    const selfPaid = isSender ? r.sender_paid : r.receiver_paid;
    const otherPaid = isSender ? r.receiver_paid : r.sender_paid;
    return requiresMyAction(stage, role, { selfPaid, otherPaid });
  };

  const list = useMemo(() => {
    let arr = tab === 'active' ? buckets.active : tab === 'incoming' ? buckets.incoming : buckets.archive;
    // الفلترة الفرعية (تبويب النشطة فقط)
    if (tab === 'active' && subFilter !== 'all') {
      arr = arr.filter((r) => subFilter === 'sent' ? r.sender_id === activeId : r.receiver_id === activeId);
    }
    if (query.trim()) {
      const q = query.trim();
      arr = arr.filter((r) => {
        const other = r.sender_id === activeId ? r.receiver_id : r.sender_id;
        const m = getMember(other);
        return m?.nickname.includes(q) || m?.city.includes(q);
      });
    }
    // ترتيب: ما يتطلّب إجراءً أولاً، ثم الأحدث تحديثاً
    return [...arr].sort((a, b) => {
      const aAct = needsAction(a) ? 1 : 0;
      const bAct = needsAction(b) ? 1 : 0;
      if (aAct !== bAct) return bAct - aAct;
      const at = a.updated_at ? new Date(a.updated_at).getTime() : 0;
      const bt = b.updated_at ? new Date(b.updated_at).getTime() : 0;
      return bt - at;
    });
  }, [tab, buckets, query, subFilter, getMember, activeId]);

  // ===== لوحة الإحصائيات: عدّ ما يحتاج إجراءً ====
  const stats = useMemo(() => {
    let respond = 0, pay = 0, active = 0;
    for (const r of requests) {
      const stage = stageOf(r);
      if (isTerminal(stage) || stage === 'completed') continue;
      const isSender = r.sender_id === activeId;
      const role: RequestRole = isSender ? 'sender' : 'receiver';
      const selfPaid = isSender ? r.sender_paid : r.receiver_paid;
      const otherPaid = isSender ? r.receiver_paid : r.sender_paid;
      const urgency = actionUrgency(stage, role, { selfPaid, otherPaid });
      if (urgency === 'respond') respond++;
      else if (urgency === 'pay') pay++;
      active++;
    }
    return { respond, pay, active };
  }, [requests, activeId]);

  // ===== الإجراءات =====
  const onAccept = async (req: ApiRequest) => {
    const res = await runAction(req.id, 'accept');
    if (res.ok) {
      const name = getMember(req.sender_id)?.nickname || 'الطرف الآخر';
      setAcceptModal({ req: { ...req, journey_stage: 'accepted' }, name });
    } else showToast(res.error || 'تعذّر القبول', 'error');
  };

  const onDecline = async () => {
    if (!declineModal) return;
    const reason = declineReason === DECLINE_REASONS[DECLINE_REASONS.length - 1] ? declineCustom : declineReason;
    if (!reason.trim()) { showToast('يرجى اختيار سبب الاعتذار', 'error'); return; }
    const res = await runAction(declineModal.id, 'decline', { reason });
    setDeclineModal(null); setDeclineReason(''); setDeclineCustom('');
    showToast(res.ok ? 'تم الاعتذار عن الطلب بلطف' : (res.error || 'خطأ'), res.ok ? 'info' : 'error');
  };

  const onPay = async () => {
    if (!payModal || !pledge) { showToast('يرجى الموافقة على عهد الجدية', 'error'); return; }
    const res = await runAction(payModal.id, 'pay_deposit');
    setPayModal(null); setPledge(false);
    showToast(res.ok ? '✅ تم سداد رسوم الجدية بنجاح' : (res.error || 'خطأ'), res.ok ? 'success' : 'error');
  };

  const onRecordResult = async () => {
    if (!resultModal) return;
    const res = await runAction(resultModal.id, 'record_result', { result: resultChoice, note: resultNote });
    setResultModal(null); setResultNote('');
    showToast(res.ok ? 'تم تسجيل نتيجة التعارف' : (res.error || 'خطأ'), res.ok ? 'success' : 'error');
  };

  const onAdvanceIntro = async (req: ApiRequest) => {
    const res = await runAction(req.id, 'advance_viewing');
    setCoordModal(null);
    showToast(res.ok ? 'تم الانتقال للنظرة الشرعية' : (res.error || 'خطأ'), res.ok ? 'success' : 'error');
  };

  const onCancel = async () => {
    if (!cancelModal) return;
    const reason = cancelReason === CANCEL_REASONS[CANCEL_REASONS.length - 1] ? cancelCustom : cancelReason;
    if (!reason.trim()) { showToast('يرجى اختيار سبب الإلغاء', 'error'); return; }
    const res = await runAction(cancelModal.id, 'cancel', { reason });
    setCancelModal(null); setCancelReason(''); setCancelCustom('');
    showToast(res.ok ? 'تم إلغاء الطلب' : (res.error || 'خطأ'), res.ok ? 'info' : 'error');
  };

  const tabs: { key: Tab; label: string; icon: typeof Send; count: number }[] = [
    { key: 'active', label: 'الجارية', icon: Heart, count: buckets.active.length },
    { key: 'incoming', label: 'طلبات واردة', icon: Inbox, count: buckets.incoming.length },
    { key: 'archive', label: 'المنتهية', icon: Archive, count: buckets.archive.length },
  ];

  return (
    <div className="min-h-screen bg-cream-50" dir="rtl">
      {/* ترويسة */}
      <div className="bg-gradient-to-br from-navy-900 to-navy-800 text-white">
        <div className="max-w-3xl mx-auto px-4 py-8 sm:py-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 rounded-2xl bg-gold-gradient flex items-center justify-center text-navy-900">
              <Heart className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h1 className="font-cairo font-extrabold text-2xl">طلبات التعارف</h1>
              <p className="text-cream-200 text-sm font-cairo">
                {(() => {
                  const me = getMember(activeId);
                  return me
                    ? <>مرحباً <span className="text-gold-300 font-bold">{me.nickname}</span> — تابع رحلاتك هنا</>
                    : 'تابع جميع رحلات التعارف من الطلب حتى الزواج';
                })()}
              </p>
            </div>
          </div>

          {/* ===== لوحة ملخّص علوية (Stats Bar) ===== */}
          {!loading && (
            <div className="flex items-stretch gap-2 mt-5">
              <StatChip
                active={stats.respond > 0}
                value={stats.respond} label="تحتاج ردّك"
                icon={UserCheck} tone="gold"
                onClick={() => { setTab('active'); setSubFilter('all'); }}
              />
              <StatChip
                active={stats.pay > 0}
                value={stats.pay} label="تحتاج سداد"
                icon={CreditCard} tone="rose"
                onClick={() => { setTab('active'); setSubFilter('all'); }}
              />
              <StatChip
                active={false}
                value={stats.active} label="رحلات جارية"
                icon={Heart} tone="emerald"
                onClick={() => { setTab('active'); setSubFilter('all'); }}
              />
            </div>
          )}
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 -mt-5 pb-16">
        {/* خريطة الرحلة المرجعية */}
        <JourneyLegend />

        {/* التبويبات */}
        <div className="flex gap-2 bg-white rounded-2xl p-1.5 shadow-soft border border-cream-200 mt-4">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all
                  ${active ? 'bg-navy-900 text-white shadow-soft' : 'text-navy-500 hover:bg-cream-100'}`}
              >
                <Icon className="w-4 h-4" /> {t.label}
                {t.count > 0 && (
                  <span className={`px-1.5 rounded-md text-[11px] ${active ? 'bg-gold-500 text-navy-950 font-black' : 'bg-cream-200 text-navy-700'}`}>
                    {t.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* الفلترة الفرعية (chips) — تبويب النشطة فقط */}
        {tab === 'active' && buckets.active.length > 0 && (
          <div className="flex gap-2 mt-3">
            {([
              { key: 'all', label: 'الكل' },
              { key: 'sent', label: 'أرسلتها' },
              { key: 'received', label: 'وردتني' },
            ] as const).map((chip) => (
              <button
                key={chip.key}
                onClick={() => setSubFilter(chip.key)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-cairo font-bold transition-all
                  ${subFilter === chip.key ? 'bg-navy-900 text-white' : 'bg-white border border-cream-200 text-navy-500 hover:bg-cream-100'}`}
              >
                {chip.label}
              </button>
            ))}
          </div>
        )}

        {/* البحث */}
        <div className="relative mt-3">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-300" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم أو المدينة..."
            className="w-full bg-white border border-cream-200 rounded-2xl py-3 pr-10 pl-4 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-gold-200"
          />
        </div>

        {/* القائمة */}
        <div className="mt-4 space-y-4">
          {loading && (
            <div className="flex flex-col items-center py-16 text-navy-400">
              <Loader2 className="w-8 h-8 animate-spin mb-3" />
              <p className="font-cairo text-sm">جارٍ تحميل الطلبات...</p>
            </div>
          )}

          {!loading && error && (
            <div className="flex flex-col items-center py-12 text-center">
              <AlertCircle className="w-10 h-10 text-rose-400 mb-3" />
              <p className="font-cairo text-navy-700 font-bold mb-2">{error}</p>
              <button onClick={refresh} className="text-sm font-cairo font-bold text-gold-700 underline">إعادة المحاولة</button>
            </div>
          )}

          {!loading && !error && list.length === 0 && (
            <EmptyState tab={tab} />
          )}

          {!loading && !error && (
            <AnimatePresence mode="popLayout">
              {list.map((req) => (
                <RequestCard
                  key={req.id}
                  req={req}
                  getMember={getMember}
                  busy={actionLoading === req.id}
                  urgent={needsAction(req)}
                  unseen={isRequestUnseen(req.id, req.updated_at)}
                  onAccept={() => onAccept(req)}
                  onDecline={() => { setDeclineModal(req); setDeclineReason(''); }}
                  onPay={() => { setPayModal(req); setPledge(false); }}
                  onCoord={() => setCoordModal(req)}
                  onResult={() => { setResultModal(req); setResultChoice('success'); setResultNote(''); }}
                  onCancel={() => { setCancelModal(req); setCancelReason(''); setCancelCustom(''); }}
                />
              ))}
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* ===== بطاقة القبول الاحتفالية ===== */}
      <AcceptedCelebrationModal
        open={!!acceptModal}
        memberName={acceptModal?.name || ''}
        onClose={() => setAcceptModal(null)}
        onInquiry={() => {
          const r = acceptModal?.req;
          setAcceptModal(null);
          if (r) navigate(`/journey/${r.id}?tab=inquiry`);
        }}
        onOpenJourney={() => {
          const r = acceptModal?.req;
          setAcceptModal(null);
          if (r) navigate(`/journey/${r.id}`);
        }}
        onProceed={() => {
          const r = acceptModal?.req;
          setAcceptModal(null);
          if (r) navigate(`/journey/${r.id}?tab=deposit`);
        }}
      />

      {/* ===== مودال الاعتذار ===== */}
      <Modal open={!!declineModal} onClose={() => setDeclineModal(null)} title="الاعتذار عن الطلب">
        <p className="text-sm text-navy-600 font-cairo mb-4">الاعتذار حق مشروع. اختر السبب الأقرب — لن يظهر اسمك للطرف الآخر بشكل محرج.</p>
        <div className="space-y-2">
          {DECLINE_REASONS.map((reason) => (
            <label key={reason} className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all
              ${declineReason === reason ? 'border-rose-300 bg-rose-50' : 'border-cream-200 hover:bg-cream-50'}`}>
              <input type="radio" name="decline" checked={declineReason === reason} onChange={() => setDeclineReason(reason)} className="accent-rose-500" />
              <span className="text-sm font-cairo text-navy-700">{reason}</span>
            </label>
          ))}
        </div>
        {declineReason === DECLINE_REASONS[DECLINE_REASONS.length - 1] && (
          <textarea
            value={declineCustom} onChange={(e) => setDeclineCustom(e.target.value)}
            placeholder="اكتب التفاصيل..." rows={3}
            className="w-full mt-3 bg-white border border-cream-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-rose-200"
          />
        )}
        <button onClick={onDecline} disabled={actionLoading !== null}
          className="w-full mt-4 bg-rose-deep text-white font-cairo font-bold py-3.5 rounded-2xl hover:brightness-110 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
          {actionLoading !== null ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
          تأكيد الاعتذار
        </button>
      </Modal>

      {/* ===== مودال إلغاء الطلب (متاح في أي مرحلة) ===== */}
      <Modal open={!!cancelModal} onClose={() => setCancelModal(null)} title="إلغاء الطلب">
        <div className="flex items-start gap-2.5 bg-rose-50 border border-rose-100 rounded-2xl p-3 mb-4">
          <Ban className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-navy-600 font-cairo leading-relaxed">
            يمكنك إلغاء هذا الطلب في أي مرحلة. يرجى تحديد السبب لتحسين تجربة المنصة.
            <span className="block mt-1 font-bold text-rose-600">⚠️ ملاحظة: لا تُسترد رسوم تأكيد الجدية عند الإلغاء الاختياري (تُسترد فقط عند عدم التوافق بعد النظرة الشرعية).</span>
          </p>
        </div>
        <div className="space-y-2">
          {CANCEL_REASONS.map((reason) => (
            <label key={reason} className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all
              ${cancelReason === reason ? 'border-rose-300 bg-rose-50' : 'border-cream-200 hover:bg-cream-50'}`}>
              <input type="radio" name="cancel" checked={cancelReason === reason} onChange={() => setCancelReason(reason)} className="accent-rose-500" />
              <span className="text-sm font-cairo text-navy-700">{reason}</span>
            </label>
          ))}
        </div>
        {cancelReason === CANCEL_REASONS[CANCEL_REASONS.length - 1] && (
          <textarea
            value={cancelCustom} onChange={(e) => setCancelCustom(e.target.value)}
            placeholder="اكتب سبب الإلغاء..." rows={3}
            className="w-full mt-3 bg-white border border-cream-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-rose-200"
          />
        )}
        <div className="flex gap-2 mt-4">
          <button onClick={() => setCancelModal(null)}
            className="flex-1 bg-cream-100 text-navy-600 font-cairo font-bold py-3.5 rounded-2xl hover:bg-cream-200 transition-all">
            تراجع
          </button>
          <button onClick={onCancel} disabled={actionLoading !== null}
            className="flex-1 bg-rose-deep text-white font-cairo font-bold py-3.5 rounded-2xl hover:brightness-110 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
            {actionLoading !== null ? <Loader2 className="w-4 h-4 animate-spin" /> : <Ban className="w-4 h-4" />}
            تأكيد الإلغاء
          </button>
        </div>
      </Modal>

      {/* ===== مودال سداد رسوم الجدية ===== */}
      <Modal open={!!payModal} onClose={() => setPayModal(null)} title="تأكيد الجدية — سداد الرسوم">
        {payModal && (
          <div>
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4 text-center">
              <ShieldCheck className="w-8 h-8 text-amber-600 mx-auto mb-2" />
              <p className="font-cairo font-extrabold text-2xl text-amber-700">{DEPOSIT_AMOUNT} <span className="text-sm">ريال</span></p>
              <p className="text-xs text-navy-500 font-cairo mt-1">رسوم تأكيد الجدية — تُدفع مرة واحدة فقط</p>
              <p className="text-[10px] text-emerald-600 font-cairo mt-1 font-bold">✅ تُسترد بالكامل عند عدم التوافق بعد النظرة الشرعية</p>
            </div>
            <PayProgress req={payModal} />
            <label className="flex items-start gap-2.5 mt-4 p-3 rounded-xl bg-cream-50 border border-cream-200 cursor-pointer">
              <input type="checkbox" checked={pledge} onChange={(e) => setPledge(e.target.checked)} className="mt-0.5 accent-gold-500" />
              <span className="text-xs font-cairo text-navy-600 leading-relaxed">
                أتعهّد أمام الله بأن طلبي هذا بنية الزواج الحقيقي والجاد، وأوافق على شروط المنصة.
              </span>
            </label>
            <button onClick={onPay} disabled={!pledge || actionLoading !== null}
              className="w-full mt-4 bg-gold-gradient text-navy-900 font-cairo font-extrabold py-3.5 rounded-2xl shadow-gold hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:translate-y-0 flex items-center justify-center gap-2">
              {actionLoading !== null ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
              سداد رسوم الجدية
            </button>
          </div>
        )}
      </Modal>

      {/* ===== مودال التنسيق ===== */}
      <Modal open={!!coordModal} onClose={() => setCoordModal(null)} title="تنسيق التواصل">
        {coordModal && (
          <div className="space-y-3">
            {coordModal.meeting_date ? (
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-blue-700 mb-2">
                  <CalendarClock className="w-5 h-5" />
                  <span className="font-cairo font-bold text-sm">موعد التنسيق</span>
                </div>
                <p className="font-cairo text-navy-800 font-bold">{coordModal.meeting_date}</p>
                {coordModal.meeting_notes && <p className="text-xs text-navy-500 font-cairo mt-1">{coordModal.meeting_notes}</p>}
              </div>
            ) : (
              <div className="bg-cream-50 border border-cream-200 rounded-2xl p-4 text-center">
                <Loader2 className="w-6 h-6 text-blue-400 mx-auto mb-2 animate-spin" />
                <p className="text-sm font-cairo text-navy-600">الإدارة تنسّق الموعد حالياً. ستصلك التفاصيل قريباً.</p>
              </div>
            )}
            <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-3 text-xs font-cairo text-navy-600 leading-relaxed">
              <Info className="w-4 h-4 text-indigo-500 inline ml-1" />
              عند تأكيد الموعد وإتمام التعارف الأولي، انتقل لمرحلة تبادل القنوات الرسمية.
            </div>
            {stageOf(coordModal) === 'coordination' && coordModal.meeting_date && (
              <button onClick={() => onAdvanceIntro(coordModal)} disabled={actionLoading !== null}
                className="w-full bg-indigo-500 text-white font-cairo font-bold py-3.5 rounded-2xl hover:brightness-105 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
                {actionLoading !== null ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                المتابعة لمرحلة التعارف
              </button>
            )}
          </div>
        )}
      </Modal>

      {/* ===== مودال تسجيل النتيجة ===== */}
      <Modal open={!!resultModal} onClose={() => setResultModal(null)} title="تسجيل نتيجة التعارف">
        <div className="grid grid-cols-2 gap-3 mb-4">
          <button onClick={() => setResultChoice('success')}
            className={`p-4 rounded-2xl border-2 text-center transition-all ${resultChoice === 'success' ? 'border-emerald-400 bg-emerald-50' : 'border-cream-200'}`}>
            <span className="text-2xl block mb-1">💚</span>
            <span className="font-cairo font-bold text-sm text-emerald-700">توافق مبارك</span>
          </button>
          <button onClick={() => setResultChoice('failed')}
            className={`p-4 rounded-2xl border-2 text-center transition-all ${resultChoice === 'failed' ? 'border-slate-400 bg-slate-50' : 'border-cream-200'}`}>
            <span className="text-2xl block mb-1">🤝</span>
            <span className="font-cairo font-bold text-sm text-slate-600">لم يكتمل</span>
          </button>
        </div>
        <textarea value={resultNote} onChange={(e) => setResultNote(e.target.value)} rows={3} placeholder="ملاحظة (اختياري)..."
          className="w-full bg-white border border-cream-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-gold-200" />
        <button onClick={onRecordResult} disabled={actionLoading !== null}
          className="w-full mt-4 bg-navy-900 text-white font-cairo font-bold py-3.5 rounded-2xl hover:bg-navy-800 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
          {actionLoading !== null ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
          تسجيل النتيجة وإنهاء الرحلة
        </button>
      </Modal>

      {/* ===== Toast ===== */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }} animate={{ opacity: 1, y: 0, x: '-50%' }} exit={{ opacity: 0, y: 50, x: '-50%' }}
            className={`fixed bottom-6 left-1/2 z-[100] px-5 py-3 rounded-2xl shadow-2xl font-cairo font-bold text-sm text-white max-w-[90%]
              ${toast.type === 'success' ? 'bg-emerald-600' : toast.type === 'error' ? 'bg-rose-deep' : 'bg-navy-800'}`}
          >
            {toast.text}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ============================================================
//  بطاقة الطلب الواحدة
// ============================================================
function RequestCard({
  req, getMember, busy, urgent, unseen, onAccept, onDecline, onPay, onCoord, onResult, onCancel,
}: {
  req: ApiRequest;
  getMember: (id: string) => any;
  busy: boolean;
  urgent: boolean;
  unseen: boolean;
  onAccept: () => void;
  onDecline: () => void;
  onPay: () => void;
  onCoord: () => void;
  onResult: () => void;
  onCancel: () => void;
}) {
  const stage = stageOf(req);
  const isSender = req.sender_id === getCurrentUserId();
  const role: RequestRole = isSender ? 'sender' : 'receiver';
  const other = getMember(isSender ? req.receiver_id : req.sender_id);
  const colors = other ? getGenderColors(other.gender) : getGenderColors('male');
  const meta = STAGE_META[stage];

  const selfPaid = isSender ? req.sender_paid : req.receiver_paid;
  const otherPaid = isSender ? req.receiver_paid : req.sender_paid;
  const action = getPrimaryAction(stage, role, { selfPaid, otherPaid });
  const urgency = actionUrgency(stage, role, { selfPaid, otherPaid });

  const [showTimeline, setShowTimeline] = useState(false);
  const [events, setEvents] = useState<RequestEvent[]>([]);

  const loadTimeline = async () => {
    if (!showTimeline && events.length === 0) {
      setEvents(await fetchRequestEvents(req.id));
    }
    setShowTimeline((v) => !v);
  };

  if (!other) return null;

  const summary = getJourneyStatusSummary(req, getCurrentUserId(), other.nickname);

  // لون الشريط الجانبي حسب نوع الإجراء المطلوب
  const railColor = urgency === 'pay' ? 'bg-rose-400' : urgency === 'respond' ? 'bg-gold-gradient' : 'bg-blue-300';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }}
      className={`relative bg-white rounded-3xl border shadow-soft overflow-hidden transition-all
        ${urgent ? 'border-gold-300 ring-1 ring-gold-200/60' : 'border-cream-200'}`}
    >
      {/* شريط جانبي ملوّن للطلبات التي تتطلّب إجراءً */}
      {urgent && <div className={`absolute right-0 top-0 bottom-0 w-1.5 ${railColor}`} />}

      {/* شارة "يتطلّب إجراءك" النابضة */}
      {urgent && (
        <div className="absolute top-3 left-3 z-10">
          <motion.span
            animate={{ scale: [1, 1.06, 1] }}
            transition={{ duration: 1.8, repeat: Infinity }}
            className={`inline-flex items-center gap-1 text-[10px] font-cairo font-extrabold px-2.5 py-1 rounded-full text-white shadow-soft
              ${urgency === 'pay' ? 'bg-rose-500' : 'bg-gold-600'}`}
          >
            <Zap className="w-3 h-3" /> يتطلّب إجراءك
          </motion.span>
        </div>
      )}

      {/* رأس البطاقة */}
      <div className="p-4 flex items-start gap-3">
        <Link to={`/member/${other.id}`} className="flex-shrink-0 relative">
          <img src={getAvatar(other.gender)} alt={other.nickname}
            className={`w-14 h-14 rounded-2xl object-cover ring-2 ${colors.ring} ring-offset-2`} />
          {/* نقطة غير المقروء */}
          {unseen && (
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-rose-500 border-2 border-white" />
          )}
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <Link to={`/member/${other.id}`} className="font-cairo font-extrabold text-navy-900 hover:text-gold-700 transition-colors">
              {other.nickname}
            </Link>
            {other.verified && <BadgeCheck className="w-4 h-4 text-emerald-500" />}
            {unseen && <span className="text-[9px] font-cairo font-bold text-rose-500 bg-rose-50 px-1.5 py-0.5 rounded-full">جديد</span>}
            <span className="text-[11px] text-navy-400 font-cairo">· {other.age} سنة</span>
          </div>
          <div className="flex items-center gap-1 text-xs text-navy-400 font-cairo mt-0.5">
            <MapPin className="w-3 h-3" /> {other.city}، {other.country}
          </div>
          <span className={`inline-flex items-center gap-1 mt-1.5 text-[10px] font-cairo font-bold px-2 py-0.5 rounded-full ${ACCENT_CLASSES[meta.accent].bgSoft} ${ACCENT_CLASSES[meta.accent].text}`}>
            {isSender ? 'طلب أرسلته' : 'طلب وارد إليك'} · {meta.badge}
          </span>
          {req.frozen && (
            <span className="inline-flex items-center gap-1 mt-1.5 text-[10px] font-cairo font-bold px-2 py-0.5 rounded-full bg-sky-50 text-sky-600">
              <Clock className="w-3 h-3" /> بانتظار تنسيق الإدارة
            </span>
          )}
        </div>
      </div>

      {/* الرسالة */}
      {req.message && (
        <div className="px-4 pb-3">
          <p className="text-sm text-navy-600 font-cairo bg-cream-50 rounded-2xl p-3 leading-relaxed border border-cream-100">
            "{req.message}"
          </p>
        </div>
      )}

      <div className="px-4 pb-3">
        <RequestStatusPanel summary={summary} compact />
      </div>

      {/* خط الرحلة الموحّد */}
      <div className="px-4 pb-3">
        <JourneyTimeline
          stage={stage}
          isSender={isSender}
        />
      </div>

      {/* تفاصيل خاصة بالمرحلة */}
      {stage === 'declined' && req.decline_reason && (
        <div className="mx-4 mb-3 text-xs font-cairo text-rose-700 bg-rose-50 border border-rose-100 rounded-xl p-2.5">
          سبب الاعتذار: {req.decline_reason}
        </div>
      )}
      {stage === 'completed' && req.evaluation_note && (
        <div className="mx-4 mb-3 text-xs font-cairo text-emerald-700 bg-emerald-50 border border-emerald-100 rounded-xl p-2.5">
          {req.evaluation_result === 'failed' ? '🤝 ' : '💚 '}{req.evaluation_note}
        </div>
      )}
      {(stage === 'coordination' || stage === 'sharia_viewing' || stage === 'engagement') && req.meeting_date && (
        <div className="mx-4 mb-3 text-xs font-cairo text-blue-700 bg-blue-50 border border-blue-100 rounded-xl p-2.5 flex items-center gap-1.5">
          <CalendarClock className="w-4 h-4" /> {req.meeting_date}
        </div>
      )}
      {stage === 'seriousness' && (
        <div className="mx-4 mb-3 grid grid-cols-2 gap-2">
          <div className={`rounded-xl p-2.5 text-center border ${selfPaid ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'}`}>
            <p className="text-[10px] font-cairo text-navy-500">سدادك أنت</p>
            <p className={`text-xs font-cairo font-extrabold ${selfPaid ? 'text-emerald-600' : 'text-amber-700'}`}>{selfPaid ? 'تم السداد ✓' : 'بانتظارك'}</p>
          </div>
          <div className={`rounded-xl p-2.5 text-center border ${otherPaid ? 'bg-emerald-50 border-emerald-200' : 'bg-blue-50 border-blue-200'}`}>
            <p className="text-[10px] font-cairo text-navy-500">سداد الطرف الآخر</p>
            <p className={`text-xs font-cairo font-extrabold ${otherPaid ? 'text-emerald-600' : 'text-blue-700'}`}>{otherPaid ? 'تم السداد ✓' : 'بانتظار'}</p>
          </div>
        </div>
      )}

      {/* الإجراء الأساسي الوحيد */}
      <div className="px-4 pb-4 pt-1 border-t border-cream-100">
        <PrimaryActionBar
          stage={stage} action={action} busy={busy} requestId={req.id}
          onAccept={onAccept} onDecline={onDecline} onPay={onPay} onCoord={onCoord} onResult={onResult}
        />
        {/* فتح الرحلة الكاملة */}
        {!isTerminal(stage) && (
          <Link to={`/journey/${req.id}`}
            className={`${action.type === 'open_journey' ? 'mt-2 text-xs bg-cream-50 text-navy-500 hover:bg-cream-100' : 'mt-2 text-sm text-gold-700 bg-gold-300/10 hover:bg-gold-300/20'} w-full flex items-center justify-center gap-1.5 font-cairo font-bold rounded-2xl py-2.5 transition-colors`}>
            <Sparkles className="w-4 h-4" /> عرض الرحلة الكاملة
          </Link>
        )}
        {/* إلغاء الطلب — متاح في أي مرحلة نشطة (عدا الرد على طلب وارد) */}
        {!isTerminal(stage) && action.type !== 'accept_decline' && (
          <button onClick={onCancel} disabled={busy}
            className="mt-2 w-full flex items-center justify-center gap-1.5 text-[12px] font-cairo font-bold text-rose-500 hover:text-rose-600 hover:bg-rose-50 rounded-2xl py-2 transition-colors disabled:opacity-60">
            <Ban className="w-3.5 h-3.5" /> إلغاء الطلب
          </button>
        )}
        {/* سجل الأحداث */}
        <button onClick={loadTimeline}
          className="mt-2 w-full flex items-center justify-center gap-1 text-[11px] font-cairo font-bold text-navy-400 hover:text-navy-600 transition-colors py-1">
          {showTimeline ? 'إخفاء سجل الرحلة' : 'عرض سجل الرحلة'}
          <ChevronLeft className={`w-3.5 h-3.5 transition-transform ${showTimeline ? '-rotate-90' : ''}`} />
        </button>
        <AnimatePresence>
          {showTimeline && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="pt-2 space-y-2">
                {events.length === 0 && <p className="text-[11px] text-navy-400 font-cairo text-center py-2">لا توجد أحداث مسجّلة بعد</p>}
                {events.map((ev) => (
                  <div key={ev.id} className="flex items-start gap-2 text-xs font-cairo">
                    <span className="w-1.5 h-1.5 rounded-full bg-gold-400 mt-1.5 flex-shrink-0" />
                    <div>
                      <p className="text-navy-700">{ev.note}</p>
                      <p className="text-[10px] text-navy-300">{new Date(ev.created_at).toLocaleString('ar-SA')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// ============================================================
//  شريط الإجراء الأساسي — زر واحد بارز فقط
// ============================================================
function PrimaryActionBar({
  stage, action, busy, requestId, onAccept, onDecline, onPay, onCoord, onResult,
}: {
  stage: JourneyState; action: ReturnType<typeof getPrimaryAction>; busy: boolean; requestId: number;
  onAccept: () => void; onDecline: () => void; onPay: () => void; onCoord: () => void; onResult: () => void;
}) {
  if (action.type === 'open_journey') {
    return (
      <Link to={`/journey/${requestId}`}
        className="w-full bg-gold-gradient text-navy-900 font-cairo font-extrabold py-3.5 rounded-2xl shadow-soft hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">
        <Sparkles className="w-5 h-5" /> {action.label}
      </Link>
    );
  }

  if (action.type === 'accept_decline') {
    return (
      <div className="flex gap-2">
        <button onClick={onAccept} disabled={busy}
          className="flex-1 bg-emerald-500 text-white font-cairo font-bold py-3 rounded-2xl hover:bg-emerald-600 transition-all disabled:opacity-60 flex items-center justify-center gap-1.5">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Heart className="w-4 h-4" />} قبول
        </button>
        <button onClick={onDecline} disabled={busy}
          className="flex-1 bg-cream-100 text-navy-600 font-cairo font-bold py-3 rounded-2xl hover:bg-cream-200 transition-all disabled:opacity-60 flex items-center justify-center gap-1.5">
          <X className="w-4 h-4" /> اعتذار
        </button>
      </div>
    );
  }

  if (action.type === 'none') {
    return (
      <div className="text-center py-2.5 bg-cream-50 rounded-2xl border border-cream-100">
        <p className="text-sm font-cairo font-bold text-navy-500">{action.label}</p>
        <p className="text-[11px] font-cairo text-navy-400 mt-0.5">{action.hint}</p>
      </div>
    );
  }

  const handler = action.type === 'pay_deposit' ? onPay
    : action.type === 'view_coordination' ? onCoord
    : action.type === 'record_result' ? onResult : () => {};

  const accent = stage === 'seriousness' || stage === 'accepted' || stage === 'engagement' ? 'bg-gold-gradient text-navy-900'
    : stage === 'sharia_viewing' ? 'bg-indigo-500 text-white' : 'bg-blue-500 text-white';

  const Icon = action.type === 'pay_deposit' ? ShieldCheck : action.type === 'record_result' ? Heart : CalendarClock;

  return (
    <button onClick={handler} disabled={busy}
      className={`w-full ${accent} font-cairo font-extrabold py-3.5 rounded-2xl shadow-soft hover:-translate-y-0.5 transition-all disabled:opacity-60 disabled:translate-y-0 flex items-center justify-center gap-2`}>
      {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Icon className="w-5 h-5" />}
      {action.label}
    </button>
  );
}

// ============================================================
//  تقدّم السداد الثنائي داخل مودال الدفع
// ============================================================
function PayProgress({ req }: { req: ApiRequest }) {
  const items = [
    { label: 'سدادك أنت', paid: req.sender_id === getCurrentUserId() ? req.sender_paid : req.receiver_paid },
    { label: 'سداد الطرف الآخر', paid: req.sender_id === getCurrentUserId() ? req.receiver_paid : req.sender_paid },
  ];
  return (
    <div className="flex gap-2">
      {items.map((it) => (
        <div key={it.label} className={`flex-1 rounded-xl p-2.5 text-center border ${it.paid ? 'bg-emerald-50 border-emerald-200' : 'bg-cream-50 border-cream-200'}`}>
          <p className="text-[11px] font-cairo text-navy-500">{it.label}</p>
          <p className={`text-sm font-cairo font-bold ${it.paid ? 'text-emerald-600' : 'text-navy-400'}`}>
            {it.paid ? '✓ تم' : 'بانتظار'}
          </p>
        </div>
      ))}
    </div>
  );
}

// ============================================================
//  خريطة الرحلة المرجعية (Legend) — قابلة للطي
// ============================================================
function JourneyLegend() {
  const [open, setOpen] = useState(false);
  const stages: JourneyState[] = ['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed'];
  return (
    <div className="bg-white rounded-2xl border border-cream-200 shadow-soft overflow-hidden">
      <button onClick={() => setOpen((v) => !v)} className="w-full flex items-center justify-between px-4 py-3">
        <span className="flex items-center gap-2 font-cairo font-bold text-sm text-navy-700">
          <Info className="w-4 h-4 text-gold-600" /> كيف تعمل رحلة التعارف؟ (٧ خطوات)
        </span>
        <ChevronLeft className={`w-4 h-4 text-navy-400 transition-transform ${open ? '-rotate-90' : ''}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="px-4 pb-4 space-y-2">
              {stages.map((s, i) => {
                const m = STAGE_META[s];
                const c = ACCENT_CLASSES[m.accent];
                const Icon = m.icon;
                return (
                  <div key={s} className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-xl ${c.bg} flex items-center justify-center text-white flex-shrink-0`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <p className="font-cairo font-bold text-sm text-navy-800">{i + 1}. {m.title}</p>
                      <p className="text-xs text-navy-500 font-cairo leading-relaxed">{m.whereYouAre}</p>
                      <p className="text-[10px] text-gold-600 font-cairo font-bold mt-0.5">← {m.whatsNext}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ============================================================
//  شريحة إحصائية في اللوحة العلوية (Stats Bar)
// ============================================================
function StatChip({
  value, label, icon: Icon, tone, active, onClick,
}: {
  value: number; label: string; icon: typeof Heart; tone: 'gold' | 'rose' | 'emerald'; active: boolean; onClick: () => void;
}) {
  const tones = {
    gold: { ring: 'ring-gold-400/40', icon: 'text-gold-300', val: 'text-gold-300' },
    rose: { ring: 'ring-rose-400/40', icon: 'text-rose-300', val: 'text-rose-300' },
    emerald: { ring: 'ring-emerald-400/40', icon: 'text-emerald-300', val: 'text-emerald-300' },
  }[tone];
  return (
    <button
      onClick={onClick}
      className={`flex-1 bg-white/10 hover:bg-white/15 backdrop-blur rounded-2xl px-3 py-2.5 text-center transition-all
        ${active ? `ring-2 ${tones.ring}` : ''}`}
    >
      <div className="flex items-center justify-center gap-1.5">
        <Icon className={`w-4 h-4 ${tones.icon}`} />
        <span className={`font-cairo font-extrabold text-xl ${active ? tones.val : 'text-white'}`}>{value}</span>
      </div>
      <p className="text-[10px] font-cairo text-cream-200 mt-0.5">{label}</p>
    </button>
  );
}

// ============================================================
//  حالة فارغة محسّنة — نص مخصّص لكل تبويب
// ============================================================
function EmptyState({ tab }: { tab: Tab }) {
  const config = {
    active: {
      icon: Compass,
      title: 'لا توجد رحلات تعارف جارية بعد',
      desc: 'رحلتك تبدأ هنا! تصفّح الأعضاء وأرسل طلب تعارف لمن يناسبك، وستتابع رحلتك خطوة بخطوة حتى الزواج.',
      cta: '🔍 ابدأ البحث عن شريك حياتك', link: '/search',
    },
    incoming: {
      icon: Mail,
      title: 'لا توجد طلبات واردة حالياً',
      desc: 'كلما كان ملفك الشخصي مكتملاً وموثقاً، كلما زادت فرص وصول طلبات تعارف مناسبة لك.',
      cta: '✨ إكمال ملفي الشخصي', link: '/profile',
    },
    archive: {
      icon: Archive,
      title: 'لا توجد رحلات منتهية بعد',
      desc: 'ستظهر هنا الرحلات التي اكتملت بنجاح أو التي اعتُذر عنها. ابدأ رحلتك الأولى الآن!',
      cta: '🔍 تصفّح الأعضاء', link: '/search',
    },
  }[tab];
  const Icon = config.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center py-14 text-center px-6"
    >
      <div className="relative mb-5">
        <div className="w-24 h-24 rounded-[2rem] bg-gradient-to-br from-cream-100 to-cream-200 flex items-center justify-center">
          <Icon className="w-11 h-11 text-gold-500" />
        </div>
        <motion.span
          animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.7, 0.4] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="absolute -inset-2 rounded-[2.5rem] border-2 border-gold-300/40"
        />
      </div>
      <h3 className="font-cairo font-extrabold text-lg text-navy-800">{config.title}</h3>
      <p className="font-cairo text-sm text-navy-500 mt-1.5 max-w-xs leading-relaxed">{config.desc}</p>
      <Link
        to={config.link}
        className="mt-5 bg-gold-gradient text-navy-900 font-cairo font-extrabold px-6 py-3 rounded-2xl shadow-gold hover:-translate-y-0.5 transition-all"
      >
        {config.cta}
      </Link>
    </motion.div>
  );
}
