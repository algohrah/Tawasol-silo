import { type LocalNotification } from './localStore';
import { dataService } from './data/DataService';
const { getJourneyNotifications, getUnreadNotificationsCount, markAllNotificationsRead, markRequestNotificationsRead, deleteNotification, markNotificationRead } = dataService.api;



export type UnifiedNotification = LocalNotification & {
  href: string;
  title: string;
  isJourney: boolean;
};

export async function getUnifiedNotifications(userId: string): Promise<UnifiedNotification[]> {
  const items = await getJourneyNotifications(userId);
  return items.map((item) => ({
    ...item,
    href: item.request_id ? `/journey/${item.request_id}${item.type === 'inquiry' ? '?tab=inquiry' : ''}` : '/notifications',
    title: item.type === 'admin' ? 'رسالة من الإدارة' : 'تحديث في رحلة طلب اهتمام',
    isJourney: item.request_id > 0,
  }));
}

export async function getUnifiedUnreadCount(userId: string): Promise<number> {
  return getUnreadNotificationsCount(userId);
}

export function markUnifiedNotificationRead(id: number) {
  markNotificationRead(id);
}

export function markAllUnifiedNotificationsRead(userId: string) {
  markAllNotificationsRead(userId);
}

export function markRequestUnifiedNotificationsRead(requestId: number, userId: string) {
  markRequestNotificationsRead(requestId, userId);
}

export function deleteUnifiedNotification(id: number) {
  deleteNotification(id);
}
