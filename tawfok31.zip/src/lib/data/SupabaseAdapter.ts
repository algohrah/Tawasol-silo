import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { IRepository, IDatabaseAdapter, ISettingsRepository } from './interfaces';

// ============================================================
//  مستودع إعدادات مؤقت (in-memory) لـ Supabase
//  عند الإنتاج: يُستبدل بجدول key_value في Supabase
// ============================================================
class MemorySettingsRepository implements ISettingsRepository {
  private store = new Map<string, string>();
  get(key: string): string | null {
    return this.store.get(key) ?? null;
  }
  set(key: string, value: string): void {
    this.store.set(key, value);
  }
  remove(key: string): void {
    this.store.delete(key);
  }
}

export class SupabaseRepository<T extends { id: string | number }> implements IRepository<T> {
  private supabase: SupabaseClient;
  private tableName: string;

  constructor(supabaseClient: SupabaseClient, tableName: string) {
    this.supabase = supabaseClient;
    this.tableName = tableName;
  }

  async getAll(): Promise<T[]> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select('*');
    if (error) {
      console.error(`Error fetching from ${this.tableName}:`, error);
      throw error;
    }
    return data as T[];
  }

  async getById(id: string | number): Promise<T | null> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select('*')
      .eq('id', id)
      .single();
    if (error) {
      if (error.code === 'PGRST116') return null;
      console.error(`Error fetching ${this.tableName} id=${id}:`, error);
      throw error;
    }
    return data as T;
  }

  async create(item: T): Promise<T> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .insert(item as any)
      .select()
      .single();
    if (error) {
      console.error(`Error creating in ${this.tableName}:`, error);
      throw error;
    }
    return data as T;
  }

  async update(id: string | number, payload: Partial<T>): Promise<T> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .update(payload as any)
      .eq('id', id)
      .select()
      .single();
    if (error) {
      console.error(`Error updating ${this.tableName} id=${id}:`, error);
      throw error;
    }
    return data as T;
  }

  async delete(id: string | number): Promise<boolean> {
    const { error } = await this.supabase
      .from(this.tableName)
      .delete()
      .eq('id', id);
    if (error) {
      console.error(`Error deleting from ${this.tableName} id=${id}:`, error);
      return false;
    }
    return true;
  }
}

export class SupabaseAdapter implements IDatabaseAdapter {
  private supabase: SupabaseClient;

  public members: IRepository<any>;
  public requests: IRepository<any>;
  public transactions: IRepository<any>;
  public tickets: IRepository<any>;
  public adminUsers: IRepository<any>;
  public settings: ISettingsRepository;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);

    this.members = new SupabaseRepository<any>(this.supabase, 'members');
    this.requests = new SupabaseRepository<any>(this.supabase, 'requests');
    this.transactions = new SupabaseRepository<any>(this.supabase, 'transactions');
    this.tickets = new SupabaseRepository<any>(this.supabase, 'tickets');
    this.adminUsers = new SupabaseRepository<any>(this.supabase, 'admin_users');
    this.settings = new MemorySettingsRepository();
  }
}
