import { Client, Databases, ID } from 'appwrite';
import { IRepository, IDatabaseAdapter, ISettingsRepository } from './interfaces';

// ============================================================
//  مستودع إعدادات مؤقت (in-memory) لـ Appwrite
//  عند الإنتاج: يُستبدل بـ Appwrite collection للإعدادات
// ============================================================
class MemorySettingsRepository implements ISettingsRepository {
  private store = new Map<string, string>();
  get(key: string): string | null {
    return this.store.get(key) ?? null;
  }
  set(key: string, value: string): void {
    this.store.set(key, value);
  }
  remove(key: string): void {
    this.store.delete(key);
  }
}

export class AppwriteRepository<T extends { id: string | number }> implements IRepository<T> {
  private databases: Databases;
  private databaseId: string;
  private collectionId: string;

  constructor(databases: Databases, databaseId: string, collectionId: string) {
    this.databases = databases;
    this.databaseId = databaseId;
    this.collectionId = collectionId;
  }

  async getAll(): Promise<T[]> {
    try {
      const response = await this.databases.listDocuments(this.databaseId, this.collectionId);
      return response.documents as unknown as T[];
    } catch (error) {
      console.error(`Error fetching from Appwrite collection ${this.collectionId}:`, error);
      return [];
    }
  }

  async getById(id: string | number): Promise<T | null> {
    try {
      const response = await this.databases.getDocument(this.databaseId, this.collectionId, String(id));
      return response as unknown as T;
    } catch (error) {
      console.error(`Error fetching Appwrite doc id=${id}:`, error);
      return null;
    }
  }

  async create(item: T): Promise<T> {
    try {
      const { id, ...data } = item;
      const response = await this.databases.createDocument(
        this.databaseId,
        this.collectionId,
        String(id || ID.unique()),
        data
      );
      return response as unknown as T;
    } catch (error) {
      console.error(`Error creating Appwrite doc:`, error);
      throw error;
    }
  }

  async update(id: string | number, payload: Partial<T>): Promise<T> {
    try {
      const response = await this.databases.updateDocument(
        this.databaseId,
        this.collectionId,
        String(id),
        payload
      );
      return response as unknown as T;
    } catch (error) {
      console.error(`Error updating Appwrite doc id=${id}:`, error);
      throw error;
    }
  }

  async delete(id: string | number): Promise<boolean> {
    try {
      await this.databases.deleteDocument(this.databaseId, this.collectionId, String(id));
      return true;
    } catch (error) {
      console.error(`Error deleting Appwrite doc id=${id}:`, error);
      return false;
    }
  }
}

export class AppwriteAdapter implements IDatabaseAdapter {
  private client: Client;
  private databases: Databases;

  public members: IRepository<any>;
  public requests: IRepository<any>;
  public transactions: IRepository<any>;
  public tickets: IRepository<any>;
  public adminUsers: IRepository<any>;
  public settings: ISettingsRepository;

  constructor(endpoint: string, projectId: string, databaseId: string) {
    this.client = new Client()
      .setEndpoint(endpoint)
      .setProject(projectId);

    this.databases = new Databases(this.client);

    this.members = new AppwriteRepository<any>(this.databases, databaseId, 'members');
    this.requests = new AppwriteRepository<any>(this.databases, databaseId, 'requests');
    this.transactions = new AppwriteRepository<any>(this.databases, databaseId, 'transactions');
    this.tickets = new AppwriteRepository<any>(this.databases, databaseId, 'tickets');
    this.adminUsers = new AppwriteRepository<any>(this.databases, databaseId, 'admin_users');
    this.settings = new MemorySettingsRepository();
  }
}
