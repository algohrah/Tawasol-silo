// ============================================================
//  واجهات طبقة البيانات الموحّدة — Single Source Data Architecture
//  كل وصول للبيانات يمر عبر DataService → Adapter → Storage
// ============================================================

export interface IRepository<T> {
  getAll(): Promise<T[]>;
  getById(id: string | number): Promise<T | null>;
  create(item: T): Promise<T>;
  update(id: string | number, item: Partial<T>): Promise<T>;
  delete(id: string | number): Promise<boolean>;
}

/**
 * مستودع الإعدادات — مخزن key/value عام.
 * يُستخدم لجميع البيانات التي لا تحتاج جداول مستقلة (إعدادات، عدادات، حالات UI).
 * عند التحويل لقاعدة بيانات سحابية: يُستبدل بجدول settings (key, value) أو JSON column.
 */
export interface ISettingsRepository {
  get(key: string): string | null;
  set(key: string, value: string): void;
  remove(key: string): void;
}

export interface IDatabaseAdapter {
  members: IRepository<any>;
  requests: IRepository<any>;
  transactions: IRepository<any>;
  tickets: IRepository<any>;
  adminUsers: IRepository<any>;
  /** مستودع الإعدادات العام — المصدر الوحيد للتخزين key/value */
  settings: ISettingsRepository;
}
