import { IDatabaseAdapter } from './interfaces';
import { LocalStorageAdapter } from './LocalStorageAdapter';
import { SupabaseAdapter } from './SupabaseAdapter';
import { AppwriteAdapter } from './AppwriteAdapter';
import { DATABASE_CONFIG } from './LocalStorageAdapter';

import * as legacyLocalStore from '../localStore';
import * as legacyVerificationStore from '../verificationStore';
import * as legacyGeoStore from '../geoStore';

type LegacyApi = typeof legacyLocalStore & typeof legacyVerificationStore & typeof legacyGeoStore;

// ============================================================
//  DataService — نقطة الوصول الوحيدة لجميع عمليات البيانات
//  Singleton — لا يُنشأ إلا مرة واحدة خلال حياة التطبيق
// ============================================================
export class DataService {
  private static instance: DataService;

  /** الـ Adapter النشط — يحدده VITE_DATABASE_PROVIDER */
  public db: IDatabaseAdapter;

  /** واجهات الـ legacy — تُصدَّر للملفات التي لم تُحوَّل بعد (useAdminData.ts) */
  public api: LegacyApi;

  private constructor() {
    console.log(`[DataService] Initializing with provider: ${DATABASE_CONFIG.PROVIDER}`);

    // تجميع دوال الـ legacy للوصول الرجعي
    this.api = {
      ...legacyLocalStore,
      ...legacyVerificationStore,
      ...legacyGeoStore,
    };

    // اختيار الـ Adapter بناءً على الإعداد
    switch (DATABASE_CONFIG.PROVIDER) {
      case 'supabase': {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
        const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
        if (supabaseUrl && supabaseKey) {
          this.db = new SupabaseAdapter(supabaseUrl, supabaseKey);
        } else {
          console.warn('[DataService] Supabase credentials missing → falling back to LocalStorage');
          this.db = new LocalStorageAdapter();
        }
        break;
      }
      case 'appwrite': {
        const endpoint = import.meta.env.VITE_APPWRITE_ENDPOINT || '';
        const projectId = import.meta.env.VITE_APPWRITE_PROJECT_ID || '';
        const databaseId = import.meta.env.VITE_APPWRITE_DATABASE_ID || '';
        if (endpoint && projectId && databaseId) {
          this.db = new AppwriteAdapter(endpoint, projectId, databaseId);
        } else {
          console.warn('[DataService] Appwrite credentials missing → falling back to LocalStorage');
          this.db = new LocalStorageAdapter();
        }
        break;
      }
      case 'local':
      default:
        this.db = new LocalStorageAdapter();
        break;
    }
  }

  public static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }
}

export const dataService = DataService.getInstance();
