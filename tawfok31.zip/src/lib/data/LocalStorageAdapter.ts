import { IRepository, IDatabaseAdapter, ISettingsRepository } from './interfaces';

// ============================================================
//  LocalStorage Adapter — التخزين المحلي عبر المتصفح
//  هذا هو الملف الوحيد المسموح له بالوصول المباشر لـ window.localStorage
// ============================================================

export class LocalStorageRepository<T extends { id: string | number }> implements IRepository<T> {
  private storageKey: string;

  constructor(storageKey: string) {
    this.storageKey = storageKey;
  }

  private getItems(): T[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(this.storageKey);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  private saveItems(items: T[]): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(items));
    } catch (e) {
      console.error(`Error saving to localStorage [${this.storageKey}]:`, e);
    }
  }

  async getAll(): Promise<T[]> {
    return this.getItems();
  }

  async getById(id: string | number): Promise<T | null> {
    const items = this.getItems();
    const item = items.find((i) => i.id == id);
    return item || null;
  }

  async create(item: T): Promise<T> {
    const items = this.getItems();
    items.push(item);
    this.saveItems(items);
    return item;
  }

  async update(id: string | number, payload: Partial<T>): Promise<T> {
    const items = this.getItems();
    const index = items.findIndex((i) => i.id == id);
    if (index === -1) {
      throw new Error(`Item with id ${id} not found.`);
    }
    const updatedItem = { ...items[index], ...payload };
    items[index] = updatedItem;
    this.saveItems(items);
    return updatedItem;
  }

  async delete(id: string | number): Promise<boolean> {
    const items = this.getItems();
    const initialLength = items.length;
    const filteredItems = items.filter((i) => i.id != id);
    if (filteredItems.length === initialLength) {
      return false;
    }
    this.saveItems(filteredItems);
    return true;
  }
}

/**
 * مستودع الإعدادات عبر localStorage.
 * المنفذ الوحيد المسموح له بالقراءة/الكتابة المباشرة في localStorage.
 */
export class LocalStorageSettingsRepository implements ISettingsRepository {
  get(key: string): string | null {
    if (typeof window === 'undefined') return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  set(key: string, value: string): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.error(`Error setting localStorage key [${key}]:`, e);
    }
  }

  remove(key: string): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.removeItem(key);
    } catch {
      /* تجاهل */
    }
  }
}

export class LocalStorageAdapter implements IDatabaseAdapter {
  members = new LocalStorageRepository<any>('twafok_members');
  requests = new LocalStorageRepository<any>('twafok_requests');
  transactions = new LocalStorageRepository<any>('twafok_transactions');
  tickets = new LocalStorageRepository<any>('twafok_tickets');
  adminUsers = new LocalStorageRepository<any>('twafok_admin_users');
  settings = new LocalStorageSettingsRepository();
}

export type DatabaseProvider = 'local' | 'supabase' | 'appwrite';

export const DATABASE_CONFIG = {
  PROVIDER: (import.meta.env.VITE_DATABASE_PROVIDER || 'local') as DatabaseProvider,
};
