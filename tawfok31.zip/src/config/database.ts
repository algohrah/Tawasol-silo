export type DatabaseProvider = 'local' | 'supabase' | 'appwrite';

export const DATABASE_CONFIG = {
  // قم بتغيير هذا السطر للتحويل بين قواعد البيانات
  PROVIDER: (import.meta.env.VITE_DATABASE_PROVIDER || 'local') as DatabaseProvider,
};
