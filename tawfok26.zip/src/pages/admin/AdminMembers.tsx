import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Eye, Ban, CheckCircle2, Mail, Phone, Lock, MapPin,
  ShieldCheck, Crown, Download, Users, Loader2, AlertCircle,
  Fingerprint, Briefcase, GraduationCap, Flag, Send, StickyNote,
  BadgeCheck, UserCheck, UserX, Sparkles, Trash2, KeyRound, Copy, RefreshCw,
  LogIn, Upload, MoreHorizontal, FileSpreadsheet, TrendingUp,
  Building2, Calendar, Hash, FileDown, Table, UserPlus, Import,
  Edit, Save, AlertTriangle, ChevronRight, ChevronLeft, Award,
} from 'lucide-react';
import { useAdminMembers, type AdminMemberRow } from '../../lib/useAdminData';
import { useApp } from '../../lib/AppContext';
import { useNavigate } from 'react-router-dom';
import { getImportBatches } from '../../lib/importBatches';
import { adminGrantSeriousnessBadge, adminRevokeSeriousnessBadge, getLiveMembers } from '../../lib/localStore';
import Modal from '../../components/ui/Modal';
import FilterDropdown from '../../components/admin/FilterDropdown';
import ActionMenu from '../../components/admin/ActionMenu';

type PageSize = 10 | 20 | 50 | 100 | 999999;
const PAGE_SIZE_ALL = 999999;
const DEFAULT_PAGE_SIZE: PageSize = 100;

const PAGE_SIZE_OPTIONS: { value: PageSize; label: string }[] = [
  { value: 10, label: '10' },
  { value: 20, label: '20' },
  { value: 50, label: '50' },
  { value: 100, label: '100' },
  { value: PAGE_SIZE_ALL, label: 'الكل' },
];

const statusConfig: Record<string, { label: string; color: string; dot: string }> = {
  active: { label: 'نشط', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' },
  pending: { label: 'قيد المراجعة', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
  suspended: { label: 'موقوف', color: 'bg-orange-100 text-orange-700', dot: 'bg-orange-500' },
  banned: { label: 'محظور نهائياً', color: 'bg-rose-100 text-rose-700', dot: 'bg-rose-600' },
};
const planConfig: Record<string, { label: string; color: string }> = {
  free: { label: 'مجاني', color: 'bg-slate-100 text-slate-600' },
  gold: { label: 'ذهبي', color: 'bg-amber-100 text-amber-700' },
  elite: { label: 'نخبة', color: 'bg-purple-100 text-purple-700' },
};

export default function AdminMembers() {
  const {
    members, loading, error, updateMember, deleteMember, resetPassword,
    toggleVerified, setPremium, setNote, toggleFlag, notifyMember,
    bulkDelete, bulkUpdateStatus, bulkSetVerified, refresh,
  } = useAdminMembers();
  const { impersonateUser, importMembers, showToast } = useApp();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended' | 'pending' | 'banned'>('all');
  const [filterPlan, setFilterPlan] = useState<'all' | 'free' | 'gold' | 'elite'>('all');
  const [onlyFlagged, setOnlyFlagged] = useState(false);
  // ===== فلاتر الاستيراد =====
  const [filterSource, setFilterSource] = useState<'all' | 'registered' | 'imported'>('all');
  const [filterOffice, setFilterOffice] = useState<string>('all');
  const [filterBatch, setFilterBatch] = useState<string>('all');
  const [filterImportDate, setFilterImportDate] = useState<string>('all');
  const [filterCompleteness, setFilterCompleteness] = useState<'all' | 'complete' | 'incomplete'>('all');
  const [filterBadge, setFilterBadge] = useState<'all' | 'has' | 'none'>('all');
  
  // ===== حالات تعديل الملف من الإدارة =====
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Record<string, any>>({});
  const [activeEditTab, setActiveEditTab] = useState<'basic' | 'account' | 'partner'>('basic');

  const [selected, setSelected] = useState<AdminMemberRow | null>(null);
  const [revealSensitive, setRevealSensitive] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<PageSize>(DEFAULT_PAGE_SIZE);
  const [localToast, setLocalToast] = useState<string | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState('');

  const showLocalToast = (t: string) => {
    setLocalToast(t);
    setTimeout(() => setLocalToast(null), 2500);
  };

  const impersonateAndGo = (member: AdminMemberRow) => {
    impersonateUser({
      id: member.id,
      nickname: member.nickname,
      gender: member.gender,
      age: member.age,
      country: member.country,
      city: member.city,
      realName: member.realName,
      email: member.email,
      phone: member.phone,
      plan: member.plan,
      password: member.password,
    });
    showLocalToast(`جارٍ الدخول بحساب ${member.nickname}...`);
    setTimeout(() => navigate('/profile'), 400);
  };

  const selectedLive = useMemo(
    () => (selected ? members.find((m) => m.id === selected.id) || selected : null),
    [selected, members]
  );
  useEffect(() => {
    if (selectedLive) setNoteDraft(selectedLive.adminNote || '');
  }, [selectedLive?.id]);

  const [notifyFor, setNotifyFor] = useState<AdminMemberRow | null>(null);
  const [notifyText, setNotifyText] = useState('');
  const [noteDraft, setNoteDraft] = useState('');
  const [deleteFor, setDeleteFor] = useState<AdminMemberRow | null>(null);

  // ===== التحديد المتعدد والإجراءات الجماعية =====
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  // نافذة تأكيد الإجراء الجماعي: {action, label}
  const [bulkConfirm, setBulkConfirm] = useState<{ action: 'ban' | 'suspend' | 'activate' | 'verify' | 'delete'; label: string } | null>(null);
  const [bulkReason, setBulkReason] = useState('');
  const [bulkBusy, setBulkBusy] = useState(false);
  // نافذة تغيير حالة فردية بسبب (حظر/تجميد/إيقاف)
  const [statusFor, setStatusFor] = useState<{ member: AdminMemberRow; status: 'banned' | 'suspended' } | null>(null);
  const [statusReasonDraft, setStatusReasonDraft] = useState('');

  // ===== الخطابات والدفعات =====
  const offices = useMemo(() => {
    const officeSet = new Set<string>();
    members.forEach(m => { if (m.importOfficeName) officeSet.add(m.importOfficeName); });
    return Array.from(officeSet);
  }, [members]);
  
  const batches = useMemo(() => {
    const batchSet = new Set<string>();
    members.forEach(m => { if (m.importBatchId) batchSet.add(m.importBatchId); });
    return Array.from(batchSet);
  }, [members]);

  const allImportBatches = useMemo(() => {
    return getImportBatches();
  }, [members]);

  const batchMap = useMemo(() => {
    const map = new Map<string, string>();
    allImportBatches.forEach(b => {
      map.set(b.id, b.batchNumber);
    });
    return map;
  }, [allImportBatches]);

  const importDates = useMemo(() => {
    const datesSet = new Set<string>();
    members.forEach(m => {
      if (m.importDate) {
        const d = m.importDate.includes('T') ? m.importDate.split('T')[0] : m.importDate;
        datesSet.add(d);
      }
    });
    return Array.from(datesSet).sort((a, b) => b.localeCompare(a));
  }, [members]);

  const stats = useMemo(
    () => ({
      total: members.length,
      registered: members.filter((m) => !m.sourceType || m.sourceType === 'registered').length,
      imported: members.filter((m) => m.sourceType === 'imported').length,
      active: members.filter((m) => m.status === 'active').length,
      pending: members.filter((m) => m.status === 'pending').length,
      verified: members.filter((m) => m.verified).length,
      premium: members.filter((m) => m.premium).length,
      flagged: members.filter((m) => m.flagged).length,
    }),
    [members]
  );

  const filtered = useMemo(
    () =>
      members.filter((m) => {
        const matchSearch =
          !search ||
          m.nickname.includes(search) ||
          m.realName.includes(search) ||
          m.email.toLowerCase().includes(search.toLowerCase()) ||
          m.nationalId?.includes(search) ||
          m.phone?.includes(search);
        const matchStatus = filterStatus === 'all' || m.status === filterStatus;
        const matchPlan = filterPlan === 'all' || m.plan === filterPlan;
        const matchFlag = !onlyFlagged || m.flagged;
        // فلاتر الاستيراد
        const matchSource = filterSource === 'all' || 
          (filterSource === 'registered' && (!m.sourceType || m.sourceType === 'registered')) ||
          (filterSource === 'imported' && m.sourceType === 'imported');
        const matchOffice = filterOffice === 'all' || m.importOfficeName === filterOffice;
        const matchBatch = filterBatch === 'all' || m.importBatchId === filterBatch;
        const matchImportDate = filterImportDate === 'all' || 
          (m.importDate && (m.importDate.startsWith(filterImportDate) || m.importDate === filterImportDate));
        
        // فلتر اكتمال الملف الشخصي
        const matchCompleteness = filterCompleteness === 'all' || 
          (filterCompleteness === 'complete' && !m.isProfileIncomplete) ||
          (filterCompleteness === 'incomplete' && m.isProfileIncomplete);
        // فلتر وسام الجدية
        const memberLive = getLiveMembers(true).find((lm) => lm.id === m.id);
        const hasBadge = !!(memberLive?.hasSeriousnessBadge || (m as any).hasSeriousnessBadge);
        const matchBadge = filterBadge === 'all' ||
          (filterBadge === 'has' && hasBadge) ||
          (filterBadge === 'none' && !hasBadge);

        return matchSearch && matchStatus && matchPlan && matchFlag && matchSource && matchOffice && matchBatch && matchImportDate && matchCompleteness && matchBadge;
      }),
    [members, search, filterStatus, filterPlan, onlyFlagged, filterSource, filterOffice, filterBatch, filterImportDate, filterCompleteness]
  );

  const effectivePageSize = pageSize === PAGE_SIZE_ALL ? filtered.length : pageSize;
  const totalPages = Math.ceil(filtered.length / effectivePageSize) || 1;
  const paginated = pageSize === PAGE_SIZE_ALL ? filtered : filtered.slice((page - 1) * pageSize, page * pageSize);
  const showingFrom = filtered.length === 0 ? 0 : (page - 1) * effectivePageSize + 1;
  const showingTo = Math.min(page * effectivePageSize, filtered.length);

  useEffect(() => {
    setPage(1);
  }, [search, filterStatus, filterPlan, onlyFlagged, filterSource, filterOffice, filterBatch, filterImportDate, filterCompleteness, filterBadge, pageSize]);

  // ===== منطق التحديد المتعدد =====
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };
  // هل كل الصفحة المعروضة محدّدة؟
  const allPageSelected = paginated.length > 0 && paginated.every((m) => selectedIds.has(m.id));
  // هل كل النتائج المفلترة محدّدة؟
  const allFilteredSelected = filtered.length > 0 && filtered.every((m) => selectedIds.has(m.id));
  // هل توجد نتائج خارج الصفحة الحالية غير محدّدة؟
  const hasMoreBeyondPage = filtered.length > paginated.length && filtered.some((m) => !selectedIds.has(m.id));

  // تحديد/إلغاء تحديد الصفحة المعروضة فقط
  const toggleSelectPage = () => {
    setSelectedIds((prev) => {
      if (allPageSelected) {
        const next = new Set(prev);
        paginated.forEach((m) => next.delete(m.id));
        return next;
      }
      const next = new Set(prev);
      paginated.forEach((m) => next.add(m.id));
      return next;
    });
  };
  // تحديد/إلغاء تحديد كل النتائج المفلترة
  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      if (allFilteredSelected) {
        const next = new Set(prev);
        filtered.forEach((m) => next.delete(m.id));
        return next;
      }
      const next = new Set(prev);
      filtered.forEach((m) => next.add(m.id));
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());
  const selectedCount = selectedIds.size;

  // تنفيذ الإجراء الجماعي بعد التأكيد
  const runBulk = async () => {
    if (!bulkConfirm) return;
    const ids = Array.from(selectedIds);
    if (ids.length === 0) { setBulkConfirm(null); return; }
    setBulkBusy(true);
    let ok = false;
    const needsReason = bulkConfirm.action === 'ban' || bulkConfirm.action === 'suspend';
    const reason = needsReason ? bulkReason.trim() : '';
    switch (bulkConfirm.action) {
      case 'ban': ok = await bulkUpdateStatus(ids, 'banned', reason); break;
      case 'suspend': ok = await bulkUpdateStatus(ids, 'suspended', reason); break;
      case 'activate': ok = await bulkUpdateStatus(ids, 'active'); break;
      case 'verify': ok = await bulkSetVerified(ids, true); break;
      case 'delete': ok = await bulkDelete(ids); break;
    }
    setBulkBusy(false);
    if (ok) {
      showLocalToast(`تم تطبيق "${bulkConfirm.label}" على ${ids.length} عضو ✓`);
      clearSelection();
    } else {
      showToast('تعذّر تنفيذ الإجراء', 'error');
    }
    setBulkConfirm(null);
    setBulkReason('');
  };

  // تغيير حالة فردية بسبب
  const applyStatusChange = async () => {
    if (!statusFor) return;
    const ok = await updateMember(statusFor.member.id, { status: statusFor.status, statusReason: statusReasonDraft.trim() });
    if (ok) showLocalToast(`تم تحديث حالة ${statusFor.member.nickname} ✓`);
    setStatusFor(null);
    setStatusReasonDraft('');
  };

  const handleExport = () => {
    const headers = [
      'المعرّف', 'الاسم المستعار', 'الاسم الحقيقي', 'البريد', 'الهاتف',
      'الهوية', 'الجنس', 'العمر', 'المدينة', 'الباقة', 'الحالة', 'موثق', 'تاريخ الانضمام'
    ];
    const rows = filtered.map((m) => [
      m.id, m.nickname, m.realName, m.email, m.phone, m.nationalId, m.gender === 'male' ? 'ذكر' : 'أنثى',
      m.age, m.city, m.plan, m.status, m.verified ? 'نعم' : 'لا', m.joinedAt,
    ]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `members-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showLocalToast(`تم تصدير ${filtered.length} عضو ✓`);
  };

  const handleImport = () => {
    try {
      const parsed = JSON.parse(importText);
      if (!Array.isArray(parsed)) {
        showToast('البيانات المدخلة غير صالحة', 'error');
        return;
      }
      const valid = parsed.filter((m) => m.nickname && m.email && m.gender);
      if (valid.length === 0) {
        showToast('لم يتم العثور على أعضاء صالحين للاستيراد', 'error');
        return;
      }
      importMembers(valid);
      setImportOpen(false);
      setImportText('');
      showToast(`تم استيراد ${valid.length} عضو بنجاح`, 'success');
    } catch {
      showToast('حدث خطأ أثناء الاستيراد. تأكد من صحة تنسيق JSON.', 'error');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-9 h-9 animate-spin mb-3" />
        <p className="font-cairo text-sm">جارٍ تحميل الأعضاء...</p>
      </div>
    );
  }
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <AlertCircle className="w-10 h-10 text-rose-400 mb-3" />
        <p className="font-cairo text-slate-700 font-bold">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-500" /> إدارة الأعضاء
          </h2>
          <p className="text-sm text-slate-500 font-tajawal">تحكم كامل في حسابات الأعضاء وحالاتهم</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/admin/import-members')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-semibold text-sm hover:bg-emerald-200 transition-colors"
          >
            <Upload className="w-4 h-4" /> استيراد أعضاء
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors"
          >
            <Download className="w-4 h-4" /> تصدير ({filtered.length})
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-8 gap-3">
        {[
          { label: 'الإجمالي', value: stats.total, icon: Users, color: 'text-slate-700', bg: 'bg-slate-50', onClick: () => { setFilterStatus('all'); setOnlyFlagged(false); setFilterSource('all'); } },
          { label: 'مسجلون', value: stats.registered, icon: UserPlus, color: 'text-blue-600', bg: 'bg-blue-50', onClick: () => setFilterSource('registered') },
          { label: 'مستوردون', value: stats.imported, icon: Import, color: 'text-purple-600', bg: 'bg-purple-50', onClick: () => setFilterSource('imported') },
          { label: 'نشط', value: stats.active, icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-50', onClick: () => setFilterStatus('active') },
          { label: 'قيد المراجعة', value: stats.pending, icon: Loader2, color: 'text-amber-600', bg: 'bg-amber-50', onClick: () => setFilterStatus('pending') },
          { label: 'موثق', value: stats.verified, icon: BadgeCheck, color: 'text-blue-600', bg: 'bg-blue-50', onClick: () => {} },
          { label: 'مميّز', value: stats.premium, icon: Crown, color: 'text-purple-600', bg: 'bg-purple-50', onClick: () => setFilterPlan('gold') },
          { label: 'معلّم', value: stats.flagged, icon: Flag, color: 'text-rose-600', bg: 'bg-rose-50', onClick: () => setOnlyFlagged(true) },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <button
              key={s.label}
              onClick={s.onClick}
              className={`${s.bg} rounded-2xl p-3 text-right border border-transparent hover:border-slate-200 transition-all`}
            >
              <Icon className={`w-5 h-5 ${s.color} mb-1`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم المستعار أو الحقيقي أو البريد أو الهاتف أو الهوية..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <FilterDropdown
            label="الحالة:"
            value={filterStatus}
            onChange={(v) => setFilterStatus(v as typeof filterStatus)}
            options={(['all', 'active', 'pending', 'suspended', 'banned'] as const).map((s) => ({
              value: s,
              label: s === 'all' ? 'كل الحالات' : statusConfig[s].label,
            }))}
          />
          <FilterDropdown
            label="الباقة:"
            value={filterPlan}
            onChange={(v) => setFilterPlan(v as typeof filterPlan)}
            options={(['all', 'free', 'gold', 'elite'] as const).map((p) => ({
              value: p,
              label: p === 'all' ? 'كل الباقات' : planConfig[p].label,
            }))}
          />
          <FilterDropdown
            label="النوع:"
            value={filterSource}
            onChange={(v) => setFilterSource(v as typeof filterSource)}
            options={[
              { value: 'all', label: 'كل الأعضاء' },
              { value: 'registered', label: 'مسجلون' },
              { value: 'imported', label: 'مستوردون' },
            ]}
          />
          <FilterDropdown
            label="اكتمال الملف:"
            value={filterCompleteness}
            onChange={(v) => setFilterCompleteness(v as any)}
            options={[
              { value: 'all', label: 'كل مستويات الاكتمال' },
              { value: 'complete', label: 'الملفات المكتملة' },
              { value: 'incomplete', label: 'الملفات غير المكتملة' },
            ]}
          />
          <FilterDropdown
            label="الوسام:"
            value={filterBadge}
            onChange={(v) => setFilterBadge(v as any)}
            options={[
              { value: 'all', label: 'كل الأعضاء' },
              { value: 'has', label: 'حاصل على الوسام' },
              { value: 'none', label: 'بدون وسام' },
            ]}
          />
          {offices.length > 0 && (
            <FilterDropdown
              label="الخطابة:"
              value={filterOffice}
              onChange={(v) => setFilterOffice(v)}
              options={[
                { value: 'all', label: 'كل الخطابات' },
                ...offices.map(o => ({ value: o, label: o })),
              ]}
            />
          )}
          {batches.length > 0 && (
            <FilterDropdown
              label="الدفعة:"
              value={filterBatch}
              onChange={(v) => setFilterBatch(v)}
              options={[
                { value: 'all', label: 'كل الدفعات' },
                ...batches.map(bId => ({ value: bId, label: batchMap.get(bId) || bId })),
              ]}
            />
          )}
          {importDates.length > 0 && (
            <FilterDropdown
              label="تاريخ الاستيراد:"
              value={filterImportDate}
              onChange={(v) => setFilterImportDate(v)}
              options={[
                { value: 'all', label: 'كل التواريخ' },
                ...importDates.map(d => ({ value: d, label: d })),
              ]}
            />
          )}
          <button
            onClick={() => setOnlyFlagged((v) => !v)}
            className={`px-3.5 py-2.5 rounded-xl text-sm font-cairo font-bold transition-colors flex items-center gap-1.5 border ${
              onlyFlagged ? 'bg-rose-500 text-white border-rose-500' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Flag className="w-4 h-4" /> المعلّمون فقط
          </button>
          {(filterSource !== 'all' || filterOffice !== 'all' || filterBatch !== 'all' || filterImportDate !== 'all' || filterCompleteness !== 'all') && (
            <button
              onClick={() => { setFilterSource('all'); setFilterOffice('all'); setFilterBatch('all'); setFilterImportDate('all'); setFilterCompleteness('all'); }}
              className="px-3.5 py-2.5 rounded-xl text-sm font-cairo font-bold bg-slate-200 text-slate-700 hover:bg-slate-300 transition-colors"
            >
              إعادة تعيين الفلاتر
            </button>
          )}
        </div>
      </div>

      {/* شريط الإجراءات الجماعية (يظهر عند تحديد عضو أو أكثر) */}
      <AnimatePresence>
        {selectedCount > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="sticky top-2 z-30 bg-navy-900 text-white rounded-2xl shadow-xl border border-navy-800 px-4 py-3 flex flex-wrap items-center gap-2"
          >
            <span className="font-cairo font-bold text-sm flex items-center gap-2">
              <span className="w-7 h-7 rounded-full bg-amber-400 text-navy-900 flex items-center justify-center text-xs font-black">{selectedCount}</span>
              عضو محدّد
            </span>
            <div className="h-5 w-px bg-white/20 mx-1" />
            <div className="flex flex-wrap gap-1.5 mr-auto">
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'verify', label: 'توثيق الأعضاء' }); }}
                className="px-3 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <BadgeCheck className="w-3.5 h-3.5" /> توثيق
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'activate', label: 'تفعيل الأعضاء' }); }}
                className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <CheckCircle2 className="w-3.5 h-3.5" /> تفعيل
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'suspend', label: 'إيقاف' }); }}
                className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <Ban className="w-3.5 h-3.5" /> إيقاف
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'ban', label: 'حظر نهائي' }); }}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <UserX className="w-3.5 h-3.5" /> حظر نهائي
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'delete', label: 'حذف نهائي' }); }}
                className="px-3 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <Trash2 className="w-3.5 h-3.5" /> حذف نهائي
              </button>
              <button onClick={clearSelection}
                className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-cairo font-bold transition-colors">
                إلغاء التحديد
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop table */}
      <div className="hidden lg:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-4 py-3 w-10">
                <input
                  type="checkbox"
                  checked={allPageSelected}
                  onChange={toggleSelectPage}
                  className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  title="تحديد الصفحة المعروضة"
                />
              </th>
              {['العضو', 'البريد', 'الباقة', 'الحالة', 'إجراءات'].map((h) => (
                <th key={h} className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {paginated.map((m) => (
              <tr key={m.id} className={`hover:bg-slate-50 transition-colors ${selectedIds.has(m.id) ? 'bg-amber-50/50' : m.flagged ? 'bg-rose-50/40' : ''}`}>
                <td className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.has(m.id)}
                    onChange={() => toggleSelect(m.id)}
                    className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  />
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`relative w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                        m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                      }`}
                    >
                      {m.nickname.charAt(0)}
                      {m.flagged && <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-white" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</span>
                        {m.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
                        {m.plan === 'elite' && <Crown className="w-3.5 h-3.5 text-purple-500" />}
                        {m.premium && m.plan !== 'elite' && <Crown className="w-3.5 h-3.5 text-amber-500" />}
                        {m.isProfileIncomplete && (
                          <span className="px-1.5 py-0.5 text-[9px] font-cairo font-bold bg-amber-100 text-amber-800 rounded select-none">غير مكتمل</span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-tajawal">
                        {m.realName} · {m.age} سنة · {m.city}
                      </span>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-xs text-slate-600 font-tajawal">{m.email}</td>
                <td className="px-5 py-3">
                  <span className={`px-2 py-1 rounded-md text-[11px] font-cairo font-bold ${planConfig[m.plan].color}`}>
                    {planConfig[m.plan].label}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-cairo font-bold ${statusConfig[m.status].color}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${statusConfig[m.status].dot}`} />
                    {statusConfig[m.status].label}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-1">
                    <ActionMenu
                      items={[
                        {
                          label: 'عرض التفاصيل',
                          icon: <Eye className="w-4 h-4" />,
                          onClick: () => { setSelected(m); setRevealSensitive(false); },
                        },
                        {
                          label: 'الدخول بحساب العضو',
                          icon: <LogIn className="w-4 h-4" />,
                          variant: 'primary',
                          onClick: () => impersonateAndGo(m),
                        },
                        {
                          label: m.verified ? 'إلغاء التوثيق' : 'توثيق العضو',
                          icon: <BadgeCheck className="w-4 h-4" />,
                          onClick: async () => {
                            await toggleVerified(m.id, !m.verified);
                            showLocalToast(m.verified ? 'تم إلغاء التوثيق' : 'تم التوثيق ✓');
                          },
                        },
                        {
                          label: m.premium ? 'إلغاء التميّز' : 'ترقية لمميّز',
                          icon: <Crown className="w-4 h-4" />,
                          onClick: async () => {
                            await setPremium(m.id, !m.premium);
                            showLocalToast(m.premium ? 'تم إلغاء التميّز' : 'تمت الترقية لمميّز 👑');
                          },
                        },
                        {
                          label: 'منح وسام الجدية',
                          icon: <Award className="w-4 h-4" />,
                          variant: 'success',
                          hidden: (() => {
                            const lm = getLiveMembers(true).find((x) => x.id === m.id);
                            return !!(lm?.hasSeriousnessBadge || (m as any).hasSeriousnessBadge);
                          })(),
                          onClick: () => {
                            adminGrantSeriousnessBadge(m.id);
                            showLocalToast('تم منح وسام الجدية يدوياً ✓');
                            refresh();
                          },
                        },
                        {
                          label: 'إزالة وسام الجدية',
                          icon: <Award className="w-4 h-4" />,
                          variant: 'danger',
                          hidden: (() => {
                            const lm = getLiveMembers(true).find((x) => x.id === m.id);
                            return !(lm?.hasSeriousnessBadge || (m as any).hasSeriousnessBadge);
                          })(),
                          onClick: () => {
                            adminRevokeSeriousnessBadge(m.id);
                            showLocalToast('تم إزالة وسام الجدية');
                            refresh();
                          },
                        },
                        {
                          label: 'تفعيل الحساب',
                          icon: <CheckCircle2 className="w-4 h-4" />,
                          variant: 'success',
                          hidden: m.status === 'active',
                          onClick: async () => {
                            await updateMember(m.id, { status: 'active' });
                            showLocalToast('تم تفعيل العضو ✓');
                          },
                        },
                        {
                          label: 'إيقاف العضو',
                          icon: <Ban className="w-4 h-4" />,
                          hidden: m.status === 'suspended',
                          onClick: () => { setStatusFor({ member: m, status: 'suspended' }); setStatusReasonDraft(m.statusReason || ''); },
                        },
                        {
                          label: 'حظر نهائي',
                          icon: <UserX className="w-4 h-4" />,
                          variant: 'danger',
                          hidden: m.status === 'banned',
                          onClick: () => { setStatusFor({ member: m, status: 'banned' }); setStatusReasonDraft(m.statusReason || ''); },
                        },
                        {
                          label: m.flagged ? 'إزالة التعليم' : 'تعليم العضو',
                          icon: <Flag className="w-4 h-4" />,
                          onClick: async () => {
                            await toggleFlag(m.id, !m.flagged);
                            showLocalToast(m.flagged ? 'أُزيل التعليم' : 'تم تعليم العضو');
                          },
                        },
                        {
                          label: 'إرسال إشعار',
                          icon: <Send className="w-4 h-4" />,
                          onClick: () => { setNotifyFor(m); setNotifyText(''); },
                        },
                        {
                          label: 'حذف الحساب',
                          icon: <Trash2 className="w-4 h-4" />,
                          variant: 'danger',
                          divider: true,
                          onClick: () => setDeleteFor(m),
                        },
                      ]}
                    />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="text-center py-10 text-slate-400 font-cairo text-sm">لا يوجد أعضاء مطابقون</p>}
      </div>

      {/* شريط التحديد الذكي — يظهر عند تحديد صفحة كاملة ويوفر خيار تحديد الكل */}
      <AnimatePresence>
        {allPageSelected && hasMoreBeyondPage && !allFilteredSelected && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="bg-blue-50 border border-blue-200 rounded-2xl px-4 py-2.5 flex items-center justify-between gap-2"
          >
            <span className="text-xs font-cairo text-blue-800">
              تم تحديد {paginated.length} عضو من الصفحة الحالية.
            </span>
            <button
              onClick={toggleSelectAll}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-cairo font-bold transition-colors"
            >
              تحديد كل النتائج ({filtered.length})
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile cards */}
      <div className="lg:hidden space-y-3">
        {paginated.map((m) => (
          <div key={m.id} className={`bg-white rounded-2xl p-4 shadow-sm border ${selectedIds.has(m.id) ? 'border-amber-300 ring-1 ring-amber-200' : m.flagged ? 'border-rose-200' : 'border-slate-200'}`}>
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={selectedIds.has(m.id)}
                onChange={() => toggleSelect(m.id)}
                className="w-4 h-4 rounded accent-amber-500 cursor-pointer flex-shrink-0"
              />
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center text-white font-bold ${
                  m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                }`}
              >
                {m.nickname.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</span>
                  {m.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
                  {m.premium && <Crown className="w-3.5 h-3.5 text-amber-500" />}
                  {m.isProfileIncomplete && (
                    <span className="px-1.5 py-0.5 text-[9px] font-cairo font-bold bg-amber-100 text-amber-800 rounded select-none">غير مكتمل</span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400 font-tajawal">
                  {m.realName} · {m.city}
                </span>
              </div>
              <span className={`px-2 py-1 rounded-md text-[10px] font-cairo font-bold ${statusConfig[m.status].color}`}>
                {statusConfig[m.status].label}
              </span>
            </div>
            {/* أزرار إجراءات واضحة على الجوال */}
            <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
              <button
                onClick={() => { setSelected(m); setRevealSensitive(false); }}
                className="flex-shrink-0 px-3 py-2 rounded-xl bg-slate-100 text-slate-700 font-cairo font-bold text-xs flex items-center gap-1"
              >
                <Eye className="w-3.5 h-3.5" /> عرض
              </button>
              <button
                onClick={() => impersonateAndGo(m)}
                className="flex-shrink-0 px-3 py-2 rounded-xl bg-amber-100 text-amber-700 font-cairo font-bold text-xs flex items-center gap-1"
              >
                <LogIn className="w-3.5 h-3.5" /> دخول
              </button>
              <button
                onClick={async () => {
                  await toggleVerified(m.id, !m.verified);
                  showLocalToast(m.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓');
                }}
                className={`flex-shrink-0 px-3 py-2 rounded-xl font-cairo font-bold text-xs flex items-center gap-1 ${
                  m.verified ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500'
                }`}
              >
                <BadgeCheck className="w-3.5 h-3.5" /> {m.verified ? 'موثق' : 'توثيق'}
              </button>
              <button
                onClick={async () => {
                  await setPremium(m.id, !m.premium);
                  showLocalToast(m.premium ? 'أُلغي التميّز' : 'ترقية 👑');
                }}
                className={`flex-shrink-0 px-3 py-2 rounded-xl font-cairo font-bold text-xs flex items-center gap-1 ${
                  m.premium ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <Crown className="w-3.5 h-3.5" /> {m.premium ? 'مميّز' : 'ترقية'}
              </button>
              {m.status !== 'active' ? (
                <button
                  onClick={async () => {
                    await updateMember(m.id, { status: 'active' });
                    showLocalToast('تم التفعيل ✓');
                  }}
                  className="flex-shrink-0 px-3 py-2 rounded-xl bg-emerald-100 text-emerald-600 font-cairo font-bold text-xs flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> تفعيل
                </button>
              ) : (
                <button
                  onClick={() => { setStatusFor({ member: m, status: 'suspended' }); setStatusReasonDraft(m.statusReason || ''); }}
                  className="flex-shrink-0 px-3 py-2 rounded-xl bg-orange-100 text-orange-600 font-cairo font-bold text-xs flex items-center gap-1"
                >
                  <Ban className="w-3.5 h-3.5" /> إيقاف
                </button>
              )}
              <button
                onClick={() => { setStatusFor({ member: m, status: 'banned' }); setStatusReasonDraft(m.statusReason || ''); }}
                className="flex-shrink-0 px-3 py-2 rounded-xl bg-rose-100 text-rose-600 font-cairo font-bold text-xs flex items-center gap-1"
              >
                <UserX className="w-3.5 h-3.5" /> حظر
              </button>
              <button
                onClick={() => setDeleteFor(m)}
                className="flex-shrink-0 px-3 py-2 rounded-xl bg-white border border-rose-200 text-rose-500 font-cairo font-bold text-xs flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" /> حذف
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* شريط التحكم السفلي: عدّاد + حجم الصفحة + ترقيم */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white rounded-2xl border border-slate-200 px-4 py-3 shadow-sm">
        {/* عدّاد النتائج */}
        <div className="flex items-center gap-2 text-xs font-cairo text-slate-500">
          {selectedCount > 0 ? (
            <span className="flex items-center gap-1.5">
              <span className="w-6 h-6 rounded-full bg-amber-400 text-navy-900 flex items-center justify-center text-[10px] font-black">{selectedCount}</span>
              محدّد من {filtered.length}
            </span>
          ) : (
            <span>عرض <strong className="text-slate-700">{showingFrom}–{showingTo}</strong> من <strong className="text-slate-700">{filtered.length}</strong></span>
          )}
        </div>

        {/* حجم الصفحة */}
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-cairo text-slate-400">عرض:</span>
          {PAGE_SIZE_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setPageSize(opt.value)}
              className={`px-2.5 py-1 rounded-lg text-xs font-cairo font-bold transition-colors ${
                pageSize === opt.value ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* الترقيم */}
        {totalPages > 1 && (
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center disabled:opacity-40 hover:bg-slate-200 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              let p: number;
              if (totalPages <= 7) {
                p = i + 1;
              } else if (page <= 4) {
                p = i + 1;
              } else if (page >= totalPages - 3) {
                p = totalPages - 6 + i;
              } else {
                p = page - 3 + i;
              }
              return (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`w-8 h-8 rounded-lg font-cairo font-bold text-xs transition-colors ${
                    page === p ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {p}
                </button>
              );
            })}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center disabled:opacity-40 hover:bg-slate-200 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Detail modal */}
      <Modal open={!!selectedLive} onClose={() => { setSelected(null); setIsEditing(false); }} title={isEditing ? `تعديل بيانات: ${selectedLive?.nickname}` : "ملف العضو"} size="lg">
        {selectedLive && (
          isEditing ? (
            <div className="space-y-4 font-cairo">
              {/* Warning banner if incomplete */}
              {editForm.isProfileIncomplete && (
                <div className="bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-xl flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5 animate-pulse" />
                  <div>
                    <p className="font-bold text-xs">ملف شخصي غير مكتمل</p>
                    <p className="text-[11px] font-tajawal text-amber-700 leading-relaxed">هذا العضو مستورد ومصنف "غير مكتمل" لغياب بعض البيانات الإلزامية. املأ الحقول الفارغة لحفظ ملفه كملف كامل ليظهر للبحث العام.</p>
                  </div>
                </div>
              )}

              {/* Tabs */}
              <div className="flex border-b border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveEditTab('basic')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all ${
                    activeEditTab === 'basic' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  البيانات الشخصية والأساسية
                </button>
                <button
                  type="button"
                  onClick={() => setActiveEditTab('partner')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all ${
                    activeEditTab === 'partner' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  مواصفات الشريك المطلوبة
                </button>
                <button
                  type="button"
                  onClick={() => setActiveEditTab('account')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all ${
                    activeEditTab === 'account' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  بيانات الحساب والاتصال
                </button>
              </div>

              {activeEditTab === 'basic' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto px-1 py-1">
                  {/* Nickname & Real Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الاسم المستعار (اللقب) <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.nickname || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, nickname: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.nickname ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="مثال: الواثق بالله"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الاسم الحقيقي <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.realName || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, realName: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.realName ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="الاسم الثلاثي للتثبت الإداري"
                    />
                  </div>

                  {/* Gender & BirthDate */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الجنس <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.gender || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, gender: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.gender ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر --</option>
                      <option value="male">ذكر</option>
                      <option value="female">أنثى</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ الميلاد <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.birthDate || ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        const year = parseInt(val.split('-')[0] || val.split('/')[0] || '');
                        const calculatedAge = year && !isNaN(year) ? (new Date().getFullYear() - year) : editForm.age;
                        setEditForm(prev => ({ ...prev, birthDate: val, age: calculatedAge || prev.age }));
                      }}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.birthDate ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="مثال: 1994-05-12"
                    />
                  </div>

                  {/* Age & Nationality */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">العمر (سنوات) <span className="text-red-500">*</span></label>
                    <input
                      type="number"
                      value={editForm.age || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, age: Number(e.target.value) }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.age ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      min="18"
                      max="90"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الجنسية</label>
                    <input
                      type="text"
                      value={editForm.nationality || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, nationality: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثال: سعودي"
                    />
                  </div>

                  {/* Country & City */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">بلد الإقامة <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.country || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, country: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.country ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="مثال: السعودية"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المدينة <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.city || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, city: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.city ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="مثال: الرياض"
                    />
                  </div>

                  {/* District & Sect */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحي / المنطقة</label>
                    <input
                      type="text"
                      value={editForm.district || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, district: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثال: الملقا"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المذهب</label>
                    <input
                      type="text"
                      value={editForm.sect || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, sect: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثال: سني"
                    />
                  </div>

                  {/* Marital Status & Children */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحالة الاجتماعية <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.maritalStatus || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, maritalStatus: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.maritalStatus ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر --</option>
                      <option value="single">أعزب / عزباء</option>
                      <option value="divorced">مطلق / مطلقة</option>
                      <option value="widow">أرمل / أرملة</option>
                      <option value="widower">أرمل / أرملة</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">عدد الأبناء</label>
                    <input
                      type="text"
                      value={editForm.childrenCount || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, childrenCount: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثال: لا يوجد أو ٢"
                    />
                  </div>

                  {/* Height & Weight */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الطول (سم) <span className="text-red-500">*</span></label>
                    <input
                      type="number"
                      value={editForm.height || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, height: Number(e.target.value) }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.height ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="170"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الوزن (كجم) <span className="text-red-500">*</span></label>
                    <input
                      type="number"
                      value={editForm.weight || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, weight: Number(e.target.value) }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.weight ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="70"
                    />
                  </div>

                  {/* Skin Color & Education */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">لون البشرة <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.skinColor || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, skinColor: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.skinColor ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="أبيض، حنطي، أسمر..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المستوى التعليمي <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.education || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, education: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.education ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="بكالوريوس، ماجستير، ثانوية..."
                    />
                  </div>

                  {/* Work Type & Housing */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">نوع العمل / الوظيفة <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.workType || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, workType: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.workType ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="قطاع حكومي، خاص، أعمال حرة..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">طبيعة السكن <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.housing || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, housing: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.housing ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="ملك، إيجار، مع العائلة..."
                    />
                  </div>

                  {/* Bio & About Partner */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">نبذة عن العضو (تحدث عن نفسك)</label>
                    <textarea
                      value={editForm.bio || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 h-16 resize-none"
                      placeholder="اكتب بضعة أسطر عن شخصيتك واهتماماتك..."
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">شروط ومواصفات الشريك المطلوبة</label>
                    <textarea
                      value={editForm.aboutPartner || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, aboutPartner: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 h-16 resize-none"
                      placeholder="اكتب مواصفات شريك الحياة المطلوب..."
                    />
                  </div>

                  {/* Incompleteness Override Checkbox */}
                  <div className="sm:col-span-2 bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl flex items-center justify-between mt-2">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-xs text-amber-900">حالة غير مكتملة</p>
                        <p className="text-[10px] text-amber-700 font-tajawal leading-relaxed">عند تفعيل هذا الخيار، سيتم اعتبار الملف غير مكتمل وسيُحجب من العرض العام للأعضاء.</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={!!editForm.isProfileIncomplete}
                      onChange={(e) => setEditForm(prev => ({ ...prev, isProfileIncomplete: e.target.checked }))}
                      className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                    />
                  </div>
                </div>
              ) : activeEditTab === 'account' ? (
                <div className="space-y-3.5 max-h-[50vh] overflow-y-auto px-1 py-1">
                  {/* Phone & Whatsapp */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">رقم الهاتف الجوال <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={editForm.phone || ''}
                        onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.phone ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        placeholder="مثال: 0500000000"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">رقم الواتساب</label>
                      <input
                        type="text"
                        value={editForm.whatsapp || ''}
                        onChange={(e) => setEditForm(prev => ({ ...prev, whatsapp: e.target.value }))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                        placeholder="مثال: +966500000000"
                        dir="ltr"
                      />
                    </div>
                  </div>

                  {/* Email & Password */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">البريد الإلكتروني <span className="text-red-500">*</span></label>
                      <input
                        type="email"
                        value={editForm.email || ''}
                        onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.email ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        placeholder="member@email.com"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">كلمة المرور <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={editForm.password || ''}
                        onChange={(e) => setEditForm(prev => ({ ...prev, password: e.target.value }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.password ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        placeholder="Pass@1234"
                        dir="ltr"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto px-1 py-1">
                  {/* مواصفات الشريك المطلوبة */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">بلد إقامة الشريك</label>
                    <input
                      type="text"
                      value={editForm.pCountry || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pCountry: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: السعودية أو لا يهم"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">مدينة إقامة الشريك</label>
                    <input
                      type="text"
                      value={editForm.pCity || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pCity: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: الرياض أو لا يهم"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">جنسية الشريك</label>
                    <input
                      type="text"
                      value={editForm.pNationality || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pNationality: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: سعودي أو لا يهم"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">مذهب الشريك</label>
                    <input
                      type="text"
                      value={editForm.pSect || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pSect: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: سني أو لا يهم"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">الحد الأدنى لعمر الشريك</label>
                    <input
                      type="number"
                      value={editForm.pAgeMin || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pAgeMin: Number(e.target.value) || '' }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="18"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">الحد الأقصى لعمر الشريك</label>
                    <input
                      type="number"
                      value={editForm.pAgeMax || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pAgeMax: Number(e.target.value) || '' }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="60"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">الحالة الاجتماعية للشريك</label>
                    <select
                      value={editForm.pMaritalStatus || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pMaritalStatus: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                    >
                      <option value="">-- اختر --</option>
                      <option value="لا يهم">لا يهم</option>
                      <option value="أعزب / عزباء">أعزب / عزباء</option>
                      <option value="مطلق / مطلقة">مطلق / مطلقة</option>
                      <option value="أرمل / أرملة">أرمل / أرملة</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">قبول أطفال لدى الشريك</label>
                    <select
                      value={editForm.pAcceptChildren || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pAcceptChildren: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                    >
                      <option value="">-- اختر --</option>
                      <option value="لا يهم">لا يهم</option>
                      <option value="نعم">نعم</option>
                      <option value="لا">لا</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">اللتزام الديني للشريك</label>
                    <input
                      type="text"
                      value={editForm.pReligionLevel || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pReligionLevel: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: ملتزم، متوسط الالتزام، لا يهم..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">المستوى التعليمي للشريك</label>
                    <input
                      type="text"
                      value={editForm.pEducation || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pEducation: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: بكالوريوس فما فوق أو لا يهم..."
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">الطول المفضل للشريك</label>
                    <input
                      type="text"
                      value={editForm.pHeight || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pHeight: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: فوق 160 سم أو لا يهم..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">لون بشرة الشريك المفضل</label>
                    <input
                      type="text"
                      value={editForm.pSkinColor || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pSkinColor: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: أبيض، حنطي، لا يهم..."
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">الحالة الوظيفية للشريك</label>
                    <input
                      type="text"
                      value={editForm.pWorkType || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pWorkType: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: موظف، عمل حر، لا يهم..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">السكن المفضل للشريك</label>
                    <input
                      type="text"
                      value={editForm.pHousing || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pHousing: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      placeholder="مثال: سكن مستقل أو لا يهم..."
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">تفاصيل وملاحظات إضافية عن الشريك المطلوبة</label>
                    <textarea
                      value={editForm.pNotes || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, pNotes: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 h-20 resize-none font-tajawal"
                      placeholder="مثال: يفضل سكن مستقل بالرياض، لديه قدرة على تحمل المسؤولية..."
                    />
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={async () => {
                    const updatedIncomplete = 
                      !editForm.gender || 
                      !editForm.nickname || 
                      !editForm.birthDate || 
                      !editForm.country || 
                      !editForm.city || 
                      !editForm.maritalStatus || 
                      !editForm.height || 
                      !editForm.weight || 
                      !editForm.skinColor || 
                      !editForm.education || 
                      !editForm.workType || 
                      !editForm.housing || 
                      !editForm.realName || 
                      !editForm.phone;

                    const fieldsToSave = {
                      ...editForm,
                      isProfileIncomplete: editForm.isProfileIncomplete !== undefined ? editForm.isProfileIncomplete : updatedIncomplete,
                    } as any;

                    const ok = await updateMember(selectedLive.id, fieldsToSave);
                    if (ok) {
                      showLocalToast('تم تحديث بيانات ملف العضو بنجاح ✓');
                      setIsEditing(false);
                      setSelected(prev => prev ? { ...prev, ...fieldsToSave } : null);
                    } else {
                      showLocalToast('حدث خطأ أثناء حفظ التغييرات');
                    }
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-cairo font-bold text-sm transition-colors flex items-center justify-center gap-1.5"
                >
                  <Save className="w-4 h-4" /> حفظ التغييرات
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-cairo font-bold text-sm transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-2xl ${
                    selectedLive.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                  }`}
                >
                  {selectedLive.nickname.charAt(0)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 justify-between">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-cairo font-extrabold text-lg text-slate-900">{selectedLive.nickname}</h3>
                      {selectedLive.verified && <BadgeCheck className="w-5 h-5 text-blue-500" />}
                      {selectedLive.premium && <Crown className="w-5 h-5 text-amber-500" />}
                      {selectedLive.isProfileIncomplete && (
                        <span className="px-2 py-0.5 text-[10px] font-cairo font-bold bg-amber-100 text-amber-800 rounded select-none">غير مكتمل</span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        setEditForm({ ...selectedLive });
                        setIsEditing(true);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 text-white font-cairo font-bold text-xs hover:bg-amber-600 transition-all flex items-center gap-1"
                    >
                      <Edit className="w-3.5 h-3.5" /> تعديل البيانات
                    </button>
                  </div>
                <p className="text-sm text-slate-500 font-tajawal">
                  {selectedLive.age} سنة · {selectedLive.city}، {selectedLive.country}
                </p>
                <div className="flex gap-1.5 mt-1">
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${statusConfig[selectedLive.status].color}`}>
                    {statusConfig[selectedLive.status].label}
                  </span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${planConfig[selectedLive.plan].color}`}>
                    {planConfig[selectedLive.plan].label}
                  </span>
                  {selectedLive.flagged && (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold bg-rose-100 text-rose-700 flex items-center gap-0.5">
                      <Flag className="w-3 h-3" /> معلّم
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* بانر سبب تقييد الحساب (حظر/تجميد/إيقاف) */}
            {selectedLive.status !== 'active' && selectedLive.status !== 'pending' && (
              <div className={`rounded-xl p-3 border ${
                selectedLive.status === 'banned' ? 'bg-rose-50 border-rose-200' : 'bg-orange-50 border-orange-200'
              }`}>
                <div className="flex items-center gap-1.5 mb-1">
                  {selectedLive.status === 'banned' ? <UserX className="w-4 h-4 text-rose-600" /> :
                   <Ban className="w-4 h-4 text-orange-600" />}
                  <span className="text-xs font-cairo font-bold text-slate-800">
                    الحساب {statusConfig[selectedLive.status].label}
                  </span>
                </div>
                {selectedLive.statusReason && (
                  <p className="text-xs text-slate-600 font-tajawal leading-relaxed">السبب: {selectedLive.statusReason}</p>
                )}
                {selectedLive.statusChangedAt && (
                  <p className="text-[10px] text-slate-400 font-tajawal mt-1">
                    بواسطة {selectedLive.statusChangedBy || 'الإدارة'} · {new Date(selectedLive.statusChangedAt).toLocaleString('ar-SA')}
                  </p>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: Briefcase, label: 'العمل', value: selectedLive.workType },
                { icon: GraduationCap, label: 'التعليم', value: selectedLive.education },
                { icon: MapPin, label: 'الحي', value: selectedLive.district },
                { icon: TrendingUp, label: 'عدد الطلبات', value: String(selectedLive.requestsCount) },
              ].map((f) => {
                const Icon = f.icon;
                return (
                  <div key={f.label} className="bg-slate-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                      <Icon className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-cairo">{f.label}</span>
                    </div>
                    <p className="font-cairo font-bold text-sm text-slate-800">{f.value || '—'}</p>
                  </div>
                );
              })}
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-xs font-cairo font-bold text-rose-700">
                  <Lock className="w-4 h-4" /> بيانات حساسة — للإدارة فقط
                </span>
                <button
                  onClick={() => setRevealSensitive((v) => !v)}
                  className="text-[11px] font-cairo font-bold text-rose-700 bg-white px-2.5 py-1 rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors flex items-center gap-1"
                >
                  <Eye className="w-3 h-3" />
                  {revealSensitive ? 'إخفاء' : 'كشف الكل'}
                </button>
              </div>
              <div className="space-y-1.5">
                {[
                  { icon: Fingerprint, label: 'الاسم الحقيقي', value: selectedLive.realName, sensitive: true },
                  { icon: Mail, label: 'البريد', value: selectedLive.email, sensitive: true },
                  { icon: Phone, label: 'الهاتف', value: selectedLive.phone, sensitive: true },
                  { icon: Fingerprint, label: 'الهوية', value: selectedLive.nationalId, sensitive: true },
                  { icon: KeyRound, label: 'كلمة المرور', value: selectedLive.password, sensitive: true, mono: true },
                ].map((f) => {
                  const Icon = f.icon;
                  return (
                    <div key={f.label} className="flex items-center gap-2 text-sm bg-white/60 rounded-lg px-2 py-1.5">
                      <Icon className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      <span className="text-slate-500 font-cairo text-xs w-24 flex-shrink-0">{f.label}:</span>
                      <span
                        className={`text-slate-800 flex-1 truncate ${f.mono ? 'font-mono' : 'font-tajawal'}`}
                        dir="ltr"
                      >
                        {revealSensitive ? f.value : '•••••••••'}
                      </span>
                      {revealSensitive && (
                        <button
                          onClick={() => {
                            navigator.clipboard?.writeText(f.value);
                            showLocalToast('تم نسخ ' + f.label + ' ✓');
                          }}
                          className="text-slate-400 hover:text-slate-700 flex-shrink-0"
                          title="نسخ"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
              {revealSensitive && (
                <button
                  onClick={async () => {
                    const pw = await resetPassword(selectedLive.id);
                    if (pw) showLocalToast('كلمة المرور الجديدة: ' + pw);
                  }}
                  className="w-full mt-2 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white border border-rose-200 text-rose-600 font-cairo font-bold text-xs hover:bg-rose-100 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> إعادة تعيين كلمة المرور
                </button>
              )}
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-cairo font-bold text-slate-600 mb-1">
                <StickyNote className="w-4 h-4" /> ملاحظة إدارية خاصة
              </label>
              <div className="flex gap-2">
                <input
                  value={noteDraft}
                  onChange={(e) => setNoteDraft(e.target.value)}
                  placeholder="اكتب ملاحظة..."
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm"
                />
                <button
                  onClick={async () => {
                    await setNote(selectedLive.id, noteDraft);
                    showLocalToast('حُفظت الملاحظة ✓');
                  }}
                  className="px-4 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm"
                >
                  حفظ
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={async () => {
                  await toggleVerified(selectedLive.id, !selectedLive.verified);
                  showLocalToast(selectedLive.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓');
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${
                  selectedLive.verified ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <BadgeCheck className="w-4 h-4" /> {selectedLive.verified ? 'موثق' : 'توثيق'}
              </button>
              <button
                onClick={async () => {
                  await setPremium(selectedLive.id, !selectedLive.premium);
                  showLocalToast(selectedLive.premium ? 'أُلغي التميّز' : 'ترقية مميّز 👑');
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${
                  selectedLive.premium ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Crown className="w-4 h-4" /> {selectedLive.premium ? 'مميّز' : 'ترقية'}
              </button>
              {selectedLive.status !== 'active' ? (
                <button
                  onClick={async () => {
                    await updateMember(selectedLive.id, { status: 'active' });
                    showLocalToast('تم التفعيل ✓');
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-bold text-sm"
                >
                  <UserCheck className="w-4 h-4" /> تفعيل
                </button>
              ) : (
                <button
                  onClick={async () => {
                    await updateMember(selectedLive.id, { status: 'suspended' });
                    showLocalToast('تم الإيقاف');
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-rose-100 text-rose-700 font-cairo font-bold text-sm"
                >
                  <UserX className="w-4 h-4" /> إيقاف
                </button>
              )}
              <button
                onClick={async () => {
                  await toggleFlag(selectedLive.id, !selectedLive.flagged);
                  showLocalToast(selectedLive.flagged ? 'أُزيل التعليم' : 'تم التعليم');
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${
                  selectedLive.flagged ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Flag className="w-4 h-4" /> {selectedLive.flagged ? 'معلّم' : 'تعليم'}
              </button>
            </div>

            <button
              onClick={() => { setNotifyFor(selectedLive); setNotifyText(''); }}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:brightness-105"
            >
              <Send className="w-4 h-4 -scale-x-100" /> إرسال إشعار للعضو
            </button>

            <button
              onClick={() => impersonateAndGo(selectedLive)}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-l from-slate-900 to-slate-800 text-amber-300 font-cairo font-bold text-sm hover:brightness-110 transition-all border border-amber-500/30"
            >
              <LogIn className="w-4 h-4" /> الدخول بحساب العضو
            </button>

            <button
              onClick={() => setDeleteFor(selectedLive)}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-white border-2 border-rose-200 text-rose-600 font-cairo font-bold text-sm hover:bg-rose-50 transition-colors"
            >
              <Trash2 className="w-4 h-4" /> حذف الحساب نهائياً
            </button>
          </div>
        )
      )}
    </Modal>

      {/* Delete confirmation */}
      <Modal open={!!deleteFor} onClose={() => setDeleteFor(null)} title="حذف الحساب نهائياً">
        {deleteFor && (
          <div className="text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-7 h-7 text-rose-500" />
            </div>
            <p className="font-cairo font-bold text-slate-800 mb-1">حذف حساب «{deleteFor.nickname}»؟</p>
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 mb-4 mt-2 text-right">
              <p className="text-xs font-cairo text-rose-700 leading-relaxed">
                ⚠️ <strong>الحذف النهائي</strong> يزيل الحساب تماماً من لوحة الإدارة <strong>و</strong> من الموقع العام (البحث وصفحة الملف). لا يمكن التراجع.
              </p>
              <p className="text-[11px] font-cairo text-slate-500 mt-1.5">
                إذا كنت تريد إبقاء الحساب في النظام مع منع وصوله، استخدم «حظر نهائي» بدلاً من ذلك.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setDeleteFor(null)}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={async () => {
                  await deleteMember(deleteFor.id);
                  setDeleteFor(null);
                  setSelected(null);
                  showLocalToast('تم حذف الحساب نهائياً من الإدارة والموقع');
                }}
                className="flex-1 py-3 rounded-xl bg-rose-deep text-white font-cairo font-bold text-sm hover:brightness-110 transition-all"
              >
                تأكيد الحذف النهائي
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* نافذة تأكيد الإجراء الجماعي */}
      <Modal open={!!bulkConfirm} onClose={() => { if (!bulkBusy) { setBulkConfirm(null); setBulkReason(''); } }} title="تأكيد إجراء جماعي">
        {bulkConfirm && (
          <div className="text-center" dir="rtl">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 ${
              bulkConfirm.action === 'delete' || bulkConfirm.action === 'ban' ? 'bg-rose-100' : 'bg-amber-100'
            }`}>
              {bulkConfirm.action === 'delete' ? <Trash2 className="w-7 h-7 text-rose-600" /> :
               bulkConfirm.action === 'ban' ? <UserX className="w-7 h-7 text-rose-600" /> :
               bulkConfirm.action === 'verify' ? <BadgeCheck className="w-7 h-7 text-blue-600" /> :
               <CheckCircle2 className="w-7 h-7 text-emerald-600" />}
            </div>
            <p className="font-cairo font-bold text-slate-800 mb-1">
              تطبيق «{bulkConfirm.label}» على <span className="text-amber-600">{selectedCount}</span> عضو؟
            </p>
            <p className="text-sm text-slate-500 font-tajawal mb-4">
              {bulkConfirm.action === 'delete'
                ? 'سيُحذف هؤلاء الأعضاء نهائياً ولا يمكن التراجع عن هذا الإجراء.'
                : 'سيتم تطبيق الإجراء على جميع الأعضاء المحددين دفعة واحدة.'}
            </p>
            {(bulkConfirm.action === 'ban' || bulkConfirm.action === 'suspend') && (
              <textarea
                value={bulkReason}
                onChange={(e) => setBulkReason(e.target.value)}
                rows={2}
                placeholder="سبب الإجراء (اختياري — يظهر في ملف العضو)..."
                className="w-full mb-4 px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm text-right"
              />
            )}
            <div className="flex gap-2">
              <button
                onClick={() => { if (!bulkBusy) { setBulkConfirm(null); setBulkReason(''); } }}
                disabled={bulkBusy}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                onClick={runBulk}
                disabled={bulkBusy}
                className={`flex-1 py-3 rounded-xl text-white font-cairo font-bold text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2 ${
                  bulkConfirm.action === 'delete' || bulkConfirm.action === 'ban' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-navy-900 hover:bg-navy-800'
                }`}
              >
                {bulkBusy && <Loader2 className="w-4 h-4 animate-spin" />}
                {bulkBusy ? 'جارٍ التنفيذ...' : 'تأكيد'}
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* نافذة تغيير حالة فردية بسبب */}
      <Modal open={!!statusFor} onClose={() => { setStatusFor(null); setStatusReasonDraft(''); }} title="تغيير حالة الحساب">
        {statusFor && (
          <div dir="rtl">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 ${
              statusFor.status === 'banned' ? 'bg-rose-100' : 'bg-orange-100'
            }`}>
              {statusFor.status === 'banned' ? <UserX className="w-7 h-7 text-rose-600" /> :
               <Ban className="w-7 h-7 text-orange-600" />}
            </div>
            <p className="font-cairo font-bold text-slate-800 text-center mb-1">
              {statusFor.status === 'banned' ? 'حظر نهائي' : 'إيقاف'} لحساب «{statusFor.member.nickname}»
            </p>
            <div className={`rounded-xl p-3 mb-4 mt-2 text-right border ${
              statusFor.status === 'banned' ? 'bg-rose-50 border-rose-200' : 'bg-orange-50 border-orange-200'
            }`}>
              <p className={`text-xs font-cairo leading-relaxed ${
                statusFor.status === 'banned' ? 'text-rose-700' : 'text-orange-700'
              }`}>
                {statusFor.status === 'banned'
                  ? '🚫 لن يتمكن العضو من الدخول أو الظهور في البحث أو صفحة الملف. الحساب يبقى مسجلاً ويمكن إعادة تفعيله لاحقاً.'
                  : '⏸️ يُوقف الحساب مؤقتاً عن النشاط — يختفي من البحث. يمكن إعادة التفعيل لاحقاً.'}
              </p>
            </div>
            <label className="block text-xs font-cairo font-bold text-slate-700 mb-1.5">سبب الإجراء (يظهر في ملف العضو):</label>
            <textarea
              value={statusReasonDraft}
              onChange={(e) => setStatusReasonDraft(e.target.value)}
              rows={3}
              placeholder="مثال: مخالفة شروط الاستخدام، بلاغات متكررة..."
              className="w-full mb-4 px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm text-right"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={() => { setStatusFor(null); setStatusReasonDraft(''); }}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={applyStatusChange}
                className={`flex-1 py-3 rounded-xl text-white font-cairo font-bold text-sm transition-all ${
                  statusFor.status === 'banned' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-orange-600 hover:bg-orange-700'
                }`}
              >
                تأكيد الإجراء
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Notify modal */}
      <Modal open={!!notifyFor} onClose={() => setNotifyFor(null)} title="إرسال إشعار للعضو">
        {notifyFor && (
          <div>
            <p className="text-sm text-slate-500 font-tajawal mb-3">
              سيصل هذا الإشعار إلى <strong className="text-slate-800">{notifyFor.nickname}</strong> داخل المنصة.
            </p>
            <textarea
              value={notifyText}
              onChange={(e) => setNotifyText(e.target.value)}
              rows={4}
              placeholder="نص الإشعار..."
              className="w-full px-3 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {['نرحّب بك في توافق ✨', 'يرجى استكمال توثيق حسابك.', 'تمت مراجعة ملفك بنجاح ✓'].map((t) => (
                <button
                  key={t}
                  onClick={() => setNotifyText(t)}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-[11px] font-cairo hover:bg-slate-200"
                >
                  {t}
                </button>
              ))}
            </div>
            <button
              onClick={async () => {
                if (!notifyText.trim()) return;
                await notifyMember(notifyFor.id, notifyText.trim());
                setNotifyFor(null);
                showLocalToast('تم إرسال الإشعار ✓');
              }}
              disabled={!notifyText.trim()}
              className="w-full mt-4 flex items-center justify-center gap-2 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm disabled:opacity-50"
            >
              <Send className="w-4 h-4 -scale-x-100" /> إرسال الإشعار
            </button>
          </div>
        )}
      </Modal>

      {/* Import modal */}
      <Modal open={importOpen} onClose={() => setImportOpen(false)} title="استيراد الأعضاء" size="lg">
        <div className="space-y-4 text-right" dir="rtl">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
            <p className="text-xs text-blue-800 font-tajawal leading-relaxed">
              ألصق بيانات الأعضاء بصيغة JSON. يجب أن يكون كل عضو محتوياً على: <strong>nickname, email, gender</strong>.
              يمكنك أولاً تصدير الأعضاء والتعديل على الملف ثم إعادة الاستيراد.
            </p>
          </div>
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            rows={8}
            placeholder={`[\n  {\n    "nickname": "أحمد",\n    "email": "ahmed@example.com",\n    "gender": "male",\n    "age": 30,\n    "city": "الرياض"\n  }\n]`}
            className="w-full px-3 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm font-mono text-left"
            dir="ltr"
          />
          <button
            onClick={handleImport}
            disabled={!importText.trim()}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm disabled:opacity-50"
          >
            <Upload className="w-4 h-4" /> استيراد الأعضاء
          </button>
        </div>
      </Modal>

      {/* Toast */}
      <AnimatePresence>
        {localToast && (
          <motion.div
            initial={{ opacity: 0, y: 30, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 30, x: '-50%' }}
            className="fixed bottom-6 left-1/2 z-[100] px-5 py-3 rounded-2xl shadow-2xl font-cairo font-bold text-sm text-white bg-slate-900 flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            {localToast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
