import { useState, useEffect } from 'react';
import { Shield, Save, Check, Bell, Database, Globe, Settings, Lock, Clock } from 'lucide-react';

const SETTINGS_KEY = 'twafok_admin_security_settings_v1';

interface SecuritySettings {
  emailNotifs: boolean;
  smsNotifs: boolean;
  twoFactor: boolean;
  autoBackup: boolean;
  debugMode: boolean;
  cacheTimeout: string;
}

const DEFAULT_SETTINGS: SecuritySettings = {
  emailNotifs: true,
  smsNotifs: false,
  twoFactor: true,
  autoBackup: true,
  debugMode: false,
  cacheTimeout: '60',
};

function loadSettings(): SecuritySettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return DEFAULT_SETTINGS;
}

function saveSettings(settings: SecuritySettings) {
  if (typeof window !== 'undefined') {
    try { window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* ignore */ }
  }
}

interface ToggleProps {
  label: string;
  desc: string;
  icon: any;
  value: boolean;
  onChange: (val: boolean) => void;
}

const Toggle = ({ label, desc, icon: Icon, value, onChange }: ToggleProps) => {
  return (
    <div className="flex items-center gap-3 py-3">
      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-slate-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">{label}</p>
        <p className="text-xs text-slate-400 font-tajawal">{desc}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`w-12 h-7 rounded-full transition-colors relative flex-shrink-0 ${
          value ? 'bg-emerald-500' : 'bg-slate-300'
        }`}
      >
        <div
          className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${
            value ? 'right-1' : 'right-6'
          }`}
        />
      </button>
    </div>
  );
};

export default function AdminSecuritySettings() {
  const [saved, setSaved] = useState(false);
  const [settings, setSettings] = useState<SecuritySettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    setSettings(loadSettings());
  }, []);

  const handleSave = () => {
    saveSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const inputClass =
    'w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm';

  return (
    <div className="space-y-5 text-right" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">الأمان والنظام</h2>
          <p className="text-sm text-slate-500 font-tajawal">إعدادات الأمان، الإشعارات، والنسخ الاحتياطي — محفوظة فعلياً</p>
        </div>
        <button
          onClick={handleSave}
          className={`flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm hover:bg-slate-800 transition-colors ${
            saved ? 'bg-emerald-500 hover:bg-emerald-600' : ''
          }`}
        >
          {saved ? <><Check className="w-4 h-4" /> تم الحفظ</> : <><Save className="w-4 h-4" /> حفظ</>}
        </button>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Shield className="w-5 h-5 text-amber-500" /> الأمان
        </h3>
        <div className="divide-y divide-slate-50">
          <Toggle
            label="المصادقة الثنائية"
            desc="حماية إضافية لحساب الإدارة"
            icon={Lock}
            value={settings.twoFactor}
            onChange={(val) => setSettings({ ...settings, twoFactor: val })}
          />
          <Toggle
            label="وضع التصحيح"
            desc="عرض الأخطاء التفصيلية للمطورين"
            icon={Settings}
            value={settings.debugMode}
            onChange={(val) => setSettings({ ...settings, debugMode: val })}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-500" /> الإشعارات
        </h3>
        <div className="divide-y divide-slate-50">
          <Toggle
            label="إشعارات البريد الإلكتروني"
            desc="استقبال تنبيهات الأعضاء الجدد والطلبات"
            icon={Bell}
            value={settings.emailNotifs}
            onChange={(val) => setSettings({ ...settings, emailNotifs: val })}
          />
          <Toggle
            label="إشعارات SMS"
            desc="استقبال تنبيهات فورية على الجوال"
            icon={Bell}
            value={settings.smsNotifs}
            onChange={(val) => setSettings({ ...settings, smsNotifs: val })}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Database className="w-5 h-5 text-amber-500" /> النظام
        </h3>
        <div className="divide-y divide-slate-50">
          <Toggle
            label="النسخ الاحتياطي التلقائي"
            desc="نسخ احتياطي يومي للبيانات"
            icon={Database}
            value={settings.autoBackup}
            onChange={(val) => setSettings({ ...settings, autoBackup: val })}
          />
          <div className="flex items-center gap-3 py-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
              <Clock className="w-5 h-5 text-slate-600" />
            </div>
            <div className="flex-1">
              <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">مدة التخزين المؤقت (دقائق)</p>
              <p className="text-xs text-slate-400 font-tajawal">تحكم في أداء الموقع</p>
            </div>
            <input
              type="number"
              value={settings.cacheTimeout}
              onChange={(e) => setSettings({ ...settings, cacheTimeout: e.target.value })}
              className="w-20 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none text-center font-cairo font-bold text-slate-900 text-sm"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
