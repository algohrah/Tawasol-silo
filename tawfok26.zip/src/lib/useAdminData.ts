import { useState, useEffect, useCallback } from 'react';
import {
  adminGetMembers, adminUpdateMember, adminDeleteMember, adminResetPassword,
  adminToggleVerified, adminSetPremium, adminSetNote, adminToggleFlag,
  adminSendNotification, adminDeleteRequest,
  adminBulkDeleteMembers, adminBulkUpdateStatus, adminBulkSetVerified,
  adminGetRequests, adminGetStats, getEvents, runRequestAction, adminGetRequestPayments,
  getAllInquiryMessages, moderateInquiryMessage, deleteInquiryMessage,
  type AdminMemberRowLocal, type AdminStatsLocal, type LocalRequest,
  type MemberStatus, type RequestPaymentsSummary,
} from './localStore';
import { useApp } from './AppContext';

export type { RequestPaymentsSummary };

export type { MemberStatus };

// ============================================================
//  خطاف بيانات لوحة الإدارة — محلي بالكامل (localStorage)
//  يقرأ نفس قاعدة بيانات رحلة الطلب، فأي قبول/رفض/دفع من
//  الأعضاء ينعكس هنا فوراً، وأي تعديل من الإدارة ينعكس للأعضاء.
// ============================================================

export type AdminMemberRow = AdminMemberRowLocal;
export type AdminStats = AdminStatsLocal;
export type AdminRequestRow = LocalRequest;

export function useAdminMembers() {
  const {
    setMembers: setAppMembers,
    setAdminMembers: setAppAdminMembers,
    adminDeleteMember: appAdminDeleteMember,
    adminUpdateMemberStatus: appAdminUpdateMemberStatus,
  } = useApp();

  const [members, setMembers] = useState<AdminMemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMembers = useCallback(async () => {
    try {
      setError(null);
      setMembers(await adminGetMembers());
    } catch (err: any) {
      setError(err.message || 'تعذّر تحميل الأعضاء');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);

  const updateMember = useCallback(async (id: string, fields: { status?: string; plan?: string; verified?: boolean; premium?: boolean; adminNote?: string; flagged?: boolean; statusReason?: string; statusChangedBy?: string }) => {
    const ok = await adminUpdateMember(id, fields);
    if (ok) {
      await fetchMembers();
      if (fields.status) {
        appAdminUpdateMemberStatus(id, fields.status as any, fields.statusReason);
      }
      setAppAdminMembers((prev) => prev.map((m) => (m.id === id ? ({ ...m, ...fields } as any) : m)));
      setAppMembers((prev) => prev.map((m) => (m.id === id ? ({ ...m, ...fields } as any) : m)));
    }
    return ok;
  }, [fetchMembers, appAdminUpdateMemberStatus, setAppAdminMembers, setAppMembers]);

  // ===== إجراءات جماعية =====
  const bulkDelete = useCallback(async (ids: string[]) => {
    const ok = await adminBulkDeleteMembers(ids);
    if (ok) {
      await fetchMembers();
      setAppMembers((prev) => prev.filter((m) => !ids.includes(m.id)));
      setAppAdminMembers((prev) => prev.filter((m) => !ids.includes(m.id)));
    }
    return ok;
  }, [fetchMembers, setAppMembers, setAppAdminMembers]);

  const bulkUpdateStatus = useCallback(async (ids: string[], status: MemberStatus, reason = '', by = 'الإدارة') => {
    const ok = await adminBulkUpdateStatus(ids, status, reason, by);
    if (ok) {
      await fetchMembers();
      setAppAdminMembers((prev) =>
        prev.map((m) =>
          ids.includes(m.id)
            ? { ...m, status, statusReason: reason, statusChangedBy: by, statusChangedAt: new Date().toISOString() }
            : m
        )
      );
      setAppMembers((prev) =>
        prev.map((m) => (ids.includes(m.id) ? ({ ...m, status } as any) : m))
      );
    }
    return ok;
  }, [fetchMembers, setAppAdminMembers, setAppMembers]);

  const bulkSetVerified = useCallback(async (ids: string[], value: boolean) => {
    const ok = await adminBulkSetVerified(ids, value);
    if (ok) {
      await fetchMembers();
      setAppAdminMembers((prev) => prev.map((m) => (ids.includes(m.id) ? { ...m, verified: value } : m)));
      setAppMembers((prev) => prev.map((m) => (ids.includes(m.id) ? { ...m, verified: value } : m)));
    }
    return ok;
  }, [fetchMembers, setAppAdminMembers, setAppMembers]);

  const deleteMember = useCallback(async (id: string) => {
    const ok = await adminDeleteMember(id);
    if (ok) {
      await fetchMembers();
      appAdminDeleteMember(id);
    }
    return ok;
  }, [fetchMembers, appAdminDeleteMember]);

  const resetPassword = useCallback(async (id: string) => {
    const newPw = await adminResetPassword(id);
    if (newPw) {
      await fetchMembers();
      setAppAdminMembers((prev) => prev.map((m) => (m.id === id ? { ...m, password: newPw } : m)));
    }
    return newPw;
  }, [fetchMembers, setAppAdminMembers]);

  const toggleVerified = useCallback(async (id: string, v: boolean) => {
    return updateMember(id, { verified: v });
  }, [updateMember]);

  const setPremium = useCallback(async (id: string, v: boolean) => {
    return updateMember(id, { premium: v, plan: v ? 'gold' : 'free' });
  }, [updateMember]);

  const setNote = useCallback(async (id: string, note: string) => {
    return updateMember(id, { adminNote: note });
  }, [updateMember]);

  const toggleFlag = useCallback(async (id: string, v: boolean) => {
    return updateMember(id, { flagged: v });
  }, [updateMember]);

  const notifyMember = useCallback(async (id: string, text: string) => {
    return adminSendNotification(id, text);
  }, []);

  return {
    members, loading, error, refresh: fetchMembers,
    updateMember, deleteMember, resetPassword, toggleVerified, setPremium, setNote, toggleFlag, notifyMember,
    bulkDelete, bulkUpdateStatus, bulkSetVerified,
  };
}

export function useAdminStats() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setError(null);
      setStats(await adminGetStats());
    } catch (err: any) {
      setError(err.message || 'تعذّر تحميل الإحصائيات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  return { stats, loading, error, refresh };
}

export function useAdminRequests() {
  const [requests, setRequests] = useState<AdminRequestRow[]>([]);
  const [members, setMembers] = useState<AdminMemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<number | null>(null);

  const fetchAll = useCallback(async () => {
    try {
      setError(null);
      const [reqData, memData] = await Promise.all([
        adminGetRequests(),
        adminGetMembers(),
      ]);
      setRequests(reqData);
      setMembers(memData);
    } catch (err: any) {
      setError(err.message || 'تعذّر تحميل الطلبات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // الإدارة تضبط مرحلة الطلب مباشرة (ينعكس للأعضاء فوراً)
  const setStage = useCallback(async (requestId: number, stage: string, note?: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'set_stage', 'admin', { stage, note });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally {
      setActionLoading(null);
    }
  }, [fetchAll]);

  // الإدارة تحدّث تنسيق الموعد
  const updateCoordination = useCallback(async (requestId: number, meetingDate: string, meetingNotes: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'update_coordination', 'admin', { meetingDate, meetingNotes });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally {
      setActionLoading(null);
    }
  }, [fetchAll]);

  const getMember = useCallback((id: string) => members.find((m) => m.id === id), [members]);

  // جلب سجل أحداث طلب معيّن (للوحة الإدارة)
  const fetchEvents = useCallback((requestId: number) => getEvents(requestId), []);

  // جلب سجل مدفوعات طلب معيّن
  const fetchPayments = useCallback((requestId: number) => adminGetRequestPayments(requestId), []);

  // حذف طلب نهائياً
  const deleteRequest = useCallback(async (requestId: number) => {
    setActionLoading(requestId);
    try {
      const ok = await adminDeleteRequest(requestId);
      if (ok) await fetchAll();
      return ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  // ===== المرحلة 1: تحكّم الإدارة الكامل في المراحل =====

  // نقل الطلب لأي مرحلة مع سبب
  const moveToStage = useCallback(async (requestId: number, stage: string, reason: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'set_stage', 'admin', { stage, note: reason });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  // تأخير مرحلة (رجوع خطوة للخلف)
  const delayStage = useCallback(async (requestId: number, reason: string) => {
    setActionLoading(requestId);
    try {
      const req = requests.find((r) => r.id === requestId);
      if (!req) return false;
      const stages = ['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed'];
      const idx = stages.indexOf(req.journey_stage);
      if (idx <= 0) return false;
      const prev = stages[idx - 1];
      const res = await runRequestAction(requestId, 'set_stage', 'admin', { stage: prev, note: `تأخير إداري: ${reason}` });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally { setActionLoading(null); }
  }, [fetchAll, requests]);

  // تجميد الطلب
  const freezeRequest = useCallback(async (requestId: number, reason: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'freeze_request', 'admin', { note: reason });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  // إلغاء التجميد
  const unfreezeRequest = useCallback(async (requestId: number) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'unfreeze_request', 'admin', {});
      if (res.ok) await fetchAll();
      return res.ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  // إعادة تفعيل طلب منتهٍ/ملغى
  const reactivateRequest = useCallback(async (requestId: number, stage: string, reason: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'reactivate', 'admin', { stage, note: reason });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  // تبديل طرف (المرسِل أو المستقبِل)
  const swapParty = useCallback(async (requestId: number, role: 'sender' | 'receiver', newMemberId: string, reason: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'swap_party', 'admin', { role, newMemberId, note: reason });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  return {
    requests, members, loading, error, actionLoading,
    refresh: fetchAll, setStage, updateCoordination, getMember, fetchEvents, fetchPayments, deleteRequest,
    moveToStage, delayStage, freezeRequest, unfreezeRequest, reactivateRequest, swapParty,
  };
}
