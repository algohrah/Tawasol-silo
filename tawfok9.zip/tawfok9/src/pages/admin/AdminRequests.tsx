import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Heart, Search, Loader2, AlertCircle, ArrowLeft, Check, X,
  CalendarClock, ChevronLeft, ChevronRight, Filter, Eye, Trash2,
  Clock, ShieldCheck, CreditCard, Activity,
} from 'lucide-react';
import { useAdminRequests } from '../../lib/useAdminData';
import {
  JOURNEY_STAGES, STAGE_INDEX, STAGE_META, ACCENT_CLASSES, legacyToJourney,
  isTerminal, type JourneyState,
} from '../../lib/journey';
import Modal from '../../components/ui/Modal';
import FilterDropdown from '../../components/admin/FilterDropdown';
import ActionMenu from '../../components/admin/ActionMenu';

function stageTitle(s: string): string {
  const m = (STAGE_META as any)[s];
  return m ? m.title : s;
}

const ALL_STATES: (JourneyState | 'all')[] = ['all', 'sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed', 'declined', 'cancelled'];

function stageOf(stage: string): JourneyState {
  const valid = ['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed', 'declined', 'cancelled'];
  if (valid.includes(stage)) return stage as JourneyState;
  return legacyToJourney(stage);
}

export default function AdminRequests() {
  const { requests, loading, error, actionLoading, setStage, updateCoordination, getMember, fetchEvents, deleteRequest } = useAdminRequests();
  const [filter, setFilter] = useState<JourneyState | 'all'>('all');
  const [search, setSearch] = useState('');
  const [coordReq, setCoordReq] = useState<any | null>(null);
  const [meetingDate, setMeetingDate] = useState('');
  const [meetingNotes, setMeetingNotes] = useState('');
  const [detailReq, setDetailReq] = useState<any | null>(null);
  const [detailEvents, setDetailEvents] = useState<any[]>([]);
  const [confirmDelete, setConfirmDelete] = useState<any | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (t: string) => { setToast(t); setTimeout(() => setToast(null), 2500); };

  const openDetail = async (req: any) => {
    setDetailReq(req);
    setDetailEvents(await fetchEvents(req.id));
  };

  const summary = useMemo(() => ({
    total: requests.length,
    waiting: requests.filter((r) => stageOf(r.journey_stage) === 'sent').length,
    active: requests.filter((r) => !isTerminal(stageOf(r.journey_stage)) && !['sent', 'completed'].includes(stageOf(r.journey_stage))).length,
    completed: requests.filter((r) => stageOf(r.journey_stage) === 'completed').length,
    deposits: requests.reduce((n, r) => n + (r.sender_paid ? 1 : 0) + (r.receiver_paid ? 1 : 0), 0),
  }), [requests]);

  const filtered = useMemo(() => requests.filter((r) => {
    const st = stageOf(r.journey_stage);
    if (filter !== 'all' && st !== filter) return false;
    if (search.trim()) {
      const s = getMember(r.sender_id);
      const rc = getMember(r.receiver_id);
      return (s?.nickname.includes(search) || rc?.nickname.includes(search) || s?.realName?.includes(search) || rc?.realName?.includes(search));
    }
    return true;
  }), [requests, filter, search, getMember]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: requests.length };
    requests.forEach((r) => { const s = stageOf(r.journey_stage); c[s] = (c[s] || 0) + 1; });
    return c;
  }, [requests]);

  if (loading) {
    return <div className="flex flex-col items-center justify-center py-24 text-slate-400"><Loader2 className="w-9 h-9 animate-spin mb-3" /><p className="font-cairo text-sm">جارٍ تحميل الطلبات...</p></div>;
  }
  if (error) {
    return <div className="flex flex-col items-center justify-center py-24 text-center"><AlertCircle className="w-10 h-10 text-rose-400 mb-3" /><p className="font-cairo text-slate-700 font-bold">{error}</p></div>;
  }

  const advanceStage = async (req: any) => {
    const st = stageOf(req.journey_stage);
    const idx = STAGE_INDEX[st as keyof typeof STAGE_INDEX];
    if (idx === undefined || idx >= JOURNEY_STAGES.length - 1) return;
    const next = JOURNEY_STAGES[idx + 1];
    const ok = await setStage(req.id, next, `تقديم إداري للمرحلة: ${STAGE_META[next].title}`);
    if (ok) showToast(`تم النقل لمرحلة: ${STAGE_META[next].title} ✓`);
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2"><Heart className="w-5 h-5 text-rose-500" /> طلبات الاهتمام</h2>
        <p className="text-sm text-slate-500 font-tajawal">تحكّم كامل في رحلات التعارف من البداية حتى الإتمام</p>
      </div>

      {/* ===== شريط إحصائيات ===== */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: 'كل الطلبات', value: summary.total, icon: Heart, color: 'text-rose-600', bg: 'bg-rose-50' },
          { label: 'بانتظار الرد', value: summary.waiting, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'رحلات نشطة', value: summary.active, icon: Activity, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'مكتملة', value: summary.completed, icon: Check, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'عرابين مدفوعة', value: summary.deposits, icon: CreditCard, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className={`${s.bg} rounded-2xl p-3`}>
              <Icon className={`w-5 h-5 ${s.color} mb-1`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بأسماء الأطراف..."
          className="w-full pr-12 pl-4 py-3 rounded-xl bg-white border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 shadow-sm" />
      </div>

      {/* Stage filter — منسدل موحّد بدل صفّ الأزرار */}
      <div className="flex items-center gap-2">
        <FilterDropdown
          label="المرحلة:"
          value={filter}
          onChange={(v) => setFilter(v as JourneyState | 'all')}
          options={ALL_STATES.map((s) => ({
            value: s,
            label: s === 'all' ? 'كل المراحل' : stageTitle(s),
            count: counts[s] || 0,
          }))}
        />
        {filter !== 'all' && (
          <button onClick={() => setFilter('all')} className="text-xs font-cairo font-bold text-slate-400 hover:text-slate-600 px-2">
            مسح الفلتر
          </button>
        )}
        <span className="mr-auto text-xs font-cairo text-slate-400">{filtered.length} نتيجة</span>
      </div>

      {/* Requests list */}
      <div className="space-y-3">
        {filtered.length === 0 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
            <Filter className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-cairo text-slate-500">لا توجد طلبات في هذا التصنيف</p>
          </div>
        )}
        {filtered.map((req) => {
          const st = stageOf(req.journey_stage);
          const meta = STAGE_META[st];
          const c = ACCENT_CLASSES[meta.accent];
          const Icon = meta.icon;
          const sender = getMember(req.sender_id);
          const receiver = getMember(req.receiver_id);
          const idx = isTerminal(st) ? -1 : STAGE_INDEX[st as keyof typeof STAGE_INDEX];
          const canAdvance = !isTerminal(st) && idx < JOURNEY_STAGES.length - 1;
          const busy = actionLoading === req.id;

          return (
            <motion.div key={req.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4">
                {/* Parties */}
                <div className="flex items-center gap-2 mb-3">
                  <PartyChip member={sender} role="المرسِل" />
                  <ArrowLeft className="w-4 h-4 text-slate-300 flex-shrink-0" />
                  <PartyChip member={receiver} role="المستقبِل" />
                  <span className={`mr-auto inline-flex items-center gap-1 text-[11px] font-cairo font-bold px-2.5 py-1 rounded-full ${c.bgSoft} ${c.text}`}>
                    <Icon className="w-3.5 h-3.5" /> {meta.title}
                  </span>
                </div>

                {req.message && (
                  <p className="text-xs text-slate-500 font-tajawal bg-slate-50 rounded-xl p-2.5 mb-3 leading-relaxed">"{req.message}"</p>
                )}

                {/* mini timeline */}
                {!isTerminal(st) && (
                  <div className="flex items-center gap-1 mb-3">
                    {JOURNEY_STAGES.map((sk, i) => (
                      <div key={sk} className="flex items-center flex-1 last:flex-none">
                        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${i < idx ? 'bg-emerald-400' : i === idx ? c.dot : 'bg-slate-200'}`} />
                        {i < JOURNEY_STAGES.length - 1 && <div className={`h-0.5 flex-1 ${i < idx ? 'bg-emerald-300' : 'bg-slate-100'}`} />}
                      </div>
                    ))}
                  </div>
                )}

                {/* Payment / meeting info */}
                <div className="flex flex-wrap gap-2 mb-3 text-[11px] font-cairo">
                  <span className={`px-2 py-1 rounded-md ${req.sender_paid ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>عربون المرسِل: {req.sender_paid ? 'مدفوع ✓' : 'لم يُدفع'}</span>
                  <span className={`px-2 py-1 rounded-md ${req.receiver_paid ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>عربون المستقبِل: {req.receiver_paid ? 'مدفوع ✓' : 'لم يُدفع'}</span>
                  {req.meeting_date && <span className="px-2 py-1 rounded-md bg-blue-50 text-blue-600 flex items-center gap-1"><CalendarClock className="w-3 h-3" /> {req.meeting_date}</span>}
                </div>

                {(req.decline_reason || req.cancel_reason) && (
                  <p className="text-[11px] font-cairo text-rose-600 bg-rose-50 rounded-md px-2 py-1 mb-3">السبب: {req.decline_reason || req.cancel_reason}</p>
                )}

                {/* Admin actions — زر واحد يفتح قائمة موحّدة */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  <button onClick={() => openDetail(req)}
                    className="px-3 py-2 rounded-xl bg-slate-100 text-slate-700 font-cairo font-bold text-xs flex items-center gap-1.5 hover:bg-slate-200">
                    <Eye className="w-4 h-4" /> التفاصيل
                  </button>
                  {canAdvance && (
                    <button onClick={() => advanceStage(req)} disabled={busy}
                      className="px-3 py-2 rounded-xl bg-slate-900 text-white font-cairo font-bold text-xs flex items-center gap-1.5 disabled:opacity-60">
                      {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronLeft className="w-4 h-4" />}
                      تقديم
                    </button>
                  )}
                  <div className="mr-auto">
                    <ActionMenu
                      busy={busy}
                      items={[
                        {
                          label: 'تحديد موعد التنسيق',
                          icon: <CalendarClock className="w-4 h-4" />,
                          variant: 'primary',
                          hidden: isTerminal(st) || st !== 'coordination',
                          onClick: () => { setCoordReq(req); setMeetingDate(req.meeting_date || ''); setMeetingNotes(req.meeting_notes || ''); },
                        },
                        {
                          label: 'رجوع مرحلة',
                          icon: <ChevronRight className="w-4 h-4" />,
                          hidden: isTerminal(st) || idx <= 0,
                          onClick: async () => { const prev = JOURNEY_STAGES[idx - 1]; const ok = await setStage(req.id, prev, `تراجع إداري للمرحلة: ${stageTitle(prev)}`); if (ok) showToast(`رجوع لمرحلة: ${stageTitle(prev)}`); },
                        },
                        {
                          label: 'تقديم للمرحلة التالية',
                          icon: <ChevronLeft className="w-4 h-4" />,
                          variant: 'success',
                          hidden: !canAdvance,
                          onClick: () => advanceStage(req),
                        },
                        {
                          label: 'إلغاء الطلب',
                          icon: <X className="w-4 h-4" />,
                          variant: 'danger',
                          divider: true,
                          hidden: isTerminal(st) || st === 'completed',
                          onClick: async () => { const ok = await setStage(req.id, 'cancelled', 'إلغاء إداري'); if (ok) showToast('تم إلغاء الطلب'); },
                        },
                        {
                          label: 'حذف نهائي',
                          icon: <Trash2 className="w-4 h-4" />,
                          variant: 'danger',
                          onClick: () => setConfirmDelete(req),
                        },
                      ]}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* ===== نافذة التفاصيل والسجل ===== */}
      <Modal open={!!detailReq} onClose={() => setDetailReq(null)} title="تفاصيل الطلب" size="lg">
        {detailReq && (() => {
          const st = stageOf(detailReq.journey_stage);
          const meta = STAGE_META[st];
          const c = ACCENT_CLASSES[meta.accent];
          const sender = getMember(detailReq.sender_id);
          const receiver = getMember(detailReq.receiver_id);
          return (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PartyChip member={sender} role="المرسِل" />
                  <ArrowLeft className="w-4 h-4 text-slate-300" />
                  <PartyChip member={receiver} role="المستقبِل" />
                </div>
                <span className={`inline-flex items-center gap-1 text-[11px] font-cairo font-bold px-2.5 py-1 rounded-full ${c.bgSoft} ${c.text}`}>{meta.title}</span>
              </div>
              {detailReq.message && <p className="text-sm text-slate-600 font-tajawal bg-slate-50 rounded-xl p-3">"{detailReq.message}"</p>}
              <div className="grid grid-cols-2 gap-2 text-[11px] font-cairo">
                <span className={`px-2 py-1.5 rounded-md ${detailReq.sender_paid ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>عربون المرسِل: {detailReq.sender_paid ? 'مدفوع ✓' : '—'}</span>
                <span className={`px-2 py-1.5 rounded-md ${detailReq.receiver_paid ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>عربون المستقبِل: {detailReq.receiver_paid ? 'مدفوع ✓' : '—'}</span>
              </div>
              {detailReq.meeting_date && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm">
                  <span className="flex items-center gap-1.5 text-blue-700 font-cairo font-bold text-xs mb-1"><CalendarClock className="w-4 h-4" /> الموعد</span>
                  <p className="font-cairo text-slate-800">{detailReq.meeting_date}</p>
                  {detailReq.meeting_notes && <p className="text-xs text-slate-500 font-cairo mt-1">{detailReq.meeting_notes}</p>}
                </div>
              )}
              {/* السجل الزمني */}
              <div>
                <h4 className="font-cairo font-bold text-sm text-slate-700 mb-2 flex items-center gap-1.5"><Activity className="w-4 h-4 text-amber-500" /> سجل الرحلة</h4>
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {detailEvents.length === 0 && <p className="text-xs text-slate-400 font-cairo text-center py-3">لا توجد أحداث مسجّلة</p>}
                  {detailEvents.map((ev) => (
                    <div key={ev.id} className="flex items-start gap-2 text-xs font-cairo">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 flex-shrink-0" />
                      <div>
                        <p className="text-slate-700">{ev.note}</p>
                        <p className="text-[10px] text-slate-400">{new Date(ev.created_at).toLocaleString('ar-SA')}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })()}
      </Modal>

      {/* ===== تأكيد الحذف ===== */}
      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="حذف الطلب نهائياً">
        <p className="text-sm text-slate-600 font-tajawal mb-4">هل أنت متأكد من حذف هذا الطلب وسجله بالكامل؟ لا يمكن التراجع.</p>
        <div className="flex gap-2">
          <button onClick={async () => { if (confirmDelete) { await deleteRequest(confirmDelete.id); setConfirmDelete(null); showToast('تم حذف الطلب'); } }}
            className="flex-1 bg-rose-deep text-white font-cairo font-bold py-3 rounded-xl flex items-center justify-center gap-2"><Trash2 className="w-4 h-4" /> حذف نهائي</button>
          <button onClick={() => setConfirmDelete(null)} className="flex-1 bg-slate-100 text-slate-600 font-cairo font-bold py-3 rounded-xl">إلغاء</button>
        </div>
      </Modal>

      {/* Coordination modal */}
      <Modal open={!!coordReq} onClose={() => setCoordReq(null)} title="تحديد موعد التعارف">
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">الموعد</label>
            <input value={meetingDate} onChange={(e) => setMeetingDate(e.target.value)} placeholder="مثال: 2026-07-10 الساعة 8 مساءً"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-blue-200" />
          </div>
          <div>
            <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">ملاحظات / قنوات التواصل</label>
            <textarea value={meetingNotes} onChange={(e) => setMeetingNotes(e.target.value)} rows={3} placeholder="تفاصيل التواصل بإشراف الوسيطة..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-blue-200" />
          </div>
          <button onClick={async () => {
            if (!coordReq) return;
            const ok = await updateCoordination(coordReq.id, meetingDate, meetingNotes);
            setCoordReq(null);
            if (ok) showToast('تم حفظ الموعد ✓');
          }} className="w-full bg-blue-500 text-white font-cairo font-bold py-3 rounded-xl flex items-center justify-center gap-2">
            <Check className="w-4 h-4" /> حفظ الموعد
          </button>
        </div>
      </Modal>

      {toast && (
        <motion.div initial={{ opacity: 0, y: 30, x: '-50%' }} animate={{ opacity: 1, y: 0, x: '-50%' }}
          className="fixed bottom-6 left-1/2 z-[100] px-5 py-3 rounded-2xl shadow-2xl font-cairo font-bold text-sm text-white bg-emerald-600">
          {toast}
        </motion.div>
      )}
    </div>
  );
}

function PartyChip({ member, role }: { member: any; role: string }) {
  if (!member) return <span className="text-xs font-cairo text-slate-400">عضو غير معروف</span>;
  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0 ${member.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
        {member.nickname.charAt(0)}
      </div>
      <div className="min-w-0">
        <p className="font-cairo font-bold text-slate-900 text-xs truncate">{member.nickname}</p>
        <p className="text-[10px] text-slate-400 font-cairo">{role}</p>
      </div>
    </div>
  );
}
