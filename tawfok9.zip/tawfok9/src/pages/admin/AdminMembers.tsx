import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Eye, Ban, CheckCircle2, Mail, Phone, Lock, MapPin,
  ShieldCheck, Crown, Download, Users, Loader2, AlertCircle,
  Fingerprint, Briefcase, GraduationCap, Flag, Send, StickyNote,
  BadgeCheck, UserCheck, UserX, Sparkles, TrendingUp, Trash2, KeyRound, Copy, RefreshCw,
} from 'lucide-react';
import { useAdminMembers, type AdminMemberRow } from '../../lib/useAdminData';
import Modal from '../../components/ui/Modal';
import FilterDropdown from '../../components/admin/FilterDropdown';

const ITEMS_PER_PAGE = 10;

const statusConfig: Record<string, { label: string; color: string; dot: string }> = {
  active: { label: 'نشط', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' },
  suspended: { label: 'موقوف', color: 'bg-rose-100 text-rose-700', dot: 'bg-rose-500' },
  pending: { label: 'قيد المراجعة', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
};
const planConfig: Record<string, { label: string; color: string }> = {
  free: { label: 'مجاني', color: 'bg-slate-100 text-slate-600' },
  gold: { label: 'ذهبي', color: 'bg-amber-100 text-amber-700' },
  elite: { label: 'نخبة', color: 'bg-purple-100 text-purple-700' },
};

export default function AdminMembers() {
  const {
    members, loading, error, updateMember, deleteMember, resetPassword,
    toggleVerified, setPremium, setNote, toggleFlag, notifyMember,
  } = useAdminMembers();
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended' | 'pending'>('all');
  const [filterPlan, setFilterPlan] = useState<'all' | 'free' | 'gold' | 'elite'>('all');
  const [onlyFlagged, setOnlyFlagged] = useState(false);
  const [selected, setSelected] = useState<AdminMemberRow | null>(null);
  const [revealSensitive, setRevealSensitive] = useState(false);
  const [page, setPage] = useState(1);
  const [toast, setToast] = useState<string | null>(null);

  // نافذة الإشعار
  const [notifyFor, setNotifyFor] = useState<AdminMemberRow | null>(null);
  const [notifyText, setNotifyText] = useState('');
  // الملاحظة الإدارية
  const [noteDraft, setNoteDraft] = useState('');
  // تأكيد الحذف
  const [deleteFor, setDeleteFor] = useState<AdminMemberRow | null>(null);

  const showToast = (t: string) => { setToast(t); setTimeout(() => setToast(null), 2500); };

  // مزامنة المحدد مع أحدث بيانات
  const selectedLive = useMemo(
    () => (selected ? members.find((m) => m.id === selected.id) || selected : null),
    [selected, members],
  );
  useEffect(() => { if (selectedLive) setNoteDraft(selectedLive.adminNote || ''); }, [selectedLive?.id]); // eslint-disable-line

  const stats = useMemo(() => ({
    total: members.length,
    active: members.filter((m) => m.status === 'active').length,
    pending: members.filter((m) => m.status === 'pending').length,
    verified: members.filter((m) => m.verified).length,
    premium: members.filter((m) => m.premium).length,
    flagged: members.filter((m) => m.flagged).length,
  }), [members]);

  const filtered = useMemo(() => members.filter((m) => {
    const matchSearch = !search ||
      m.nickname.includes(search) || m.realName.includes(search) ||
      m.email.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || m.status === filterStatus;
    const matchPlan = filterPlan === 'all' || m.plan === filterPlan;
    const matchFlag = !onlyFlagged || m.flagged;
    return matchSearch && matchStatus && matchPlan && matchFlag;
  }), [members, search, filterStatus, filterPlan, onlyFlagged]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE) || 1;
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  useEffect(() => { setPage(1); }, [search, filterStatus, filterPlan, onlyFlagged]);

  const handleExport = () => {
    const headers = ['المعرّف', 'الاسم المستعار', 'الاسم الحقيقي', 'البريد', 'الهاتف', 'الهوية', 'الجنس', 'العمر', 'المدينة', 'الباقة', 'الحالة', 'موثّق', 'تاريخ الانضمام'];
    const rows = filtered.map((m) => [m.id, m.nickname, m.realName, m.email, m.phone, m.nationalId, m.gender === 'male' ? 'ذكر' : 'أنثى', m.age, m.city, m.plan, m.status, m.verified ? 'نعم' : 'لا', m.joinedAt]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `members-${new Date().toISOString().split('T')[0]}.csv`; a.click();
    URL.revokeObjectURL(url);
    showToast(`تم تصدير ${filtered.length} عضو ✓`);
  };

  if (loading) {
    return <div className="flex flex-col items-center justify-center py-24 text-slate-400"><Loader2 className="w-9 h-9 animate-spin mb-3" /><p className="font-cairo text-sm">جارٍ تحميل الأعضاء...</p></div>;
  }
  if (error) {
    return <div className="flex flex-col items-center justify-center py-24 text-center"><AlertCircle className="w-10 h-10 text-rose-400 mb-3" /><p className="font-cairo text-slate-700 font-bold">{error}</p></div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2"><Users className="w-5 h-5 text-amber-500" /> إدارة الأعضاء</h2>
          <p className="text-sm text-slate-500 font-tajawal">تحكّم كامل في حسابات الأعضاء وحالاتهم</p>
        </div>
        <button onClick={handleExport} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
          <Download className="w-4 h-4" /> تصدير ({filtered.length})
        </button>
      </div>

      {/* ===== شريط إحصائيات بصري ===== */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'الإجمالي', value: stats.total, icon: Users, color: 'text-slate-700', bg: 'bg-slate-50', onClick: () => { setFilterStatus('all'); setOnlyFlagged(false); } },
          { label: 'نشط', value: stats.active, icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-50', onClick: () => setFilterStatus('active') },
          { label: 'قيد المراجعة', value: stats.pending, icon: Loader2, color: 'text-amber-600', bg: 'bg-amber-50', onClick: () => setFilterStatus('pending') },
          { label: 'موثّق', value: stats.verified, icon: BadgeCheck, color: 'text-blue-600', bg: 'bg-blue-50', onClick: () => {} },
          { label: 'مميّز', value: stats.premium, icon: Crown, color: 'text-purple-600', bg: 'bg-purple-50', onClick: () => setFilterPlan('gold') },
          { label: 'معلّم', value: stats.flagged, icon: Flag, color: 'text-rose-600', bg: 'bg-rose-50', onClick: () => setOnlyFlagged(true) },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <button key={s.label} onClick={s.onClick}
              className={`${s.bg} rounded-2xl p-3 text-right border border-transparent hover:border-slate-200 transition-all`}>
              <Icon className={`w-5 h-5 ${s.color} mb-1`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بالاسم المستعار أو الحقيقي أو البريد..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900" />
        </div>
        {/* فلاتر موحّدة منسدلة */}
        <div className="flex flex-wrap gap-2 items-center">
          <FilterDropdown
            label="الحالة:"
            value={filterStatus}
            onChange={(v) => setFilterStatus(v as typeof filterStatus)}
            options={(['all', 'active', 'pending', 'suspended'] as const).map((s) => ({
              value: s,
              label: s === 'all' ? 'كل الحالات' : statusConfig[s].label,
            }))}
          />
          <FilterDropdown
            label="الباقة:"
            value={filterPlan}
            onChange={(v) => setFilterPlan(v as typeof filterPlan)}
            options={(['all', 'free', 'gold', 'elite'] as const).map((p) => ({
              value: p,
              label: p === 'all' ? 'كل الباقات' : planConfig[p].label,
            }))}
          />
          <button onClick={() => setOnlyFlagged((v) => !v)}
            className={`px-3.5 py-2.5 rounded-xl text-sm font-cairo font-bold transition-colors flex items-center gap-1.5 border ${onlyFlagged ? 'bg-rose-500 text-white border-rose-500' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}>
            <Flag className="w-4 h-4" /> المعلّمون فقط
          </button>
        </div>
      </div>

      {/* Desktop table */}
      <div className="hidden lg:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['العضو', 'البريد', 'الباقة', 'الحالة', 'إجراءات سريعة'].map((h) => (
                <th key={h} className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {paginated.map((m) => (
              <tr key={m.id} className={`hover:bg-slate-50 transition-colors ${m.flagged ? 'bg-rose-50/40' : ''}`}>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className={`relative w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
                      {m.nickname.charAt(0)}
                      {m.flagged && <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-white" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</span>
                        {m.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
                        {m.plan === 'elite' && <Crown className="w-3.5 h-3.5 text-purple-500" />}
                        {m.premium && m.plan !== 'elite' && <Crown className="w-3.5 h-3.5 text-amber-500" />}
                      </div>
                      <span className="text-[11px] text-slate-400 font-tajawal">{m.realName} · {m.age} سنة · {m.city}</span>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-xs text-slate-600 font-tajawal">{m.email}</td>
                <td className="px-5 py-3"><span className={`px-2 py-1 rounded-md text-[11px] font-cairo font-bold ${planConfig[m.plan].color}`}>{planConfig[m.plan].label}</span></td>
                <td className="px-5 py-3">
                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-cairo font-bold ${statusConfig[m.status].color}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${statusConfig[m.status].dot}`} />{statusConfig[m.status].label}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-1">
                    <button onClick={() => { setSelected(m); setRevealSensitive(false); }} className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600" title="عرض التفاصيل"><Eye className="w-4 h-4" /></button>
                    <button onClick={async () => { await toggleVerified(m.id, !m.verified); showToast(m.verified ? 'تم إلغاء التوثيق' : 'تم توثيق العضو ✓'); }}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${m.verified ? 'bg-blue-100 text-blue-600 hover:bg-blue-200' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`} title="توثيق"><BadgeCheck className="w-4 h-4" /></button>
                    <button onClick={async () => { await setPremium(m.id, !m.premium); showToast(m.premium ? 'تم إلغاء التميّز' : 'تمت الترقية لمميّز 👑'); }}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${m.premium ? 'bg-amber-100 text-amber-600 hover:bg-amber-200' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`} title="ترقية مميّز"><Crown className="w-4 h-4" /></button>
                    {m.status !== 'active' ? (
                      <button onClick={async () => { await updateMember(m.id, { status: 'active' }); showToast('تم تفعيل العضو ✓'); }} className="w-8 h-8 rounded-lg bg-emerald-100 hover:bg-emerald-200 flex items-center justify-center text-emerald-600" title="تفعيل"><CheckCircle2 className="w-4 h-4" /></button>
                    ) : (
                      <button onClick={async () => { await updateMember(m.id, { status: 'suspended' }); showToast('تم إيقاف العضو'); }} className="w-8 h-8 rounded-lg bg-rose-100 hover:bg-rose-200 flex items-center justify-center text-rose-600" title="إيقاف"><Ban className="w-4 h-4" /></button>
                    )}
                    <button onClick={async () => { await toggleFlag(m.id, !m.flagged); showToast(m.flagged ? 'أُزيل التعليم' : 'تم تعليم العضو للمتابعة'); }}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${m.flagged ? 'bg-rose-100 text-rose-600 hover:bg-rose-200' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`} title="تعليم"><Flag className="w-4 h-4" /></button>
                    <button onClick={() => setDeleteFor(m)} className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-400 hover:text-rose-600 flex items-center justify-center transition-colors" title="حذف"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="text-center py-10 text-slate-400 font-cairo text-sm">لا يوجد أعضاء مطابقون</p>}
      </div>

      {/* Mobile cards */}
      <div className="lg:hidden space-y-3">
        {paginated.map((m) => (
          <div key={m.id} className={`bg-white rounded-2xl p-4 shadow-sm border ${m.flagged ? 'border-rose-200' : 'border-slate-200'}`}>
            <div className="flex items-center gap-3">
              <div className={`w-11 h-11 rounded-full flex items-center justify-center text-white font-bold ${m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>{m.nickname.charAt(0)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5"><span className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</span>{m.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}{m.premium && <Crown className="w-3.5 h-3.5 text-amber-500" />}</div>
                <span className="text-[11px] text-slate-400 font-tajawal">{m.realName} · {m.city}</span>
              </div>
              <span className={`px-2 py-1 rounded-md text-[10px] font-cairo font-bold ${statusConfig[m.status].color}`}>{statusConfig[m.status].label}</span>
            </div>
            <div className="grid grid-cols-4 gap-2 mt-3">
              <button onClick={() => { setSelected(m); setRevealSensitive(false); }} className="py-2 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center" title="عرض"><Eye className="w-4 h-4" /></button>
              <button onClick={async () => { await toggleVerified(m.id, !m.verified); showToast(m.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓'); }} className={`py-2 rounded-xl flex items-center justify-center ${m.verified ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-400'}`}><BadgeCheck className="w-4 h-4" /></button>
              <button onClick={async () => { await setPremium(m.id, !m.premium); showToast(m.premium ? 'أُلغي التميّز' : 'ترقية 👑'); }} className={`py-2 rounded-xl flex items-center justify-center ${m.premium ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-400'}`}><Crown className="w-4 h-4" /></button>
              {m.status !== 'active'
                ? <button onClick={async () => { await updateMember(m.id, { status: 'active' }); showToast('تم التفعيل ✓'); }} className="py-2 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center"><CheckCircle2 className="w-4 h-4" /></button>
                : <button onClick={async () => { await updateMember(m.id, { status: 'suspended' }); showToast('تم الإيقاف'); }} className="py-2 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center"><Ban className="w-4 h-4" /></button>}
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 flex-wrap">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <button key={p} onClick={() => setPage(p)} className={`w-9 h-9 rounded-lg font-cairo font-bold text-sm ${page === p ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>{p}</button>
          ))}
        </div>
      )}

      {/* ===== نافذة تفاصيل العضو الغنية ===== */}
      <Modal open={!!selectedLive} onClose={() => setSelected(null)} title="ملف العضو" size="lg">
        {selectedLive && (
          <div className="space-y-4">
            {/* رأس */}
            <div className="flex items-center gap-3">
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-2xl ${selectedLive.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>{selectedLive.nickname.charAt(0)}</div>
              <div className="flex-1">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-cairo font-extrabold text-lg text-slate-900">{selectedLive.nickname}</h3>
                  {selectedLive.verified && <BadgeCheck className="w-5 h-5 text-blue-500" />}
                  {selectedLive.premium && <Crown className="w-5 h-5 text-amber-500" />}
                </div>
                <p className="text-sm text-slate-500 font-tajawal">{selectedLive.age} سنة · {selectedLive.city}، {selectedLive.country}</p>
                <div className="flex gap-1.5 mt-1">
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${statusConfig[selectedLive.status].color}`}>{statusConfig[selectedLive.status].label}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${planConfig[selectedLive.plan].color}`}>{planConfig[selectedLive.plan].label}</span>
                  {selectedLive.flagged && <span className="px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold bg-rose-100 text-rose-700 flex items-center gap-0.5"><Flag className="w-3 h-3" /> معلّم</span>}
                </div>
              </div>
            </div>

            {/* معلومات عامة */}
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: Briefcase, label: 'العمل', value: selectedLive.workType },
                { icon: GraduationCap, label: 'التعليم', value: selectedLive.education },
                { icon: MapPin, label: 'الحي', value: selectedLive.district },
                { icon: TrendingUp, label: 'عدد الطلبات', value: String(selectedLive.requestsCount) },
              ].map((f) => {
                const Icon = f.icon;
                return (
                  <div key={f.label} className="bg-slate-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-0.5"><Icon className="w-3.5 h-3.5" /><span className="text-[11px] font-cairo">{f.label}</span></div>
                    <p className="font-cairo font-bold text-sm text-slate-800">{f.value || '—'}</p>
                  </div>
                );
              })}
            </div>

            {/* بيانات حساسة */}
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-xs font-cairo font-bold text-rose-700"><Lock className="w-4 h-4" /> بيانات حساسة — للإدارة فقط</span>
                <button onClick={() => setRevealSensitive((v) => !v)}
                  className="text-[11px] font-cairo font-bold text-rose-700 bg-white px-2.5 py-1 rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors flex items-center gap-1">
                  <Eye className="w-3 h-3" />{revealSensitive ? 'إخفاء' : 'كشف الكل'}
                </button>
              </div>
              <div className="space-y-1.5">
                {[
                  { icon: Fingerprint, label: 'الاسم الحقيقي', value: selectedLive.realName, sensitive: true },
                  { icon: Mail, label: 'البريد', value: selectedLive.email, sensitive: true },
                  { icon: Phone, label: 'الهاتف', value: selectedLive.phone, sensitive: true },
                  { icon: Fingerprint, label: 'الهوية', value: selectedLive.nationalId, sensitive: true },
                  { icon: KeyRound, label: 'كلمة المرور', value: selectedLive.password, sensitive: true, mono: true },
                ].map((f) => {
                  const Icon = f.icon;
                  return (
                    <div key={f.label} className="flex items-center gap-2 text-sm bg-white/60 rounded-lg px-2 py-1.5">
                      <Icon className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      <span className="text-slate-500 font-cairo text-xs w-24 flex-shrink-0">{f.label}:</span>
                      <span className={`text-slate-800 flex-1 truncate ${f.mono ? 'font-mono' : 'font-tajawal'}`} dir="ltr">
                        {revealSensitive ? f.value : '•••••••••'}
                      </span>
                      {revealSensitive && (
                        <button onClick={() => { navigator.clipboard?.writeText(f.value); showToast('تم نسخ ' + f.label + ' ✓'); }}
                          className="text-slate-400 hover:text-slate-700 flex-shrink-0" title="نسخ"><Copy className="w-3.5 h-3.5" /></button>
                      )}
                    </div>
                  );
                })}
              </div>
              {revealSensitive && (
                <button onClick={async () => { const pw = await resetPassword(selectedLive.id); if (pw) showToast('كلمة المرور الجديدة: ' + pw); }}
                  className="w-full mt-2 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white border border-rose-200 text-rose-600 font-cairo font-bold text-xs hover:bg-rose-100 transition-colors">
                  <RefreshCw className="w-3.5 h-3.5" /> إعادة تعيين كلمة المرور
                </button>
              )}
            </div>

            {/* ملاحظة إدارية */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-cairo font-bold text-slate-600 mb-1"><StickyNote className="w-4 h-4" /> ملاحظة إدارية خاصة</label>
              <div className="flex gap-2">
                <input value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)} placeholder="اكتب ملاحظة..."
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm" />
                <button onClick={async () => { await setNote(selectedLive.id, noteDraft); showToast('حُفظت الملاحظة ✓'); }}
                  className="px-4 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm">حفظ</button>
              </div>
            </div>

            {/* إجراءات التحكم */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
              <button onClick={async () => { await toggleVerified(selectedLive.id, !selectedLive.verified); showToast(selectedLive.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓'); }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${selectedLive.verified ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'}`}>
                <BadgeCheck className="w-4 h-4" /> {selectedLive.verified ? 'موثّق' : 'توثيق'}
              </button>
              <button onClick={async () => { await setPremium(selectedLive.id, !selectedLive.premium); showToast(selectedLive.premium ? 'أُلغي التميّز' : 'ترقية مميّز 👑'); }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${selectedLive.premium ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>
                <Crown className="w-4 h-4" /> {selectedLive.premium ? 'مميّز' : 'ترقية'}
              </button>
              {selectedLive.status !== 'active' ? (
                <button onClick={async () => { await updateMember(selectedLive.id, { status: 'active' }); showToast('تم التفعيل ✓'); }}
                  className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-bold text-sm"><UserCheck className="w-4 h-4" /> تفعيل</button>
              ) : (
                <button onClick={async () => { await updateMember(selectedLive.id, { status: 'suspended' }); showToast('تم الإيقاف'); }}
                  className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-rose-100 text-rose-700 font-cairo font-bold text-sm"><UserX className="w-4 h-4" /> إيقاف</button>
              )}
              <button onClick={async () => { await toggleFlag(selectedLive.id, !selectedLive.flagged); showToast(selectedLive.flagged ? 'أُزيل التعليم' : 'تم التعليم'); }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${selectedLive.flagged ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'}`}>
                <Flag className="w-4 h-4" /> {selectedLive.flagged ? 'معلّم' : 'تعليم'}
              </button>
            </div>

            <button onClick={() => { setNotifyFor(selectedLive); setNotifyText(''); }}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:brightness-105">
              <Send className="w-4 h-4 -scale-x-100" /> إرسال إشعار للعضو
            </button>

            {/* حذف الحساب */}
            <button onClick={() => setDeleteFor(selectedLive)}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-white border-2 border-rose-200 text-rose-600 font-cairo font-bold text-sm hover:bg-rose-50 transition-colors">
              <Trash2 className="w-4 h-4" /> حذف الحساب نهائياً
            </button>
          </div>
        )}
      </Modal>

      {/* نافذة تأكيد الحذف */}
      <Modal open={!!deleteFor} onClose={() => setDeleteFor(null)} title="تأكيد حذف الحساب">
        {deleteFor && (
          <div className="text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-7 h-7 text-rose-500" />
            </div>
            <p className="font-cairo font-bold text-slate-800 mb-1">حذف حساب «{deleteFor.nickname}»؟</p>
            <p className="text-sm text-slate-500 font-tajawal mb-5">سيُزال الحساب نهائياً من قوائم المنصة. لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-2">
              <button onClick={() => setDeleteFor(null)}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors">إلغاء</button>
              <button onClick={async () => { await deleteMember(deleteFor.id); setDeleteFor(null); setSelected(null); showToast('تم حذف الحساب نهائياً'); }}
                className="flex-1 py-3 rounded-xl bg-rose-deep text-white font-cairo font-bold text-sm hover:brightness-110 transition-all">تأكيد الحذف</button>
            </div>
          </div>
        )}
      </Modal>

      {/* نافذة إرسال إشعار */}
      <Modal open={!!notifyFor} onClose={() => setNotifyFor(null)} title="إرسال إشعار للعضو">
        {notifyFor && (
          <div>
            <p className="text-sm text-slate-500 font-tajawal mb-3">سيصل هذا الإشعار إلى <strong className="text-slate-800">{notifyFor.nickname}</strong> داخل المنصة.</p>
            <textarea value={notifyText} onChange={(e) => setNotifyText(e.target.value)} rows={4} placeholder="نص الإشعار..."
              className="w-full px-3 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm" />
            <div className="flex flex-wrap gap-2 mt-2">
              {['نرحّب بك في توافق ✨', 'يرجى استكمال توثيق حسابك.', 'تمت مراجعة ملفك بنجاح ✓'].map((t) => (
                <button key={t} onClick={() => setNotifyText(t)} className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-[11px] font-cairo hover:bg-slate-200">{t}</button>
              ))}
            </div>
            <button onClick={async () => { if (!notifyText.trim()) return; await notifyMember(notifyFor.id, notifyText.trim()); setNotifyFor(null); showToast('تم إرسال الإشعار ✓'); }}
              disabled={!notifyText.trim()}
              className="w-full mt-4 flex items-center justify-center gap-2 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm disabled:opacity-50">
              <Send className="w-4 h-4 -scale-x-100" /> إرسال الإشعار
            </button>
          </div>
        )}
      </Modal>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 30, x: '-50%' }} animate={{ opacity: 1, y: 0, x: '-50%' }} exit={{ opacity: 0, y: 30, x: '-50%' }}
            className="fixed bottom-6 left-1/2 z-[100] px-5 py-3 rounded-2xl shadow-2xl font-cairo font-bold text-sm text-white bg-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />{toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
