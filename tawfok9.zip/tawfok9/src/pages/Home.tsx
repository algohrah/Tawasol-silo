import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ShieldCheck, Lock, BadgeCheck, Heart, Search, Send,
  Sparkles, ArrowLeft, Star, Quote, Users, TrendingUp, Clock,
  HeartHandshake, CalendarClock, PartyPopper,
} from 'lucide-react';
import { ButtonLink } from '../components/ui/Button';
import MemberCard from '../components/MemberCard';
import SectionHeading from '../components/layout/SectionHeading';
import { TESTIMONIALS, STATS } from '../lib/data';
import { useBlogPosts } from '../lib/useContent';
import { useApp } from '../lib/AppContext';

const features = [
  { icon: BadgeCheck, title: 'تحقق كامل من الحسابات', desc: 'كل عضو يخضع لتحقق من الهوية والبيانات لضمان مصداقية المنصة.' },
  { icon: Lock, title: 'خصوصية وحماية البيانات', desc: 'بياناتك الحساسة مشفّرة ومحمية، وتتحكم أنت بمن يراها.' },
  { icon: Search, title: 'بحث متقدم ذكي', desc: 'فلاتر دقيقة حسب العمر، المدينة، الاهتمامات، والمزيد.' },
  { icon: ShieldCheck, title: 'وساطة مهنية للتواصل', desc: 'تتولى الإدارة التواصل بين الطرفين بسرية تامة واحترام كامل.' },
];

const steps = [
  { icon: Users, title: 'أنشئ حسابك', desc: 'سجّل مجانًا وأكمل ملفك الشخصي بخطوات بسيطة.' },
  { icon: Search, title: 'ابحث واكتشف', desc: 'استخدم البحث المتقدم للعثور على من يشاركك القيم.' },
  { icon: Heart, title: 'أرسل طلب اهتمام', desc: 'عبّر عن اهتمامك وستتولى الإدارة التواصل نيابة عنك.' },
  { icon: Sparkles, title: 'ابدأ رحلتك', desc: 'تواصل جاد عبر الإدارة نحو خطوة الزواج.' },
];

// مراحل رحلة طلب الاهتمام (ميزة المنصة الأساسية)
const journeyStages = [
  { icon: Send, title: 'مُرسَل', desc: 'تُرسل طلب اهتمامك بسرية عبر الإدارة.', accent: 'text-amber-600 bg-amber-50' },
  { icon: HeartHandshake, title: 'مقبول', desc: 'يقبل الطرف الآخر ويبدأ التعارف الجاد.', accent: 'text-emerald-600 bg-emerald-50' },
  { icon: ShieldCheck, title: 'تأكيد الجدية', desc: 'رسوم المنصة وجهود الإدارة للتنسيق لتأكيد جدية الطرفين.', accent: 'text-amber-700 bg-amber-50' },
  { icon: CalendarClock, title: 'التنسيق', desc: 'الإدارة والوسيطة تنسّق موعد التعارف.', accent: 'text-blue-600 bg-blue-50' },
  { icon: Users, title: 'التعارف', desc: 'تبادل القنوات والنظرة الشرعية بإشراف.', accent: 'text-indigo-600 bg-indigo-50' },
  { icon: PartyPopper, title: 'مكتمل', desc: 'توافق مبارك نحو إتمام الزواج.', accent: 'text-emerald-700 bg-emerald-50' },
];

export default function Home() {
  const { members } = useApp();
  const { posts: blogPosts } = useBlogPosts();
  return (
    <div>
      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden bg-navy-gradient">
        <div className="absolute inset-0 pattern-arabesque opacity-40" />
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 -right-32 w-[28rem] h-[28rem] bg-rose-deep/10 rounded-full blur-3xl" />

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-16 lg:pt-24 lg:pb-24 text-center flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center flex flex-col items-center w-full"
          >
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold-500/15 border border-gold-500/30 text-gold-300 text-sm font-cairo font-semibold mb-6">
              <Sparkles className="w-4 h-4" />
              منصة الزواج العربية الأولى
            </span>

            <h1 className="font-cairo font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white leading-[1.15]">
              ابدأ رحلة العمر مع
              <span className="block text-gradient-gold mt-2">شريك الحياة المناسب</span>
            </h1>

            <p className="mt-6 text-lg text-cream-200/80 font-tajawal leading-relaxed max-w-2xl mx-auto">
              توافق يربطك بأشخاص موثوقين يشاركونك القيم والطموح، في بيئة آمنة تحترم خصوصيتك وتساعدك على بناء علاقة جادة نحو الزواج.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <ButtonLink to="/register" size="lg" className="shadow-gold">
                <Heart className="w-5 h-5" />
                ابدأ مجانًا الآن
              </ButtonLink>
              <ButtonLink to="/search" variant="outline" size="lg" className="!border-gold-400/50 !text-gold-300 hover:!bg-gold-500/10">
                <Search className="w-5 h-5" />
                تصفّح الأعضاء
              </ButtonLink>
            </div>

            {/* مؤشرات الثقة */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-cream-200/70 font-tajawal">
              <span className="flex items-center gap-1.5"><BadgeCheck className="w-4 h-4 text-emerald-400" /> حسابات موثّقة</span>
              <span className="flex items-center gap-1.5"><Lock className="w-4 h-4 text-gold-300" /> خصوصية تامة</span>
              <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-blue-300" /> وساطة مهنية</span>
            </div>
          </motion.div>
        </div>

        {/* شريط الإحصائيات */}
        <div className="relative border-t border-gold-500/15 bg-navy-950/30 backdrop-blur-sm">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
            {STATS.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + i * 0.1 }}
                className="text-center"
              >
                <div className="font-cairo font-extrabold text-2xl sm:text-3xl text-gradient-gold">{s.value}</div>
                <div className="text-xs sm:text-sm text-cream-200/70 font-tajawal mt-1">{s.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="لماذا توافق؟"
            title={<>منصة تُبنى على <span className="text-gradient-gold">الثقة والأمان</span></>}
            subtitle="نحن نلتزم بأعلى معايير الأمان والخصوصية لنمنحك تجربة مريحة وموثوقة في رحلتك نحو شريك الحياة."
          />

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-3xl p-6 shadow-soft hover:shadow-luxe transition-all duration-400 border border-cream-200/60 text-center"
              >
                <div className="w-14 h-14 rounded-2xl bg-gold-300/15 flex items-center justify-center mx-auto mb-4">
                  <f.icon className="w-7 h-7 text-gold-600" />
                </div>
                <h3 className="font-cairo font-bold text-navy-900 text-lg mb-2">{f.title}</h3>
                <p className="text-sm text-navy-600 font-tajawal leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== JOURNEY (ميزة المنصة الأساسية) ===== */}
      <section className="py-20 lg:py-28 bg-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="رحلة طلب الاهتمام"
            title={<>مسار واضح <span className="text-gradient-gold">من الطلب حتى الزواج</span></>}
            subtitle="رحلة منظّمة وآمنة بإشراف الإدارة والوسيطة الشرعية، تنتقل فيها خطوة بخطوة بكل وضوح."
          />

          <div className="mt-14 grid grid-cols-2 lg:grid-cols-6 gap-4">
            {journeyStages.map((stage, i) => (
              <motion.div
                key={stage.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="relative bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60 text-center"
              >
                <span className="absolute top-3 right-3 w-6 h-6 rounded-full bg-navy-900 text-gold-300 font-cairo font-bold text-xs flex items-center justify-center">
                  {i + 1}
                </span>
                <div className={`w-12 h-12 rounded-xl ${stage.accent} flex items-center justify-center mx-auto mb-3`}>
                  <stage.icon className="w-6 h-6" />
                </div>
                <h3 className="font-cairo font-bold text-navy-900 text-sm mb-1">{stage.title}</h3>
                <p className="text-xs text-navy-500 font-tajawal leading-relaxed">{stage.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-10 text-center">
            <ButtonLink to="/search" variant="outline">
              ابدأ رحلتك الآن <ArrowLeft className="w-4 h-4" />
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ===== HOW IT WORKS ===== */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="كيف تعمل المنصة؟"
            title={<>أربع خطوات نحو <span className="text-gradient-gold">شريك حياتك</span></>}
            subtitle="رحلة بسيطة وواضحة من التسجيل حتى الزواج."
          />

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
            {steps.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative text-center"
              >
                <div className="relative inline-block mb-5">
                  <div className="w-20 h-20 rounded-full bg-gold-gradient flex items-center justify-center shadow-gold">
                    <step.icon className="w-9 h-9 text-navy-900" />
                  </div>
                  <span className="absolute -top-1 -right-1 w-7 h-7 rounded-full bg-navy-900 text-gold-300 font-cairo font-bold text-sm flex items-center justify-center ring-4 ring-cream-50">
                    {i + 1}
                  </span>
                </div>
                <h3 className="font-cairo font-bold text-navy-900 text-lg mb-2">{step.title}</h3>
                <p className="text-sm text-navy-600 font-tajawal leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FEATURED MEMBERS ===== */}
      <section className="py-20 lg:py-28 bg-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-12">
            <SectionHeading
              center={false}
              eyebrow="أعضاء مميزون"
              title={<>تعرّف على <span className="text-gradient-gold">أعضاء موثوقين</span></>}
              subtitle="تصفّح ملفات لأعضاء موثقين يبحثون عن علاقة جادة."
            />
            <Link to="/search" className="hidden sm:flex items-center gap-2 text-gold-700 font-cairo font-bold hover:gap-3 transition-all">
              عرض الكل <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
            {members.slice(0, 4).map((m) => (
              <MemberCard key={m.id} member={m} />
            ))}
          </div>

          <div className="mt-10 text-center sm:hidden">
            <ButtonLink to="/search" variant="outline">
              عرض كل الأعضاء <ArrowLeft className="w-4 h-4" />
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ===== NEW MEMBERS ===== */}
      <section className="py-20 lg:py-28 bg-white border-b border-cream-200/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-12">
            <SectionHeading
              center={false}
              eyebrow="الأعضاء الجدد"
              title={<>اكتشف أحدث <span className="text-gradient-gold">المنضمّين مؤخراً</span></>}
              subtitle="ملفات لآخر الأعضاء الذين سجلوا في منصتنا ويبحثون عن شريك الحياة وضمان خصوصيتهم."
            />
            <Link to="/search" className="hidden sm:flex items-center gap-2 text-gold-700 font-cairo font-bold hover:gap-3 transition-all">
              تصفّح كل الأعضاء الجدد <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
            {members.slice(4, 8).map((m) => (
              <MemberCard key={m.id} member={m} />
            ))}
          </div>

          <div className="mt-10 text-center sm:hidden">
            <ButtonLink to="/search" variant="outline">
              تصفّح كل الأعضاء الجدد <ArrowLeft className="w-4 h-4" />
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ===== SECURITY HIGHLIGHT ===== */}
      <section className="py-20 lg:py-28 bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                center={false}
                light
                eyebrow="الأمان أولاً"
                title={<>خصوصيتك <span className="text-gradient-gold">أمانة لدينا</span></>}
                subtitle="نستخدم أحدث تقنيات التشفير والتحقق لحماية بياناتك ومنحك تجربة آمنة تمامًا."
              />
              <div className="mt-8 space-y-4">
                {[
                  { icon: ShieldCheck, text: 'تحقق ثلاثي الخطوات من كل حساب جديد' },
                  { icon: Lock, text: 'تشفير SSL 256-bit لجميع البيانات الحساسة' },
                  { icon: BadgeCheck, text: 'مراقبة على مدار الساعة للحسابات المزيفة' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-4">
                    <div className="w-11 h-11 rounded-xl bg-gold-500/15 flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-6 h-6 text-gold-300" />
                    </div>
                    <p className="text-cream-200/90 font-tajawal">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <img src="/images/gold-texture.jpg" alt="" className="rounded-3xl shadow-2xl w-full aspect-[4/3] object-cover ring-1 ring-gold-500/30" />
              <div className="absolute inset-0 rounded-3xl bg-navy-950/30" />
              <div className="absolute bottom-6 right-6 left-6 glass-navy rounded-2xl p-5 border border-gold-500/30">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-10 h-10 text-emerald-400 flex-shrink-0" />
                  <div>
                    <div className="font-cairo font-bold text-white text-lg">معتمد وموثوق</div>
                    <div className="text-sm text-cream-200/70 font-tajawal">ملتزمون بنظام حماية البيانات السعودي</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS ===== */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="قصص نجاح"
            title={<>قصص حب بدأت <span className="text-gradient-gold">من توافق</span></>}
            subtitle="آلاف القصص السعيدة بدأت هنا. كن أنت القصة القادمة."
          />

          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-3xl p-7 shadow-soft border border-cream-200/60 relative"
              >
                <Quote className="w-10 h-10 text-gold-300 absolute top-6 left-6 opacity-50" />
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, idx) => (
                    <Star key={idx} className="w-4 h-4 fill-gold-500 text-gold-500" />
                  ))}
                </div>
                <p className="text-navy-700 font-tajawal leading-relaxed mb-6 relative z-10">{t.story}</p>
                <div className="flex items-center gap-3 pt-4 border-t border-cream-200">
                  <div className="w-12 h-12 rounded-full bg-gold-gradient flex items-center justify-center text-navy-900 font-cairo font-bold">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-cairo font-bold text-navy-900">{t.name}</div>
                    <div className="text-xs text-navy-500 font-tajawal">{t.city} · {t.duration}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== BLOG PREVIEW ===== */}
      <section className="py-20 lg:py-28 bg-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-12">
            <SectionHeading
              center={false}
              eyebrow="المدونة"
              title={<>نصائح لزواج <span className="text-gradient-gold">سعيد وناجح</span></>}
            />
            <Link to="/blog" className="hidden sm:flex items-center gap-2 text-gold-700 font-cairo font-bold hover:gap-3 transition-all">
              كل المقالات <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {blogPosts.slice(0, 3).map((post) => (
              <Link
                key={post.id}
                to={`/blog/${post.id}`}
                className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-luxe transition-all duration-400 border border-cream-200/60"
              >
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 text-xs text-gold-600 font-cairo font-bold mb-2">
                    <span className="px-2.5 py-1 rounded-full bg-gold-300/15">{post.category}</span>
                    <span className="flex items-center gap-1 text-navy-400"><Clock className="w-3 h-3" />{post.read_time}</span>
                  </div>
                  <h3 className="font-cairo font-bold text-navy-900 text-lg leading-snug mb-2 group-hover:text-gold-700 transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-sm text-navy-600 font-tajawal line-clamp-2">{post.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="py-20 lg:py-28">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative bg-navy-gradient rounded-[2.5rem] overflow-hidden p-10 lg:p-16 text-center shadow-luxe">
            <div className="absolute inset-0 pattern-arabesque opacity-30" />
            <div className="absolute -top-20 -right-20 w-72 h-72 bg-gold-500/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-rose-deep/10 rounded-full blur-3xl" />
            <div className="relative">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gold-gradient mb-6 shadow-gold">
                <Heart className="w-8 h-8 text-navy-900" />
              </div>
              <h2 className="font-cairo font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white leading-tight">
                قلبك ينتظر شريكه...
              </h2>
              <p className="mt-4 text-lg text-cream-200/80 font-tajawal max-w-xl mx-auto">
                انضم اليوم وابدأ رحلتك نحو شريك الحياة في بيئة آمنة وموثوقة.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
                <ButtonLink to="/register" size="lg" className="shadow-gold">
                  <Heart className="w-5 h-5" /> أنشئ حسابك مجانًا
                </ButtonLink>
                <ButtonLink to="/plans" variant="outline" size="lg" className="!border-gold-400/50 !text-gold-300 hover:!bg-gold-500/10">
                  <TrendingUp className="w-5 h-5" /> اكتشف الباقات
                </ButtonLink>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
