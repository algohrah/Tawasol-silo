import { useEffect, useState } from 'react';
import { UserCog, LogOut } from 'lucide-react';
import { useApp } from '../lib/AppContext';

// ============================================================
//  شريط "تتصفّح كـ..." — يظهر عند الدخول بحساب عضو من الإدارة
//  يوضّح الهوية النشطة ويتيح العودة للحساب الافتراضي
// ============================================================

const DEFAULT_ID = 'm2';

export default function ImpersonationBar() {
  const { user, showToast } = useApp() as any;
  const [activeId, setActiveId] = useState<string>(DEFAULT_ID);

  useEffect(() => {
    const read = () => {
      if (typeof window !== 'undefined') {
        setActiveId(window.localStorage.getItem('active_member_id') || DEFAULT_ID);
      }
    };
    read();
    window.addEventListener('storage', read);
    const interval = setInterval(read, 800); // متابعة التغيّر بعد التبديل
    return () => { window.removeEventListener('storage', read); clearInterval(interval); };
  }, []);

  // لا نعرض الشريط إلا إذا كانت الهوية النشطة غير الحساب الافتراضي
  if (activeId === DEFAULT_ID) return null;

  const backToDefault = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('active_member_id', DEFAULT_ID);
      setActiveId(DEFAULT_ID);
    }
    showToast('تمت العودة إلى الحساب الافتراضي', 'info');
    // إعادة تحميل لضمان تحديث كل الصفحات بالهوية الجديدة
    setTimeout(() => window.location.reload(), 300);
  };

  return (
    <div className="sticky top-0 z-[60] bg-amber-500 text-navy-950" dir="rtl">
      <div className="max-w-6xl mx-auto px-4 py-2 flex items-center justify-between gap-2">
        <span className="flex items-center gap-2 font-cairo font-bold text-sm">
          <UserCog className="w-4 h-4" />
          تتصفّح حالياً بحساب: <strong>{user?.name || activeId}</strong>
          <span className="hidden sm:inline text-amber-900/70 font-normal">({activeId})</span>
        </span>
        <button onClick={backToDefault}
          className="flex items-center gap-1.5 bg-navy-950 text-amber-300 font-cairo font-bold text-xs px-3 py-1.5 rounded-lg hover:bg-navy-800 transition-colors flex-shrink-0">
          <LogOut className="w-3.5 h-3.5" /> العودة لحسابي
        </button>
      </div>
    </div>
  );
}
