import { useState, useMemo, useEffect, useRef } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Users, Heart, Bell, FileText, HelpCircle,
  Settings, LogOut, Menu, ShieldCheck, Globe, CreditCard,
  MessageSquare, TrendingUp, ChevronDown, Search,
} from 'lucide-react';
import { useApp } from '../../lib/AppContext';

interface NavItem {
  to: string;
  label: string;
  icon: typeof Users;
  end: boolean;
  badge?: number;
  badgeColor?: string;
}

interface NavSection {
  title: string;
  icon: typeof Users;
  items: NavItem[];
}

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const { interestRequests, reports, supportTickets, currentAdminPermissions, currentAdminRole } = useApp();

  // حساب الشارات
  const pendingRequests = interestRequests.filter(r => r.status === 'pending').length;
  const pendingReports = reports.filter(r => r.status === 'pending').length;
  const openTickets = supportTickets.filter(t => t.status === 'open' || t.status === 'in_progress').length;

  // Filter sections based on permissions
  const navSections: NavSection[] = [
    {
      title: 'الرئيسية',
      icon: LayoutDashboard,
      items: [
        { to: '/admin', label: 'لوحة المعلومات', icon: LayoutDashboard, end: true },
      ],
    },
    ...(currentAdminPermissions.manage_members || currentAdminPermissions.manage_requests ? [{
      title: 'إدارة الأعضاء',
      icon: Users,
      items: [
        ...(currentAdminPermissions.manage_members ? [{ to: '/admin/members', label: 'كل الأعضاء', icon: Users, end: false }] : []),
        ...(currentAdminPermissions.manage_requests ? [{ to: '/admin/requests', label: 'طلبات الاهتمام', icon: Heart, end: false, badge: pendingRequests, badgeColor: 'bg-rose-500' }] : []),
        ...(currentAdminPermissions.manage_members ? [{ to: '/admin/notifications', label: 'الإشعارات', icon: Bell, end: false }] : []),
      ],
    }] : []),
    ...(currentAdminPermissions.manage_support ? [{
      title: 'التواصل والبلاغات',
      icon: MessageSquare,
      items: [
        { to: '/admin/messages', label: 'الرسائل والدعم', icon: MessageSquare, end: false, badge: openTickets, badgeColor: 'bg-amber-500' },
        { to: '/admin/moderation', label: 'مراجعة الرسائل', icon: ShieldCheck, end: false },
        { to: '/admin/reports', label: 'البلاغات', icon: ShieldCheck, end: false, badge: pendingReports, badgeColor: 'bg-red-500' },
      ],
    }] : []),
    ...(currentAdminPermissions.manage_content ? [{
      title: 'المحتوى',
      icon: FileText,
      items: [
        { to: '/admin/blog', label: 'المدونة', icon: FileText, end: false },
        { to: '/admin/faq', label: 'الأسئلة الشائعة', icon: HelpCircle, end: false },
        { to: '/admin/plans', label: 'الباقات والمدفوعات', icon: CreditCard, end: false },
      ],
    }] : []),
    ...(currentAdminRole === 'super_admin' ? [{
      title: 'الإعدادات',
      icon: Settings,
      items: [
        { to: '/admin/moderators', label: 'المشرفين والصلاحيات', icon: ShieldCheck, end: false },
        { to: '/admin/fields', label: 'حقول التسجيل', icon: FileText, end: false },
        { to: '/admin/site', label: 'إعدادات الموقع', icon: Globe, end: false },
        { to: '/admin/settings', label: 'الإعدادات العامة', icon: Settings, end: false },
      ],
    }] : []),
  ];

  // تحديد الأقسام المفتوحة تلقائيًا (القسم النشط + الرئيسية)
  const activeSection = useMemo(() => {
    for (const section of navSections) {
      for (const item of section.items) {
        if (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)) {
          return section.title;
        }
      }
    }
    return 'الرئيسية';
  }, [location.pathname]);

  const [openSections, setOpenSections] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = { 'الرئيسية': true };
    navSections.forEach(s => { init[s.title] = s.title === activeSection || s.title === 'الرئيسية'; });
    return init;
  });

  // تحديث الأقسام المفتوحة عند تغيير المسار
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setOpenSections(prev => ({ ...prev, [activeSection]: true }));
  }, [activeSection]);

  const toggleSection = (title: string) => {
    setOpenSections(prev => ({ ...prev, [title]: !prev[title] }));
  };

  // تصفية العناصر حسب البحث
  const filteredSections = useMemo(() => {
    if (!searchQuery.trim()) return navSections;
    return navSections.map(section => ({
      ...section,
      items: section.items.filter(item =>
        item.label.includes(searchQuery) || section.title.includes(searchQuery)
      ),
    })).filter(section => section.items.length > 0);
  }, [searchQuery, navSections]);

  const currentTitle = (() => {
    for (const section of navSections) {
      for (const item of section.items) {
        if (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)) {
          return item.label;
        }
      }
    }
    return 'لوحة التحكم';
  })();

  const sidebarContent = (
    <AdminSidebarContent
      sections={filteredSections}
      openSections={openSections}
      toggleSection={toggleSection}
      onNavigate={() => setSidebarOpen(false)}
      searchQuery={searchQuery}
      setSearchQuery={setSearchQuery}
    />
  );

  return (
    <div className="min-h-screen bg-slate-100" dir="rtl">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex fixed top-0 right-0 bottom-0 w-64 bg-gradient-to-b from-navy-950 to-navy-900 flex-col z-50 border-l border-white/5">
        {sidebarContent}
      </aside>

      {/* Sidebar - Mobile */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-[60]">
          <div className="absolute inset-0 bg-navy-950/70 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute top-0 right-0 bottom-0 w-72 bg-gradient-to-b from-navy-950 to-navy-900 flex flex-col animate-float-up">
            {sidebarContent}
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="lg:mr-64">
        {/* Top bar */}
        <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm">
          <div className="flex items-center justify-between px-4 sm:px-6 h-16">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-slate-100">
                <Menu className="w-5 h-5 text-slate-700" />
              </button>
              <div>
                <h1 className="font-cairo font-extrabold text-lg text-slate-900 leading-tight">{currentTitle}</h1>
                <p className="text-[11px] text-slate-400 font-tajawal hidden sm:block">لوحة تحكّم منصة توافق</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/" className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100 transition-colors">
                <Globe className="w-4 h-4" /> عرض الموقع
              </Link>
              <NotificationsBell pendingRequests={pendingRequests} pendingReports={pendingReports} openTickets={openTickets} />
              <div className="flex items-center gap-2 pr-1">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">إ</div>
                <div className="hidden sm:block text-right">
                  <p className="text-xs font-cairo font-bold text-slate-800 leading-tight">الإدارة</p>
                  <p className="text-[10px] text-slate-400">{currentAdminRole === 'super_admin' ? 'مدير عام' : 'مشرف'}</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function AdminSidebarContent({
  sections,
  openSections,
  toggleSection,
  onNavigate,
  searchQuery,
  setSearchQuery,
}: {
  sections: NavSection[];
  openSections: Record<string, boolean>;
  toggleSection: (title: string) => void;
  onNavigate?: () => void;
  searchQuery: string;
  setSearchQuery: (v: string) => void;
}) {
  return (
    <>
      <div className="flex items-center justify-between p-5 border-b border-slate-700/50">
        <Link to="/admin" onClick={onNavigate} className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="font-cairo font-bold text-white">لوحة الإدارة</div>
            <div className="text-[10px] text-amber-400">توافق</div>
          </div>
        </Link>
      </div>

      {/* بحث في القائمة */}
      <div className="p-3 border-b border-slate-700/50">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في القائمة..."
            className="w-full pr-9 pl-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-tajawal placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-1.5">
        {sections.map((section) => {
          const isOpen = openSections[section.title] !== false;
          return (
            <div key={section.title} className="rounded-2xl overflow-hidden">
              <button
                onClick={() => toggleSection(section.title)}
                className={`w-full flex items-center justify-between px-3 py-2.5 text-xs font-cairo font-bold rounded-xl transition-colors ${
                  isOpen ? 'text-amber-400 bg-white/5' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-2">
                  <section.icon className="w-4 h-4" />
                  {section.title}
                </div>
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }} className="overflow-hidden"
                  >
                    <div className="space-y-1 mt-1 pr-2">
                      {section.items.map((item) => (
                        <NavLink
                          key={item.to}
                          to={item.to}
                          end={item.end}
                          onClick={onNavigate}
                          label={item.label}
                          icon={item.icon}
                          badge={item.badge}
                          badgeColor={item.badgeColor}
                        />
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </nav>

      <div className="p-3 border-t border-slate-700/50">
        <Link to="/" onClick={onNavigate} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-colors">
          <LogOut className="w-5 h-5" />
          <span className="font-cairo font-semibold text-sm">العودة للموقع</span>
        </Link>
      </div>
    </>
  );
}

function NavLink({
  to, label, icon: Icon, end, onClick, badge, badgeColor,
}: {
  to: string; label: string; icon: typeof Users; end: boolean; onClick?: () => void;
  badge?: number; badgeColor?: string;
}) {
  const location = useLocation();
  const active = end ? location.pathname === to : location.pathname.startsWith(to);
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`group flex items-center gap-3 px-3 py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all no-tap-highlight ${
        active
          ? 'bg-gold-gradient text-navy-950 shadow-gold'
          : 'text-slate-400 hover:bg-white/5 hover:text-white'
      }`}
    >
      <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-navy-900' : 'group-hover:text-amber-400'}`} />
      <span className="flex-1">{label}</span>
      {badge !== undefined && badge > 0 && (
        <span className={`text-white text-[10px] font-bold min-w-5 h-5 px-1 rounded-full flex items-center justify-center ${active ? 'bg-navy-900 text-amber-300' : (badgeColor || 'bg-rose-500')}`}>
          {badge > 9 ? '9+' : badge}
        </span>
      )}
    </Link>
  );
}

// ============================================================
//  جرس الإشعارات — قائمة منسدلة تُفتح عند الضغط
// ============================================================
function NotificationsBell({ pendingRequests, pendingReports, openTickets }: {
  pendingRequests: number; pendingReports: number; openTickets: number;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const total = pendingRequests + pendingReports + openTickets;

  useEffect(() => {
    const handler = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const items = [
    { show: pendingRequests > 0, to: '/admin/requests', icon: Heart, color: 'text-rose-500 bg-rose-50', label: 'طلبات اهتمام معلّقة', count: pendingRequests },
    { show: openTickets > 0, to: '/admin/messages', icon: MessageSquare, color: 'text-amber-500 bg-amber-50', label: 'تذاكر دعم مفتوحة', count: openTickets },
    { show: pendingReports > 0, to: '/admin/reports', icon: ShieldCheck, color: 'text-red-500 bg-red-50', label: 'بلاغات بانتظار المراجعة', count: pendingReports },
  ].filter((i) => i.show);

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((v) => !v)}
        className={`relative p-2.5 rounded-xl transition-colors ${open ? 'bg-slate-100' : 'hover:bg-slate-100'}`}>
        <Bell className="w-5 h-5 text-slate-600" />
        {total > 0 && (
          <span className="absolute -top-0.5 -left-0.5 bg-rose-500 text-white text-[9px] font-bold min-w-4 h-4 px-1 rounded-full flex items-center justify-center ring-2 ring-white">
            {total > 9 ? '9+' : total}
          </span>
        )}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: 0.96 }}
            className="absolute left-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-50">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-cairo font-bold text-sm text-slate-900">الإشعارات</span>
              {total > 0 && <span className="text-[10px] font-bold text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full">{total} جديد</span>}
            </div>
            <div className="max-h-80 overflow-y-auto">
              {items.length === 0 ? (
                <div className="py-10 text-center">
                  <Bell className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                  <p className="text-xs text-slate-400 font-tajawal">لا توجد إشعارات جديدة</p>
                </div>
              ) : items.map((it) => {
                const Icon = it.icon;
                return (
                  <Link key={it.to} to={it.to} onClick={() => setOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${it.color}`}><Icon className="w-4.5 h-4.5" /></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-cairo font-bold text-slate-800">{it.label}</p>
                      <p className="text-[10px] text-slate-400 font-tajawal">اضغط للانتقال والمعالجة</p>
                    </div>
                    <span className="text-sm font-bold text-slate-900">{it.count}</span>
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
