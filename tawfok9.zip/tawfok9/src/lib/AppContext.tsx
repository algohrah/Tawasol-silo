import React, { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import { MEMBERS } from './members';
import type { Member } from './members';
import { ADMIN_MEMBERS, ADMIN_NOTIFICATIONS } from './admin-data';
import type { AdminMember } from './admin-data';
import { INTEREST_REQUESTS, FEE_CONFIG, type InterestRequest, type RequestStatus, type MediationStage } from './data';

export interface ExemptRequest {
  id: string;
  requestId: string;
  userId: string;
  userNickname: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
}

interface UserProfile {
  name: string;
  email: string;
  city: string;
  age: number;
  plan: 'free' | 'gold' | 'elite';
  verified: boolean;
  profileCompletion: number;
  credits: number;
  walletBalance: number; // الرصيد المالي في المحفظة الداخلية بالريال السعودي
  isBoosted?: boolean;
  realName: string;
  phone: string;
  whatsapp: string;
  password: string;
  globalChatCredits?: number;
}

interface AuthUser {
  name: string;
  isLoggedIn: boolean;
  memberId?: string;   // هوية العضو النشط (للتنقّل بين الحسابات)
  profile: UserProfile;
}

import { PLANS as DEFAULT_PLANS, SUPPORT_TICKETS as DEFAULT_TICKETS } from './data';
import type { Plan, SupportTicket, InterestPurchaseSettings, MemberReport, AdminUser, AdminPermissions } from './types';
import { calculateCompatibility, type CompatResult } from './compatibility';

interface PaypalSettings {
  clientId: string;
  clientSecret: string;
  mode: 'sandbox' | 'live';
  guestCheckout: boolean;
  active: boolean;
}

export interface PaymentSettings {
  paypalActive: boolean;
  cryptoActive: boolean;
  bankActive: boolean;
  cryptoWalletAddress: string;
  bankDetails: string;
  forceSingleMethod: 'none' | 'paypal' | 'crypto' | 'bank';
}

export interface SocialSettings {
  whatsappNumber: string;
  showWhatsapp: boolean;
  twitter: string;
  showTwitter: boolean;
  instagram: string;
  showInstagram: boolean;
  snapchat: string;
  showSnapchat: boolean;
  facebook: string;
  showFacebook: boolean;
}

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  user: AuthUser;
  login: (name: string, memberId?: string) => void;
  logout: () => void;
  impersonateUser: (member: AdminMember) => void;
  importMembers: (newMembers: AdminMember[]) => void;
  likedMembers: Set<string>;
  toggleLike: (id: string) => void;
  toasts: Toast[];
  showToast: (message: string, type?: Toast['type']) => void;
  dismissToast: (id: number) => void;
  upgradePlan: (plan: 'gold' | 'elite') => void;
  plans: Plan[];
  updatePlan: (updated: Plan) => void;
  paypalSettings: PaypalSettings;
  updatePaypalSettings: (settings: PaypalSettings) => void;
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: PaymentSettings) => void;
  socialSettings: SocialSettings;
  updateSocialSettings: (settings: SocialSettings) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  showDarkModeToggle: boolean;
  updateShowDarkModeToggle: (show: boolean) => void;
  usage: {
    messagesSent: number;
    searchesDone: number;
    contactsViewed: number;
  };
  checkLimit: (action: 'message' | 'search' | 'contact') => { allowed: boolean; current: number; max: number; error?: string };
  incrementUsage: (action: 'message' | 'search' | 'contact') => void;
  buyMicrotransaction: (type: 'messages_20' | 'contact_1', cost: number) => void;
  boostProfile: () => void;
  isBoosted: boolean;
  resetUsage: () => void;
  interestPurchaseSettings: InterestPurchaseSettings;
  updateInterestPurchaseSettings: (settings: InterestPurchaseSettings) => void;
  extraInterestsCount: number;
  setExtraInterestsCount: React.Dispatch<React.SetStateAction<number>>;
  unlimitedInterestsUntil: number;
  setUnlimitedInterestsUntil: React.Dispatch<React.SetStateAction<number>>;
  buyExtraInterests: () => void;

  // Real-Time Stateful Collections & Admin integrations
  members: Member[];
  setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
  adminMembers: AdminMember[];
  setAdminMembers: React.Dispatch<React.SetStateAction<AdminMember[]>>;
  interestRequests: InterestRequest[];
  adminUsers: AdminUser[];
  addAdminUser: (admin: Omit<AdminUser, 'id' | 'createdAt'>) => void;
  updateAdminUser: (id: string, updates: Partial<AdminUser>) => void;
  deleteAdminUser: (id: string) => void;
  currentAdminRole: AdminUser['role'];
  currentAdminPermissions: AdminPermissions;
  simulateAdminLogin: (id: string | null) => void; // null means super admin (default)
  setInterestRequests: React.Dispatch<React.SetStateAction<InterestRequest[]>>;
  depositQuota: {
    hasActiveQuota: boolean;
    remainingAttempts: number;
    totalPaidAmount: number;
    paidAt?: string;
    selectedTierPrice?: number;
  };
  setDepositQuota: React.Dispatch<React.SetStateAction<{
    hasActiveQuota: boolean;
    remainingAttempts: number;
    totalPaidAmount: number;
    paidAt?: string;
    selectedTierPrice?: number;
  }>>;
  adminNotifications: any[];
  setAdminNotifications: React.Dispatch<React.SetStateAction<any[]>>;
  supportTickets: SupportTicket[];
  setSupportTickets: React.Dispatch<React.SetStateAction<SupportTicket[]>>;
  reports: MemberReport[];
  submitReport: (reportedId: string, reportedName: string, reason: string) => void;
  resolveReport: (id: string) => void;
  deleteReport: (id: string) => void;
  updateReport: (id: string, fields: Partial<MemberReport>) => void;
  addReportActionLog: (id: string, action: string, adminNote?: string) => void;

  // Secure API boundaries for Admin operations
  adminDeleteMember: (id: string) => void;
  adminUpdateMemberStatus: (id: string, status: 'active' | 'suspended' | 'pending') => void;
  adminUpdateMember: (updated: AdminMember) => void;
  adminSendBulkBroadcast: (title: string, message: string, audience: 'all' | 'verified' | 'premium' | 'specific') => Promise<void>;
  adminUpdateInterestRequestStatus: (id: string, status: RequestStatus | 'accepted', declineReason?: string) => void;
  adminUpdateInterestRequestDetails: (id: string, fields: Partial<InterestRequest>) => void;
  adminCancelAndRefund: (requestId: string, type: 'full' | 'partial') => void;
  adminProcessExemptRequest: (id: string, action: 'approve' | 'reject') => void;
  adminModeratePreExchangeMessage: (requestId: string, messageId: string, action: 'approve' | 'reject') => void;
  
  // Wallet & Exemption system
  exemptRequests: ExemptRequest[];
  submitExemptRequest: (requestId: string, reason: string) => void;
  topUpWallet: (amount: number) => void;
  payInterestRequestFee: (requestId: string, isSender: boolean, pledgeAccepted: boolean, useWallet: boolean) => void;
  payPreExchangeChatFee: (requestId: string, isSender: boolean) => void;
  buyGlobalChatCredits: (packType: '5' | '10' | '20') => boolean;
  sendPreExchangeChatMessage: (requestId: string, text: string, isSender: boolean) => void;
  flagPreExchangeNoMoney: (requestId: string, isSender: boolean) => void;
  giftPreExchangeMessages: (requestId: string, isSender: boolean, count: number) => void;
  choosePreExchangeOption: (requestId: string, choice: 'chat' | 'direct_deposit' | null) => void;

  calculateCompat: (m1: Member, m2: Member) => number;
  calculateCompatDetailed: (target: Member) => CompatResult;
  sendInterestRequest: (memberId: string, messageText: string) => void;
  sendSupportMessage: (ticketId: string, text: string, sender: 'user' | 'admin') => void;
  createSupportTicket: (subject: string, category: 'استفسار عام' | 'طلب ترقية' | 'مشكلة تقنية' | 'شكوى' | 'اقتراح', initialMessageText: string, userId?: string) => SupportTicket;
  showCompatibility: boolean;
  compatibilityPaidOnly: boolean;
  updateCompatibilitySettings: (enabled: boolean, paidOnly: boolean) => void;
  profileData: ProfileData;
  updateProfileData: (fields: Partial<ProfileData>) => void;
  updateAccountInfo: (fields: { realName?: string; email?: string; phone?: string; whatsapp?: string; password?: string }) => void;
}

const DEFAULT_PROFILE: UserProfile = {
  name: 'سارة',
  email: 'demo@tawasul.sa',
  city: 'الرياض',
  age: 26,
  plan: 'gold',
  verified: true,
  profileCompletion: 85,
  credits: 12,
  walletBalance: 1000, // رصيد افتراضي للتجربة 1000 ريال سعودي
  isBoosted: false,
  realName: 'سارة أحمد القحطاني',
  phone: '+966501234567',
  whatsapp: '+966501234567',
  password: 'password123',
  globalChatCredits: 5,
};

// ===== بيانات الملف الشخصي التفصيلية (كل حقول التسجيل) =====
export interface ProfileData {
  gender: string;
  nickname: string;
  birthDate: string;
  age: number;
  country: string;
  city: string;
  district: string;
  sect: string;
  sectOther: string;
  nationality: string;
  maritalStatus: string;
  childrenCount: string;
  childrenLiveWith: string;
  hasChildren: string;
  wifeCount: string;
  seekingWife: string;
  height: number;
  weight: number;
  skinColor: string;
  ethnicity: string;
  health: string;
  smoking: string;
  acceptPolygamy: string;
  acceptDivorced: string;
  acceptWithChildren: string;
  education: string;
  workType: string;
  jobTitle: string;
  housing: string;
  bio: string;
  // مواصفات الشريك
  pCountry: string;
  pCity: string;
  pAgeMin: number;
  pAgeMax: number;
  pNationality: string;
  pMaritalStatus: string;
  pAcceptChildren: string;
  pSect: string;
  pSectOther: string;
  pEducation: string;
  pWorkType: string;
  pReligionLevel: string;
  pSkinColor: string;
  pHeightNoMatter: boolean;
  pHeight: number;
  pHousing: string;
  pNotes: string;
}

const DEFAULT_PROFILE_DATA: ProfileData = {
  gender: 'female',
  nickname: 'سارة',
  birthDate: '',
  age: 26,
  country: 'السعودية',
  city: 'الرياض',
  district: '',
  sect: '',
  sectOther: '',
  nationality: 'السعودية',
  maritalStatus: 'single',
  childrenCount: '',
  childrenLiveWith: '',
  hasChildren: '',
  wifeCount: '',
  seekingWife: '',
  height: 0,
  weight: 0,
  skinColor: '',
  ethnicity: '',
  health: '',
  smoking: '',
  acceptPolygamy: '',
  acceptDivorced: '',
  acceptWithChildren: '',
  education: '',
  workType: '',
  jobTitle: '',
  housing: '',
  bio: '',
  pCountry: '',
  pCity: '',
  pAgeMin: 22,
  pAgeMax: 35,
  pNationality: '',
  pMaritalStatus: '',
  pAcceptChildren: '',
  pSect: '',
  pSectOther: '',
  pEducation: '',
  pWorkType: '',
  pReligionLevel: '',
  pSkinColor: '',
  pHeightNoMatter: false,
  pHeight: 170,
  pHousing: '',
  pNotes: '',
};

const DEFAULT_PAYPAL: PaypalSettings = {
  clientId: 'AX_demo_paypal_client_id_12345',
  clientSecret: 'SK_demo_secret_key_54321',
  mode: 'sandbox',
  guestCheckout: true,
  active: true,
};

const DEFAULT_PAYMENTS_CONFIG: PaymentSettings = {
  paypalActive: true,
  cryptoActive: true,
  bankActive: true,
  cryptoWalletAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F (USDT ERC20)',
  bankDetails: 'مصرف الراجحي - رقم الحساب: SA8980000012345678901234 - باسم شركة توافق المحدودة',
  forceSingleMethod: 'none'
};

const DEFAULT_SOCIALS: SocialSettings = {
  whatsappNumber: '966500000000',
  showWhatsapp: true,
  twitter: 'https://twitter.com/tawasul_sa',
  showTwitter: true,
  instagram: 'https://instagram.com/tawasul_sa',
  showInstagram: true,
  snapchat: 'https://snapchat.com/add/tawasul_sa',
  showSnapchat: true,
  facebook: 'https://facebook.com/tawasul_sa',
  showFacebook: false,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('auth_user');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return {
      name: '',
      isLoggedIn: false,
      profile: DEFAULT_PROFILE,
    };
  });
  const [likedMembers, setLikedMembers] = useState<Set<string>>(new Set(['m2', 'm5']));
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Persistent Collections for full administration real-time integration
  const [members, setMembers] = useState<Member[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_members_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return MEMBERS;
  });

  const [adminMembers, setAdminMembers] = useState<AdminMember[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_admin_members_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return ADMIN_MEMBERS;
  });

  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_admin_users');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return [
      {
        id: 'admin-1',
        name: 'المدير العام',
        email: 'admin@tawafok.com',
        role: 'super_admin',
        permissions: { manage_members: true, manage_requests: true, manage_support: true, manage_content: true, view_sensitive_data: true },
        status: 'active',
        createdAt: new Date().toISOString(),
      }
    ];
  });

  const [currentAdminId, setCurrentAdminId] = useState<string | null>(null);

  useEffect(() => {
    window.localStorage.setItem('saved_admin_users', JSON.stringify(adminUsers));
  }, [adminUsers]);

  const addAdminUser = (admin: Omit<AdminUser, 'id' | 'createdAt'>) => {
    setAdminUsers(prev => [...prev, { ...admin, id: 'admin-' + Math.random().toString(36).substr(2, 9), createdAt: new Date().toISOString() }]);
    showToast('تم إضافة المشرف بنجاح', 'success');
  };

  const updateAdminUser = (id: string, updates: Partial<AdminUser>) => {
    setAdminUsers(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
    showToast('تم تحديث بيانات المشرف', 'success');
  };

  const deleteAdminUser = (id: string) => {
    setAdminUsers(prev => prev.filter(a => a.id !== id));
    showToast('تم حذف المشرف', 'info');
  };

  const simulateAdminLogin = (id: string | null) => {
    setCurrentAdminId(id);
    showToast(id ? 'تم التبديل لصلاحيات المشرف المختار' : 'تم التبديل لصلاحيات المدير العام', 'info');
  };

  const currentAdmin = currentAdminId ? adminUsers.find(a => a.id === currentAdminId) : adminUsers.find(a => a.role === 'super_admin');
  const currentAdminRole = currentAdmin?.role || 'super_admin';
  const currentAdminPermissions = currentAdmin?.permissions || { manage_members: true, manage_requests: true, manage_support: true, manage_content: true, view_sensitive_data: true };

  const [interestRequests, setInterestRequests] = useState<InterestRequest[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_interest_requests');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return INTEREST_REQUESTS;
  });

  const [adminNotifications, setAdminNotifications] = useState<any[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_admin_notifications');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return ADMIN_NOTIFICATIONS;
  });

  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_support_tickets_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return DEFAULT_TICKETS.map(t => ({ ...t, userId: t.userId || 'm2' }));
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_support_tickets_list', JSON.stringify(supportTickets));
    }
  }, [supportTickets]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_members_list', JSON.stringify(members));
    }
  }, [members]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_admin_members_list', JSON.stringify(adminMembers));
    }
  }, [adminMembers]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_interest_requests', JSON.stringify(interestRequests));
    }
  }, [interestRequests]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_admin_notifications', JSON.stringify(adminNotifications));
    }
  }, [adminNotifications]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('auth_user', JSON.stringify(user));
    }
  }, [user]);

  // Initialize plans with local storage backup or default
  const [plans, setPlans] = useState<Plan[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_plans');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PLANS;
  });

  // Initialize PayPal settings from storage or default
  const [paypalSettings, setPaypalSettings] = useState<PaypalSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('paypal_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PAYPAL;
  });

  // Initialize Social and WhatsApp settings from storage or default
  const [socialSettings, setSocialSettings] = useState<SocialSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('social_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_SOCIALS;
  });

  // Initialize unified Multiple Payments config from storage or default
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('payment_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PAYMENTS_CONFIG;
  });

  const updatePaymentSettings = useCallback((settings: PaymentSettings) => {
    setPaymentSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('payment_settings', JSON.stringify(settings));
    }
  }, []);

  // Extra interest requests settings & state
  const [interestPurchaseSettings, setInterestPurchaseSettings] = useState<InterestPurchaseSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('interest_purchase_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // ignore
        }
      }
    }
    return {
      price: 29,
      type: 'count', // 'count' or 'duration'
      count: 10,
      durationDays: 7,
    };
  });

  const updateInterestPurchaseSettings = useCallback((settings: InterestPurchaseSettings) => {
    setInterestPurchaseSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('interest_purchase_settings', JSON.stringify(settings));
    }
  }, []);

  const [extraInterestsCount, setExtraInterestsCount] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('user_extra_interests_count');
      if (saved) return Number(saved);
    }
    return 0;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('user_extra_interests_count', String(extraInterestsCount));
    }
  }, [extraInterestsCount]);

  const [depositQuota, setDepositQuota] = useState<{
    hasActiveQuota: boolean;
    remainingAttempts: number;
    totalPaidAmount: number;
    paidAt?: string;
    selectedTierPrice?: number;
  }>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('user_deposit_quota');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          return {
            hasActiveQuota: parsed.hasActiveQuota ?? false,
            remainingAttempts: parsed.remainingAttempts ?? 5,
            totalPaidAmount: parsed.totalPaidAmount ?? 0,
            paidAt: parsed.paidAt,
            selectedTierPrice: parsed.selectedTierPrice ?? 500,
          };
        } catch (e) {
          console.warn('Failed parsing deposit quota', e);
        }
      }
    }
    return {
      hasActiveQuota: false,
      remainingAttempts: 5,
      totalPaidAmount: 0,
    };
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('user_deposit_quota', JSON.stringify(depositQuota));
    }
  }, [depositQuota]);

  const [unlimitedInterestsUntil, setUnlimitedInterestsUntil] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('user_unlimited_interests_until');
      if (saved) return Number(saved);
    }
    return 0;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('user_unlimited_interests_until', String(unlimitedInterestsUntil));
    }
  }, [unlimitedInterestsUntil]);

  // Initialize dark mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('dark_mode');
      return saved === 'true';
    }
    return false;
  });

  // تحكم الإدارة بإظهار/إخفاء زر الوضع الليلي
  const [showDarkModeToggle, setShowDarkModeToggle] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('show_dark_mode_toggle');
      return saved === null ? true : saved === 'true';
    }
    return true;
  });

  const updateShowDarkModeToggle = useCallback((show: boolean) => {
    setShowDarkModeToggle(show);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('show_dark_mode_toggle', String(show));
    }
  }, []);

  // Compatibility Feature Control (White priority - Admin toggle)
  const [showCompatibility, setShowCompatibility] = useState<boolean>(true); // Forced true for demo as per request

  // ===== بيانات الملف الشخصي التفصيلية =====
  const [profileData, setProfileData] = useState<ProfileData>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('user_profile_data');
      if (saved) {
        try { return { ...DEFAULT_PROFILE_DATA, ...JSON.parse(saved) }; } catch { /* ignore error */ }
      }
    }
    return DEFAULT_PROFILE_DATA;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('user_profile_data', JSON.stringify(profileData));
    }
  }, [profileData]);

  const updateProfileData = useCallback((fields: Partial<ProfileData>) => {
    setProfileData(prev => {
      const next = { ...prev, ...fields };
      // إعادة حساب نسبة إكمال الملف
      const allFields = Object.keys(next) as (keyof ProfileData)[];
      const checkFields = allFields.filter(k =>
        !['pAgeMin', 'pAgeMax', 'pHeight', 'pHeightNoMatter', 'sectOther', 'pSectOther', 'childrenLiveWith', 'wifeCount', 'seekingWife'].includes(k as string)
      );
      const filled = checkFields.filter(k => {
        const v = next[k];
        if (typeof v === 'number') return v > 0;
        if (typeof v === 'boolean') return true;
        return v && String(v).trim().length > 0;
      }).length;
      const pct = Math.round((filled / checkFields.length) * 100);
      setUser(u => ({ ...u, profile: { ...u.profile, profileCompletion: pct } }));
      return next;
    });
  }, []);

  const updateAccountInfo = useCallback((fields: { realName?: string; email?: string; phone?: string; whatsapp?: string; password?: string }) => {
    setUser(u => {
      const next = {
        ...u,
        profile: {
          ...u.profile,
          ...(fields.realName !== undefined ? { realName: fields.realName } : {}),
          ...(fields.email !== undefined ? { email: fields.email } : {}),
          ...(fields.phone !== undefined ? { phone: fields.phone } : {}),
          ...(fields.whatsapp !== undefined ? { whatsapp: fields.whatsapp } : {}),
          ...(fields.password !== undefined ? { password: fields.password } : {}),
        },
      };
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('auth_user', JSON.stringify(next));
      }
      return next;
    });
  }, []);

  const [compatibilityPaidOnly, setCompatibilityPaidOnly] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('compatibility_paid_only');
      return saved === 'true';
    }
    return true; // default paid only
  });

  const updateCompatibilitySettings = useCallback((enabled: boolean, paidOnly: boolean) => {
    setShowCompatibility(enabled);
    setCompatibilityPaidOnly(paidOnly);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('show_compatibility', String(enabled));
      window.localStorage.setItem('compatibility_paid_only', String(paidOnly));
    }
    // Use the showToast function from context (declared later)
    // For now we log - the toast is handled in the settings page
    console.log(`Compatibility settings updated: enabled=${enabled}, paidOnly=${paidOnly}`);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setDarkMode(prev => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('dark_mode', String(next));
        if (next) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
      return next;
    });
  }, []);

  // Sync dark class on mount and state change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [darkMode]);

  // Keep track of active operational counters in local state with persistent backup
  const [usage, setUsage] = useState<{
    messagesSent: number;
    searchesDone: number;
    contactsViewed: number;
  }>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('user_usage_counters');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.warn("Error parsing usage counters:", e);
        }
      }
    }
    return { messagesSent: 0, searchesDone: 0, contactsViewed: 0 };
  });

  const [isBoosted, setIsBoosted] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('profile_boosted');
      return saved === 'true';
    }
    return false;
  });

  const showToast = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const [reports, setReports] = useState<MemberReport[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_member_reports_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return [
      {
        id: 'rep1',
        reporterId: 'm2',
        reporterName: 'سارة',
        reportedId: 'm4',
        reportedName: 'سليمان الحربي',
        reason: 'الحساب يتصرف بشكل مريب أو يرسل رسائل مكررة غير جدية.',
        timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
        status: 'pending',
        category: 'spam' as const,
        severity: 'medium' as const,
        adminNotes: '',
        actionLog: [],
      },
      {
        id: 'rep2',
        reporterId: 'm6',
        reporterName: 'أم عبدالرحمن',
        reportedId: 'm1',
        reportedName: 'أبو عبدالله',
        reason: 'أرسل رسائل غير لائقة ومضايقات متكررة رغم الاعتذار.',
        timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
        status: 'pending',
        category: 'harassment' as const,
        severity: 'high' as const,
        adminNotes: 'تم التواصل المبدئي مع المُبلِغة، بانتظار مراجعة الإدارة.',
        actionLog: [
          { id: 'al1', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 5).toISOString(), by: 'النظام' },
          { id: 'al2', action: 'تم التواصل المبدئي مع المُبلِغة', timestamp: new Date(Date.now() - 3600000 * 3).toISOString(), by: 'د. منى السالم' },
        ],
      },
      {
        id: 'rep3',
        reporterId: 'm3',
        reporterName: 'القحطاني',
        reportedId: 'm8',
        reportedName: 'بنت الخليج',
        reason: 'الصور والمعلومات الشخصية غير حقيقية، يبدو حساباً وهمياً.',
        timestamp: new Date(Date.now() - 3600000 * 48).toISOString(),
        status: 'pending',
        category: 'fake' as const,
        severity: 'high' as const,
        adminNotes: 'يجب التحقق من هوية العضوة قبل اتخاذ إجراء.',
        actionLog: [
          { id: 'al3', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 48).toISOString(), by: 'النظام' },
        ],
      },
      {
        id: 'rep4',
        reporterId: 'm5',
        reporterName: 'العتيبي',
        reportedId: 'm7',
        reportedName: 'أبو فيصل',
        reason: 'محتوى النبذة الشخصية يحتوي على عبارات غير مناسبة.',
        timestamp: new Date(Date.now() - 3600000 * 72).toISOString(),
        status: 'resolved',
        category: 'inappropriate' as const,
        severity: 'low' as const,
        adminNotes: 'تم تنبيه العضو وتعديل النبذة.',
        actionLog: [
          { id: 'al4', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 72).toISOString(), by: 'النظام' },
          { id: 'al5', action: 'تم تنبيه العضو وتعديل النبذة', timestamp: new Date(Date.now() - 3600000 * 60).toISOString(), by: 'أ. خالد المنصور' },
          { id: 'al6', action: 'تم حل البلاغ', timestamp: new Date(Date.now() - 3600000 * 58).toISOString(), by: 'أ. خالد المنصور' },
        ],
      },
      {
        id: 'rep5',
        reporterId: 'm1',
        reporterName: 'أبو عبدالله',
        reportedId: 'm5',
        reportedName: 'العتيبي',
        reason: 'سلوك غير لائق أثناء التنسيق الشرعي وعدم احترام الإدارة.',
        timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
        status: 'pending',
        category: 'inappropriate' as const,
        severity: 'medium' as const,
        adminNotes: '',
        actionLog: [
          { id: 'al7', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 12).toISOString(), by: 'النظام' },
        ],
      },
      {
        id: 'rep6',
        reporterId: 'm8',
        reporterName: 'بنت الخليج',
        reportedId: 'm3',
        reportedName: 'القحطاني',
        reason: 'يرسل طلبات اهتمام متكررة بشكل مزعج رغم الرفض.',
        timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
        status: 'pending',
        category: 'spam' as const,
        severity: 'low' as const,
        adminNotes: '',
        actionLog: [
          { id: 'al8', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 8).toISOString(), by: 'النظام' },
        ],
      },
    ];
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_member_reports_list', JSON.stringify(reports));
    }
  }, [reports]);

  const submitReport = useCallback((reportedId: string, reportedName: string, reason: string) => {
    const newReport: MemberReport = {
      id: 'rep_' + Date.now(),
      reporterId: user.isLoggedIn ? 'user_self' : 'guest',
      reporterName: user.isLoggedIn ? user.profile.name : 'زائر',
      reportedId,
      reportedName,
      reason,
      timestamp: new Date().toISOString(),
      status: 'pending'
    };
    setReports(prev => [newReport, ...prev]);
    showToast('تم إرسال بلاغك بنجاح للإدارة وسيتخذ الوسيط الإجراء اللازم حيال العضو المخالف 🛡️', 'success');
  }, [user, showToast]);

  const resolveReport = useCallback((id: string) => {
    setReports(prev => prev.map(rep => rep.id === id ? { ...rep, status: 'resolved' as const } : rep));
    showToast('تمت معالجة البلاغ ووضع العلامة كمكتمل بنجاح.', 'success');
  }, [showToast]);

  const deleteReport = useCallback((id: string) => {
    setReports(prev => prev.filter(rep => rep.id !== id));
    showToast('تم حذف البلاغ نهائياً.', 'info');
  }, [showToast]);

  const updateReport = useCallback((id: string, fields: Partial<MemberReport>) => {
    setReports(prev => prev.map(rep => rep.id === id ? { ...rep, ...fields } : rep));
  }, []);

  const addReportActionLog = useCallback((id: string, action: string, adminNote?: string) => {
    setReports(prev => prev.map(rep => {
      if (rep.id !== id) return rep;
      const logEntry = {
        id: 'al_' + Date.now(),
        action,
        adminNote,
        timestamp: new Date().toISOString(),
        by: 'الإدارة',
      };
      return { ...rep, actionLog: [...(rep.actionLog || []), logEntry] };
    }));
  }, []);

  const buyExtraInterests = useCallback(() => {
    if (interestPurchaseSettings.type === 'count') {
      setExtraInterestsCount(prev => prev + interestPurchaseSettings.count);
      showToast(`🎉 تم شراء وشحن ${interestPurchaseSettings.count} اهتمامات إضافية بنجاح! يمكنك الآن إرسال الطلبات.`, 'success');
    } else {
      const newExpire = Date.now() + (interestPurchaseSettings.durationDays * 24 * 60 * 60 * 1000);
      setUnlimitedInterestsUntil(newExpire);
      showToast(`🎉 تم شراء وتفعيل اهتمامات بلا حدود لمدة ${interestPurchaseSettings.durationDays} أيام بنجاح!`, 'success');
    }
  }, [interestPurchaseSettings, showToast]);

  // Wallet & Exemption system
  const [exemptRequests, setExemptRequests] = useState<ExemptRequest[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_exempt_requests');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return [
      {
        id: 'ex1',
        requestId: 'ir4',
        userId: 'm3',
        userNickname: 'أبو عبدالله',
        reason: 'أواجه صعوبة مالية مؤقتة وأتمنى تخفيض الرسوم أو إعفائي لتأكيد جديتي.',
        status: 'pending',
        createdAt: Date.now() - 3600000 * 12,
      }
    ];
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('saved_exempt_requests', JSON.stringify(exemptRequests));
    }
  }, [exemptRequests]);

  const submitExemptRequest = useCallback((requestId: string, reason: string) => {
    const newExempt: ExemptRequest = {
      id: 'ex_' + Date.now(),
      requestId,
      userId: 'm2', // Demo user is m2
      userNickname: user.profile.name,
      reason,
      status: 'pending',
      createdAt: Date.now(),
    };
    setExemptRequests(prev => [newExempt, ...prev]);

    // Also update the interest request with exemption status
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const isSender = req.senderId === 'm2';
        return {
          ...req,
          ...(isSender ? {
            senderExemptionStatus: 'pending',
            senderExemptionReason: reason,
          } : {
            receiverExemptionStatus: 'pending',
            receiverExemptionReason: reason,
          })
        };
      }
      return req;
    }));

    showToast('تم تقديم طلب التسهيل المالي للإدارة بنجاح. سيتم مراجعته والرد عليك خلال 24 ساعة.', 'success');
  }, [user, showToast]);

  const adminProcessExemptRequest = useCallback((id: string, action: 'approve' | 'reject') => {
    setExemptRequests(prev => prev.map(ex => {
      if (ex.id !== id) return ex;
      
      const updatedStatus = action === 'approve' ? 'approved' as const : 'rejected' as const;
      
      // Update corresponding interest request
      setInterestRequests(currRequests => currRequests.map(req => {
        if (req.id === ex.requestId) {
          const isSender = req.senderId === ex.userId;
          const updatedReq = {
            ...req,
            ...(isSender ? {
              senderExemptionStatus: updatedStatus,
              senderPaid: action === 'approve' ? true : req.senderPaid,
              senderPaidAmount: action === 'approve' ? 0 : req.senderPaidAmount,
              senderPaidAt: action === 'approve' ? new Date().toISOString() : req.senderPaidAt,
              senderExempted: action === 'approve' ? true : false,
            } : {
              receiverExemptionStatus: updatedStatus,
              receiverPaid: action === 'approve' ? true : req.receiverPaid,
              receiverPaidAmount: action === 'approve' ? 0 : req.receiverPaidAmount,
              receiverPaidAt: action === 'approve' ? new Date().toISOString() : req.receiverPaidAt,
              receiverExempted: action === 'approve' ? true : false,
            })
          };

          // Check if both paid
          if (updatedReq.senderPaid && updatedReq.receiverPaid) {
            updatedReq.status = 'paid';
            updatedReq.paymentStatus = 'paid';
            updatedReq.paidAt = new Date().toISOString();
            updatedReq.mediationStage = 'scheduling';
          }
          return updatedReq;
        }
        return req;
      }));

      return { ...ex, status: updatedStatus };
    }));

    showToast(action === 'approve' ? 'تمت الموافقة على طلب الإعفاء وتفعيل الجدية مجاناً ✓' : 'تم رفض طلب الإعفاء المالي.', 'info');
  }, [showToast]);

  const topUpWallet = useCallback((amount: number) => {
    setUser(prev => {
      const next = {
        ...prev,
        profile: {
          ...prev.profile,
          walletBalance: prev.profile.walletBalance + amount,
        }
      };
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('auth_user', JSON.stringify(next));
      }
      return next;
    });
    showToast(`تم شحن المحفظة بمبلغ ${amount} ريال بنجاح ✓`, 'success');
  }, [showToast]);

  const payInterestRequestFee = useCallback((requestId: string, isSender: boolean, pledgeAccepted: boolean, useWallet: boolean) => {
    if (!pledgeAccepted) {
      showToast('يجب الموافقة على عهد الأمانة والجدية للمتابعة.', 'error');
      return;
    }

    const feeAmount = 500; // Fixed fee
    
    if (useWallet) {
      if (user.profile.walletBalance < feeAmount) {
        showToast('رصيد المحفظة غير كافٍ. يرجى شحن المحفظة أولاً.', 'error');
        return;
      }
      
      // Deduct from wallet
      setUser(prev => {
        const next = {
          ...prev,
          profile: {
            ...prev.profile,
            walletBalance: prev.profile.walletBalance - feeAmount,
            hasSeriousnessBadge: true,
          }
        };
        if (typeof window !== 'undefined') {
          window.localStorage.setItem('auth_user', JSON.stringify(next));
        }
        return next;
      });
    }

    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedReq = {
          ...req,
          ...(isSender ? {
            senderPaid: true,
            senderPaidAmount: feeAmount,
            senderPaidAt: new Date().toISOString(),
          } : {
            receiverPaid: true,
            receiverPaidAmount: feeAmount,
            receiverPaidAt: new Date().toISOString(),
          })
        };

        // Check if both paid
        if (updatedReq.senderPaid && updatedReq.receiverPaid) {
          updatedReq.status = 'paid';
          updatedReq.paymentStatus = 'paid';
          updatedReq.paidAt = new Date().toISOString();
          updatedReq.mediationStage = 'scheduling';
        }
        return updatedReq;
      }
      return req;
    }));

    showToast('تم تأكيد جديتك وسداد رسوم خدمة الوساطة بنجاح ✓', 'success');
  }, [user, showToast]);

  const buyGlobalChatCredits = useCallback((packType: '5' | '10' | '20') => {
    let cost = 100;
    let credits = 10;
    if (packType === '5') {
      cost = 60;
      credits = 5;
    } else if (packType === '20') {
      cost = 180;
      credits = 20;
    }

    if (user.profile.walletBalance < cost) {
      showToast(`رصيد المحفظة غير كافٍ لشراء باقة الاستفسار. يرجى الشحن أولاً. تحتاج إلى ${cost} ريال.`, 'error');
      return false;
    }

    // Deduct from wallet and add to user profile global credits
    setUser(prev => {
      const nextCredits = (prev.profile.globalChatCredits ?? 0) + credits;
      const next = {
        ...prev,
        profile: {
          ...prev.profile,
          walletBalance: prev.profile.walletBalance - cost,
          globalChatCredits: nextCredits,
        }
      };
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('auth_user', JSON.stringify(next));
      }
      return next;
    });

    // Mark active requests as unlocked chat (so UI shows chat mode)
    setInterestRequests(prev => prev.map(req => {
      if (req.status === 'accepted_pending_payment') {
        const isSender = req.senderId === 'm2';
        return {
          ...req,
          ...(isSender ? {
            senderChatUnlocked: true,
            senderChatCredits: (req.senderChatCredits ?? 0) + credits,
            senderNoMoney: false,
          } : {
            receiverChatUnlocked: true,
            receiverChatCredits: (req.receiverChatCredits ?? 0) + credits,
            receiverNoMoney: false,
          })
        };
      }
      return req;
    }));

    showToast(`🎉 تم شراء باقة الاستفسار الموحدة (${credits} رسائل بقيمة ${cost} ريال) بنجاح! رصيدك العام الآن: ${(user.profile.globalChatCredits ?? 0) + credits} رسائل.`, 'success');
    return true;
  }, [user, showToast]);

  const payPreExchangeChatFee = useCallback((requestId: string, isSender: boolean) => {
    // Backwards compatibility: buy 10 credits pack
    const success = buyGlobalChatCredits('10');
    if (success) {
      setInterestRequests(prev => prev.map(req => {
        if (req.id === requestId) {
          return {
            ...req,
            ...(isSender ? {
              senderChatUnlocked: true,
              senderNoMoney: false,
            } : {
              receiverChatUnlocked: true,
              receiverNoMoney: false,
            })
          };
        }
        return req;
      }));
    }
  }, [buyGlobalChatCredits]);

  const sendPreExchangeChatMessage = useCallback((requestId: string, text: string, isSender: boolean) => {
    if (!text.trim()) return;

    const userCredits = user.profile.globalChatCredits ?? 0;
    if (userCredits <= 0) {
      showToast('لا يوجد لديك رصيد رسائل كافٍ في محفظة الاستفسار الموحدة. يرجى شراء باقة رسائل للمتابعة.', 'error');
      return;
    }

    // Deduct 1 global credit
    setUser(prev => {
      const next = {
        ...prev,
        profile: {
          ...prev.profile,
          globalChatCredits: Math.max(0, (prev.profile.globalChatCredits ?? 0) - 1),
        }
      };
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('auth_user', JSON.stringify(next));
      }
      return next;
    });

    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const newMsg = {
          id: 'chat_' + Date.now() + Math.random().toString(36).substring(2, 6),
          senderId: isSender ? req.senderId : req.receiverId,
          text: text.trim(),
          time: 'الآن',
          approved: false, // Messages are unapproved by default and require admin review
          rejected: false,
        };

        return {
          ...req,
          chatMessages: [...(req.chatMessages || []), newMsg],
          ...(isSender ? {
            senderChatUnlocked: true,
          } : {
            receiverChatUnlocked: true,
          })
        };
      }
      return req;
    }));
    showToast('تم إرسال رسالتك بنجاح. الرسالة قيد المراجعة والتدقيق من قبل الإدارة والوسيط الأخصائي لضمان الجدية والخصوصية الكاملة 🛡️', 'info');
  }, [user, showToast]);

  const flagPreExchangeNoMoney = useCallback((requestId: string, isSender: boolean) => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          ...(isSender ? { senderNoMoney: true } : { receiverNoMoney: true })
        };
      }
      return req;
    }));
    showToast('تم إرسال إشعار للطرف الآخر بعدم إمكانية الشحن حالياً.', 'info');
  }, [showToast]);

  const giftPreExchangeMessages = useCallback((requestId: string, isSender: boolean, count: number) => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const gifterCredits = isSender ? (req.senderChatCredits ?? 0) : (req.receiverChatCredits ?? 0);
        if (gifterCredits < count) {
          showToast('لا يوجد لديك رصيد رسائل كافٍ للإهداء.', 'error');
          return req;
        }

        return {
          ...req,
          ...(isSender ? {
            senderChatCredits: gifterCredits - count,
            receiverChatCredits: (req.receiverChatCredits ?? 0) + count,
            receiverNoMoney: false,
          } : {
            receiverChatCredits: gifterCredits - count,
            senderChatCredits: (req.senderChatCredits ?? 0) + count,
            senderNoMoney: false,
          })
        };
      }
      return req;
    }));
    showToast(`تم إهداء ${count} رسائل للطرف الآخر بنجاح! يمكنه الآن الرد عليك. ❤️`, 'success');
  }, [showToast]);

  const choosePreExchangeOption = useCallback((requestId: string, choice: 'chat' | 'direct_deposit' | null) => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          preExchangeChoice: choice,
        };
      }
      return req;
    }));
    showToast(choice === 'chat' ? 'تم اختيار الاستفسار المبكر قبل تبادل الأرقام.' : 'تم اختيار الانتقال المباشر لتبادل الأرقام ودفع العربون.', 'info');
  }, [showToast]);

  const adminCancelAndRefund = useCallback((requestId: string, type: 'full' | 'partial') => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const refundFactor = type === 'full' ? 1.0 : 0.5;
        
        // Refund sender if sender is m2 (active user) and paid
        if (req.senderId === 'm2' && req.senderPaid && req.senderPaidAmount) {
          const refundAmount = req.senderPaidAmount * refundFactor;
          setUser(prevUser => {
            const next = {
              ...prevUser,
              profile: {
                ...prevUser.profile,
                walletBalance: prevUser.profile.walletBalance + refundAmount,
              }
            };
            if (typeof window !== 'undefined') {
              window.localStorage.setItem('auth_user', JSON.stringify(next));
            }
            return next;
          });
        }

        // Refund receiver if receiver is m2 (active user) and paid
        if (req.receiverId === 'm2' && req.receiverPaid && req.receiverPaidAmount) {
          const refundAmount = req.receiverPaidAmount * refundFactor;
          setUser(prevUser => {
            const next = {
              ...prevUser,
              profile: {
                ...prevUser.profile,
                walletBalance: prevUser.profile.walletBalance + refundAmount,
              }
            };
            if (typeof window !== 'undefined') {
              window.localStorage.setItem('auth_user', JSON.stringify(next));
            }
            return next;
          });
        }

        return {
          ...req,
          status: 'cancelled' as const,
          cancelReason: type === 'full' ? 'إلغاء لعدم السداد الثنائي أو بطلب الإدارة' : 'عدم توافق بعد بدء الوساطة',
          refundPercentage: type === 'full' ? 100 : 50,
        };
      }
      return req;
    }));

    showToast(
      type === 'full' 
        ? 'تم إلغاء الطلب واسترداد كامل الرسوم (100%) إلى المحفظة الداخلية بنجاح.' 
        : 'تم إنهاء الوساطة واسترداد نصف الرسوم (50%) إلى المحفظة الداخلية للطرفين بالتساوي.', 
      'success'
    );
  }, [showToast]);

  const login = (name: string, memberId: string = 'm2') => {
    const finalName = name || 'سارة';
    // نحاول مطابقة بيانات العضو من القائمة لعرض اسمه ومدينته الحقيقية
    const matched = members.find((m) => m.id === memberId);
    setUser({
      name: matched?.nickname || finalName,
      isLoggedIn: true,
      memberId,
      profile: {
        ...DEFAULT_PROFILE,
        name: matched?.nickname || finalName,
        city: matched?.city || DEFAULT_PROFILE.city,
        age: matched?.age || DEFAULT_PROFILE.age,
      },
    });
    // تعيين الهوية النشطة لصفحة الطلبات والرحلة حسب الحساب المختار
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('active_member_id', memberId);
    }
  };

  const logout = () => {
    setUser({ name: '', isLoggedIn: false, profile: DEFAULT_PROFILE });
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem('active_member_id');
    }
  };

  const impersonateUser = (member: AdminMember) => {
    setUser({
      name: member.nickname,
      isLoggedIn: true,
      memberId: member.id,
      profile: {
        ...DEFAULT_PROFILE,
        name: member.nickname,
        realName: member.realName || member.nickname,
        email: member.email || '',
        phone: member.phone || '',
        city: member.city || DEFAULT_PROFILE.city,
        age: member.age || DEFAULT_PROFILE.age,
        plan: member.plan || 'free',
      },
    });
    // تخزين الهوية النشطة لصفحة الطلبات والرحلة
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('active_member_id', member.id);
    }
    showToast(`تم تسجيل الدخول كـ ${member.nickname}`, 'success');
  };

  const importMembers = (newMembers: AdminMember[]) => {
    setAdminMembers(prev => [...newMembers, ...prev]);
    // Sync with public members list if needed
    setMembers(prev => {
      const publicMembers = newMembers.map(nm => ({
        ...nm, // Just spread the whole member object to keep all properties
        isManagedByAdmin: nm.isManagedByAdmin,
        managedByAdminId: nm.managedByAdminId
      }));
      return [...publicMembers, ...prev];
    });
    showToast(`تم استيراد ${newMembers.length} عضو بنجاح`, 'success');
  };

  const toggleLike = (id: string) => {
    setLikedMembers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        showToast('تمت الإزالة من المحفوظات', 'info');
      } else {
        next.add(id);
        showToast('تم الحفظ في المحفوظات ❤️', 'success');
      }
      return next;
    });
  };

  const upgradePlan = (plan: 'gold' | 'elite') => {
    setUser((prev) => ({
      ...prev,
      profile: { ...prev.profile, plan },
    }));
    showToast(`تم تفعيل باقة ${plan === 'gold' ? 'الذهبية' : 'النخبة'} بنجاح! 🎉`, 'success');
  };

  const updatePlan = (updated: Plan) => {
    setPlans((prev) => {
      const next = prev.map((p) => (p.id === updated.id ? updated : p));
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('saved_plans', JSON.stringify(next));
      }
      return next;
    });
    showToast(`تم تحديث باقة ${updated.name} بنجاح!`, 'success');
  };

  const updatePaypalSettings = (settings: PaypalSettings) => {
    setPaypalSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('paypal_settings', JSON.stringify(settings));
    }
    showToast('تم حفظ إعدادات PayPal بنجاح!', 'success');
  };

  const updateSocialSettings = (settings: SocialSettings) => {
    setSocialSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('social_settings', JSON.stringify(settings));
    }
    showToast('تم حفظ إعدادات التواصل الاجتماعي بنجاح!', 'success');
  };

  // CHECK LIMIT LOGIC
  const checkLimit = useCallback((action: 'message' | 'search' | 'contact') => {
    const currentPlanId = user.profile.plan === 'gold' ? 'premium' : user.profile.plan === 'elite' ? 'elite' : 'free';
    const activePlan = plans.find((p) => p.id === currentPlanId) || plans[0];

    let max = 0;
    let current = 0;

    if (action === 'message') {
      if (unlimitedInterestsUntil > Date.now()) {
        return {
          allowed: true,
          current: usage.messagesSent,
          max: 999,
          error: undefined,
        };
      }
      const baseMax = activePlan.messagesLimit !== undefined ? activePlan.messagesLimit : 3;
      max = baseMax + extraInterestsCount;
      current = usage.messagesSent;
    } else if (action === 'search') {
      max = activePlan.searchLimit !== undefined ? activePlan.searchLimit : 2;
      current = usage.searchesDone;
    } else if (action === 'contact') {
      max = activePlan.showContactLimit !== undefined ? activePlan.showContactLimit : 0;
      current = usage.contactsViewed;
    }

    const allowed = current < max;

    return {
      allowed,
      current,
      max,
      error: allowed
        ? undefined
        : `لقد استنفدت حد باقتك لطلبات الاهتمام المساعدة والربط المباشر (${max}/${max}). يمكنك ترقية باقتك أو شراء باقات طلبات اهتمام إضافية فورياً لمواصلة التواصل مع شريك حياتك المنشود.`,
    };
  }, [user.profile.plan, plans, usage, extraInterestsCount, unlimitedInterestsUntil]);

  // INCREMENT COUNTER ON ACTION SUCCESS
  const incrementUsage = useCallback((action: 'message' | 'search' | 'contact') => {
    setUsage((prev) => {
      const next = { ...prev };
      if (action === 'message') next.messagesSent += 1;
      if (action === 'search') next.searchesDone += 1;
      if (action === 'contact') next.contactsViewed += 1;

      if (typeof window !== 'undefined') {
        window.localStorage.setItem('user_usage_counters', JSON.stringify(next));
      }
      return next;
    });
  }, []);

  const resetUsage = useCallback(() => {
    const fresh = { messagesSent: 0, searchesDone: 0, contactsViewed: 0 };
    setUsage(fresh);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('user_usage_counters', JSON.stringify(fresh));
    }
    showToast('تم تصفير عدادات الاستخدام والميزات التجريبية بنجاح.', 'success');
  }, [showToast]);

  // MICROTRANSACTIONS LOGIC (buying 20 messages pack or 1 contact pack)
  const buyMicrotransaction = useCallback((type: 'messages_20' | 'contact_1', cost: number) => {
    // subtract usage offset so user gets more tokens allowed or just deduct from usage counter
    setUsage((prev) => {
      const next = { ...prev };
      if (type === 'messages_20') {
        // give breathing room of 20 more messages
        next.messagesSent = Math.max(0, next.messagesSent - 20);
      } else if (type === 'contact_1') {
        // give breathing room of 1 more contact
        next.contactsViewed = Math.max(0, next.contactsViewed - 1);
      }
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('user_usage_counters', JSON.stringify(next));
      }
      return next;
    });

    setUser((prev) => {
      const nextProfile = { ...prev.profile };
      // optionally adjust credits if they had enough
      nextProfile.credits = Math.max(0, nextProfile.credits - cost);
      return { ...prev, profile: nextProfile };
    });

    showToast(
      type === 'messages_20'
        ? `🎉 تم شراء حزمة (20 رسالة إضافية) وتفعيلها بنجاح!`
        : `🎉 تم تفعيل رؤية رقم تواصل لحساب إضافي بنجاح!`,
      'success'
    );
  }, [showToast]);

  // PROFILE BOOSTING LOGIC
  const boostProfile = useCallback(() => {
    setIsBoosted(true);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('profile_boosted', 'true');
    }
    setUser((prev) => ({
      ...prev,
      profile: { ...prev.profile, isBoosted: true },
    }));
    showToast('تم رفع وترقية ملفك متصدراً نتائج البحث بنجاح! 🚀✨', 'success');
  }, [showToast]);

  // Synchronize demo user profile updates with the member 'm2' list entry in real-time
  useEffect(() => {
    if (user.isLoggedIn && user.profile.email === 'demo@tawasul.sa') {
      const p = user.profile;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setMembers((prev) =>
        prev.map((m) =>
          m.id === 'm2'
            ? {
                ...m,
                nickname: p.name,
                city: p.city,
                age: p.age,
                verified: p.verified,
                premium: p.plan !== 'free',
              }
            : m
        )
      );
      setAdminMembers((prev) =>
        prev.map((m) =>
          m.id === 'm2'
            ? {
                ...m,
                nickname: p.name,
                city: p.city,
                age: p.age,
                realName: p.name + ' القحطاني',
                verified: p.verified,
                plan: p.plan,
              }
            : m
        )
      );
    }
  }, [user]);

  // Mathematically balanced weighted compatibility index calculator
  const calculateCompat = useCallback((m1: Member, m2: Member): number => {
    const currentUserMember = members.find(m => m.id === 'm2') || m1;
    const result = calculateCompatibility(currentUserMember, m2, profileData);
    return result.score;
  }, [members, profileData]);

  // حساب تفصيلي يرجع الأسباب والألوان
  const calculateCompatDetailed = useCallback((target: Member): CompatResult => {
    const currentUserMember = members.find(m => m.id === 'm2');
    if (!currentUserMember) {
      return { score: 0, isGenderMatch: false, isEstimated: false, reasons: [], details: [] };
    }
    return calculateCompatibility(currentUserMember, target, profileData);
  }, [members, profileData]);

  // Secure API Operations for Administrative Console
  const adminDeleteMember = useCallback((id: string) => {
    setAdminMembers((prev) => prev.filter((m) => m.id !== id));
    setMembers((prev) => prev.filter((m) => m.id !== id));
    
    // Cascading Delete: remove from liked/bookmarked lists
    setLikedMembers((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });

    // Cascading Delete: remove from pending/active interest requests
    setInterestRequests((prev) => prev.filter((r) => r.senderId !== id && r.receiverId !== id));
    
    // real-time Session Invalidation
    if (id === 'm2' || (user.isLoggedIn && user.profile.email === 'demo@tawasul.sa' && id === 'm2')) {
      logout();
      showToast('تم إلغاء جلستك فوراً وحذف حسابك من قواعد البيانات بشكل متتالٍ وآمن', 'error');
    } else {
      showToast('تم حذف حساب العضو كلياً من المنصة مع إزالة كافة الارتباطات والبيانات ذات الصلة', 'success');
    }
  }, [user, logout, showToast]);

  const adminUpdateMemberStatus = useCallback((id: string, status: AdminMember['status']) => {
    setAdminMembers((prev) => prev.map((m) => (m.id === id ? { ...m, status } : m)));
    
    // Real-time Session Invalidation on Account Suspension
    if (status === 'suspended') {
      if (id === 'm2' || (user.isLoggedIn && user.profile.email === 'demo@tawasul.sa' && id === 'm2')) {
        logout();
        showToast('تم تجميد حسابك وطرد جلستك فوراً لأسباب انضباطية من الإدارة', 'error');
      } else {
        showToast('تم تجميد حساب العضو قسرياً وحظر دخوله وجلساته النشطة بنجاح', 'info');
      }
    } else {
      showToast('تم تحديث حالة العضو وتأكيدها بنجاح', 'success');
    }
  }, [user, logout, showToast]);

  const adminUpdateMember = useCallback((updated: AdminMember) => {
    setAdminMembers((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
    setMembers((prev) =>
      prev.map((m) =>
        m.id === updated.id
          ? {
              ...m,
              nickname: updated.nickname,
              gender: updated.gender,
              age: updated.age,
              country: updated.country,
              city: updated.city,
              district: updated.district,
              nationality: updated.nationality,
              sect: updated.sect,
              maritalStatus: updated.maritalStatus,
              maritalLabel: updated.maritalLabel,
              hasChildren: updated.hasChildren,
              childrenCount: updated.childrenCount,
              height: updated.height,
              weight: updated.weight,
              skinColor: updated.skinColor,
              health: updated.health,
              smoking: updated.smoking,
              education: updated.education,
              workType: updated.workType,
              housing: updated.housing,
              bio: updated.bio,
              aboutPartner: updated.aboutPartner,
              verified: updated.verified,
              premium: updated.plan !== 'free',
            }
          : m
      )
    );
    
    // If updating the demo user, synchronize current auth session
    if (updated.id === 'm2') {
      setUser((prev) => ({
        ...prev,
        profile: {
          ...prev.profile,
          name: updated.nickname,
          city: updated.city,
          age: updated.age,
          plan: updated.plan,
          verified: updated.verified,
        },
      }));
    }
    
    showToast('تم حفظ التعديلات وترقية حدود العضو برمجياً فورياً وفي اللحظة نفسها', 'success');
  }, [showToast]);

  const adminSendBulkBroadcast = useCallback(async (title: string, message: string, audience: 'all' | 'verified' | 'premium' | 'specific') => {
    // Non-blocking asynchronous chunk-by-chunk scheduling simulation representing Async Bulk Insertion
    showToast('تجري الجدولة غير المتزامنة والإدراج على دفعات لجدول مستلمي الرسائل (message_recipient)...', 'info');
    
    return new Promise<void>((resolve) => {
      let insertedCount = 0;
      const targetCount = audience === 'all' ? 154320 : audience === 'verified' ? 98450 : audience === 'premium' ? 12450 : 2500;
      const batchSize = Math.max(1, Math.floor(targetCount / 4));
      
      const timer = setInterval(() => {
        insertedCount += batchSize;
        if (insertedCount >= targetCount) {
          insertedCount = targetCount;
          clearInterval(timer);
          
          setAdminNotifications((prev) => [
            {
              id: 'an' + Date.now(),
              title,
              message,
              audience,
              sentAt: 'الآن',
              recipients: targetCount,
            },
            ...prev,
          ]);
          
          showToast(`تم الإدراج بنجاح! تم استهداف وتوصيل الرسالة إلى ${targetCount.toLocaleString('ar-EG')} عضو نشط`, 'success');
          resolve();
        } else {
          showToast(`جاري إدراج الدفعة... (${insertedCount.toLocaleString('ar-EG')} / ${targetCount.toLocaleString('ar-EG')})`, 'info');
        }
      }, 400);
    });
  }, [showToast]);

  const adminUpdateInterestRequestStatus = useCallback((requestId: string, status: RequestStatus | 'accepted', declineReason?: string) => {
    const targetStatus: RequestStatus = status === 'accepted' ? 'accepted_pending_payment' : status;
    setInterestRequests((prevRequests) => {
      return prevRequests.map((req) => {
        if (req.id === requestId) {
          // If accepted, calculate dynamic compatibility score and update members
          if (targetStatus === 'accepted_pending_payment') {
            const partnerId = req.senderId === 'm2' ? req.receiverId : req.senderId;
            const requester = members.find((m) => m.id === partnerId);
            const targetMember = members.find((m) => m.id === 'm2'); // Demo User context
            
            if (requester && targetMember) {
              const weightCompat = calculateCompat(requester, targetMember);
              
              showToast(`تم قياس وحساب التوافق الموزون للمعادلة الرياضية: ${weightCompat}% للطرفين`, 'success');
              
              setMembers((currMembers) =>
                currMembers.map((m) =>
                  m.id === partnerId ? { ...m, matchScore: weightCompat } : m
                )
              );
              setAdminMembers((currAdmin) =>
                currAdmin.map((m) =>
                  m.id === partnerId ? { ...m, matchScore: weightCompat } : m
                )
              );
            }
          }
          
          const deadlineTime = targetStatus === 'accepted_pending_payment' 
            ? new Date(Date.now() + 72 * 3600 * 1000).toISOString() 
            : req.paymentDeadline;

          return { 
            ...req, 
            status: targetStatus, 
            ...(declineReason !== undefined ? { declineReason } : {}),
            ...(targetStatus === 'accepted_pending_payment' ? { 
              paymentStatus: 'waiting_for_payment' as const,
              paymentDeadline: deadlineTime,
              senderPaid: false,
              receiverPaid: false,
              attemptsCount: FEE_CONFIG.freeAttemptsAfterDeposit,
            } : {}),
            ...(targetStatus === 'paid' ? { 
              paymentStatus: 'paid' as const,
              paidAt: 'الآن',
              mediationStage: 'scheduling' as MediationStage,
            } : {}),
            ...(targetStatus === 'in_mediation' ? { 
              mediationStage: 'scheduling' as MediationStage,
            } : {}),
            ...(targetStatus === 'completed' ? { 
              mediationStage: 'evaluating' as MediationStage,
            } : {}),
            ...(targetStatus === 'cancelled' ? { 
              refundPercentage: req.mediationStage === 'evaluating' || req.status === 'in_mediation' 
                ? FEE_CONFIG.refundAfterMeeting 
                : FEE_CONFIG.refundBeforeMeeting,
            } : {}),
          };
        }
        return req;
      });
    });
    
    const statusLabels: Record<RequestStatus, string> = {
      pending: 'قيد الانتظار',
      accepted_pending_admin: 'مقبول وبانتظار موافقة الإدارة والتحقق ⏳',
      accepted_pending_payment: 'تمت الموافقة وبانتظار سداد رسوم تأكيد الجدية ثنائياً 💳',
      paid: 'تم السداد، جاهز للوساطة ✅',
      in_mediation: 'الوساطة جارية 🤝',
      completed: 'مكتمل 🎉',
      declined: 'مرفوض',
      cancelled: 'ملغى',
    };
    showToast(`تم تحديث حالة طلب الاهتمام: ${statusLabels[targetStatus]}`, 'info');
  }, [members, calculateCompat, showToast]);

  const adminUpdateInterestRequestDetails = useCallback((requestId: string, fields: Partial<InterestRequest>) => {
    setInterestRequests((prevRequests) => {
      return prevRequests.map((req) => {
        if (req.id === requestId) {
          return { ...req, ...fields };
        }
        return req;
      });
    });
    showToast('تم حفظ تحديثات طلب الاهتمام والموعد بنجاح بنظام التوفيق والمطابقة ✓', 'success');
  }, [showToast]);

  const adminModeratePreExchangeMessage = useCallback((requestId: string, messageId: string, action: 'approve' | 'reject') => {
    setInterestRequests((prevRequests) => {
      return prevRequests.map((req) => {
        if (req.id === requestId) {
          const updatedMessages = (req.chatMessages || []).map((msg: any) => {
            if (msg.id === messageId) {
              return {
                ...msg,
                approved: action === 'approve',
                rejected: action === 'reject',
              };
            }
            return msg;
          });
          return {
            ...req,
            chatMessages: updatedMessages,
          };
        }
        return req;
      });
    });
    showToast(action === 'approve' ? 'تمت الموافقة على الرسالة وتوصيلها للطرف الآخر ✓' : 'تم رفض وتصفية الرسالة لمخالفتها شروط المنصة ❌', 'info');
  }, [showToast]);

  const sendInterestRequest = useCallback((memberId: string, messageText: string) => {
    // منع التكرار — التحقق من وجود طلب معلّق لنفس الشخص
    const existingPending = interestRequests.find(
      r => r.senderId === 'm2' && r.receiverId === memberId &&
        ['pending', 'accepted_pending_payment', 'paid', 'in_mediation'].includes(r.status)
    );
    if (existingPending) {
      showToast('لديك طلب نشط لدى هذا العضو بالفعل', 'error');
      return;
    }

    const newRequest: InterestRequest = {
      id: 'ir' + Date.now(),
      senderId: 'm2', // Demo active user
      receiverId: memberId,
      status: 'pending',
      message: messageText.trim() || 'طلب اهتمام مرسل عبر الإدارة',
      time: 'الآن',
      createdAt: Date.now(),
    };
    setInterestRequests((prev) => [newRequest, ...prev]);
    showToast('تم إرسال طلب الاهتمام بنجاح ✓', 'success');
  }, [interestRequests, setInterestRequests, showToast]);

  const sendSupportMessage = useCallback((ticketId: string, text: string, sender: 'user' | 'admin') => {
    setSupportTickets((prev) =>
      prev.map((t) => {
        if (t.id === ticketId) {
          return {
            ...t,
            status: sender === 'admin' ? 'in_progress' : 'open',
            updatedAt: 'الآن',
            messages: [
              ...t.messages,
              {
                id: 'msg-' + Date.now() + Math.random().toString(36).substring(2, 6),
                sender,
                text,
                time: 'الآن',
              },
            ],
          };
        }
        return t;
      })
    );
  }, []);

  const createSupportTicket = useCallback((
    subject: string,
    category: 'استفسار عام' | 'طلب ترقية' | 'مشكلة تقنية' | 'شكوى' | 'اقتراح',
    initialMessageText: string,
    userId?: string
  ) => {
    const newTicket: SupportTicket = {
      id: 't-' + Date.now(),
      userId: userId || 'm2',
      subject,
      category,
      status: 'open',
      priority: 'normal',
      updatedAt: 'الآن',
      messages: [
        {
          id: 'msg-' + Date.now(),
          sender: 'user',
          text: initialMessageText,
          time: 'الآن',
        },
      ],
    };
    setSupportTickets((prev) => [newTicket, ...prev]);
    return newTicket;
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        login,
        logout,
        impersonateUser,
        importMembers,
        likedMembers,
        toggleLike,
        toasts,
        showToast,
        dismissToast,
        upgradePlan,
        plans,
        updatePlan,
        paypalSettings,
        updatePaypalSettings,
        paymentSettings,
        updatePaymentSettings,
        socialSettings,
        updateSocialSettings,
        darkMode,
        toggleDarkMode,
        showDarkModeToggle,
        updateShowDarkModeToggle,
        usage,
        checkLimit,
        incrementUsage,
        buyMicrotransaction,
        boostProfile,
        isBoosted,
        resetUsage,
        interestPurchaseSettings,
        updateInterestPurchaseSettings,
        extraInterestsCount,
        setExtraInterestsCount,
        unlimitedInterestsUntil,
        setUnlimitedInterestsUntil,
        buyExtraInterests,
        members,
        setMembers,
        adminMembers,
        setAdminMembers,
        interestRequests,
        adminUsers,
        addAdminUser,
        updateAdminUser,
        deleteAdminUser,
        currentAdminRole,
        currentAdminPermissions,
        simulateAdminLogin,
        setInterestRequests,
        depositQuota,
        setDepositQuota,
        adminNotifications,
        setAdminNotifications,
        supportTickets,
        setSupportTickets,
        reports,
        submitReport,
        resolveReport,
        deleteReport,
        updateReport,
        addReportActionLog,
        adminDeleteMember,
        adminUpdateMemberStatus,
        adminUpdateMember,
        adminSendBulkBroadcast,
        adminUpdateInterestRequestStatus,
        adminUpdateInterestRequestDetails,
        adminCancelAndRefund,
        adminProcessExemptRequest,
        adminModeratePreExchangeMessage,
        exemptRequests,
        submitExemptRequest,
        topUpWallet,
        payInterestRequestFee,
        payPreExchangeChatFee,
        buyGlobalChatCredits,
        sendPreExchangeChatMessage,
        flagPreExchangeNoMoney,
        giftPreExchangeMessages,
        choosePreExchangeOption,
        calculateCompat,
        calculateCompatDetailed,
        sendInterestRequest,
        sendSupportMessage,
        createSupportTicket,
        showCompatibility,
        compatibilityPaidOnly,
        updateCompatibilitySettings,
        profileData,
        updateProfileData,
        updateAccountInfo,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
