// ====================================================================
//  نظام الخطابات والدفعات — إدارة أسماء الخطابات وعمليات الاستيراد
//  جميع البيانات تُخزن في localStorage
// ====================================================================

// ===== أنواع البيانات =====

export interface ImportOffice {
  id: string;
  name: string;           // اسم الخطابة أو المكتب
  createdAt: string;      // تاريخ الإنشاء
  usageCount: number;     // عدد مرات الاستخدام
  lastUsedAt?: string;    // آخر استخدام
  notes?: string;         // ملاحظات
}

export interface ImportBatch {
  id: string;
  batchNumber: string;    // رقم الدفعة (مثال: IMP-001)
  officeId?: string;      // معرف الخطابة (اختياري)
  officeName?: string;    // اسم الخطابة (للعرض)
  importDate: string;     // تاريخ الاستيراد
  membersCount: number;   // عدد الأعضاء المستوردين
  duplicatesCount: number;// عدد المكررات
  skippedCount: number;   // عدد السجلات المتجاهلة
  errorsCount: number;    // عدد الأخطاء
  notes?: string;         // ملاحظات الاستيراد
  sourceType: 'csv' | 'paste' | 'api';  // طريقة الاستيراد
  createdAt: string;
}

export interface ImportReport {
  batchId: string;
  totalRows: number;      // إجمالي الصفوف في الملف
  importedCount: number;  // تم استيرادهم
  duplicatesCount: number;// مكررات
  skippedCount: number;   // متجاهلة
  errorsCount: number;    // أخطاء
  errors: ImportError[];  // تفاصيل الأخطاء
  warnings: ImportWarning[]; // التحذيرات
  officeName?: string;
  batchNumber?: string;
  importDate?: string;
}

export interface ImportError {
  row: number;            // رقم الصف
  field?: string;         // الحقل المشكل
  message: string;        // رسالة الخطأ
  value?: any;            // القيمة المشكلة
}

export interface ImportWarning {
  row: number;
  field?: string;
  message: string;
}

// ===== ثوابت =====

const STORAGE_KEYS = {
  offices: 'import_offices_list',
  batches: 'import_batches_list',
};

// ===== دوال الخطابات =====

export function getImportOffices(): ImportOffice[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = window.localStorage.getItem(STORAGE_KEYS.offices);
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  return [];
}

export function saveImportOffices(offices: ImportOffice[]): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(STORAGE_KEYS.offices, JSON.stringify(offices));
}

export function addImportOffice(name: string, notes?: string): ImportOffice {
  const offices = getImportOffices();
  const newOffice: ImportOffice = {
    id: 'office_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
    name: name.trim(),
    createdAt: new Date().toISOString(),
    usageCount: 0,
    notes: notes?.trim(),
  }; 
  offices.push(newOffice);
  saveImportOffices(offices);
  return newOffice;
}

export function updateImportOffice(id: string, updates: Partial<ImportOffice>): void {
  const offices = getImportOffices();
  const idx = offices.findIndex(o => o.id === id);
  if (idx !== -1) {
    offices[idx] = { ...offices[idx], ...updates }; 
    saveImportOffices(offices);
  }
}

export function deleteImportOffice(id: string): void {
  const offices = getImportOffices().filter(o => o.id !== id);
  saveImportOffices(offices);
}

export function incrementOfficeUsage(id: string): void {
  const offices = getImportOffices();
  const idx = offices.findIndex(o => o.id === id);
  if (idx !== -1) {
    offices[idx].usageCount += 1;
    offices[idx].lastUsedAt = new Date().toISOString();
    saveImportOffices(offices);
  }
}

export function getImportOfficeById(id: string): ImportOffice | undefined {
  return getImportOffices().find(o => o.id === id);
}

export function getImportOfficeByName(name: string): ImportOffice | undefined {
  return getImportOffices().find(o => o.name.toLowerCase() === name.toLowerCase());
}

// ===== دوال الدفعات =====

export function getImportBatches(): ImportBatch[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = window.localStorage.getItem(STORAGE_KEYS.batches);
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  return [];
}

export function saveImportBatches(batches: ImportBatch[]): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(STORAGE_KEYS.batches, JSON.stringify(batches));
}

export function generateBatchNumber(): string {
  const batches = getImportBatches();
  const lastNum = batches.length > 0 
    ? Math.max(...batches.map(b => parseInt(b.batchNumber.replace('IMP-', '')) || 0)) 
    : 0;
  return `IMP-${String(lastNum + 1).padStart(3, '0')}`;
}

export function createImportBatch(data: {
  officeId?: string;
  officeName?: string;
  importDate?: string;
  membersCount: number;
  duplicatesCount: number;
  skippedCount: number;
  errorsCount: number;
  notes?: string;
  sourceType: 'csv' | 'paste' | 'api';
}): ImportBatch {
  const batches = getImportBatches();
  const batchNumber = generateBatchNumber();
  const newBatch: ImportBatch = {
    id: 'batch_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
    batchNumber,
    officeId: data.officeId,
    officeName: data.officeName,
    importDate: data.importDate || new Date().toISOString(),
    membersCount: data.membersCount,
    duplicatesCount: data.duplicatesCount,
    skippedCount: data.skippedCount,
    errorsCount: data.errorsCount,
    notes: data.notes?.trim(),
    sourceType: data.sourceType,
    createdAt: new Date().toISOString(),
  }; 
  batches.unshift(newBatch);
  saveImportBatches(batches);
  
  // تحديث استخدام الخطابة
  if (data.officeId) incrementOfficeUsage(data.officeId);
  
  return newBatch;
}

export function getImportBatchById(id: string): ImportBatch | undefined {
  return getImportBatches().find(b => b.id === id);
}

export function getImportBatchByNumber(batchNumber: string): ImportBatch | undefined {
  return getImportBatches().find(b => b.batchNumber === batchNumber);
}

export function deleteImportBatch(id: string): void {
  const batches = getImportBatches().filter(b => b.id !== id);
  saveImportBatches(batches);
}

// ===== دوال الاستيراد =====

// تحليل CSV
export function parseCSV(csvText: string): { headers: string[]; rows: string[][]; errors: string[] } {
  const errors: string[] = []; 
  const lines = csvText.trim().split('\n');
  
  if (lines.length < 2) {
    errors.push('الملف يجب أن يحتوي على صف العناوين وصف البيانات على الأقل');
    return { headers: [], rows: [], errors }; 
  }
  
  // تحليل العناوين
  const headers = parseCSVLine(lines[0]);
  
  // تحليل الصفوف
  const rows: string[][] = []; 
  for (let i = 1; i < lines.length; i++) {
    try {
      const row = parseCSVLine(lines[i]);
      if (row.length !== headers.length) {
        errors.push(`الصف ${i + 1}: عدد الأعمدة (${row.length}) لا يطابق العناوين (${headers.length})`); 
      } else {
        rows.push(row); 
      }
    } catch (e) {
      errors.push(`الصف ${i + 1}: خطأ في تحليل البيانات`); 
    }
  }
  
  return { headers, rows, errors }; 
}

// تحليل صف CSV واحد
function parseCSVLine(line: string): string[] {
  const result: string[] = []; 
  let current = ''; 
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"'; 
        i++; 
      } else {
        inQuotes = !inQuotes; 
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim()); 
      current = ''; 
    } else {
      current += char; 
    }
  }
  
  result.push(current.trim()); 
  return result; 
}

// تحليل Paste (Tab-separated or comma-separated)
export function parsePastedData(text: string): { headers: string[]; rows: string[][]; errors: string[] } {
  const lines = text.trim().split('\n');
  const errors: string[] = []; 
  
  if (lines.length < 2) {
    errors.push('البيانات يجب أن تحتوي على صف العناوين وصف البيانات على الأقل');
    return { headers: [], rows: [], errors }; 
  }
  
  // تحديد الفاصل (Tab أو comma)
  const firstLine = lines[0];
  const separator = firstLine.includes('\t') ? '\t' : ',';
  
  const headers = firstLine.split(separator).map(h => h.trim());
  const rows: string[][] = []; 
  
  for (let i = 1; i < lines.length; i++) {
    const row = lines[i].split(separator).map(c => c.trim());
    if (row.length !== headers.length) {
      errors.push(`الصف ${i + 1}: عدد الأعمدة (${row.length}) لا يطابق العناوين (${headers.length})`); 
    } else {
      rows.push(row); 
    }
  }
  
  return { headers, rows, errors }; 
}

// التحقق من التكرار (بناءً على البريد الإلكتروني أو الهاتف)
export function checkDuplicates(
  data: Record<string, any>[],
  existingMembers: { email?: string; phone?: string; id?: string }[]
): { duplicates: Record<string, any>[]; unique: Record<string, any>[]; duplicateIndices: number[] } {
  const duplicates: Record<string, any>[] = []; 
  const unique: Record<string, any>[] = []; 
  const duplicateIndices: number[] = []; 
  
  const existingEmails = new Set(existingMembers.map(m => m.email?.toLowerCase()));
  const existingPhones = new Set(existingMembers.map(m => m.phone));
  
  data.forEach((item, idx) => {
    const email = item.email?.toLowerCase();
    const phone = item.phone;
    
    if (email && existingEmails.has(email) || phone && existingPhones.has(phone)) {
      duplicates.push(item);
      duplicateIndices.push(idx);
    } else {
      unique.push(item);
    }
  });
  
  return { duplicates, unique, duplicateIndices }; 
}

// توليد ID فريد للعضو
export function generateMemberId(): string {
  return 'm_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// حساب العمر من تاريخ الميلاد
export function calculateAgeFromBirthDate(birthDate: string): number {
  if (!birthDate) return 0;
  const birth = new Date(birthDate);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--; 
  }
  return age;
}

// تحويل الحالة الاجتماعية إلى النص العربي
export function getMaritalLabel(status: string, gender: 'male' | 'female'): string {
  const labels: Record<string, Record<string, string>> = {
    male: { single: 'أعزب', divorced: 'مطلق', widower: 'أرمل', married: 'متزوج' },
    female: { single: 'عزباء', divorced: 'مطلقة', widow: 'أرملة' },
  }; 
  return labels[gender]?.[status] || status;
}

// تنظيف وتجهيز بيانات العضو المستورد - مرن مع الحقول الناقصة
export function prepareImportedMember(
  data: Record<string, any>,
  batchId: string,
  officeName?: string,
  importDate?: string,
  notes?: string
): Record<string, any> {
  // تحديد الجنس - افتراضي ذكر
  const gender = (data.gender || data['الجنس'] || 'male').toString().toLowerCase();
  const isMale = gender === 'male' || gender === 'ذكر' || gender === 'm';
  
  // حساب العمر من تاريخ الميلاد أو استخدام قيمة افتراضية
  const age = Number(data.age || data['العمر']) || calculateAgeFromBirthDate(data.birthDate || data.birth_date) || 25;
  
  // توليد ID فريد
  const memberId = generateMemberId();
  
  // توليد بريد افتراضي إذا لم يكن موجوداً
  const email = (data.email || data['البريد'] || '').toString().trim();
  const defaultEmail = `member_${memberId}@tawfok.temp`;
  
  // توليد هاتف افتراضي إذا لم يكن موجوداً
  const phone = (data.phone || data['الهاتف'] || '').toString().trim();
  const defaultPhone = '05' + Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
  
  return {
    id: memberId,
    // ===== البيانات الأساسية =====
    nickname: (data.nickname || data['الاسم المستعار'] || data.name || data['الاسم'] || `عضو_${memberId.slice(-4)}`).toString().trim(),
    gender: isMale ? 'male' : 'female',
    age: age,
    birthDate: (data.birthDate || data.birth_date || data['تاريخ الميلاد'] || '').toString().trim(),
    country: (data.country || data['الدولة'] || 'السعودية').toString().trim(),
    city: (data.city || data['المدينة'] || 'الرياض').toString().trim(),
    district: (data.district || data['الحي'] || data['المنطقة'] || '').toString().trim(),
    nationality: (data.nationality || data['الجنسية'] || data.country || 'السعودية').toString().trim(),
    sect: (data.sect || data['المذهب'] || 'سني').toString().trim(),
    sectOther: (data.sectOther || data.sect_other || '').toString().trim(),
    maritalStatus: (data.maritalStatus || data.marital_status || data['الحالة الاجتماعية'] || 'single').toString().toLowerCase(),
    maritalLabel: getMaritalLabel(data.maritalStatus || data.marital_status || 'single', isMale ? 'male' : 'female'),
    hasChildren: data.hasChildren === 'yes' || data.has_children === 'yes' || data['أبناء'] === 'نعم' || data.hasChildren === true,
    childrenCount: (data.childrenCount || data.children_count || data['عدد الأبناء'] || 'لا يوجد').toString().trim(),
    childrenLiveWith: (data.childrenLiveWith || data.children_live_with || '').toString().trim(),
    wifeCount: (data.wifeCount || data.wife_count || '').toString().trim(),
    seekingWife: (data.seekingWife || data.seeking_wife || '').toString().trim(),
    // ===== المواصفات الشخصية =====
    height: Number(data.height || data['الطول']) || 170,
    weight: Number(data.weight || data['الوزن']) || 70,
    skinColor: (data.skinColor || data.skin_color || data['لون البشرة'] || 'حنطي').toString().trim(),
    ethnicity: (data.ethnicity || data['العرق'] || 'عربي').toString().trim(),
    health: (data.health || data['الحالة الصحية'] || 'ممتازة').toString().trim(),
    smoking: (data.smoking || data['التدخين'] || 'لا أدخن').toString().trim(),
    education: (data.education || data['المؤهل'] || 'بكالوريوس').toString().trim(),
    workType: (data.workType || data.work_type || data['نوع العمل'] || 'حكومي').toString().trim(),
    jobTitle: (data.jobTitle || data.job_title || data['المسمى الوظيفي'] || '').toString().trim(),
    housing: (data.housing || data['السكن'] || 'أسكن مع العائلة').toString().trim(),
    bio: (data.bio || data['نبذة'] || data['عني'] || 'عضو جديد في منصة توافق').toString().trim(),
    // ===== خيارات النساء =====
    acceptPolygamy: (data.acceptPolygamy || data.accept_polygamy || '').toString().trim(),
    acceptDivorced: (data.acceptDivorced || data.accept_divorced || '').toString().trim(),
    acceptWithChildren: (data.acceptWithChildren || data.accept_with_children || '').toString().trim(),
    // ===== مواصفات الشريك =====
    pCountry: (data.pCountry || data.partner_country || data['دولة الشريك'] || '').toString().trim(),
    pCity: (data.pCity || data.partner_city || data['مدينة الشريك'] || '').toString().trim(),
    pAgeMin: Number(data.pAgeMin || data.partner_age_min || data['العمر من']) || 22,
    pAgeMax: Number(data.pAgeMax || data.partner_age_max || data['العمر إلى']) || 35,
    pNationality: (data.pNationality || data.partner_nationality || '').toString().trim(),
    pMaritalStatus: (data.pMaritalStatus || data.partner_marital_status || '').toString().trim(),
    pAcceptChildren: (data.pAcceptChildren || data.partner_accept_children || '').toString().trim(),
    pSect: (data.pSect || data.partner_sect || '').toString().trim(),
    pSectOther: (data.pSectOther || data.partner_sect_other || '').toString().trim(),
    pEducation: (data.pEducation || data.partner_education || '').toString().trim(),
    pWorkType: (data.pWorkType || data.partner_work_type || '').toString().trim(),
    pReligionLevel: (data.pReligionLevel || data.partner_religion_level || '').toString().trim(),
    pSkinColor: (data.pSkinColor || data.partner_skin_color || '').toString().trim(),
    pHeight: Number(data.pHeight || data.partner_height) || 170,
    pHeightNoMatter: data.pHeightNoMatter === true || data.partner_height_no_matter === 'true',
    pHousing: (data.pHousing || data.partner_housing || '').toString().trim(),
    pNotes: (data.pNotes || data.partner_notes || '').toString().trim(),
    // ===== بيانات الإدارة =====
    realName: (data.realName || data.real_name || data['الاسم الحقيقي'] || `عضو_${memberId.slice(-4)}`).toString().trim(),
    phone: phone || defaultPhone,
    whatsapp: (data.whatsapp || '').toString().trim(),
    email: email || defaultEmail,
    password: (data.password || data['كلمة المرور'] || 'Pass@1234').toString().trim(),
    // ===== حالة الحساب =====
    verified: false,
    premium: false,
    online: false,
    lastActive: new Date().toISOString(),
    aboutPartner: (data.aboutPartner || data.partner_notes || '').toString().trim(),
    // ===== بيانات الاستيراد =====
    sourceType: 'imported',
    importBatchId: batchId,
    importOfficeName: officeName || '',
    importDate: importDate || new Date().toISOString(),
    importNotes: notes || '',
    // ===== بيانات الإدارة =====
    status: 'pending',
    plan: 'free',
    joinedAt: new Date().toLocaleDateString('ar-SA'),
    requestsCount: 0,
  }; 
}

// إنشاء تقرير الاستيراد
export function createImportReport(
  totalRows: number,
  imported: number,
  duplicates: number,
  skipped: number,
  errors: ImportError[],
  warnings: ImportWarning[],
  batch: ImportBatch
): ImportReport {
  return {
    batchId: batch.id,
    totalRows,
    importedCount: imported,
    duplicatesCount: duplicates,
    skippedCount: skipped,
    errorsCount: errors.length,
    errors,
    warnings,
    officeName: batch.officeName,
    batchNumber: batch.batchNumber,
    importDate: batch.importDate,
  }; 
}

// إعادة تعيين جميع البيانات
export function resetImportData(): void {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(STORAGE_KEYS.offices);
  window.localStorage.removeItem(STORAGE_KEYS.batches);
}
