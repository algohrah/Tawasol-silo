// معطّل — التطبيق يعمل محلياً بالكامل (localStorage) بدون قاعدة بيانات.
export default function handler(_req, res) {
  res.status(410).json({ error: 'هذا المسار معطّل. التطبيق يعمل محلياً.' });
}
