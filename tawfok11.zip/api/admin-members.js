// معطّل — التطبيق يعمل محلياً بالكامل.
export default function handler(_req, res) {
  res.status(410).json({ error: 'معطّل' });
}
