import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LifeBuoy, MessageCircle, Mail, Phone, BookOpen, ChevronLeft, Download, FileArchive } from 'lucide-react';

const topics = [
  { icon: MessageCircle, title: 'المساعدة في الحساب', desc: 'تسجيل الدخول، إعادة تعيين كلمة المرور، إعدادات الحساب', to: '/faq' },
  { icon: BookOpen, title: 'دليل استخدام المنصة', desc: 'كيفية إنشاء ملف جذاب، البحث، والرسائل', to: '/blog' },
  { icon: Mail, title: 'مشاكل الاشتراك', desc: 'الباقات، الدفع، والاسترداد', to: '/plans' },
  { icon: LifeBuoy, title: 'الأمان والخصوصية', desc: 'الإبلاغ، الحظر، وحماية البيانات', to: '/privacy' },
];

export default function Support() {
  return (
    <div className="bg-cream-50 min-h-screen">
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 py-14 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gold-300/15 mb-4">
            <LifeBuoy className="w-7 h-7 text-gold-300" />
          </div>
          <h1 className="font-cairo font-extrabold text-3xl sm:text-4xl text-white">الدعم الفني</h1>
          <p className="mt-3 text-cream-200/80 font-tajawal max-w-xl mx-auto">نحن هنا لمساعدتك في كل خطوة. اختر القسم المناسب أو تواصل معنا مباشرة.</p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
        {/* Quick links */}
        <div className="grid sm:grid-cols-2 gap-4 mb-10">
          {topics.map((t, i) => (
            <motion.div key={t.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Link to={t.to} className="block bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60 hover:shadow-luxe hover:border-gold-300 transition-all group">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gold-300/15 flex items-center justify-center flex-shrink-0">
                    <t.icon className="w-6 h-6 text-gold-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-cairo font-bold text-navy-900">{t.title}</h3>
                    <p className="text-sm text-navy-500 font-tajawal mt-1">{t.desc}</p>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-navy-300 group-hover:text-gold-600 transition-colors" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Direct contact */}
        <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-6 sm:p-8">
          <h2 className="font-cairo font-extrabold text-2xl text-navy-900 mb-2">تواصل معنا مباشرة</h2>
          <p className="text-navy-600 font-tajawal mb-6">فريق الدعم متاح على مدار الساعة لمساعدتك.</p>
          <div className="grid sm:grid-cols-2 gap-4">
            <a href="mailto:support@tawasul.sa" className="flex items-center gap-4 p-5 rounded-2xl bg-cream-50 border border-cream-200 hover:border-gold-300 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-gold-300/15 flex items-center justify-center flex-shrink-0"><Mail className="w-6 h-6 text-gold-600" /></div>
              <div><div className="font-cairo font-bold text-navy-900">البريد</div><div className="text-sm text-navy-500 font-tajawal">support@tawasul.sa</div></div>
            </a>
            <a href="tel:+966112345678" className="flex items-center gap-4 p-5 rounded-2xl bg-cream-50 border border-cream-200 hover:border-gold-300 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-gold-300/15 flex items-center justify-center flex-shrink-0"><Phone className="w-6 h-6 text-gold-600" /></div>
              <div><div className="font-cairo font-bold text-navy-900">الهاتف</div><div className="text-sm text-navy-500 font-tajawal">+966 11 234 5678</div></div>
            </a>
          </div>
        </div>

        {/* Project download */}
        <div className="mt-6 bg-navy-gradient rounded-3xl p-6 sm:p-8 relative overflow-hidden">
          <div className="absolute inset-0 pattern-arabesque opacity-30" />
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-gold-500/20 rounded-full blur-3xl" />
          <div className="relative flex flex-col sm:flex-row items-center gap-5">
            <div className="w-16 h-16 rounded-2xl bg-gold-gradient flex items-center justify-center flex-shrink-0 shadow-gold">
              <FileArchive className="w-8 h-8 text-navy-900" />
            </div>
            <div className="flex-1 text-center sm:text-right">
              <h2 className="font-cairo font-extrabold text-xl text-white">توافق اصدار 10</h2>
              <p className="text-cream-200/70 font-tajawal text-sm mt-1">حزمة الكود الكاملة — نسخة محلية تعمل بدون قاعدة بيانات (بدون node_modules)</p>
            </div>
            <a
              href="/tawfok10.zip"
              download="tawfok10.zip"
              className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-gold hover:-translate-y-0.5 transition-all whitespace-nowrap"
            >
              <Download className="w-5 h-5" /> تحميل الآن
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
