import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate, Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Loader2, AlertCircle, BadgeCheck, MapPin, Check, Info, X,
  ShieldCheck, MessageSquare, Send as SendIcon, CalendarClock, Heart,
  Sparkles, Coins, AlertTriangle, ChevronLeft, LifeBuoy, Eye, Gem, Ban,
  Phone, Lock, Clock,
} from 'lucide-react';
import { getAvatar, getGenderColors } from '../lib/types';
import {
  fetchRequest, fetchRequestEvents, fetchInquiry, buyInquiryPackage, sendInquiryMessage,
  fetchMembers, runActionStandalone, simulateInquiryReply, markRequestSeen,
  getCurrentUserId, type ApiRequest, type RequestEvent, type InquiryState,
} from '../lib/useInterestRequests';
import { useSettings } from '../lib/useSettings';
import {
  JOURNEY_STAGES, STAGE_INDEX, STAGE_META, ACCENT_CLASSES, legacyToJourney,
  isTerminal, DECLINE_REASONS, CANCEL_REASONS,
  type JourneyState,
} from '../lib/journey';

function stageOf(r: ApiRequest): JourneyState {
  const valid = ['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed', 'declined', 'cancelled'];
  if (valid.includes(r.journey_stage)) return r.journey_stage as JourneyState;
  return legacyToJourney(r.journey_stage);
}

export default function JourneyPage() {
  const { requestId } = useParams();
  const rid = Number(requestId);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get('tab'); // 'inquiry' | 'deposit'

  // تعليم الطلب كمقروء عند فتح رحلته
  useEffect(() => { if (rid) markRequestSeen(rid); }, [rid]);

  const [req, setReq] = useState<ApiRequest | null>(null);
  const [events, setEvents] = useState<RequestEvent[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [inquiry, setInquiry] = useState<InquiryState>({ package: null, remaining: 0, messages: [] });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ text: string; type: string } | null>(null);
  const [cancelOpen, setCancelOpen] = useState(false);

  const showToast = (text: string, type = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3200);
  };

  const load = useCallback(async () => {
    const [r, ev, inq, mem] = await Promise.all([
      fetchRequest(rid),
      fetchRequestEvents(rid),
      fetchInquiry(rid),
      fetchMembers(),
    ]);
    setReq(r);
    setEvents(ev);
    setInquiry(inq);
    setMembers(mem);
    setLoading(false);
  }, [rid]);

  useEffect(() => { load(); }, [load]);

  const runAction = async (action: string, payload: Record<string, any> = {}) => {
    setBusy(true);
    try {
      const res = await runActionStandalone(rid, action, getCurrentUserId(), payload);
      if (!res.ok) { showToast(res.error || 'فشل الإجراء', 'error'); return false; }
      await load();
      return true;
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-cream-50 flex flex-col items-center justify-center" dir="rtl">
        <Loader2 className="w-10 h-10 animate-spin text-gold-500 mb-3" />
        <p className="font-cairo text-navy-500">جارٍ فتح رحلتك...</p>
      </div>
    );
  }

  if (!req) {
    return (
      <div className="min-h-screen bg-cream-50 flex flex-col items-center justify-center px-6 text-center" dir="rtl">
        <AlertCircle className="w-12 h-12 text-rose-400 mb-3" />
        <p className="font-cairo font-bold text-navy-700 mb-4">تعذّر العثور على هذا الطلب</p>
        <Link to="/requests" className="text-gold-700 font-cairo font-bold underline">العودة لطلباتي</Link>
      </div>
    );
  }

  const stage = stageOf(req);
  const isSender = req.sender_id === getCurrentUserId();
  const other = members.find((m) => m.id === (isSender ? req.receiver_id : req.sender_id));
  const colors = other ? getGenderColors(other.gender) : getGenderColors('male');
  const currentIdx = isTerminal(stage) ? -1 : STAGE_INDEX[stage as keyof typeof STAGE_INDEX];
  const progress = isTerminal(stage) ? 0 : Math.round(((currentIdx) / (JOURNEY_STAGES.length - 1)) * 100);

  return (
    <div className="min-h-screen bg-cream-50 pb-20" dir="rtl">
      {/* ===== الطبقة 1: رأس ثابت ===== */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-lg border-b border-cream-200 shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/requests')}
              className="w-9 h-9 rounded-full bg-cream-100 hover:bg-cream-200 flex items-center justify-center text-navy-600 flex-shrink-0 transition-colors">
              <ArrowRight className="w-5 h-5" />
            </button>
            {other && (
              <Link to={`/member/${other.id}`} className="flex items-center gap-2.5 flex-1 min-w-0">
                <img src={getAvatar(other.gender)} alt={other.nickname}
                  className={`w-10 h-10 rounded-xl object-cover ring-2 ${colors.ring} ring-offset-1`} />
                <div className="min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-cairo font-extrabold text-navy-900 truncate">{other.nickname}</span>
                    {other.verified && <BadgeCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />}
                  </div>
                  <span className="text-[11px] text-navy-400 font-cairo flex items-center gap-1">
                    <MapPin className="w-3 h-3" />{other.city}
                  </span>
                </div>
              </Link>
            )}
            <a href="/support" className="w-9 h-9 rounded-full bg-blue-50 hover:bg-blue-100 flex items-center justify-center text-blue-500 flex-shrink-0 transition-colors" title="تواصل مع الوسيطة">
              <LifeBuoy className="w-5 h-5" />
            </a>
          </div>
          {/* شريط التقدّم */}
          {!isTerminal(stage) && (
            <div className="mt-2.5">
              <div className="flex items-center justify-between text-[11px] font-cairo font-bold text-navy-400 mb-1">
                <span>المرحلة {currentIdx + 1} من {JOURNEY_STAGES.length}</span>
                <span>{progress}% من الرحلة</span>
              </div>
              <div className="h-1.5 bg-cream-200 rounded-full overflow-hidden">
                <motion.div className="h-full bg-gold-gradient rounded-full"
                  initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.6 }} />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4">
        {/* ===== الطبقة 2: المرحلة النشطة (Hero) ===== */}
        <div className="mt-5">
          <ActiveStagePanel
            req={req} stage={stage} isSender={isSender} other={other} busy={busy}
            self={members.find((m) => m.id === getCurrentUserId())}
            inquiry={inquiry} setInquiry={setInquiry} reload={load} showToast={showToast}
            runAction={runAction} initialTab={initialTab}
          />
          {/* #7 معاينة المرحلة القادمة */}
          <NextStepHint stage={stage} />
        </div>

        {/* ===== الطبقة 3: خريطة الرحلة الكاملة (عمودية) ===== */}
        <div className="mt-6">
          <h3 className="font-cairo font-extrabold text-navy-800 mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-gold-500" /> خريطة رحلتك الكاملة
          </h3>
          <VerticalJourney stage={stage} events={events} />
        </div>

        {/* ===== إلغاء الطلب — متاح في أي مرحلة نشطة ===== */}
        {!isTerminal(stage) && (
          <div className="mt-6 bg-white rounded-2xl border border-rose-100 p-4">
            <div className="flex items-start gap-2.5 mb-3">
              <Ban className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-navy-500 font-cairo leading-relaxed">
                يمكنك إلغاء هذا الطلب في أي مرحلة مع ذكر السبب. لا تُسترد رسوم العربون عند الإلغاء وفق عهد الجدية.
              </p>
            </div>
            <button onClick={() => setCancelOpen(true)} disabled={busy}
              className="w-full flex items-center justify-center gap-1.5 text-sm font-cairo font-bold text-rose-500 border border-rose-200 hover:bg-rose-50 rounded-2xl py-2.5 transition-colors disabled:opacity-60">
              <Ban className="w-4 h-4" /> إلغاء الطلب
            </button>
          </div>
        )}

        {/* العودة لقائمة الطلبات (البطاقات الصغيرة) */}
        <button onClick={() => navigate('/requests')}
          className="mt-6 mb-2 w-full flex items-center justify-center gap-2 text-sm font-cairo font-bold text-navy-600 bg-cream-100 hover:bg-cream-200 rounded-2xl py-3.5 transition-colors">
          <ArrowRight className="w-4 h-4" /> العودة لقائمة طلباتي
        </button>
      </div>

      {/* حوار الإلغاء */}
      <CancelDialog open={cancelOpen} onClose={() => setCancelOpen(false)} busy={busy}
        onConfirm={async (reason: string) => {
          const ok = await runAction('cancel', { reason });
          setCancelOpen(false);
          if (ok) showToast('تم إلغاء الطلب', 'info');
        }} />

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }} animate={{ opacity: 1, y: 0, x: '-50%' }} exit={{ opacity: 0, y: 50, x: '-50%' }}
            className={`fixed bottom-6 left-1/2 z-[100] px-5 py-3 rounded-2xl shadow-2xl font-cairo font-bold text-sm text-white max-w-[90%]
              ${toast.type === 'success' ? 'bg-emerald-600' : toast.type === 'error' ? 'bg-rose-deep' : 'bg-navy-800'}`}>
            {toast.text}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ============================================================
//  الطبقة 2 — لوحة المرحلة النشطة (تتغيّر حسب المرحلة)
// ============================================================
function ActiveStagePanel({
  req, stage, isSender, other, self, busy, inquiry, setInquiry, reload, showToast, runAction, initialTab,
}: any) {
  const meta = STAGE_META[stage as JourneyState];
  const c = ACCENT_CLASSES[meta.accent];
  const Icon = meta.icon;

  // حالات المسارات الجانبية
  if (stage === 'declined' || stage === 'cancelled') {
    return (
      <div className={`rounded-3xl ${c.bgSoft} border ${c.border} p-6 text-center`}>
        <div className={`w-14 h-14 rounded-2xl ${c.bg} flex items-center justify-center text-white mx-auto mb-3`}>
          <Icon className="w-7 h-7" />
        </div>
        <h2 className={`font-cairo font-extrabold text-xl ${c.text}`}>{meta.title}</h2>
        <p className="text-sm text-navy-600 font-cairo mt-2">{meta.whereYouAre}</p>
        {(req.decline_reason || req.cancel_reason) && (
          <p className="text-xs text-navy-500 font-cairo mt-3 bg-white/60 rounded-xl p-2.5">
            السبب: {req.decline_reason || req.cancel_reason}
          </p>
        )}
        <Link to="/search" className="inline-block mt-4 bg-navy-900 text-white font-cairo font-bold px-6 py-3 rounded-2xl">
          ابدأ بحثاً جديداً
        </Link>
      </div>
    );
  }

  // المرحلة: مُرسَل
  if (stage === 'sent') {
    if (!isSender) {
      // المستقبِل يرى قرار القبول/الإلغاء
      return <DecisionPanel req={req} other={other} busy={busy} runAction={runAction} showToast={showToast} mode="incoming" />;
    }
    return (
      <HeroCard meta={meta} c={c} Icon={Icon}>
        <p className="text-sm text-navy-600 font-cairo leading-relaxed">{meta.whatToDo}</p>
        <div className="mt-3 bg-cream-50 rounded-xl p-3 text-center text-sm font-cairo font-bold text-navy-500">
          بانتظار رد {other?.nickname || 'الطرف الآخر'}...
        </div>
      </HeroCard>
    );
  }

  // المرحلة: مقبول → صفحة واحدة فيها (استفسار + عربون) أو الإلغاء
  if (stage === 'accepted') {
    return <AcceptedHub req={req} other={other} busy={busy} inquiry={inquiry} setInquiry={setInquiry} reload={reload} showToast={showToast} runAction={runAction} initialTab={initialTab} />;
  }

  // المرحلة: تأكيد الجدية (عربون)
  if (stage === 'seriousness') {
    return <DepositPanel req={req} isSender={isSender} busy={busy} runAction={runAction} showToast={showToast} />;
  }

  // تبادل التواصل (التنسيق)
  if (stage === 'coordination') {
    return (
      <HeroCard meta={meta} c={c} Icon={Icon}>
        <p className="text-sm text-navy-600 font-cairo leading-relaxed">{meta.whereYouAre}</p>
        {req.meeting_date ? (
          <div className={`mt-3 rounded-xl p-3 ${c.bgSoft} border ${c.border}`}>
            <div className={`flex items-center gap-1.5 ${c.text} font-cairo font-bold text-sm mb-1`}>
              <CalendarClock className="w-4 h-4" /> الموعد
            </div>
            <p className="font-cairo text-navy-800 font-bold text-sm">{req.meeting_date}</p>
            {req.meeting_notes && <p className="text-xs text-navy-500 font-cairo mt-1">{req.meeting_notes}</p>}
          </div>
        ) : (
          <div className="mt-3 bg-cream-50 border border-cream-200 rounded-xl p-3 text-center">
            <Loader2 className="w-5 h-5 text-blue-400 mx-auto mb-1 animate-spin" />
            <p className="text-xs font-cairo text-navy-500">الإدارة تنسّق الموعد حالياً.</p>
          </div>
        )}

        {/* ===== مشاركة معلومات التواصل (الأنثى تُدخل، الذكر يطّلع بعد القَسَم) ===== */}
        <ContactExchange req={req} self={self} busy={busy} runAction={runAction} showToast={showToast} />

        {/* المتابعة للنظرة الشرعية بعد اكتمال تبادل التواصل واطّلاع الطرف الآخر */}
        {(req.guardian_phone || req.contact_info) && req.male_pledged && (
          <button onClick={() => runAction('advance_viewing')} disabled={busy}
            className="w-full mt-4 bg-indigo-500 text-white font-cairo font-bold py-3.5 rounded-2xl hover:brightness-105 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Heart className="w-4 h-4" />} المتابعة للنظرة الشرعية
          </button>
        )}
        {(req.guardian_phone || req.contact_info) && !req.male_pledged && self?.gender === 'female' && (
          <p className="mt-3 text-center text-[11px] font-cairo text-navy-400">
            بانتظار اطّلاع الطرف الآخر على المعلومات للمتابعة للنظرة الشرعية.
          </p>
        )}
      </HeroCard>
    );
  }

  // النظرة الشرعية — تسجيل النتيجة (توافق -> الملكة، اعتذار مع سبب -> مرفوض)
  if (stage === 'sharia_viewing') {
    return (
      <HeroCard meta={meta} c={c} Icon={Icon}>
        <p className="text-sm text-navy-600 font-cairo leading-relaxed">{meta.whereYouAre}</p>
        {req.meeting_date && (
          <div className={`mt-3 rounded-xl p-3 ${c.bgSoft} border ${c.border}`}>
            <div className={`flex items-center gap-1.5 ${c.text} font-cairo font-bold text-sm mb-1`}>
              <Eye className="w-4 h-4" /> موعد النظرة
            </div>
            <p className="font-cairo text-navy-800 font-bold text-sm">{req.meeting_date}</p>
            {req.meeting_notes && <p className="text-xs text-navy-500 font-cairo mt-1">{req.meeting_notes}</p>}
          </div>
        )}
        <RecordResultButton req={req} busy={busy} runAction={runAction} />
      </HeroCard>
    );
  }

  // الملكة — إتمام العقد ورسوم السعي النهائية
  if (stage === 'engagement') {
    return <EngagementPanel req={req} busy={busy} runAction={runAction} showToast={showToast} meta={meta} c={c} Icon={Icon} />;
  }

  // مكتمل
  return (
    <HeroCard meta={meta} c={c} Icon={Icon}>
      <p className="text-sm text-navy-600 font-cairo leading-relaxed">{meta.whereYouAre}</p>
      {req.evaluation_note && (
        <div className="mt-3 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-sm font-cairo text-emerald-700">
          {req.evaluation_result === 'failed' ? '🤝 ' : '💚 '}{req.evaluation_note}
        </div>
      )}
    </HeroCard>
  );
}

// ============================================================
//  لوحة الملكة — رسوم السعي النهائية + إتمام العقد
// ============================================================
function EngagementPanel({ req, busy, runAction, showToast, meta, c, Icon }: any) {
  const { settings } = useSettings();
  const [pledge, setPledge] = useState(false);
  const complete = async () => {
    if (!pledge) { showToast('يرجى تأكيد إتمام إجراءات العقد', 'error'); return; }
    const ok = await runAction('complete_engagement');
    if (ok) showToast('🎉 مبارك! تمت الملكة بنجاح');
  };
  return (
    <HeroCard meta={meta} c={c} Icon={Icon}>
      <p className="text-sm text-navy-600 font-cairo leading-relaxed">{meta.whereYouAre}</p>
      <div className="mt-3 bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
        <Gem className="w-8 h-8 text-amber-600 mx-auto mb-2" />
        <p className="font-cairo font-extrabold text-2xl text-amber-700">{settings.final_fee_amount} <span className="text-sm">ريال</span></p>
        <p className="text-xs text-navy-500 font-cairo mt-1">رسوم السعي النهائية — تُسدّد عند إتمام الملكة إبراءً للذمة</p>
      </div>
      <label className="flex items-start gap-2.5 mt-4 p-3 rounded-xl bg-cream-50 border border-cream-200 cursor-pointer">
        <input type="checkbox" checked={pledge} onChange={(e) => setPledge(e.target.checked)} className="mt-0.5 accent-gold-500" />
        <span className="text-xs font-cairo text-navy-600 leading-relaxed">
          أؤكّد إتمام إجراءات عقد القران مع الإدارة وسداد رسوم السعي النهائية وفق العهد المتفق عليه.
        </span>
      </label>
      <button onClick={complete} disabled={!pledge || busy}
        className="w-full mt-4 bg-gold-gradient text-navy-900 font-cairo font-extrabold py-3.5 rounded-2xl shadow-gold hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:translate-y-0 flex items-center justify-center gap-2">
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Gem className="w-5 h-5" />} إتمام الملكة وإنهاء الرحلة
      </button>
    </HeroCard>
  );
}

// ============================================================
//  مشاركة معلومات التواصل
//  الأنثى تُدخل رقم ولي الأمر → الذكر يراه بعد القَسَم بعدم النشر
// ============================================================
const GUARDIAN_RELATIONS = ['الأب', 'الأخ', 'العم', 'الخال', 'الجد', 'ولي الأمر'];

function ContactExchange({ req, self, busy, runAction, showToast }: any) {
  const isFemale = self?.gender === 'female';
  const submitted = !!req.guardian_phone || !!req.contact_info;

  // نموذج إدخال الأنثى
  const [phone, setPhone] = useState('');
  const [gName, setGName] = useState('');
  const [gRel, setGRel] = useState('');
  const [time, setTime] = useState('');
  const [note, setNote] = useState('');

  // قَسَم الذكر
  const [pledged, setPledged] = useState(false);

  const submit = async () => {
    if (!phone.trim()) { showToast('رقم ولي الأمر مطلوب', 'error'); return; }
    const ok = await runAction('submit_contact', {
      guardianPhone: phone.trim(), guardianName: gName.trim(),
      guardianRelation: gRel, contactTime: time.trim(), contactNote: note.trim(),
    });
    if (ok) showToast('تمت مشاركة معلومات التواصل بإشراف الإدارة ✓');
  };

  const doPledge = async () => {
    const ok = await runAction('male_pledge', {});
    if (ok) showToast('تم تأكيد التعهّد — تظهر لك معلومات التواصل الآن', 'success');
  };

  // ===== الحالة 1: لم تُدخل الأنثى المعلومات بعد =====
  if (!submitted) {
    if (isFemale) {
      // نموذج إدخال الأنثى
      return (
        <div className="mt-3 rounded-2xl p-4 bg-cream-50 border border-cream-200">
          <div className="flex items-center gap-1.5 text-navy-800 font-cairo font-extrabold text-sm mb-1">
            <Phone className="w-4 h-4 text-indigo-500" /> مشاركة معلومات التواصل
          </div>
          <p className="text-[11px] text-navy-500 font-cairo mb-3 leading-relaxed">
            تُشارَك هذه المعلومات بإشراف الإدارة، ولن تظهر للطرف الآخر إلا بعد تعهّده بعدم نشرها والتواصل بنية الزواج فقط.
          </p>

          <label className="block text-[11px] font-cairo font-bold text-navy-600 mb-1">📱 رقم ولي الأمر <span className="text-rose-500">*</span></label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" placeholder="مثال: 05xxxxxxxx"
            className="w-full bg-white border border-cream-200 rounded-xl px-3 py-2.5 text-sm font-cairo mb-3 focus:outline-none focus:ring-2 focus:ring-indigo-200" />

          <div className="grid grid-cols-2 gap-2 mb-3">
            <div>
              <label className="block text-[11px] font-cairo font-bold text-navy-600 mb-1">👤 اسم ولي الأمر</label>
              <input value={gName} onChange={(e) => setGName(e.target.value)} placeholder="اختياري"
                className="w-full bg-white border border-cream-200 rounded-xl px-3 py-2.5 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-indigo-200" />
            </div>
            <div>
              <label className="block text-[11px] font-cairo font-bold text-navy-600 mb-1">صلة القرابة</label>
              <select value={gRel} onChange={(e) => setGRel(e.target.value)}
                className="w-full bg-white border border-cream-200 rounded-xl px-3 py-2.5 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-indigo-200">
                <option value="">اختر</option>
                {GUARDIAN_RELATIONS.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
          </div>

          <label className="block text-[11px] font-cairo font-bold text-navy-600 mb-1">⏰ الوقت المناسب للاتصال</label>
          <input value={time} onChange={(e) => setTime(e.target.value)} placeholder="مثال: بعد العصر، من 5 إلى 8 مساءً"
            className="w-full bg-white border border-cream-200 rounded-xl px-3 py-2.5 text-sm font-cairo mb-3 focus:outline-none focus:ring-2 focus:ring-indigo-200" />

          <label className="block text-[11px] font-cairo font-bold text-navy-600 mb-1">📝 ملاحظة (اختياري)</label>
          <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="مثال: يُفضّل التواصل عبر الأب فقط"
            className="w-full bg-white border border-cream-200 rounded-xl px-3 py-2.5 text-sm font-cairo mb-3 focus:outline-none focus:ring-2 focus:ring-indigo-200" />

          <button onClick={submit} disabled={busy || !phone.trim()}
            className="w-full bg-indigo-500 text-white font-cairo font-bold py-3 rounded-xl hover:brightness-105 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <SendIcon className="w-4 h-4 -scale-x-100" />} مشاركة بإشراف الإدارة
          </button>
        </div>
      );
    }
    // الذكر ينتظر إدخال الأنثى
    return (
      <div className="mt-3 rounded-2xl p-4 bg-blue-50 border border-blue-200 text-center">
        <Loader2 className="w-6 h-6 text-blue-400 mx-auto mb-2 animate-spin" />
        <p className="text-sm font-cairo font-bold text-blue-700 mb-0.5">بانتظار مشاركة معلومات التواصل</p>
        <p className="text-xs font-cairo text-navy-500 leading-relaxed">
          يقوم الطرف الآخر بمشاركة رقم ولي الأمر عبر الوسيطة. ستظهر لك هنا فور إرسالها.
        </p>
      </div>
    );
  }

  // ===== الحالة 2: أُدخلت المعلومات =====
  // الأنثى ترى تأكيداً أنها شاركت
  if (isFemale) {
    return (
      <div className="mt-3 rounded-2xl p-4 bg-emerald-50 border border-emerald-200">
        <div className="flex items-center gap-1.5 text-emerald-700 font-cairo font-bold text-sm mb-1">
          <Check className="w-4 h-4" /> تمت مشاركة معلومات التواصل
        </div>
        <ContactDetails req={req} />
        <p className="text-[10px] text-navy-400 font-cairo mt-2">
          {req.male_pledged ? 'اطّلع الطرف الآخر على المعلومات بعد تعهّده.' : 'ستظهر للطرف الآخر بعد تعهّده بعدم نشرها.'}
        </p>
      </div>
    );
  }

  // الذكر: يجب أن يُقسم أولاً قبل رؤية المعلومات
  if (!req.male_pledged) {
    return (
      <div className="mt-3 rounded-2xl p-4 bg-amber-50 border border-amber-200">
        <div className="flex items-center gap-1.5 text-amber-700 font-cairo font-extrabold text-sm mb-2">
          <Lock className="w-4 h-4" /> تعهّد قبل الاطّلاع
        </div>
        <label className="flex items-start gap-2.5 p-3 rounded-xl bg-white border border-amber-200 cursor-pointer">
          <input type="checkbox" checked={pledged} onChange={(e) => setPledged(e.target.checked)} className="mt-0.5 accent-amber-500" />
          <span className="text-xs font-cairo text-navy-700 leading-relaxed">
            أُقسم بالله أن لا أنشر أو أشارك معلومات التواصل مع أي جهة، وأن أتواصل بنية الزواج الجادّ فقط، وأتحمّل المسؤولية الكاملة أمام الله ثم الإدارة.
          </span>
        </label>
        <button onClick={doPledge} disabled={busy || !pledged}
          className="w-full mt-3 bg-amber-500 text-white font-cairo font-bold py-3 rounded-xl hover:brightness-105 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />} أتعهّد وأطّلع على المعلومات
        </button>
      </div>
    );
  }

  // الذكر بعد القَسَم: يرى المعلومات
  return (
    <div className="mt-3 rounded-2xl p-4 bg-emerald-50 border border-emerald-200">
      <div className="flex items-center gap-1.5 text-emerald-700 font-cairo font-bold text-sm mb-2">
        <Phone className="w-4 h-4" /> معلومات التواصل
      </div>
      <ContactDetails req={req} />
      <p className="text-[10px] text-navy-400 font-cairo mt-2">
        تواصل بأدب واحترام بنية الزواج فقط. حفظ المعلومات أمانة شرعية.
      </p>
    </div>
  );
}

// عرض تفاصيل التواصل بشكل منظّم
function ContactDetails({ req }: any) {
  const rows = [
    { icon: '👤', label: 'ولي الأمر', value: req.guardian_name ? `${req.guardian_name}${req.guardian_relation ? ' — ' + req.guardian_relation : ''}` : req.guardian_relation },
    { icon: '📱', label: 'رقم التواصل', value: req.guardian_phone },
    { icon: '⏰', label: 'الوقت المناسب', value: req.contact_time },
    { icon: '📝', label: 'ملاحظة', value: req.contact_note },
  ].filter((r) => r.value);

  if (rows.length === 0 && req.contact_info) {
    return <p className="font-cairo text-navy-800 font-bold text-sm break-words">{req.contact_info}</p>;
  }

  return (
    <div className="space-y-1.5">
      {rows.map((r) => (
        <div key={r.label} className="flex items-center gap-2 bg-white/70 rounded-lg px-2.5 py-1.5">
          <span className="text-sm">{r.icon}</span>
          <span className="text-[11px] font-cairo text-navy-400 w-20 flex-shrink-0">{r.label}</span>
          <span className="text-sm font-cairo font-bold text-navy-800 break-words">{r.value}</span>
        </div>
      ))}
    </div>
  );
}

// بطاقة Hero عامة
function HeroCard({ meta, c, Icon, children }: any) {
  return (
    <div className="rounded-3xl bg-white border border-cream-200 shadow-soft overflow-hidden">
      <div className={`${c.bgSoft} border-b ${c.border} px-5 py-4 flex items-center gap-3`}>
        <div className={`w-12 h-12 rounded-2xl ${c.bg} flex items-center justify-center text-white`}>
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <span className="text-[11px] font-cairo font-bold text-navy-400">المرحلة الحالية</span>
          <h2 className={`font-cairo font-extrabold text-lg ${c.text}`}>{meta.title}</h2>
        </div>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

// ============================================================
//  مركز "مقبول" — الاستفسار + العربون في صفحة واحدة
// ============================================================
function AcceptedHub({ req, other, busy, inquiry, setInquiry, reload, showToast, runAction, initialTab }: any) {
  const [tab, setTab] = useState<'choose' | 'inquiry' | 'deposit'>(
    initialTab === 'inquiry' ? 'inquiry' : initialTab === 'deposit' ? 'deposit' : 'choose'
  );
  const [cancelOpen, setCancelOpen] = useState(false);
  const hasPackage = !!inquiry.package;

  // إذا اشترى باقة سابقاً، افتح تبويب الاستفسار
  useEffect(() => { if (hasPackage && tab === 'choose') setTab('inquiry'); }, [hasPackage]); // eslint-disable-line

  return (
    <div className="rounded-3xl bg-white border border-cream-200 shadow-soft overflow-hidden">
      <div className="bg-emerald-50 border-b border-emerald-200 px-5 py-4 flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500 flex items-center justify-center text-white">
          <Check className="w-6 h-6" />
        </div>
        <div className="flex-1">
          <span className="text-[11px] font-cairo font-bold text-navy-400">تم القبول ✓</span>
          <h2 className="font-cairo font-extrabold text-lg text-emerald-700">اختر خطوتك التالية</h2>
        </div>
      </div>

      {/* تبويبات الاختيار */}
      <div className="flex gap-2 p-3 border-b border-cream-100">
        <button onClick={() => setTab('inquiry')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all
            ${tab === 'inquiry' ? 'bg-amber-500 text-white' : 'bg-cream-100 text-navy-500'}`}>
          <MessageSquare className="w-4 h-4" /> استفسار أولاً
        </button>
        <button onClick={() => setTab('deposit')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all
            ${tab === 'deposit' ? 'bg-gold-gradient text-navy-900' : 'bg-cream-100 text-navy-500'}`}>
          <ShieldCheck className="w-4 h-4" /> العربون مباشرة
        </button>
      </div>

      <div className="p-5">
        <AnimatePresence mode="wait">
          {tab === 'inquiry' && (
            <motion.div key="inq" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
              <InquiryRoom req={req} other={other} inquiry={inquiry} setInquiry={setInquiry} showToast={showToast}
                onProceedDeposit={() => setTab('deposit')} />
            </motion.div>
          )}
          {tab === 'deposit' && (
            <motion.div key="dep" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
              <DepositInline req={req} busy={busy} runAction={runAction} showToast={showToast} />
            </motion.div>
          )}
          {tab === 'choose' && (
            <motion.div key="cho" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center py-4">
              <p className="text-sm font-cairo text-navy-500">اختر أحد الخيارين بالأعلى للمتابعة</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* إلغاء الطلب */}
        <button onClick={() => setCancelOpen(true)}
          className="w-full mt-4 text-rose-500 font-cairo font-bold text-sm py-2 hover:text-rose-600 transition-colors">
          إلغاء الطلب
        </button>
      </div>

      <CancelDialog open={cancelOpen} onClose={() => setCancelOpen(false)} busy={busy}
        onConfirm={async (reason: string) => {
          const ok = await runAction('cancel', { reason });
          setCancelOpen(false);
          if (ok) showToast('تم إلغاء الطلب', 'info');
        }} />
    </div>
  );
}

// ============================================================
//  غرفة الاستفسار — المحادثة + الباقة
// ============================================================
// أسئلة استفسار جاهزة (chips)
const INQUIRY_SUGGESTIONS = [
  'ما توقعاتك بخصوص السكن المستقبلي؟',
  'هل تمانع/ين استمرار العمل بعد الزواج؟',
  'ما رأيك في السكن المستقل عن الأهل؟',
  'كيف تصف/ين التزامك الديني؟',
  'هل لديك خطط للدراسة أو السفر؟',
];

function InquiryRoom({ req, other, inquiry, setInquiry, showToast, onProceedDeposit }: any) {
  const { settings } = useSettings();
  const [buying, setBuying] = useState(false);
  const [sending, setSending] = useState(false);
  const [input, setInput] = useState('');
  const [showBuyInfo, setShowBuyInfo] = useState(false);
  const [typing, setTyping] = useState(false);
  const [confirmLow, setConfirmLow] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [inquiry.messages.length, typing]);

  const hasPackage = !!inquiry.package;
  const remaining = inquiry.remaining;
  const low = remaining <= settings.inquiry_low_credits;

  const handleBuy = async () => {
    setBuying(true);
    const res = await buyInquiryPackage(req.id, getCurrentUserId());
    setBuying(false);
    if (res.ok && res.state) { setInquiry(res.state); showToast('تم تفعيل باقة الاستفسار ✓'); }
    else showToast(res.error || 'تعذّر الشراء', 'error');
  };

  const doSend = async () => {
    setConfirmLow(false);
    setSending(true);
    const res = await sendInquiryMessage(req.id, getCurrentUserId(), input.trim());
    if (res.ok && res.state) {
      setInquiry(res.state);
      setInput('');
      // محاكاة ردّ الطرف الآخر مع مؤشّر "يكتب الآن" — يُخصم من رصيد صاحب الباقة
      const otherId = req.sender_id === getCurrentUserId() ? req.receiver_id : req.sender_id;
      if (res.state.remaining > 0) {
        setTyping(true);
        setTimeout(async () => {
          const reply = await simulateInquiryReply(req.id, otherId, 'شكراً لاستفسارك، سأوضّح لك بكل صدق إن شاء الله.');
          setTyping(false);
          if (reply.ok && reply.state) setInquiry(reply.state);
        }, 1400);
      }
    } else {
      showToast(res.error || 'تعذّر الإرسال', 'error');
    }
    setSending(false);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    if (remaining <= 0) { showToast('نفد رصيد الباقة', 'error'); return; }
    // تأكيد قبل الإرسال عند الرصيد المنخفض (≤3)
    if (low) { setConfirmLow(true); return; }
    doSend();
  };

  // شاشة الشراء
  if (!hasPackage) {
    return (
      <div>
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-center">
          <MessageSquare className="w-10 h-10 text-amber-500 mx-auto mb-2" />
          <h3 className="font-cairo font-extrabold text-navy-800">باقة الاستفسار المبكّر</h3>
          <p className="text-sm text-navy-600 font-cairo mt-1 leading-relaxed">
            تريد معرفة المزيد عن {other?.nickname || 'الطرف الآخر'} قبل دفع العربون؟ فعّل باقة الاستفسار واطرح أسئلتك بإشراف الوسيطة.
          </p>
          <div className="flex items-center justify-center gap-4 mt-3">
            <div className="text-center">
              <p className="font-cairo font-extrabold text-2xl text-amber-700">{settings.inquiry_package_price}</p>
              <p className="text-[10px] text-navy-400 font-cairo">ريال</p>
            </div>
            <div className="w-px h-8 bg-amber-200" />
            <div className="text-center">
              <p className="font-cairo font-extrabold text-2xl text-amber-700">{settings.inquiry_package_credits}</p>
              <p className="text-[10px] text-navy-400 font-cairo">رسالة</p>
            </div>
          </div>
        </div>

        {/* شرح اقتصاد الباقة بوضوح قبل الشراء */}
        <button onClick={() => setShowBuyInfo((v) => !v)}
          className="w-full mt-2 flex items-center justify-center gap-1 text-[11px] font-cairo font-bold text-navy-400 py-1">
          <Info className="w-3.5 h-3.5" /> كيف يُحتسب الرصيد؟
        </button>
        <AnimatePresence>
          {showBuyInfo && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="bg-cream-50 rounded-xl p-3 text-xs font-cairo text-navy-600 leading-relaxed space-y-1">
                <p>• كل رسالة <strong>ترسلها أنت</strong> = رصيد واحد.</p>
                <p>• كل <strong>ردّ من الطرف الآخر</strong> = رصيد واحد أيضاً يُخصم من باقتك.</p>
                <p>• أي رسالة من الطرفين تُحتسب من رصيد صاحب باقة الاستفسار.</p>
                <p>• مثال: 20 رسالة تكفي لنحو 10 أسئلة وردودها.</p>
                <p>• الباقة دائمة الصلاحية حتى نفاد الرصيد أو انتقالك للعربون.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <button onClick={handleBuy} disabled={buying}
          className="w-full mt-3 bg-amber-500 text-white font-cairo font-extrabold py-3.5 rounded-2xl hover:brightness-105 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
          {buying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Coins className="w-5 h-5" />}
          تفعيل الباقة ({settings.inquiry_package_price} ريال)
        </button>
        <button onClick={onProceedDeposit}
          className="w-full mt-2 text-navy-500 font-cairo font-bold text-sm py-2 hover:text-navy-700">
          تخطّي الاستفسار والانتقال للعربون مباشرة ←
        </button>
      </div>
    );
  }

  // غرفة المحادثة
  return (
    <div>
      {/* عدّاد الرصيد */}
      <div className={`flex items-center justify-between rounded-xl px-3 py-2 mb-3 ${low ? 'bg-rose-50 border border-rose-200' : 'bg-emerald-50 border border-emerald-200'}`}>
        <span className="flex items-center gap-1.5 text-sm font-cairo font-bold text-navy-700">
          <Coins className={`w-4 h-4 ${low ? 'text-rose-500' : 'text-emerald-500'}`} />
          الرصيد المتبقي
        </span>
        <span className={`font-cairo font-extrabold ${low ? 'text-rose-600' : 'text-emerald-600'}`}>
          {remaining} / {inquiry.package.credits_total}
        </span>
      </div>
      {low && remaining > 0 && (
        <div className="flex items-center gap-1.5 text-[11px] font-cairo text-rose-600 mb-2">
          <AlertTriangle className="w-3.5 h-3.5" /> رصيدك على وشك النفاد
        </div>
      )}

      {/* المحادثة */}
      <div className="bg-cream-50 rounded-2xl p-3 max-h-72 overflow-y-auto space-y-2 border border-cream-100">
        {inquiry.messages.map((m: any) => {
          const mine = m.sender_id === getCurrentUserId();
          const admin = m.sender_id === 'admin';
          return (
            <div key={m.id} className={`flex ${admin ? 'justify-center' : mine ? 'justify-start' : 'justify-end'}`}>
              {admin ? (
                <div className="bg-blue-50 border border-blue-200 rounded-xl px-3 py-2 text-[11px] font-cairo text-blue-700 max-w-[90%] text-center">
                  <ShieldCheck className="w-3.5 h-3.5 inline ml-1" />{m.text}
                </div>
              ) : (
                <div className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-sm font-cairo
                  ${mine ? 'bg-gold-gradient text-navy-900' : 'bg-white border border-cream-200 text-navy-700'}`}>
                  {m.text}
                  {!mine && <span className="block text-[9px] text-amber-500 mt-0.5">−1 من رصيدك</span>}
                </div>
              )}
            </div>
          );
        })}
        {/* مؤشّر "يكتب الآن" */}
        {typing && (
          <div className="flex justify-end">
            <div className="bg-white border border-cream-200 rounded-2xl px-4 py-2.5 flex items-center gap-1">
              {[0, 1, 2].map((i) => (
                <motion.span key={i} className="w-1.5 h-1.5 rounded-full bg-navy-300"
                  animate={{ y: [0, -4, 0] }} transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }} />
              ))}
              <span className="text-[10px] font-cairo text-navy-400 mr-1">يكتب الآن</span>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* اقتراحات أسئلة جاهزة (chips) */}
      {remaining > 0 && inquiry.messages.length <= 2 && (
        <div className="flex flex-wrap gap-1.5 mt-3">
          {INQUIRY_SUGGESTIONS.map((q) => (
            <button key={q} onClick={() => setInput(q)}
              className="text-[11px] font-cairo text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-full px-2.5 py-1 transition-colors">
              {q}
            </button>
          ))}
        </div>
      )}

      {/* تأكيد عند الرصيد المنخفض */}
      <AnimatePresence>
        {confirmLow && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mt-3">
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3">
              <p className="text-xs font-cairo font-bold text-rose-700 mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" /> رصيدك منخفض ({remaining} متبقٍّ). متابعة الإرسال؟
              </p>
              <div className="flex gap-2">
                <button onClick={doSend} className="flex-1 bg-rose-500 text-white font-cairo font-bold text-sm py-2 rounded-xl">نعم، أرسل</button>
                <button onClick={() => setConfirmLow(false)} className="flex-1 bg-white border border-cream-200 text-navy-600 font-cairo font-bold text-sm py-2 rounded-xl">تراجع</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* إدخال */}
      {remaining > 0 ? (
        <div className="flex gap-2 mt-3">
          <input value={input} onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="اكتب استفسارك..." disabled={sending}
            className="flex-1 bg-white border border-cream-200 rounded-2xl px-4 py-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-amber-200" />
          <button onClick={handleSend} disabled={sending || !input.trim()}
            className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center disabled:opacity-50 flex-shrink-0">
            {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <SendIcon className="w-5 h-5 -scale-x-100" />}
          </button>
        </div>
      ) : (
        <div className="mt-3 bg-rose-50 border border-rose-200 rounded-2xl p-3 text-center">
          <p className="text-sm font-cairo font-bold text-rose-600 mb-2">نفد رصيد الباقة</p>
          <button onClick={handleBuy} disabled={buying}
            className="bg-amber-500 text-white font-cairo font-bold px-5 py-2.5 rounded-xl text-sm disabled:opacity-60">
            {buying ? '...' : `شحن باقة جديدة (${settings.inquiry_package_price} ريال)`}
          </button>
        </div>
      )}

      {/* الانتقال للعربون */}
      <button onClick={onProceedDeposit}
        className="w-full mt-4 bg-gold-gradient text-navy-900 font-cairo font-extrabold py-3.5 rounded-2xl shadow-gold hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">
        <ShieldCheck className="w-5 h-5" /> انتهيت من الاستفسار — المتابعة للعربون
      </button>
    </div>
  );
}

// ============================================================
//  لوحة العربون (داخل مركز مقبول)
// ============================================================
function DepositInline({ req, busy, runAction, showToast }: any) {
  const { settings } = useSettings();
  const [pledge, setPledge] = useState(false);
  const isSender = req.sender_id === getCurrentUserId();
  const selfPaid = isSender ? req.sender_paid : req.receiver_paid;

  const pay = async () => {
    if (!pledge) { showToast('يرجى الموافقة على عهد الجدية', 'error'); return; }
    const ok = await runAction('pay_deposit');
    if (ok) showToast('✅ تم سداد عربون الجدية بنجاح');
  };

  return (
    <div>
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center mb-4">
        <ShieldCheck className="w-9 h-9 text-amber-600 mx-auto mb-2" />
        <p className="font-cairo font-extrabold text-2xl text-amber-700">{settings.deposit_amount} <span className="text-sm">ريال</span></p>
        <p className="text-xs text-navy-500 font-cairo mt-1">عربون السعي — يؤكّد جديتك ويُحفظ لضمان المصداقية</p>
      </div>
      {selfPaid ? (
        <WaitingOther />
      ) : (
        <>
          <label className="flex items-start gap-2.5 p-3 rounded-xl bg-cream-50 border border-cream-200 cursor-pointer">
            <input type="checkbox" checked={pledge} onChange={(e) => setPledge(e.target.checked)} className="mt-0.5 accent-gold-500" />
            <span className="text-xs font-cairo text-navy-600 leading-relaxed">
              أتعهّد بالجدية والصدق، وأوافق على أن العربون يُحفظ لضمان جدية الطرفين وفق عهد الأمانة.
            </span>
          </label>
          <button onClick={pay} disabled={!pledge || busy}
            className="w-full mt-4 bg-gold-gradient text-navy-900 font-cairo font-extrabold py-3.5 rounded-2xl shadow-gold hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:translate-y-0 flex items-center justify-center gap-2">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
            سداد العربون وتأكيد الجدية
          </button>
        </>
      )}
    </div>
  );
}

// لوحة العربون المستقلة (لمرحلة seriousness)
function DepositPanel({ req, isSender, busy, runAction, showToast }: any) {
  const selfPaid = isSender ? req.sender_paid : req.receiver_paid;
  const otherPaid = isSender ? req.receiver_paid : req.sender_paid;
  const meta = STAGE_META.seriousness;
  const c = ACCENT_CLASSES[meta.accent];
  return (
    <HeroCard meta={meta} c={c} Icon={meta.icon}>
      <div className="flex gap-2 mb-4">
        {[
          { label: 'سدادك أنت', paid: selfPaid },
          { label: 'الطرف الآخر', paid: otherPaid },
        ].map((it) => (
          <div key={it.label} className={`flex-1 rounded-xl p-2.5 text-center border ${it.paid ? 'bg-emerald-50 border-emerald-200' : 'bg-cream-50 border-cream-200'}`}>
            <p className="text-[11px] font-cairo text-navy-500">{it.label}</p>
            <p className={`text-sm font-cairo font-bold ${it.paid ? 'text-emerald-600' : 'text-navy-400'}`}>{it.paid ? '✓ تم' : 'بانتظار'}</p>
          </div>
        ))}
      </div>
      {!selfPaid && <DepositInline req={req} busy={busy} runAction={runAction} showToast={showToast} />}
      {selfPaid && !otherPaid && <WaitingOther />}
    </HeroCard>
  );
}

// زر تسجيل النتيجة
function RecordResultButton({ req, busy, runAction }: any) {
  const [open, setOpen] = useState(false);
  const [choice, setChoice] = useState<'success' | 'failed'>('success');
  const [note, setNote] = useState('');
  return (
    <>
      <button onClick={() => setOpen(true)} disabled={busy}
        className="w-full mt-4 bg-navy-900 text-white font-cairo font-bold py-3.5 rounded-2xl hover:bg-navy-800 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
        <Eye className="w-4 h-4" /> تسجيل نتيجة النظرة الشرعية
      </button>
      <DialogShell open={open} onClose={() => setOpen(false)} title="نتيجة النظرة الشرعية">
        <div className="grid grid-cols-2 gap-3 mb-4">
          <button onClick={() => setChoice('success')}
            className={`p-4 rounded-2xl border-2 text-center ${choice === 'success' ? 'border-emerald-400 bg-emerald-50' : 'border-cream-200'}`}>
            <span className="text-2xl block mb-1">💚</span><span className="font-cairo font-bold text-sm text-emerald-700">توافق — المضي للملكة</span>
          </button>
          <button onClick={() => setChoice('failed')}
            className={`p-4 rounded-2xl border-2 text-center ${choice === 'failed' ? 'border-rose-400 bg-rose-50' : 'border-cream-200'}`}>
            <span className="text-2xl block mb-1">🤝</span><span className="font-cairo font-bold text-sm text-rose-600">اعتذار عن المتابعة</span>
          </button>
        </div>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3}
          placeholder={choice === 'failed' ? 'يرجى ذكر سبب الاعتذار (إلزامي)...' : 'ملاحظة (اختياري)...'}
          className="w-full bg-white border border-cream-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-gold-200" />
        {choice === 'failed' && !note.trim() && (
          <p className="text-[11px] text-rose-500 font-cairo mt-1">ذكر السبب إلزامي عند الاعتذار.</p>
        )}
        <button
          disabled={choice === 'failed' && !note.trim()}
          onClick={async () => { await runAction('record_result', { result: choice, note }); setOpen(false); }}
          className="w-full mt-4 bg-navy-900 text-white font-cairo font-bold py-3.5 rounded-2xl disabled:opacity-50">
          {choice === 'success' ? 'تأكيد التوافق والمضي للملكة' : 'تأكيد الاعتذار'}
        </button>
      </DialogShell>
    </>
  );
}

// ============================================================
//  لوحة القرار (المستقبِل: قبول/إلغاء)
// ============================================================
function DecisionPanel({ req, other, busy, runAction, showToast }: any) {
  const [cancelOpen, setCancelOpen] = useState(false);
  return (
    <div className="rounded-3xl bg-white border border-cream-200 shadow-soft overflow-hidden">
      <div className="bg-gold-300/15 border-b border-gold-200 px-5 py-4 flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gold-gradient flex items-center justify-center text-navy-900">
          <Heart className="w-6 h-6" />
        </div>
        <div>
          <span className="text-[11px] font-cairo font-bold text-navy-400">طلب وارد إليك</span>
          <h2 className="font-cairo font-extrabold text-lg text-navy-800">الرد على الطلب</h2>
        </div>
      </div>
      <div className="p-5">
        {req.message && (
          <p className="text-sm text-navy-600 font-cairo bg-cream-50 rounded-2xl p-3 mb-4 border border-cream-100 leading-relaxed">"{req.message}"</p>
        )}
        <button onClick={async () => { const ok = await runAction('accept'); if (ok) showToast('تم قبول الطلب ✓'); }} disabled={busy}
          className="w-full bg-emerald-500 text-white font-cairo font-extrabold py-3.5 rounded-2xl hover:bg-emerald-600 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-5 h-5" />} قبول والمتابعة
        </button>
        <button onClick={() => setCancelOpen(true)}
          className="w-full mt-2 bg-cream-100 text-navy-600 font-cairo font-bold py-3 rounded-2xl hover:bg-cream-200 transition-all flex items-center justify-center gap-2">
          <X className="w-4 h-4" /> الاعتذار عن الطلب
        </button>
      </div>
      <CancelDialog open={cancelOpen} onClose={() => setCancelOpen(false)} busy={busy} reasons={DECLINE_REASONS} title="الاعتذار عن الطلب"
        onConfirm={async (reason: string) => { const ok = await runAction('decline', { reason }); setCancelOpen(false); if (ok) showToast('تم الاعتذار بلطف', 'info'); }} />
    </div>
  );
}

// ============================================================
//  حوار الإلغاء/الاعتذار مع ذكر السبب
// ============================================================
function CancelDialog({ open, onClose, onConfirm, busy, reasons = CANCEL_REASONS, title = 'إلغاء الطلب' }: any) {
  const [reason, setReason] = useState('');
  const [custom, setCustom] = useState('');
  const finalReason = reason === reasons[reasons.length - 1] ? custom : reason;
  return (
    <DialogShell open={open} onClose={onClose} title={title}>
      <p className="text-sm text-navy-600 font-cairo mb-3">يرجى ذكر السبب:</p>
      <div className="space-y-2">
        {reasons.map((r: string) => (
          <label key={r} className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all ${reason === r ? 'border-rose-300 bg-rose-50' : 'border-cream-200'}`}>
            <input type="radio" checked={reason === r} onChange={() => setReason(r)} className="accent-rose-500" />
            <span className="text-sm font-cairo text-navy-700">{r}</span>
          </label>
        ))}
      </div>
      {reason === reasons[reasons.length - 1] && (
        <textarea value={custom} onChange={(e) => setCustom(e.target.value)} rows={3} placeholder="اكتب التفاصيل..."
          className="w-full mt-3 bg-white border border-cream-200 rounded-xl p-3 text-sm font-cairo focus:outline-none focus:ring-2 focus:ring-rose-200" />
      )}
      <button onClick={() => finalReason.trim() && onConfirm(finalReason)} disabled={busy || !finalReason.trim()}
        className="w-full mt-4 bg-rose-deep text-white font-cairo font-bold py-3.5 rounded-2xl hover:brightness-110 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : null} تأكيد
      </button>
    </DialogShell>
  );
}

// قشرة حوار بسيطة
function DialogShell({ open, onClose, title, children }: any) {
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[97] flex items-end sm:items-center justify-center p-0 sm:p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-navy-950/60 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 40 }}
            className="relative w-full max-w-md bg-cream-50 rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
            <div className="sticky top-0 bg-cream-50 z-10 flex items-center justify-between px-6 py-4 border-b border-cream-200">
              <h3 className="font-cairo font-bold text-lg text-navy-900">{title}</h3>
              <button onClick={onClose} className="w-9 h-9 rounded-full bg-cream-100 flex items-center justify-center text-navy-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6">{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

// ============================================================
//  الطبقة 3 — خريطة الرحلة العمودية (كل المراحل)
// ============================================================
function VerticalJourney({ stage, events }: { stage: JourneyState; events: RequestEvent[] }) {
  const [infoFor, setInfoFor] = useState<JourneyState | null>(null);
  const currentIdx = isTerminal(stage) ? 99 : STAGE_INDEX[stage as keyof typeof STAGE_INDEX];

  return (
    <div className="bg-white rounded-3xl border border-cream-200 shadow-soft p-5">
      <div className="relative">
        {JOURNEY_STAGES.map((sKey, idx) => {
          const meta = STAGE_META[sKey];
          const c = ACCENT_CLASSES[meta.accent];
          const Icon = meta.icon;
          const isDone = idx < currentIdx;
          const isCurrent = idx === currentIdx;
          const stageEvents = events.filter((e) => mapEventToStage(e.type) === sKey);

          return (
            <div key={sKey} className="flex gap-4 pb-5 last:pb-0 relative">
              {/* الخط العمودي */}
              {idx < JOURNEY_STAGES.length - 1 && (
                <div className={`absolute right-[18px] top-10 bottom-0 w-0.5 ${isDone ? 'bg-emerald-300' : 'bg-cream-200'}`} />
              )}
              {/* الأيقونة */}
              <button onClick={() => setInfoFor(sKey)} className="relative z-10 flex-shrink-0">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all
                  ${isDone ? 'bg-emerald-500 text-white' : isCurrent ? `${c.bg} text-white ring-4 ${c.ring}` : 'bg-cream-100 text-navy-300'}`}>
                  {isDone ? <Check className="w-5 h-5" /> : <Icon className="w-4 h-4" />}
                </div>
              </button>
              {/* المحتوى */}
              <div className="flex-1 pt-1">
                <button onClick={() => setInfoFor(sKey)} className="flex items-center gap-1.5 text-right">
                  <span className={`font-cairo font-bold ${isDone ? 'text-emerald-700' : isCurrent ? c.text : 'text-navy-400'}`}>
                    {idx + 1}. {meta.title}
                  </span>
                  {isCurrent && <span className={`text-[9px] font-cairo font-bold px-1.5 py-0.5 rounded-full ${c.bgSoft} ${c.text}`}>الآن</span>}
                  <Info className="w-3 h-3 text-navy-300" />
                </button>
                <p className="text-xs text-navy-500 font-cairo mt-0.5 leading-relaxed">{meta.whereYouAre}</p>
                {/* أحداث هذه المرحلة */}
                {stageEvents.length > 0 && (
                  <div className="mt-1.5 space-y-1">
                    {stageEvents.map((ev) => (
                      <div key={ev.id} className="flex items-center gap-1.5 text-[10px] font-cairo text-navy-400">
                        <span className="w-1 h-1 rounded-full bg-gold-400" />{ev.note}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* بطاقة شرح المرحلة */}
      <AnimatePresence>
        {infoFor && (
          <div className="fixed inset-0 z-[95] flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-navy-950/60 backdrop-blur-sm" onClick={() => setInfoFor(null)} />
            <StageInfo stage={infoFor} onClose={() => setInfoFor(null)} />
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StageInfo({ stage, onClose }: { stage: JourneyState; onClose: () => void }) {
  const meta = STAGE_META[stage];
  const c = ACCENT_CLASSES[meta.accent];
  const Icon = meta.icon;
  const rows = [
    { label: 'أين أنت الآن', text: meta.whereYouAre, icon: '📍' },
    { label: 'ماذا تفعل', text: meta.whatToDo, icon: '✅' },
    { label: 'المرحلة التالية', text: meta.whatsNext, icon: '➡️' },
  ];
  return (
    <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 40 }}
      className="relative w-full max-w-md bg-cream-50 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden" dir="rtl">
      <div className={`${c.bgSoft} border-b ${c.border} px-6 py-5 relative`}>
        <button onClick={onClose} className="absolute top-4 left-4 w-9 h-9 rounded-full bg-white/70 flex items-center justify-center text-navy-600"><X className="w-5 h-5" /></button>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-2xl ${c.bg} flex items-center justify-center text-white`}><Icon className="w-6 h-6" /></div>
          <div>
            {meta.step > 0 && <span className="text-[11px] font-cairo font-bold text-navy-400">المرحلة {meta.step} من 6</span>}
            <h3 className={`font-cairo font-extrabold text-xl ${c.text}`}>{meta.title}</h3>
          </div>
        </div>
      </div>
      <div className="p-6 space-y-3">
        {rows.map((r) => (
          <div key={r.label} className="bg-white rounded-2xl border border-cream-200 p-4">
            <div className="flex items-center gap-2 mb-1"><span>{r.icon}</span><span className="text-xs font-cairo font-extrabold text-navy-800">{r.label}</span></div>
            <p className="text-sm text-navy-600 font-cairo leading-relaxed pr-7">{r.text}</p>
          </div>
        ))}
        <button onClick={onClose} className={`w-full ${c.bg} text-white font-cairo font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2`}>
          فهمت <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
}

// ربط نوع الحدث بالمرحلة لعرضه في الخريطة العمودية
function mapEventToStage(type: string): JourneyState {
  switch (type) {
    case 'sent': return 'sent';
    case 'accept': return 'accepted';
    case 'inquiry_buy': return 'accepted';
    case 'pay_deposit': return 'seriousness';
    case 'coordination': return 'coordination';
    case 'sharia_viewing': return 'sharia_viewing';
    case 'completed': return 'completed';
    case 'decline': return 'declined';
    case 'cancel': return 'cancelled';
    default: return 'sent';
  }
}

// ============================================================
//  #7 معاينة المرحلة القادمة — يقلّل قلق المجهول
// ============================================================
function NextStepHint({ stage }: { stage: JourneyState }) {
  if (isTerminal(stage) || stage === 'completed') return null;
  const idx = STAGE_INDEX[stage as keyof typeof STAGE_INDEX];
  const nextKey = JOURNEY_STAGES[idx + 1];
  if (!nextKey) return null;
  const next = STAGE_META[nextKey];
  const c = ACCENT_CLASSES[next.accent];
  const NextIcon = next.icon;
  return (
    <div className="mt-3 bg-white rounded-2xl border border-cream-200 shadow-soft px-4 py-3 flex items-center gap-3">
      <div className={`w-9 h-9 rounded-xl ${c.bgSoft} flex items-center justify-center ${c.text} flex-shrink-0`}>
        <NextIcon className="w-4.5 h-4.5" />
      </div>
      <div className="flex-1 min-w-0">
        <span className="text-[10px] font-cairo font-bold text-navy-400">ماذا ينتظرني بعد ذلك؟</span>
        <p className="font-cairo font-bold text-sm text-navy-700 truncate">
          الخطوة القادمة: <span className={c.text}>{next.title}</span>
        </p>
      </div>
      <ChevronLeft className="w-4 h-4 text-navy-300 flex-shrink-0" />
    </div>
  );
}

// ============================================================
//  #11 حالة "بانتظار الطرف الآخر" — متحركة لطيفة
// ============================================================
function WaitingOther() {
  return (
    <div className="bg-gradient-to-br from-blue-50 to-cream-50 border border-blue-100 rounded-2xl p-5 text-center">
      <div className="relative w-14 h-14 mx-auto mb-3">
        <motion.span
          className="absolute inset-0 rounded-full bg-blue-200/50"
          animate={{ scale: [1, 1.5, 1], opacity: [0.6, 0, 0.6] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <motion.span
          className="absolute inset-0 rounded-full bg-blue-200/40"
          animate={{ scale: [1, 1.8, 1], opacity: [0.4, 0, 0.4] }}
          transition={{ duration: 2, repeat: Infinity, delay: 0.4 }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-11 h-11 rounded-full bg-blue-500 flex items-center justify-center text-white">
            <Clock className="w-5 h-5" />
          </div>
        </div>
      </div>
      <p className="font-cairo font-extrabold text-emerald-600">أكملت سدادك ✓</p>
      <p className="text-sm font-cairo text-navy-500 mt-1">بانتظار سداد الطرف الآخر لبدء التنسيق</p>
      <p className="text-[11px] font-cairo text-blue-500 mt-2 flex items-center justify-center gap-1">
        <Sparkles className="w-3 h-3" /> سنُشعرك فور سداده
      </p>
    </div>
  );
}
