import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Bell, Heart, Eye, ShieldCheck, Info, CheckCheck, Headphones, Users,
  X, Trash2, Inbox, Sparkles, ChevronLeft,
} from 'lucide-react';
import { NOTIFICATIONS } from '../lib/data';
import { useApp } from '../lib/AppContext';
import {
  getJourneyNotifications, markAllNotificationsRead, deleteNotification, markNotificationRead,
  getCurrentUserId, type JourneyNotification,
} from '../lib/useInterestRequests';

const typeConfig = {
  like: { icon: Heart, color: 'text-rose-deep bg-rose-deep/10' },
  request: { icon: Heart, color: 'text-rose-deep bg-rose-deep/10' },
  match: { icon: Users, color: 'text-gold-600 bg-gold-300/15' },
  visit: { icon: Eye, color: 'text-navy-600 bg-navy-900/10' },
  verification: { icon: ShieldCheck, color: 'text-emerald-600 bg-emerald-100' },
  system: { icon: Info, color: 'text-sky-600 bg-sky-100' },
  admin: { icon: Headphones, color: 'text-gold-600 bg-gold-300/15' },
};

type NotifItem = (typeof NOTIFICATIONS)[number];

export default function Notifications() {
  const { showToast, user } = useApp();
  const [notifs, setNotifs] = useState<NotifItem[]>(NOTIFICATIONS);
  const unread = notifs.filter((n) => !n.read).length;

  // #9 إشعارات الرحلة الحقيقية (تقود مباشرة لصفحة الرحلة)
  const activeId = user?.memberId || getCurrentUserId();
  const [journeyNotifs, setJourneyNotifs] = useState<JourneyNotification[]>([]);

  const loadJourney = useCallback(async () => {
    setJourneyNotifs(await getJourneyNotifications(activeId));
  }, [activeId]);

  useEffect(() => { loadJourney(); }, [loadJourney]);

  const journeyUnread = journeyNotifs.filter((n) => !n.read).length;

  const markAllJourney = () => {
    markAllNotificationsRead(activeId);
    loadJourney();
    showToast('تم تعليم إشعارات الرحلة كمقروءة', 'success');
  };
  const removeJourney = (id: number) => {
    deleteNotification(id);
    loadJourney();
  };

  const markAll = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast('تم تعليم جميع الإشعارات كمقروءة', 'success');
  };

  const removeNotif = (id: string) => {
    setNotifs((prev) => prev.filter((n) => n.id !== id));
    showToast('تم حذف الإشعار', 'info');
  };

  const clearAll = () => {
    setNotifs([]);
    showToast('تم حذف جميع الإشعارات', 'info');
  };

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gold-300/15 flex items-center justify-center">
              <Bell className="w-6 h-6 text-gold-600" />
            </div>
            <div>
              <h1 className="font-cairo font-extrabold text-2xl text-navy-900">الإشعارات</h1>
              <p className="text-navy-600 font-tajawal text-sm">
                {unread > 0 ? `${unread} إشعار غير مقروء` : 'لا توجد إشعارات غير مقروءة'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {unread > 0 && (
              <button
                onClick={markAll}
                className="flex items-center gap-1.5 text-sm text-gold-700 font-cairo font-semibold hover:bg-gold-300/10 px-3 py-2 rounded-xl transition-colors"
              >
                <CheckCheck className="w-4 h-4" />
                <span className="hidden sm:inline">تعليم الكل كمقروء</span>
              </button>
            )}
            {notifs.length > 0 && (
              <button
                onClick={clearAll}
                className="flex items-center gap-1.5 text-sm text-rose-deep font-cairo font-semibold hover:bg-rose-50 px-3 py-2 rounded-xl transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">حذف الكل</span>
              </button>
            )}
          </div>
        </div>

        {/* #9 إشعارات الرحلة — تقود مباشرة لصفحة الرحلة */}
        {journeyNotifs.length > 0 && (
          <div className="mb-5">
            <div className="flex items-center justify-between mb-2">
              <h2 className="flex items-center gap-1.5 font-cairo font-extrabold text-navy-800">
                <Sparkles className="w-4 h-4 text-gold-500" /> تحديثات رحلاتك
                {journeyUnread > 0 && (
                  <span className="bg-rose-500 text-white text-[10px] font-cairo font-bold px-1.5 py-0.5 rounded-full">{journeyUnread}</span>
                )}
              </h2>
              {journeyUnread > 0 && (
                <button onClick={markAllJourney} className="text-xs text-gold-700 font-cairo font-bold hover:underline">
                  تعليم الكل كمقروء
                </button>
              )}
            </div>
            <div className="space-y-2">
              <AnimatePresence>
                {journeyNotifs.map((n) => (
                  <motion.div
                    key={n.id} layout
                    initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -50, scale: 0.95 }}
                    className={`group relative bg-white rounded-2xl shadow-soft border overflow-hidden transition-all hover:shadow-luxe ${
                      !n.read ? 'border-gold-300/50 ring-1 ring-gold-300/20' : 'border-cream-200/60'
                    }`}
                  >
                    <Link
                      to={`/journey/${n.request_id}`}
                      onClick={() => { markNotificationRead(n.id); }}
                      className="flex items-center gap-3 p-4"
                    >
                      <div className={`w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 ${(typeConfig[n.type as keyof typeof typeConfig] || typeConfig.system).color}`}>
                        {(() => { const Ic = (typeConfig[n.type as keyof typeof typeConfig] || typeConfig.system).icon; return <Ic className="w-5 h-5" />; })()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`font-tajawal text-sm leading-snug ${!n.read ? 'text-navy-900 font-bold' : 'text-navy-700'}`}>{n.text}</p>
                        <p className="text-[11px] text-navy-400 font-tajawal mt-0.5 flex items-center gap-1">
                          {new Date(n.created_at).toLocaleString('ar-SA')} · <span className="text-gold-600 font-bold">افتح الرحلة</span>
                        </p>
                      </div>
                      {!n.read && <span className="w-2.5 h-2.5 rounded-full bg-gold-500 flex-shrink-0" />}
                      <ChevronLeft className="w-4 h-4 text-navy-300 flex-shrink-0" />
                    </Link>
                    <button
                      onClick={(e) => { e.preventDefault(); removeJourney(n.id); }}
                      className="absolute top-2 left-2 w-7 h-7 rounded-full bg-cream-100 hover:bg-rose-50 flex items-center justify-center text-navy-400 hover:text-rose-deep transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                    {!n.read && <div className="absolute top-0 right-0 bottom-0 w-1 bg-gold-gradient" />}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            <div className="mt-4 mb-1 border-t border-cream-200" />
            <h2 className="font-cairo font-extrabold text-navy-800 mt-3">إشعارات عامة</h2>
          </div>
        )}

        {/* Notifications list */}
        {notifs.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-cream-200/60">
            <div className="w-20 h-20 rounded-full bg-cream-100 flex items-center justify-center mx-auto mb-4">
              <Inbox className="w-10 h-10 text-navy-300" />
            </div>
            <h3 className="font-cairo font-bold text-xl text-navy-900">لا توجد إشعارات</h3>
            <p className="text-navy-500 font-tajawal mt-2">ستظهر هنا جميع التنبيهات والتحديثات الجديدة</p>
          </div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence>
              {notifs.map((n) => {
                const cfg = typeConfig[n.type] || typeConfig.system;
                const Icon = cfg.icon;
                return (
                  <motion.div
                    key={n.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -50, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className={`group relative bg-white rounded-2xl shadow-soft border overflow-hidden transition-all hover:shadow-luxe ${
                      !n.read ? 'border-gold-300/40 ring-1 ring-gold-300/20' : 'border-cream-200/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 p-4">
                      {/* Icon */}
                      <div className="relative flex-shrink-0">
                        <div className="w-12 h-12 rounded-full bg-cream-100 flex items-center justify-center">
                          <Info className="w-6 h-6 text-navy-400" />
                        </div>
                        <div className={`absolute -bottom-1 -left-1 w-6 h-6 rounded-full flex items-center justify-center ring-2 ring-white ${cfg.color}`}>
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                      </div>

                      {/* Content */}
                      <Link to="#" className="flex-1 min-w-0">
                        <p className={`font-tajawal text-sm leading-snug ${!n.read ? 'text-navy-900 font-semibold' : 'text-navy-700'}`}>
                          {n.text}
                        </p>
                        <p className="text-xs text-navy-400 font-tajawal mt-0.5">{n.time}</p>
                      </Link>

                      {/* Unread dot */}
                      {!n.read && (
                        <span className="w-2.5 h-2.5 rounded-full bg-gold-500 flex-shrink-0" />
                      )}

                      {/* Close button */}
                      <button
                        onClick={() => removeNotif(n.id)}
                        className="w-8 h-8 rounded-full bg-cream-100 hover:bg-rose-50 flex items-center justify-center text-navy-400 hover:text-rose-deep transition-colors flex-shrink-0"
                        aria-label="حذف الإشعار"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Unread accent bar */}
                    {!n.read && (
                      <div className="absolute top-0 right-0 bottom-0 w-1 bg-gold-gradient" />
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
