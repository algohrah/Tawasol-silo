import { useState } from 'react';
import { Globe, Save, Check, Palette } from 'lucide-react';
import { SITE_SETTINGS, type SiteSettings } from '../../lib/admin-data';

export default function AdminSite() {
  const [settings, setSettings] = useState<SiteSettings>(SITE_SETTINGS);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">إعدادات الموقع</h2>
          <p className="text-sm text-slate-500 font-tajawal">تحكم في هوية المنصة العامة</p>
        </div>
        <button onClick={handleSave} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-semibold text-sm transition-colors ${saved ? 'bg-emerald-500 text-white' : 'bg-slate-900 text-white hover:bg-slate-800'}`}>
          {saved ? <><Check className="w-4 h-4" /> تم الحفظ</> : <><Save className="w-4 h-4" /> حفظ</>}
        </button>
      </div>

      {/* Branding */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-4 flex items-center gap-2"><Globe className="w-5 h-5 text-amber-500" /> هوية المنصة</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>اسم الموقع</label>
            <input value={settings.siteName} onChange={(e) => setSettings({ ...settings, siteName: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>نص الشعار</label>
            <input value={settings.logoText} onChange={(e) => setSettings({ ...settings, logoText: e.target.value })} className={inputClass} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelClass}>الوصف المختصر</label>
            <input value={settings.tagline} onChange={(e) => setSettings({ ...settings, tagline: e.target.value })} className={inputClass} />
          </div>
        </div>
      </div>

      {/* Colors */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-4 flex items-center gap-2"><Palette className="w-5 h-5 text-amber-500" /> اللون الرئيسي</h3>
        <div className="flex flex-wrap gap-3">
          {['#C9A961', '#1f1f3a', '#e11d48', '#2563eb', '#059669', '#7c3aed'].map((color) => (
            <button
              key={color}
              onClick={() => setSettings({ ...settings, primaryColor: color })}
              className={`w-12 h-12 rounded-xl transition-all ${settings.primaryColor === color ? 'ring-2 ring-offset-2 ring-slate-900 scale-110' : ''}`}
              style={{ backgroundColor: color }}
            />
          ))}
          <div className="flex items-center gap-2 px-3 rounded-xl bg-slate-50 border border-slate-200">
            <input type="color" value={settings.primaryColor} onChange={(e) => setSettings({ ...settings, primaryColor: e.target.value })} className="w-8 h-8 rounded cursor-pointer" />
            <span className="text-sm font-tajawal text-slate-600">{settings.primaryColor}</span>
          </div>
        </div>
      </div>

      {/* Contact */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-4">معلومات التواصل</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>البريد الإلكتروني</label>
            <input value={settings.email} onChange={(e) => setSettings({ ...settings, email: e.target.value })} className={inputClass} dir="ltr" />
          </div>
          <div>
            <label className={labelClass}>رقم الهاتف</label>
            <input value={settings.phone} onChange={(e) => setSettings({ ...settings, phone: e.target.value })} className={inputClass} dir="ltr" />
          </div>
        </div>
      </div>

      {/* Toggles */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-3">
        <h3 className="font-cairo font-bold text-slate-900 mb-2">التحكم في المنصة</h3>
        {[
          { key: 'allowRegistration' as const, label: 'السماح بالتسجيل الجديد', desc: 'فتح أو إغلاق التسجيل في المنصة' },
          { key: 'maintenanceMode' as const, label: 'وضع الصيانة', desc: 'إغلاق الموقع مؤقتًا للزوار' },
        ].map((item) => (
          <div key={item.key} className="flex items-center justify-between gap-3 py-2">
            <div>
              <p className="font-cairo font-semibold text-slate-800 text-sm">{item.label}</p>
              <p className="text-xs text-slate-400 font-tajawal">{item.desc}</p>
            </div>
            <button onClick={() => setSettings({ ...settings, [item.key]: !settings[item.key] })} className={`w-12 h-7 rounded-full transition-colors relative flex-shrink-0 ${settings[item.key] ? 'bg-emerald-500' : 'bg-slate-300'}`}>
              <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${settings[item.key] ? 'right-1' : 'right-6'}`} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
