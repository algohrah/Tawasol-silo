import { useState, useMemo } from 'react';
import {
  MessageSquare, ShieldAlert, CheckCircle2, XCircle, Search, Clock, ShieldCheck, Heart, AlertTriangle
} from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import FilterDropdown from '../../components/admin/FilterDropdown';

export default function AdminModeration() {
  const { interestRequests, adminModeratePreExchangeMessage, members, showToast } = useApp();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected'>('pending');

  const getMemberById = (id: string) => members.find(m => m.id === id);

  // Extract all chat messages from all requests
  const messagesList = useMemo(() => {
    const list: any[] = [];
    interestRequests.forEach(req => {
      if (req.chatMessages && req.chatMessages.length > 0) {
        req.chatMessages.forEach((msg: any) => {
          const sender = getMemberById(msg.senderId);
          const receiverId = req.senderId === msg.senderId ? req.receiverId : req.senderId;
          const receiver = getMemberById(receiverId);
          
          list.push({
            requestId: req.id,
            messageId: msg.id,
            sender,
            receiver,
            text: msg.text,
            time: msg.time,
            approved: msg.approved,
            rejected: msg.rejected,
          });
        });
      }
    });

    // Filter by search and status
    return list.filter(msg => {
      const matchesSearch = msg.text.toLowerCase().includes(search.toLowerCase()) ||
        (msg.sender?.nickname || '').toLowerCase().includes(search.toLowerCase()) ||
        (msg.receiver?.nickname || '').toLowerCase().includes(search.toLowerCase());
      
      const matchesStatus = 
        filter === 'pending' ? (!msg.approved && !msg.rejected) :
        filter === 'approved' ? msg.approved : msg.rejected;

      return matchesSearch && matchesStatus;
    });
  }, [interestRequests, search, filter, members]);

  return (
    <div className="space-y-6 font-cairo text-right p-4 sm:p-6" dir="rtl">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-slate-700" /> مراجعة وتدقيق الرسائل
        </h2>
        <p className="text-sm text-slate-500 font-tajawal mt-1">
          مراجعة وتدقيق استفسارات الأعضاء المتبادلة قبل إظهارها للطرف الآخر لضمان الخصوصية والجدية.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex items-center justify-between">
          <div className="text-right">
            <span className="block text-xs text-slate-400 font-tajawal">بانتظار المراجعة</span>
            <span className="text-2xl font-black text-amber-600">
              {interestRequests.reduce((acc, req) => acc + (req.chatMessages || []).filter((m: any) => !m.approved && !m.rejected).length, 0)}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
            <Clock className="w-5 h-5" />
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex items-center justify-between">
          <div className="text-right">
            <span className="block text-xs text-slate-400 font-tajawal">الرسائل المقبولة</span>
            <span className="text-2xl font-black text-emerald-600">
              {interestRequests.reduce((acc, req) => acc + (req.chatMessages || []).filter((m: any) => m.approved).length, 0)}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex items-center justify-between">
          <div className="text-right">
            <span className="block text-xs text-slate-400 font-tajawal">الرسائل المرفوضة</span>
            <span className="text-2xl font-black text-rose-600">
              {interestRequests.reduce((acc, req) => acc + (req.chatMessages || []).filter((m: any) => m.rejected).length, 0)}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center text-rose-600">
            <XCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="w-full md:w-auto">
          <FilterDropdown
            label="الحالة:"
            value={filter}
            onChange={(v) => setFilter(v as 'pending' | 'approved' | 'rejected')}
            options={[
              { value: 'pending', label: 'بانتظار المراجعة', count: interestRequests.reduce((acc, req) => acc + (req.chatMessages || []).filter((m: any) => !m.approved && !m.rejected).length, 0) },
              { value: 'approved', label: 'مقبولة', count: interestRequests.reduce((acc, req) => acc + (req.chatMessages || []).filter((m: any) => m.approved).length, 0) },
              { value: 'rejected', label: 'مرفوضة', count: interestRequests.reduce((acc, req) => acc + (req.chatMessages || []).filter((m: any) => m.rejected).length, 0) },
            ]}
          />
        </div>

        <div className="relative w-full md:w-80">
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="البحث بنص الرسالة أو الأعضاء..."
            className="w-full pr-9 pl-3 py-2 border border-slate-200 rounded-xl text-xs font-tajawal focus:outline-none focus:border-slate-900 text-slate-800"
          />
        </div>
      </div>

      {/* Warning Alert */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-amber-900 text-xs leading-relaxed font-tajawal flex items-start gap-2">
        <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <strong>ملاحظة هامة للمشرفين 🛡️:</strong> يرجى مراجعة كافة الرسائل بدقة. يجب الموافقة فقط على الرسائل الجادة والمحترمة التي لا تحتوي على وسائل تواصل خارجية مباشرة (مثل أرقام هواتف أو سناب شات) خارج نظام المنصة، لمنع التحايل وضمان الجدية التامة.
        </div>
      </div>

      {/* Messages Feed */}
      <div className="space-y-4">
        {messagesList.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200">
            <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <p className="text-slate-500 font-tajawal text-sm">لا توجد رسائل مطابقة حالياً.</p>
          </div>
        ) : (
          messagesList.map((msg, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-4 animate-fade-in">
              {/* Message Header */}
              <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-3 flex-wrap">
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-tajawal">المرسل</span>
                    <span className="block text-sm font-bold text-slate-900">{msg.sender?.nickname || 'عضو مجهول'}</span>
                    <span className="text-[10px] text-slate-400 font-tajawal">({msg.sender?.gender === 'male' ? 'ذكر' : 'أنثى'} · {msg.sender?.city})</span>
                  </div>
                  <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 text-xs font-bold">←</div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-tajawal">المستقبل</span>
                    <span className="block text-sm font-bold text-slate-900">{msg.receiver?.nickname || 'عضو مجهول'}</span>
                    <span className="text-[10px] text-slate-400 font-tajawal">({msg.receiver?.gender === 'male' ? 'ذكر' : 'أنثى'} · {msg.receiver?.city})</span>
                  </div>
                </div>

                <span className="text-[10px] text-slate-400 font-tajawal">{msg.time}</span>
              </div>

              {/* Message Content */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-sm text-slate-800 font-tajawal leading-relaxed">
                "{msg.text}"
              </div>

              {/* Action Buttons */}
              {filter === 'pending' && (
                <div className="flex gap-2.5 justify-end">
                  <button
                    onClick={() => adminModeratePreExchangeMessage(msg.requestId, msg.messageId, 'approve')}
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-cairo font-bold transition-colors flex items-center gap-1.5 shadow-sm"
                  >
                    <CheckCircle2 className="w-4 h-4" /> قبول وتوصيل الرسالة
                  </button>
                  <button
                    onClick={() => adminModeratePreExchangeMessage(msg.requestId, msg.messageId, 'reject')}
                    className="px-5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-cairo font-bold border border-rose-100 transition-colors flex items-center gap-1.5"
                  >
                    <XCircle className="w-4 h-4" /> رفض وحجب الرسالة
                  </button>
                </div>
              )}

              {filter === 'approved' && (
                <div className="flex items-center gap-1.5 justify-end text-emerald-600 text-xs font-bold font-cairo">
                  <CheckCircle2 className="w-4 h-4" /> تمت الموافقة عليها وإظهارها للطرف الآخر
                </div>
              )}

              {filter === 'rejected' && (
                <div className="flex items-center gap-1.5 justify-end text-rose-600 text-xs font-bold font-cairo">
                  <XCircle className="w-4 h-4" /> تم رفضها وحجبها لمخالفة الشروط
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
