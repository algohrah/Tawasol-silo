import { Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Header from '../ui/Header';
import Footer from './Footer';
import MobileNav from './MobileNav';
import ToastContainer from '../ui/Toast';
import ImpersonationBar from '../ImpersonationBar';

export default function Layout() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  const hideFooter = pathname === '/search' || 
                     pathname.startsWith('/checkout') || 
                     pathname === '/requests' || 
                     pathname === '/admin-chat' || 
                     pathname === '/notifications' ||
                     pathname.startsWith('/profile');

  return (
    <div className="min-h-screen flex flex-col bg-cream-50">
      <ImpersonationBar />
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      {!hideFooter && <Footer />}
      <MobileNav />
      <ToastContainer />
    </div>
  );
}
