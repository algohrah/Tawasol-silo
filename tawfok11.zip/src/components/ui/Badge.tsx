import type { ReactNode } from 'react';
import { ShieldCheck, Crown, Circle } from 'lucide-react';

export function VerifiedBadge({ size = 'sm' }: { size?: 'sm' | 'md' }) {
  const s = size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';
  const text = size === 'sm' ? 'text-[10px]' : 'text-xs';
  return (
    <span className={`inline-flex items-center gap-1 ${text} font-bold text-sky-600 bg-sky-50 px-2 py-0.5 rounded-full`}>
      <ShieldCheck className={s} /> موثّق
    </span>
  );
}

export function PremiumBadge({ size = 'sm' }: { size?: 'sm' | 'md' }) {
  const s = size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4';
  const text = size === 'sm' ? 'text-[10px]' : 'text-xs';

  return (
    <span className={`inline-flex items-center gap-1 ${text} font-bold text-gold-700 bg-gold-100 bg-gold-300/20 px-2 py-0.5 rounded-full`}>
      <Crown className={s} /> ذهبي
    </span>
  );
}

export function OnlineBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
      <Circle className="w-2 h-2 fill-emerald-500 text-emerald-500" /> متصل
    </span>
  );
}

export function Chip({ children, active, onClick }: { children: ReactNode; active?: boolean; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full text-sm font-cairo font-semibold transition-all duration-200 no-tap-highlight ${
        active
          ? 'bg-gold-gradient text-navy-900 shadow-soft'
          : 'bg-cream-100 text-navy-700 hover:bg-cream-200'
      }`}
    >
      {children}
    </button>
  );
}

export function MatchScore({ score }: { score: number }) {
  const color = score >= 90 ? 'text-emerald-600' : score >= 80 ? 'text-gold-600' : 'text-rose-deep';
  return (
    <div className="flex items-center gap-1.5">
      <div className="relative w-8 h-8">
        <svg viewBox="0 0 36 36" className="w-8 h-8 -rotate-90">
          <circle cx="18" cy="18" r="15" fill="none" stroke="currentColor" strokeWidth="3" className="text-cream-200" />
          <circle
            cx="18" cy="18" r="15" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"
            className={color}
            strokeDasharray={`${(score / 100) * 94.2} 94.2`}
          />
        </svg>
        <span className={`absolute inset-0 flex items-center justify-center text-[9px] font-bold ${color}`}>{score}</span>
      </div>
      <span className="text-xs font-semibold text-navy-600">توافق</span>
    </div>
  );
}
