import { Link } from 'react-router-dom';

interface LogoProps {
  variant?: 'dark' | 'light';
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ variant = 'dark', size = 'md' }: LogoProps) {
  const textColor = variant === 'light' ? 'text-white' : 'text-navy-900';
  const subColor = variant === 'light' ? 'text-gold-300' : 'text-gold-600';
  const sizes = {
    sm: { mark: 'w-8 h-8', text: 'text-lg' },
    md: { mark: 'w-10 h-10', text: 'text-xl' },
    lg: { mark: 'w-14 h-14', text: 'text-3xl' },
  };
  const s = sizes[size];

  return (
    <Link to="/" className="flex items-center gap-2 no-tap-highlight">
      <div className={`${s.mark} relative flex-shrink-0`}>
        <svg viewBox="0 0 64 64" className="w-full h-full">
          <defs>
            <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e0c485" />
              <stop offset="50%" stopColor="#c9a961" />
              <stop offset="100%" stopColor="#b08f47" />
            </linearGradient>
          </defs>
          {/* قلبان متشابكان */}
          <path d="M32 12 C 26 12, 22 17, 22 23 C 22 31, 32 42, 32 42 C 32 42, 42 31, 42 23 C 42 17, 38 12, 32 12 Z" fill="url(#logoGrad)" />
          <path d="M32 20 C 28 20, 26 22, 26 26 C 26 31, 32 38, 32 38 C 32 38, 38 31, 38 26 C 38 22, 36 20, 32 20 Z" fill="#16162e" />
          <circle cx="32" cy="26" r="2.5" fill="url(#logoGrad)" />
          <path d="M20 46 Q 32 52, 44 46" stroke="url(#logoGrad)" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx="20" cy="46" r="2.5" fill="url(#logoGrad)" />
          <circle cx="44" cy="46" r="2.5" fill="url(#logoGrad)" />
        </svg>
      </div>
      <div className="flex flex-col leading-none">
        <span className={`font-cairo font-extrabold ${s.text} ${textColor}`}>توافق</span>
        <span className={`text-[10px] tracking-wider ${subColor} font-tajawal`}>زواج موثوق</span>
      </div>
    </Link>
  );
}
