import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, XCircle, Info, X } from 'lucide-react';
import { useApp } from '../../lib/AppContext';

const config = {
  success: { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
  error: { icon: XCircle, color: 'text-rose-deep', bg: 'bg-rose-50', border: 'border-rose-200' },
  info: { icon: Info, color: 'text-gold-600', bg: 'bg-gold-300/10', border: 'border-gold-300/30' },
};

export default function ToastContainer() {
  const { toasts, dismissToast } = useApp();

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-[92%] max-w-sm flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => {
          const c = config[toast.type];
          const Icon = c.icon;
          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className={`pointer-events-auto ${c.bg} ${c.border} border rounded-2xl px-4 py-3 shadow-luxe flex items-center gap-3`}
            >
              <Icon className={`w-5 h-5 ${c.color} flex-shrink-0`} />
              <p className="flex-1 font-cairo font-semibold text-sm text-navy-800">{toast.message}</p>
              <button onClick={() => dismissToast(toast.id)} className="text-navy-400 hover:text-navy-700">
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
