import { useState } from 'react';
import { Plus, Edit3, Trash2, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { FAQS } from '../lib/data';
import Modal from './ui/Modal';

export default function AdminFAQ() {
  const [faqs, setFaqs] = useState(FAQS);
  const [editing, setEditing] = useState<{ q: string; a: string; index: number } | null>(null);
  const [creating, setCreating] = useState(false);

  const handleDelete = (index: number) => {
    setFaqs(prev => prev.filter((_, i) => i !== index));
  };

  const moveItem = (index: number, dir: 'up' | 'down') => {
    setFaqs(prev => {
      const next = [...prev];
      const target = dir === 'up' ? index - 1 : index + 1;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">الأسئلة الشائعة</h2>
          <p className="text-sm text-slate-500 font-tajawal">{faqs.length} سؤال وجواب</p>
        </div>
        <button onClick={() => setCreating(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
          <Plus className="w-4 h-4" /> سؤال جديد
        </button>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                <HelpCircle className="w-5 h-5 text-slate-500" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1">{faq.q}</h3>
                <p className="text-xs text-slate-600 font-tajawal leading-relaxed">{faq.a}</p>
              </div>
              <div className="flex flex-col gap-1">
                <button onClick={() => moveItem(i, 'up')} disabled={i === 0} className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"><ChevronUp className="w-4 h-4 text-slate-400" /></button>
                <button onClick={() => moveItem(i, 'down')} disabled={i === faqs.length - 1} className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"><ChevronDown className="w-4 h-4 text-slate-400" /></button>
              </div>
            </div>
            <div className="flex gap-2 mt-3 pt-3 border-t border-slate-50">
              <button onClick={() => setEditing({ ...faq, index: i })} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-600 text-xs font-cairo font-bold hover:bg-amber-100 transition-colors">
                <Edit3 className="w-3.5 h-3.5" /> تعديل
              </button>
              <button onClick={() => handleDelete(i)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 text-rose-600 text-xs font-cairo font-bold hover:bg-rose-100 transition-colors">
                <Trash2 className="w-3.5 h-3.5" /> حذف
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal open={creating || !!editing} onClose={() => { setCreating(false); setEditing(null); }} title={editing ? 'تعديل السؤال' : 'سؤال جديد'}>
        <FAQForm
          faq={editing}
          onSave={(faq) => {
            if (editing) {
              setFaqs(prev => prev.map((f, i) => i === editing.index ? faq : f));
            } else {
              setFaqs(prev => [...prev, faq]);
            }
            setCreating(false);
            setEditing(null);
          }}
        />
      </Modal>
    </div>
  );
}

function FAQForm({ faq, onSave }: { faq: { q: string; a: string } | null; onSave: (f: { q: string; a: string }) => void }) {
  const [q, setQ] = useState(faq?.q || '');
  const [a, setA] = useState(faq?.a || '');
  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  return (
    <div className="space-y-4">
      <div>
        <label className={labelClass}>السؤال</label>
        <input value={q} onChange={(e) => setQ(e.target.value)} className={inputClass} placeholder="اكتب السؤال..." />
      </div>
      <div>
        <label className={labelClass}>الجواب</label>
        <textarea value={a} onChange={(e) => setA(e.target.value)} rows={4} className={inputClass + ' resize-none'} placeholder="اكتب الجواب..." />
      </div>
      <button onClick={() => onSave({ q, a })} disabled={!q.trim() || !a.trim()} className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50">
        حفظ
      </button>
    </div>
  );
}
