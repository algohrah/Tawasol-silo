import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MoreHorizontal, Loader2 } from 'lucide-react';

// ============================================================
//  قائمة إجراءات موحّدة بزر (⋯) — تستبدل صفّ الأزرار المبعثرة
//  تقلّل المساحة والتشتّت في بطاقات الإدارة
// ============================================================

export interface ActionItem {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  variant?: 'default' | 'primary' | 'danger' | 'success';
  disabled?: boolean;
  hidden?: boolean;
  divider?: boolean; // فاصل قبل العنصر
}

interface Props {
  items: ActionItem[];
  busy?: boolean;
  label?: string;
  align?: 'left' | 'right';
}

const variantClasses: Record<string, string> = {
  default: 'text-slate-700 hover:bg-slate-50',
  primary: 'text-slate-900 hover:bg-amber-50',
  danger: 'text-rose-600 hover:bg-rose-50',
  success: 'text-emerald-600 hover:bg-emerald-50',
};

export default function ActionMenu({ items, busy, label = 'إجراءات', align = 'left' }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const visible = items.filter((i) => !i.hidden);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        disabled={busy}
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 text-white font-cairo font-bold text-xs hover:bg-slate-800 transition-colors disabled:opacity-60"
      >
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <MoreHorizontal className="w-4 h-4" />}
        {label}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className={`absolute z-50 mt-2 min-w-[180px] bg-white rounded-2xl shadow-xl border border-slate-100 py-1.5 ${align === 'left' ? 'left-0' : 'right-0'}`}
          >
            {visible.map((item, i) => (
              <div key={i}>
                {item.divider && <div className="my-1 h-px bg-slate-100" />}
                <button
                  onClick={() => { if (!item.disabled) { item.onClick(); setOpen(false); } }}
                  disabled={item.disabled}
                  className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-cairo font-bold text-right transition-colors disabled:opacity-40 disabled:cursor-not-allowed
                    ${variantClasses[item.variant || 'default']}`}
                >
                  {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
                  {item.label}
                </button>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
