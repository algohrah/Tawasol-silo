import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Check, Filter } from 'lucide-react';

// ============================================================
//  فلتر منسدل موحّد — يستبدل صفوف أزرار الفلترة الكثيرة
//  يوفّر المساحة ويقلّل التشتّت البصري
// ============================================================

export interface FilterOption {
  value: string;
  label: string;
  count?: number;
}

interface Props {
  label?: string;
  value: string;
  options: FilterOption[];
  onChange: (value: string) => void;
  icon?: React.ReactNode;
  className?: string;
}

export default function FilterDropdown({ label, value, options, onChange, icon, className = '' }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const current = options.find((o) => o.value === value);
  const totalActive = value !== 'all' && value !== options[0]?.value;

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        onClick={() => setOpen((v) => !v)}
        className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-sm font-cairo font-bold transition-colors border
          ${totalActive ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
      >
        {icon || <Filter className="w-4 h-4" />}
        <span className="text-[11px] opacity-70">{label}</span>
        <span>{current?.label || 'الكل'}</span>
        {current?.count !== undefined && current.count > 0 && (
          <span className={`px-1.5 rounded text-[10px] ${totalActive ? 'bg-amber-500 text-slate-900' : 'bg-slate-100 text-slate-500'}`}>
            {current.count}
          </span>
        )}
        <ChevronDown className={`w-4 h-4 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 mt-2 min-w-[200px] bg-white rounded-2xl shadow-xl border border-slate-100 py-1.5 max-h-72 overflow-y-auto right-0"
          >
            {options.map((opt) => {
              const active = opt.value === value;
              return (
                <button
                  key={opt.value}
                  onClick={() => { onChange(opt.value); setOpen(false); }}
                  className={`w-full flex items-center justify-between gap-3 px-4 py-2.5 text-sm font-cairo text-right transition-colors
                    ${active ? 'bg-slate-50 text-slate-900 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}
                >
                  <span className="flex items-center gap-2">
                    {active ? <Check className="w-4 h-4 text-emerald-500" /> : <span className="w-4" />}
                    {opt.label}
                  </span>
                  {opt.count !== undefined && (
                    <span className={`px-1.5 rounded text-[10px] ${active ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-400'}`}>
                      {opt.count}
                    </span>
                  )}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
