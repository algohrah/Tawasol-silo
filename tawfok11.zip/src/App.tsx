import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from './lib/AppContext';
import Layout from './components/layout/Layout';
import ProtectedRoute from './components/layout/ProtectedRoute';
import AdminLayout from './components/admin/AdminLayout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Search from './pages/Search';
import MemberProfile from './pages/MemberProfile';
import AdminChat from './pages/AdminChat';
import InterestRequests from './pages/InterestRequests';
import JourneyPage from './pages/JourneyPage';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';
import EditProfile from './pages/EditProfile';
import CompleteProfile from './pages/CompleteProfile';
import Plans from './pages/Plans';
import Checkout from './pages/Checkout';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import About from './pages/About';
import Contact from './pages/Contact';
import Support from './pages/Support';
import FAQ from './pages/FAQ';
import LegalPage from './pages/Legal';
import NotFound from './pages/NotFound';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminMembers from './pages/admin/AdminMembers';
import AdminRequests from './pages/admin/AdminRequests';
import AdminNotifications from './pages/admin/AdminNotifications';
import AdminBlog from './pages/admin/AdminBlog';
import AdminFAQ from './components/AdminFAQ';
import AdminPlans from './pages/admin/AdminPlans';
import AdminFields from './pages/admin/AdminFields';
import AdminSite from './pages/admin/AdminSite';
import AdminSettings from './pages/admin/AdminSettings';
import AdminModerators from './pages/admin/AdminModerators';
import AdminMessages from './pages/admin/AdminMessages';
import AdminReports from './pages/admin/AdminReports';
import AdminModeration from './pages/admin/AdminModeration';

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          {/* ===== لوحة الإدارة ===== */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="members" element={<AdminMembers />} />
            <Route path="requests" element={<AdminRequests />} />
            <Route path="messages" element={<AdminMessages />} />
            <Route path="moderation" element={<AdminModeration />} />
            <Route path="reports" element={<AdminReports />} />
            <Route path="notifications" element={<AdminNotifications />} />
            <Route path="blog" element={<AdminBlog />} />
            <Route path="faq" element={<AdminFAQ />} />
            <Route path="plans" element={<AdminPlans />} />
            <Route path="fields" element={<AdminFields />} />
            <Route path="site" element={<AdminSite />} />
            <Route path="settings" element={<AdminSettings />} />
            <Route path="moderators" element={<AdminModerators />} />
          </Route>

          {/* ===== الموقع العام ===== */}
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/search" element={<Search />} />
            <Route path="/member/:id" element={<MemberProfile />} />
            <Route path="/plans" element={<Plans />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:id" element={<BlogPost />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/support" element={<Support />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/privacy" element={<LegalPage type="privacy" />} />
            <Route path="/terms" element={<LegalPage type="terms" />} />

            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/profile/edit" element={<ProtectedRoute><EditProfile /></ProtectedRoute>} />
            <Route path="/profile/complete" element={<ProtectedRoute><CompleteProfile /></ProtectedRoute>} />
            <Route path="/profile/*" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/checkout/:planId" element={<ProtectedRoute><Checkout /></ProtectedRoute>} />
            <Route path="/admin-chat" element={<ProtectedRoute><AdminChat /></ProtectedRoute>} />
            <Route path="/requests" element={<ProtectedRoute><InterestRequests /></ProtectedRoute>} />
            <Route path="/journey/:requestId" element={<ProtectedRoute><JourneyPage /></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
}
