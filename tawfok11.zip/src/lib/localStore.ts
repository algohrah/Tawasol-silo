// ============================================================
//  مخزن بيانات محلي — يحاكي قاعدة البيانات بالكامل (للتجربة فقط)
//  كل شيء في localStorage — لا اتصال بأي خادم أو Supabase
//  عند الانتهاء من التصميم سنستبدل هذا الملف بطبقة API حقيقية
// ============================================================

import { MEMBERS } from './members';
import type { Member } from './members';

// الحساب الافتراضي عند عدم وجود انتحال هوية
export const DEFAULT_USER_ID = 'm2';

// ===== مصدر الأعضاء الموحّد =====
// يقرأ تعديلات الإدارة المحفوظة في saved_members_list (يضبطها AppContext
// عند adminUpdateMember / الموافقة / التعديل) ثم يسقط إلى القائمة الأصلية.
// هكذا تظهر تعديلات الإدارة فوراً للطرف الآخر في صفحة الطلبات والرحلة.
export function getLiveMembers(): Member[] {
  if (typeof window !== 'undefined') {
    try {
      const saved = window.localStorage.getItem('saved_members_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed as Member[];
      }
    } catch { /* تجاهل */ }
  }
  return MEMBERS;
}

export function getLiveMemberById(id: string): Member | undefined {
  return getLiveMembers().find((m) => m.id === id);
}

// ===== الهوية النشطة (تتغيّر عند الدخول لحساب من لوحة التحكم) =====
// تُقرأ من active_member_id الذي يضبطه impersonateUser في AppContext
export function getCurrentUserId(): string {
  if (typeof window !== 'undefined') {
    try {
      const id = window.localStorage.getItem('active_member_id');
      if (id) return id;
    } catch { /* تجاهل */ }
  }
  return DEFAULT_USER_ID;
}

export function setCurrentUserId(id: string) {
  if (typeof window !== 'undefined') {
    try { window.localStorage.setItem('active_member_id', id); } catch { /* تجاهل */ }
  }
}

// للتوافق الرجعي مع الكود القديم — لكن يُفضّل استخدام getCurrentUserId()
export const CURRENT_USER_ID = DEFAULT_USER_ID;

// ===== تتبّع "غير المقروء" — متى آخر مرة شاهد المستخدم كل طلب =====
const SEEN_KEY = 'requests_last_seen';

function readSeenMap(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  try { return JSON.parse(window.localStorage.getItem(SEEN_KEY) || '{}'); } catch { return {}; }
}

// هل الطلب يحمل تحديثاً لم يره المستخدم بعد؟
export function isRequestUnseen(requestId: number, updatedAt?: string | null): boolean {
  if (!updatedAt) return false;
  const map = readSeenMap();
  const seen = map[String(requestId)];
  if (!seen) return true;                 // لم يُشاهد قط
  return new Date(updatedAt).getTime() > new Date(seen).getTime();
}

// تعليم طلب كمقروء (عند فتح رحلته)
export function markRequestSeen(requestId: number) {
  if (typeof window === 'undefined') return;
  try {
    const map = readSeenMap();
    map[String(requestId)] = new Date().toISOString();
    window.localStorage.setItem(SEEN_KEY, JSON.stringify(map));
  } catch { /* تجاهل */ }
}

// ===== الأنواع =====
export interface LocalRequest {
  id: number;
  sender_id: string;
  receiver_id: string;
  journey_stage: string;
  message: string;
  sender_paid: boolean;
  receiver_paid: boolean;
  sender_paid_at?: string | null;
  receiver_paid_at?: string | null;
  paid_at?: string | null;
  meeting_date?: string | null;
  meeting_notes?: string | null;
  decline_reason?: string | null;
  cancel_reason?: string | null;
  evaluation_result?: string | null;
  evaluation_note?: string | null;
  admin_notes?: string | null;
  // ===== معلومات التواصل (تُدخلها الأنثى، يراها الذكر بعد القَسَم) =====
  contact_info?: string | null;   // (قديم) — يُترك للتوافق الرجعي
  contact_by?: string | null;     // معرّف من أدخل معلومات التواصل
  guardian_phone?: string | null; // 📱 رقم ولي الأمر (أساسي)
  guardian_name?: string | null;  // 👤 اسم ولي الأمر
  guardian_relation?: string | null; // صلة القرابة (الأب/الأخ/العم...)
  contact_time?: string | null;   // ⏰ الوقت المناسب للاتصال
  contact_note?: string | null;   // 📝 ملاحظة اختيارية
  male_pledged?: boolean;         // هل أقسم الذكر بعدم النشر قبل رؤية المعلومات
  created_at: string;
  updated_at: string;
}

export interface LocalEvent {
  id: number;
  request_id: number;
  actor_id: string;
  type: string;
  note: string;
  created_at: string;
}

export interface LocalInquiryMessage {
  id: number;
  request_id: number;
  sender_id: string;   // 'admin' = الوسيطة
  text: string;
  charged_to: string | null;
  created_at: string;
}

export interface LocalInquiryPackage {
  id: number;
  request_id: number;
  owner_id: string;
  credits_total: number;
  credits_used: number;
  price: number;
  active: boolean;
  created_at: string;
}

export interface LocalNotification {
  id: number;
  user_id: string;      // المستلم المعني بالإشعار
  request_id: number;   // الطلب المرتبط (للانتقال للرحلة)
  type: string;         // نوع الحدث
  text: string;
  read: boolean;
  created_at: string;
}

interface DB {
  requests: LocalRequest[];
  events: LocalEvent[];
  inquiryMessages: LocalInquiryMessage[];
  inquiryPackages: LocalInquiryPackage[];
  notifications: LocalNotification[];
  seq: number;
}

// رفعنا الإصدار إلى v3 لضمان بدء جميع الحسابات برحلات اهتمام فارغة نظيفة
// (يتجاهل أي بيانات بذرة قديمة كانت محفوظة في الإصدار السابق).
const STORAGE_KEY = 'twafok_local_db_v3';

// ===== بيانات البذرة (طلبات بمراحل مختلفة) =====
function seedDB(): DB {
  // لا توجد بيانات بذرة — جميع رحلات الاهتمام تبدأ فارغة لكل الحسابات.
  // يبدأ كل عضو بصفحة طلبات نظيفة بلا أي طلب سابق.
  return { requests: [], events: [], inquiryMessages: [], inquiryPackages: [], notifications: [], seq: 0 };
}

// ===== تحميل/حفظ =====
let db: DB | null = null;

function load(): DB {
  if (db) return db;
  if (typeof window !== 'undefined') {
    try {
      // تنظيف الإصدارات القديمة لضمان بداية نظيفة لجميع الحسابات
      window.localStorage.removeItem('twafok_local_db_v2');
      window.localStorage.removeItem('twafok_local_db');
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        db = JSON.parse(raw);
        // ترقية: ضمان وجود مصفوفة الإشعارات للبيانات القديمة
        if (db && !db.notifications) db.notifications = [];
        return db!;
      }
    } catch { /* تجاهل */ }
  }
  db = seedDB();
  save();
  return db;
}

function save() {
  if (db && typeof window !== 'undefined') {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); } catch { /* تجاهل */ }
  }
}

function nextId(): number {
  const d = load();
  d.seq += 1;
  return d.seq;
}

// إعادة ضبط قاعدة البيانات المحلية (للتجربة)
export function resetLocalDB() {
  db = seedDB();
  save();
}

// محاكاة تأخير شبكة بسيط (اختياري)
const delay = (ms = 120) => new Promise((r) => setTimeout(r, ms));

// ===== الأعضاء =====
export async function getMembers() {
  await delay(60);
  // يقرأ من تعديلات الإدارة الحيّة كي تظهر للطرف الآخر فور حفظها
  return getLiveMembers().map((m) => ({
    id: m.id, nickname: m.nickname, gender: m.gender, age: m.age,
    country: m.country, city: m.city, verified: m.verified, premium: m.premium,
  }));
}

// ===== الطلبات =====
export async function getRequests(userId?: string): Promise<LocalRequest[]> {
  await delay();
  const d = load();
  const sorted = [...d.requests].sort((a, b) => b.created_at.localeCompare(a.created_at));
  if (!userId) return sorted;
  return sorted.filter((r) => r.sender_id === userId || r.receiver_id === userId);
}

export async function getRequest(id: number): Promise<LocalRequest | null> {
  await delay(60);
  const d = load();
  return d.requests.find((r) => r.id === id) || null;
}

export async function createRequest(senderId: string, receiverId: string, message: string) {
  await delay();
  if (senderId === receiverId) {
    return { ok: false, error: 'لا يمكنك إرسال طلب اهتمام لنفسك' };
  }
  const d = load();
  // منع التكرار: أي طلب غير منتهٍ بالرفض/الإلغاء يُعتبر قائماً.
  // المراحل المنتهية التي تسمح بطلب جديد: declined (مرفوض) و cancelled (ملغى).
  const blocking = d.requests.find((r) =>
    r.sender_id === senderId && r.receiver_id === receiverId &&
    r.journey_stage !== 'declined' && r.journey_stage !== 'cancelled',
  );
  if (blocking) {
    // رسالة دقيقة حسب الحالة
    if (blocking.journey_stage === 'sent') {
      return { ok: false, error: 'لديك طلب اهتمام مُرسَل لهذا العضو بالفعل ولم يتم الرد عليه بعد.' };
    }
    if (blocking.journey_stage === 'completed') {
      return { ok: false, error: 'لديك رحلة مكتملة مع هذا العضو بالفعل.' };
    }
    return { ok: false, error: 'لديك طلب اهتمام نشط مع هذا العضو بالفعل.' };
  }

  const now = new Date().toISOString();
  const req: LocalRequest = {
    id: nextId(), sender_id: senderId, receiver_id: receiverId, journey_stage: 'sent',
    message: (message || '').trim() || 'طلب اهتمام مرسل عبر الإدارة',
    sender_paid: false, receiver_paid: false, created_at: now, updated_at: now,
  };
  d.requests.unshift(req);
  addEvent(d, req.id, senderId, 'sent', 'تم إرسال طلب الاهتمام');
  save();
  return { ok: true, data: req };
}

function addEvent(d: DB, requestId: number, actorId: string, type: string, note: string) {
  d.events.push({
    id: nextId(), request_id: requestId, actor_id: actorId || 'system',
    type, note, created_at: new Date().toISOString(),
  });
}

// #9 توليد إشعار حقيقي يقود مباشرة لصفحة الرحلة
function addNotification(d: DB, userId: string, requestId: number, type: string, text: string) {
  if (!d.notifications) d.notifications = [];
  d.notifications.push({
    id: nextId(), user_id: userId, request_id: requestId, type, text,
    read: false, created_at: new Date().toISOString(),
  });
}

// إشعار الطرف الآخر بتغيّر المرحلة (المتلقّي = الطرف غير الفاعل)
function notifyOther(d: DB, req: LocalRequest, actorId: string, type: string, text: string) {
  const otherId = actorId === req.sender_id ? req.receiver_id : req.sender_id;
  addNotification(d, otherId, req.id, type, text);
}

// ===== تنفيذ إجراءات الرحلة =====
export async function runRequestAction(
  requestId: number, action: string, actorId: string, payload: Record<string, any> = {},
): Promise<{ ok: boolean; data?: LocalRequest; error?: string }> {
  await delay();
  const d = load();
  const req = d.requests.find((r) => r.id === requestId);
  if (!req) return { ok: false, error: 'الطلب غير موجود' };

  const now = new Date().toISOString();
  req.updated_at = now;
  let evType = action, evNote = '';

  switch (action) {
    case 'accept':
      req.journey_stage = 'accepted';
      evNote = 'قبِل الطرف الآخر طلب الاهتمام';
      break;
    case 'decline':
      req.journey_stage = 'declined';
      req.decline_reason = payload.reason || 'عدم التوافق';
      evNote = 'تم الاعتذار عن الطلب: ' + (payload.reason || '');
      break;
    case 'cancel':
      req.journey_stage = 'cancelled';
      req.cancel_reason = payload.reason || 'تم الإلغاء';
      evNote = 'تم إلغاء الطلب: ' + (payload.reason || '');
      break;
    case 'pay_deposit': {
      const isSender = actorId === req.sender_id;
      if (isSender) { req.sender_paid = true; req.sender_paid_at = now; }
      else { req.receiver_paid = true; req.receiver_paid_at = now; }
      if (req.journey_stage === 'accepted') req.journey_stage = 'seriousness';
      if (req.sender_paid && req.receiver_paid) {
        req.journey_stage = 'coordination';
        req.paid_at = now;
      }
      evNote = 'تم سداد عربون الجدية (' + (isSender ? 'المرسِل' : 'المستقبِل') + ')';
      break;
    }
    case 'update_coordination':
      if (payload.meetingDate !== undefined) req.meeting_date = payload.meetingDate;
      if (payload.meetingNotes !== undefined) req.meeting_notes = payload.meetingNotes;
      if (payload.advance) req.journey_stage = 'sharia_viewing';
      evNote = 'تحديث تبادل التواصل وتنسيق الموعد';
      evType = 'coordination';
      break;
    case 'submit_contact': {
      // الأنثى هي من تُدخل معلومات التواصل (رقم ولي الأمر) بإشراف الإدارة
      const actor = getLiveMemberById(actorId);
      if (!actor) return { ok: false, error: 'تعذّر التحقق من الحساب' };
      if (actor.gender === 'male') {
        return { ok: false, error: 'يقوم الطرف الأنثى بمشاركة معلومات التواصل بإشراف الإدارة. ستظهر لك فور إرسالها.' };
      }
      const phone = String(payload.guardianPhone || '').trim();
      if (!phone) {
        return { ok: false, error: 'رقم ولي الأمر مطلوب' };
      }
      req.guardian_phone = phone;
      req.guardian_name = String(payload.guardianName || '').trim() || null;
      req.guardian_relation = String(payload.guardianRelation || '').trim() || null;
      req.contact_time = String(payload.contactTime || '').trim() || null;
      req.contact_note = String(payload.contactNote || '').trim() || null;
      req.contact_by = actorId;
      // تجميع نصّي للتوافق الرجعي
      req.contact_info = [
        req.guardian_name ? `${req.guardian_name}${req.guardian_relation ? ' (' + req.guardian_relation + ')' : ''}` : null,
        `📱 ${phone}`,
        req.contact_time ? `⏰ ${req.contact_time}` : null,
        req.contact_note ? `📝 ${req.contact_note}` : null,
      ].filter(Boolean).join(' — ');
      evNote = 'شاركت الطرف الأنثى معلومات التواصل (رقم ولي الأمر) بإشراف الإدارة';
      evType = 'coordination';
      break;
    }
    case 'male_pledge': {
      // قَسَم الطرف الذكر بعدم النشر والتواصل بنية الزواج قبل رؤية المعلومات
      const actor = getLiveMemberById(actorId);
      if (!actor) return { ok: false, error: 'تعذّر التحقق من الحساب' };
      if (actor.gender === 'female') {
        return { ok: false, error: 'هذا التعهّد خاص بالطرف الآخر.' };
      }
      req.male_pledged = true;
      evNote = 'أقسم الطرف الذكر بعدم نشر المعلومات والتواصل بنية الزواج';
      evType = 'coordination';
      break;
    }
    case 'advance_viewing':
      req.journey_stage = 'sharia_viewing';
      evNote = 'الانتقال لمرحلة النظرة الشرعية';
      evType = 'sharia_viewing';
      break;
    case 'record_result':
      // نتيجة النظرة: توافق -> الملكة، اعتذار -> مرفوض مع السبب
      if (payload.result === 'failed') {
        req.journey_stage = 'declined';
        req.decline_reason = payload.note || payload.reason || 'تم الاعتذار بعد النظرة الشرعية';
        req.evaluation_result = 'failed';
        req.evaluation_note = payload.note || '';
        evNote = 'الاعتذار بعد النظرة الشرعية: ' + (payload.note || payload.reason || '');
        evType = 'decline';
      } else {
        req.journey_stage = 'engagement';
        req.evaluation_result = 'success';
        req.evaluation_note = payload.note || '';
        evNote = 'توافق مبارك بعد النظرة الشرعية — الانتقال للملكة';
        evType = 'sharia_viewing';
      }
      break;
    case 'complete_engagement':
      req.journey_stage = 'completed';
      req.evaluation_result = 'success';
      if (payload.note) req.evaluation_note = payload.note;
      evNote = 'تم إتمام الملكة وعقد القران المبارك 🎉';
      evType = 'completed';
      break;
    case 'set_stage':
      if (['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed', 'declined', 'cancelled'].includes(payload.stage)) {
        req.journey_stage = payload.stage;
        if (payload.stage === 'cancelled') req.cancel_reason = payload.note || 'إلغاء إداري';
        if (payload.stage === 'declined') req.decline_reason = payload.note || 'رفض إداري';
      }
      evNote = payload.note || ('تعديل إداري للمرحلة إلى ' + payload.stage);
      break;
    default:
      return { ok: false, error: 'إجراء غير معروف: ' + action };
  }

  addEvent(d, requestId, actorId, evType, evNote);

  // #9 توليد إشعارات حقيقية للطرف الآخر حسب الإجراء — تقود مباشرة للرحلة
  const actorName = getLiveMemberById(actorId)?.nickname || 'الطرف الآخر';
  switch (action) {
    case 'accept':
      notifyOther(d, req, actorId, 'request', `قبِل ${actorName} طلب اهتمامك — تابع رحلتك الآن`);
      break;
    case 'decline':
      notifyOther(d, req, actorId, 'system', `اعتذر ${actorName} عن إكمال الطلب`);
      break;
    case 'cancel':
      notifyOther(d, req, actorId, 'system', `تم إلغاء طلب الاهتمام من ${actorName}`);
      break;
    case 'pay_deposit':
      if (req.journey_stage === 'coordination') {
        // أكّد الطرفان الجدية — أشعِر كليهما ببدء التنسيق
        addNotification(d, req.sender_id, req.id, 'match', 'أكّد الطرفان الجدية! بدأت مرحلة تنسيق التعارف 🎉');
        addNotification(d, req.receiver_id, req.id, 'match', 'أكّد الطرفان الجدية! بدأت مرحلة تنسيق التعارف 🎉');
      } else {
        notifyOther(d, req, actorId, 'request', `سدّد ${actorName} عربون الجدية — بانتظار سدادك لبدء التنسيق`);
      }
      break;
    case 'submit_contact':
      notifyOther(d, req, actorId, 'match', 'تمت مشاركة معلومات التواصل — يمكنك المتابعة');
      break;
    case 'advance_viewing':
      addNotification(d, req.sender_id, req.id, 'match', 'انتقلت رحلتكما إلى مرحلة النظرة الشرعية');
      addNotification(d, req.receiver_id, req.id, 'match', 'انتقلت رحلتكما إلى مرحلة النظرة الشرعية');
      break;
    case 'record_result':
      if (payload.result !== 'failed') {
        notifyOther(d, req, actorId, 'match', 'توافق مبارك بعد النظرة — الانتقال لمرحلة الملكة 💍');
      } else {
        notifyOther(d, req, actorId, 'system', 'تم الاعتذار بعد النظرة الشرعية');
      }
      break;
    case 'complete_engagement':
      addNotification(d, req.sender_id, req.id, 'match', 'مبارك! تم إتمام الملكة وعقد القران 🎉');
      addNotification(d, req.receiver_id, req.id, 'match', 'مبارك! تم إتمام الملكة وعقد القران 🎉');
      break;
    case 'set_stage':
      // إجراء إداري — أشعِر الطرفين بتحديث الإدارة لمرحلة الرحلة
      if (actorId === 'admin') {
        const adminText = payload.stage === 'cancelled'
          ? 'قامت إدارة المنصة بإلغاء طلب الاهتمام'
          : 'حدّثت إدارة المنصة مرحلة رحلتكما';
        addNotification(d, req.sender_id, req.id, 'admin', adminText);
        addNotification(d, req.receiver_id, req.id, 'admin', adminText);
      }
      break;
    case 'update_coordination':
      if (actorId === 'admin') {
        addNotification(d, req.sender_id, req.id, 'match', 'حدّثت الإدارة تفاصيل موعد التعارف — اطّلع عليها');
        addNotification(d, req.receiver_id, req.id, 'match', 'حدّثت الإدارة تفاصيل موعد التعارف — اطّلع عليها');
      }
      break;
  }

  save();
  return { ok: true, data: { ...req } };
}

// ===== سجل الأحداث =====
export async function getEvents(requestId: number): Promise<LocalEvent[]> {
  await delay(60);
  const d = load();
  return d.events
    .filter((e) => e.request_id === requestId)
    .sort((a, b) => a.created_at.localeCompare(b.created_at));
}

// ===== باقة الاستفسار =====
const INQUIRY_CREDITS = 20;
const INQUIRY_PRICE = 100;

export interface InquiryStateLocal {
  package: LocalInquiryPackage | null;
  remaining: number;
  messages: LocalInquiryMessage[];
}

function inquiryState(d: DB, requestId: number): InquiryStateLocal {
  const pkg = [...d.inquiryPackages]
    .filter((p) => p.request_id === requestId && p.active)
    .sort((a, b) => b.id - a.id)[0] || null;
  const messages = d.inquiryMessages
    .filter((m) => m.request_id === requestId)
    .sort((a, b) => a.created_at.localeCompare(b.created_at));
  const remaining = pkg ? Math.max(0, pkg.credits_total - pkg.credits_used) : 0;
  return { package: pkg, remaining, messages };
}

export async function getInquiry(requestId: number): Promise<InquiryStateLocal> {
  await delay(60);
  return inquiryState(load(), requestId);
}

export async function buyInquiry(requestId: number, ownerId: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay();
  const d = load();
  const pkg: LocalInquiryPackage = {
    id: nextId(), request_id: requestId, owner_id: ownerId,
    credits_total: INQUIRY_CREDITS, credits_used: 0, price: INQUIRY_PRICE,
    active: true, created_at: new Date().toISOString(),
  };
  d.inquiryPackages.push(pkg);
  addEvent(d, requestId, ownerId, 'inquiry_buy', `تم شراء باقة استفسار (${INQUIRY_CREDITS} رسالة)`);
  d.inquiryMessages.push({
    id: nextId(), request_id: requestId, sender_id: 'admin',
    text: 'مرحباً بكما في غرفة الاستفسار المُشرَفة. يرجى طرح الأسئلة الجوهرية بأسلوب لائق ومحترم.',
    charged_to: null, created_at: new Date().toISOString(),
  });
  save();
  return { ok: true, state: inquiryState(d, requestId) };
}

export async function sendInquiry(requestId: number, senderId: string, text: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay();
  const d = load();
  if (!text || text.trim().length < 2) return { ok: false, error: 'الرسالة قصيرة جداً' };
  const pkg = [...d.inquiryPackages]
    .filter((p) => p.request_id === requestId && p.active)
    .sort((a, b) => b.id - a.id)[0];
  if (!pkg) return { ok: false, error: 'لا توجد باقة استفسار نشطة' };
  const remaining = pkg.credits_total - pkg.credits_used;
  if (remaining <= 0) return { ok: false, error: 'نفد رصيد الباقة' };

  d.inquiryMessages.push({
    id: nextId(), request_id: requestId, sender_id: senderId, text: text.trim(),
    charged_to: pkg.owner_id, created_at: new Date().toISOString(),
  });
  pkg.credits_used += 1;
  save();
  return { ok: true, state: inquiryState(d, requestId) };
}

// محاكاة ردّ الطرف الآخر (للتجربة) — يُخصم من رصيد صاحب الباقة
export async function simulateReply(requestId: number, replierId: string, text: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay(400);
  const d = load();
  const pkg = [...d.inquiryPackages]
    .filter((p) => p.request_id === requestId && p.active)
    .sort((a, b) => b.id - a.id)[0];
  if (!pkg) return { ok: false, error: 'لا توجد باقة' };
  const remaining = pkg.credits_total - pkg.credits_used;
  if (remaining <= 0) return { ok: false, error: 'نفد الرصيد' };

  d.inquiryMessages.push({
    id: nextId(), request_id: requestId, sender_id: replierId, text,
    charged_to: pkg.owner_id, created_at: new Date().toISOString(),
  });
  pkg.credits_used += 1; // الردّ يُخصم من صاحب الباقة
  save();
  return { ok: true, state: inquiryState(d, requestId) };
}

// ===== #9 إشعارات الرحلة =====
export async function getJourneyNotifications(userId: string): Promise<LocalNotification[]> {
  await delay(100);
  const d = load();
  if (!d.notifications) return [];
  return d.notifications
    .filter((n) => n.user_id === userId)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function markNotificationRead(id: number) {
  const d = load();
  const n = d.notifications?.find((x) => x.id === id);
  if (n) { n.read = true; save(); }
}

export function markAllNotificationsRead(userId: string) {
  const d = load();
  (d.notifications || []).forEach((n) => { if (n.user_id === userId) n.read = true; });
  save();
}

export function deleteNotification(id: number) {
  const d = load();
  if (d.notifications) { d.notifications = d.notifications.filter((n) => n.id !== id); save(); }
}

// ============================================================
//  ===== لوحة الإدارة (محلية بالكامل) =====
//  تقرأ نفس قاعدة بيانات الطلبات المحلية، فيرتبط ما يفعله
//  الأعضاء (قبول/رفض/دفع) مباشرةً بما تراه الإدارة، والعكس.
// ============================================================

interface AdminMemberMeta {
  status: 'active' | 'suspended' | 'pending';
  plan: 'free' | 'gold' | 'elite';
  realName: string;
  email: string;
  phone: string;
  nationalId: string;
  password: string;             // كلمة سر الحساب (لعرضها للإدارة)
  joinedAt: string;
  verifiedOverride?: boolean;   // تجاوز إداري لحالة التوثيق
  premiumOverride?: boolean;    // تجاوز إداري للاشتراك المميّز
  adminNote?: string;           // ملاحظة إدارية خاصة
  flagged?: boolean;            // معلّم للمتابعة
  deleted?: boolean;            // محذوف نهائياً (إداري)
}

const ADMIN_META_KEY = 'twafok_admin_meta_v1';

function readAdminMeta(): Record<string, AdminMemberMeta> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(ADMIN_META_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* تجاهل */ }
  return {};
}

function writeAdminMeta(meta: Record<string, AdminMemberMeta>) {
  if (typeof window === 'undefined') return;
  try { window.localStorage.setItem(ADMIN_META_KEY, JSON.stringify(meta)); } catch { /* تجاهل */ }
}

function defaultMeta(m: Member): AdminMemberMeta {
  const plan: AdminMemberMeta['plan'] = m.premium ? (m.hasSeriousnessBadge ? 'elite' : 'gold') : 'free';
  const num = parseInt(m.id.replace(/\D/g, '') || '0', 10);
  const phoneTail = String(1000000 + (num * 13579) % 8999999);
  const pwSeed = String(100000 + (num * 246813) % 899999);
  return {
    status: 'active',
    plan,
    realName: m.nickname,
    email: `${m.id}@twafok.sa`,
    phone: `+9665${phoneTail}`.slice(0, 13),
    nationalId: `10${String(20000000 + (num * 7654321) % 79999999)}`,
    password: `Twafok@${pwSeed}`,
    joinedAt: '2025-01-15',
  };
}

function getMeta(m: Member): AdminMemberMeta {
  const all = readAdminMeta();
  if (!all[m.id]) {
    all[m.id] = defaultMeta(m);
    writeAdminMeta(all);
  }
  return all[m.id];
}

export interface AdminMemberRowLocal {
  id: string;
  nickname: string;
  gender: 'male' | 'female';
  age: number;
  country: string;
  city: string;
  verified: boolean;
  premium: boolean;
  realName: string;
  email: string;
  phone: string;
  nationalId: string;
  password: string;
  status: 'active' | 'suspended' | 'pending';
  plan: 'free' | 'gold' | 'elite';
  joinedAt: string;
  requestsCount: number;
  district: string;
  education: string;
  workType: string;
  adminNote: string;
  flagged: boolean;
}

export async function adminGetMembers(): Promise<AdminMemberRowLocal[]> {
  await delay(80);
  const d = load();
  return getLiveMembers().map((m) => {
    const meta = getMeta(m);
    const requestsCount = d.requests.filter(
      (r) => r.sender_id === m.id || r.receiver_id === m.id,
    ).length;
    const verified = meta.verifiedOverride !== undefined ? meta.verifiedOverride : m.verified;
    const premium = meta.premiumOverride !== undefined ? meta.premiumOverride : m.premium;
    return {
      id: m.id, nickname: m.nickname, gender: m.gender, age: m.age,
      country: m.country, city: m.city, verified, premium,
      realName: meta.realName, email: meta.email, phone: meta.phone,
      nationalId: meta.nationalId, password: meta.password || 'Twafok@000000',
      status: meta.status, plan: meta.plan,
      joinedAt: meta.joinedAt, requestsCount,
      district: m.district, education: m.education, workType: m.workType,
      adminNote: meta.adminNote || '', flagged: !!meta.flagged,
    };
  }).filter((row) => {
    const all = readAdminMeta();
    return !all[row.id]?.deleted;
  });
}

export async function adminUpdateMember(
  id: string,
  fields: { status?: string; plan?: string; verified?: boolean; premium?: boolean; adminNote?: string; flagged?: boolean },
): Promise<boolean> {
  await delay(60);
  const all = readAdminMeta();
  const m = getLiveMemberById(id);
  if (!m) return false;
  if (!all[id]) all[id] = defaultMeta(m);
  if (fields.status) all[id].status = fields.status as AdminMemberMeta['status'];
  if (fields.plan) all[id].plan = fields.plan as AdminMemberMeta['plan'];
  if (fields.verified !== undefined) all[id].verifiedOverride = fields.verified;
  if (fields.premium !== undefined) all[id].premiumOverride = fields.premium;
  if (fields.adminNote !== undefined) all[id].adminNote = fields.adminNote;
  if (fields.flagged !== undefined) all[id].flagged = fields.flagged;
  writeAdminMeta(all);
  return true;
}

export async function adminDeleteMember(id: string): Promise<boolean> {
  await delay(60);
  const all = readAdminMeta();
  const m = getLiveMemberById(id);
  if (!m) return false;
  if (!all[id]) all[id] = defaultMeta(m);
  all[id].deleted = true;
  all[id].status = 'suspended';
  writeAdminMeta(all);
  return true;
}

// إعادة تعيين كلمة سر العضو (إداري)
export async function adminResetPassword(id: string): Promise<string | null> {
  await delay(60);
  const all = readAdminMeta();
  const m = getLiveMemberById(id);
  if (!m) return null;
  if (!all[id]) all[id] = defaultMeta(m);
  const newPw = `Twafok@${String(100000 + Math.floor(Math.random() * 899999))}`;
  all[id].password = newPw;
  writeAdminMeta(all);
  return newPw;
}

// إجراءات سريعة على الأعضاء
export async function adminToggleVerified(id: string, value: boolean): Promise<boolean> {
  return adminUpdateMember(id, { verified: value });
}
export async function adminSetPremium(id: string, value: boolean): Promise<boolean> {
  return adminUpdateMember(id, { premium: value, plan: value ? 'gold' : 'free' });
}
export async function adminSetNote(id: string, note: string): Promise<boolean> {
  return adminUpdateMember(id, { adminNote: note });
}
export async function adminToggleFlag(id: string, value: boolean): Promise<boolean> {
  return adminUpdateMember(id, { flagged: value });
}

// إرسال إشعار إداري لعضو
export async function adminSendNotification(memberId: string, text: string, requestId = 0): Promise<boolean> {
  await delay(40);
  const d = load();
  if (!d.notifications) d.notifications = [];
  d.notifications.push({
    id: nextId(), user_id: memberId, request_id: requestId, type: 'admin',
    text: '📢 من الإدارة: ' + text, read: false, created_at: new Date().toISOString(),
  });
  save();
  return true;
}

// حذف طلب اهتمام نهائياً (إداري)
export async function adminDeleteRequest(requestId: number): Promise<boolean> {
  await delay(40);
  const d = load();
  d.requests = d.requests.filter((r) => r.id !== requestId);
  d.events = d.events.filter((e) => e.request_id !== requestId);
  save();
  return true;
}

export async function adminGetRequests(): Promise<LocalRequest[]> {
  await delay(80);
  const d = load();
  return [...d.requests].sort((a, b) => b.created_at.localeCompare(a.created_at));
}

export interface AdminStatsLocal {
  totalMembers: number;
  males: number;
  females: number;
  verified: number;
  premium: number;
  pendingMembers: number;
  totalRequests: number;
  pendingRequests: number;
  activeJourneys: number;
  completed: number;
  revenue: number;
  depositsPaid: number;
  stageBreakdown: Record<string, number>;
  recentEvents: LocalEvent[];
}

export async function adminGetStats(): Promise<AdminStatsLocal> {
  await delay(80);
  const d = load();
  const members = getLiveMembers();
  const meta = readAdminMeta();

  const males = members.filter((m) => m.gender === 'male').length;
  const females = members.filter((m) => m.gender === 'female').length;
  const verified = members.filter((m) => m.verified).length;
  const premium = members.filter((m) => m.premium).length;
  const pendingMembers = members.filter((m) => meta[m.id]?.status === 'pending').length;

  const stageBreakdown: Record<string, number> = {};
  let depositsPaid = 0;
  let inquiryRevenue = 0;
  for (const r of d.requests) {
    stageBreakdown[r.journey_stage] = (stageBreakdown[r.journey_stage] || 0) + 1;
    if (r.sender_paid) depositsPaid += 1;
    if (r.receiver_paid) depositsPaid += 1;
  }
  for (const p of d.inquiryPackages) inquiryRevenue += p.price || 0;

  const pendingRequests = d.requests.filter((r) => r.journey_stage === 'sent').length;
  const activeJourneys = d.requests.filter(
    (r) => !['sent', 'declined', 'cancelled', 'completed'].includes(r.journey_stage),
  ).length;
  const completed = d.requests.filter((r) => r.journey_stage === 'completed').length;

  const revenue = depositsPaid * 500 + inquiryRevenue + completed * 2000;

  const recentEvents = [...d.events]
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .slice(0, 12);

  return {
    totalMembers: members.length, males, females, verified, premium, pendingMembers,
    totalRequests: d.requests.length, pendingRequests, activeJourneys, completed,
    revenue, depositsPaid, stageBreakdown, recentEvents,
  };
}
