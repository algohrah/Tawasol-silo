import { useState, useEffect, useCallback } from 'react';
import {
  adminGetMembers, adminUpdateMember, adminDeleteMember, adminResetPassword,
  adminToggleVerified, adminSetPremium, adminSetNote, adminToggleFlag,
  adminSendNotification, adminDeleteRequest,
  adminGetRequests, adminGetStats, getEvents, runRequestAction,
  type AdminMemberRowLocal, type AdminStatsLocal, type LocalRequest,
} from './localStore';

// ============================================================
//  خطاف بيانات لوحة الإدارة — محلي بالكامل (localStorage)
//  يقرأ نفس قاعدة بيانات رحلة الطلب، فأي قبول/رفض/دفع من
//  الأعضاء ينعكس هنا فوراً، وأي تعديل من الإدارة ينعكس للأعضاء.
// ============================================================

export type AdminMemberRow = AdminMemberRowLocal;
export type AdminStats = AdminStatsLocal;
export type AdminRequestRow = LocalRequest;

export function useAdminMembers() {
  const [members, setMembers] = useState<AdminMemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMembers = useCallback(async () => {
    try {
      setError(null);
      setMembers(await adminGetMembers());
    } catch (err: any) {
      setError(err.message || 'تعذّر تحميل الأعضاء');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);

  const updateMember = useCallback(async (id: string, fields: { status?: string; plan?: string; verified?: boolean; premium?: boolean; adminNote?: string; flagged?: boolean }) => {
    const ok = await adminUpdateMember(id, fields);
    if (ok) await fetchMembers();
    return ok;
  }, [fetchMembers]);

  const deleteMember = useCallback(async (id: string) => {
    const ok = await adminDeleteMember(id);
    if (ok) await fetchMembers();
    return ok;
  }, [fetchMembers]);

  const resetPassword = useCallback(async (id: string) => {
    const newPw = await adminResetPassword(id);
    if (newPw) await fetchMembers();
    return newPw;
  }, [fetchMembers]);

  const toggleVerified = useCallback(async (id: string, v: boolean) => {
    const ok = await adminToggleVerified(id, v); if (ok) await fetchMembers(); return ok;
  }, [fetchMembers]);
  const setPremium = useCallback(async (id: string, v: boolean) => {
    const ok = await adminSetPremium(id, v); if (ok) await fetchMembers(); return ok;
  }, [fetchMembers]);
  const setNote = useCallback(async (id: string, note: string) => {
    const ok = await adminSetNote(id, note); if (ok) await fetchMembers(); return ok;
  }, [fetchMembers]);
  const toggleFlag = useCallback(async (id: string, v: boolean) => {
    const ok = await adminToggleFlag(id, v); if (ok) await fetchMembers(); return ok;
  }, [fetchMembers]);
  const notifyMember = useCallback(async (id: string, text: string) => {
    return adminSendNotification(id, text);
  }, []);

  return {
    members, loading, error, refresh: fetchMembers,
    updateMember, deleteMember, resetPassword, toggleVerified, setPremium, setNote, toggleFlag, notifyMember,
  };
}

export function useAdminStats() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setError(null);
      setStats(await adminGetStats());
    } catch (err: any) {
      setError(err.message || 'تعذّر تحميل الإحصائيات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  return { stats, loading, error, refresh };
}

export function useAdminRequests() {
  const [requests, setRequests] = useState<AdminRequestRow[]>([]);
  const [members, setMembers] = useState<AdminMemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<number | null>(null);

  const fetchAll = useCallback(async () => {
    try {
      setError(null);
      const [reqData, memData] = await Promise.all([
        adminGetRequests(),
        adminGetMembers(),
      ]);
      setRequests(reqData);
      setMembers(memData);
    } catch (err: any) {
      setError(err.message || 'تعذّر تحميل الطلبات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // الإدارة تضبط مرحلة الطلب مباشرة (ينعكس للأعضاء فوراً)
  const setStage = useCallback(async (requestId: number, stage: string, note?: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'set_stage', 'admin', { stage, note });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally {
      setActionLoading(null);
    }
  }, [fetchAll]);

  // الإدارة تحدّث تنسيق الموعد
  const updateCoordination = useCallback(async (requestId: number, meetingDate: string, meetingNotes: string) => {
    setActionLoading(requestId);
    try {
      const res = await runRequestAction(requestId, 'update_coordination', 'admin', { meetingDate, meetingNotes });
      if (res.ok) await fetchAll();
      return res.ok;
    } finally {
      setActionLoading(null);
    }
  }, [fetchAll]);

  const getMember = useCallback((id: string) => members.find((m) => m.id === id), [members]);

  // جلب سجل أحداث طلب معيّن (للوحة الإدارة)
  const fetchEvents = useCallback((requestId: number) => getEvents(requestId), []);

  // حذف طلب نهائياً
  const deleteRequest = useCallback(async (requestId: number) => {
    setActionLoading(requestId);
    try {
      const ok = await adminDeleteRequest(requestId);
      if (ok) await fetchAll();
      return ok;
    } finally { setActionLoading(null); }
  }, [fetchAll]);

  return {
    requests, members, loading, error, actionLoading,
    refresh: fetchAll, setStage, updateCoordination, getMember, fetchEvents, deleteRequest,
  };
}
