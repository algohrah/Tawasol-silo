// ============================================================
//  رحلة طلب الاهتمام — نظام موحّد (Single Source of Truth)
//  يستبدل: RequestStatus + MediationStage + coordinationStep
//  مقياس واحد للتقدّم = journeyStage
// ============================================================

import {
  Send, HeartHandshake, ShieldCheck, CalendarClock,
  Users, PartyPopper, XCircle, Ban, Eye, Gem, type LucideIcon,
} from 'lucide-react';

// ===== مراحل الرحلة (المسار الرئيسي) =====
export type JourneyStage =
  | 'sent'           // ① مُرسَل — وصل الطلب للطرف الآخر بانتظار رده
  | 'accepted'       // ② مقبول — (استفسار اختياري + عربون في صفحة واحدة)
  | 'seriousness'    // ③ تأكيد الجدية — سداد العربون من الطرفين
  | 'coordination'   // ④ تبادل التواصل — الإدارة تنسّق وتبادل القنوات
  | 'sharia_viewing' // ⑤ النظرة الشرعية — اللقاء الشرعي بإشراف الوسيطة
  | 'engagement'     // ⑥ الملكة — إتمام العقد ورسوم السعي النهائية
  | 'completed';     // ⑦ مكتمل — النتيجة النهائية

// ===== المساران الجانبيان =====
export type JourneyTerminal = 'declined' | 'cancelled';

export type JourneyState = JourneyStage | JourneyTerminal;

// ===== ترتيب المراحل الرئيسية =====
export const JOURNEY_STAGES: JourneyStage[] = [
  'sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed',
];

export const STAGE_INDEX: Record<JourneyStage, number> = {
  sent: 0, accepted: 1, seriousness: 2, coordination: 3, sharia_viewing: 4, engagement: 5, completed: 6,
};

// ===== تعريف كل مرحلة (عنوان + وصف + أيقونة + لون + إجراء + شرح منبثق) =====
export interface StageMeta {
  key: JourneyState;
  step: number;            // رقم الخطوة (1..6) أو -1 للمسارات الجانبية
  title: string;           // العنوان المختصر للـ Stepper
  badge: string;           // نص الشارة
  icon: LucideIcon;
  accent: string;          // لون مميّز (tailwind text/bg base)
  // محتوى البطاقة المنبثقة:
  whereYouAre: string;     // أين أنت الآن
  whatToDo: string;        // ماذا تفعل الآن
  whatsNext: string;       // ما المرحلة التالية
}

export const STAGE_META: Record<JourneyState, StageMeta> = {
  sent: {
    key: 'sent', step: 1, title: 'مُرسَل', badge: 'بانتظار الرد',
    icon: Send, accent: 'gold',
    whereYouAre: 'تم إرسال طلب اهتمامك بنجاح ووصل إلى الطرف الآخر عبر فريق الإدارة.',
    whatToDo: 'لا يلزمك أي إجراء الآن — انتظر رد الطرف الآخر. سنُشعرك فور وصول الرد.',
    whatsNext: 'إذا قبِل الطرف الآخر، تنتقل الرحلة تلقائياً إلى مرحلة «تأكيد الجدية».',
  },
  accepted: {
    key: 'accepted', step: 2, title: 'مقبول', badge: 'تم القبول ✓',
    icon: HeartHandshake, accent: 'emerald',
    whereYouAre: 'قبِل الطرف الآخر طلب اهتمامك! أنتما الآن على بداية الطريق لتبادل أرقام الأهل والتواصل مباشر.',
    whatToDo: 'سدّد رسوم المنصة وجهد التنسيق للمتابعة وتبادل قنوات الاتصال مباشرة مع الأهل.',
    whatsNext: 'بعد السداد، تنتقل الرحلة تلقائياً إلى مرحلة «تبادل التواصل» لتنسيق النظرة الشرعية واللقاء.',
  },
  seriousness: {
    key: 'seriousness', step: 3, title: 'رسوم المنصة', badge: 'رسوم المنصة والتنسيق',
    icon: ShieldCheck, accent: 'amber',
    whereYouAre: 'مرحلة رسوم المنصة والتنسيق — يتم سداد الرسوم البالغة 500 ريال لمرة واحدة فقط طوال اشتراكك بالمنصة لتأكيد الجدية وتغطية مجهود الإدارة والتنسيق.',
    whatToDo: 'أكمِل سداد الرسوم من جهتك. بمجرد السداد ستحصل على "وسام الجدية والالتزام" بشكل دائم في ملفك الشخصي.',
    whatsNext: 'بمجرّد السداد، ينتقل الطلب تلقائياً إلى مرحلة «تبادل التواصل» مع الأهل مباشرة.',
  },
  coordination: {
    key: 'coordination', step: 4, title: 'تبادل التواصل', badge: 'التواصل المباشر',
    icon: CalendarClock, accent: 'blue',
    whereYouAre: 'مرحلة تبادل التواصل — يقوم الطرفان بمشاركة قنوات التواصل والاتصال للتنسيق للقاء والنظرة الشرعية مباشرة وبشكل مستقل دون تدخل وسيطة.',
    whatToDo: 'أدخل بيانات التواصل والاتصال ليتواصل الطرف الآخر معك أو مع الأهل مباشرة والاتفاق ودياً.',
    whatsNext: 'بعد تبادل معلومات التواصل، تنتقل الرحلة إلى مرحلة «النظرة الشرعية» لتنسيق اللقاء والاتفاق.',
  },
  sharia_viewing: {
    key: 'sharia_viewing', step: 5, title: 'النظرة الشرعية', badge: 'اللقاء والاتفاق المباشر',
    icon: Eye, accent: 'indigo',
    whereYouAre: 'مرحلة النظرة الشرعية — اللقاء بين الطرفين وفق الضوابط الشرعية، حيث يتواصل الأعضاء مباشرة ويتم الاتفاق فيما بينهم وبحضور المحرم.',
    whatToDo: 'تواصلوا هاتفياً ورتّبوا للقاء النظرة الشرعية بين العائلتين، ثم سجّلوا نتيجة النظرة بالأسفل بكل أمانة.',
    whatsNext: 'في حال التوافق المبارك، تنتقل الرحلة إلى مرحلة «الملكة» وإتمام العقد.',
  },
  engagement: {
    key: 'engagement', step: 6, title: 'الملكة', badge: 'إتمام العقد',
    icon: Gem, accent: 'gold',
    whereYouAre: 'مرحلة الملكة — إتمام عقد القران المبارك بإشراف المنصة وسداد رسوم السعي النهائية.',
    whatToDo: 'أكمِل إجراءات العقد مع الإدارة وسدّد رسوم السعي النهائية (2000 ريال) إبراءً للذمة.',
    whatsNext: 'بعد إتمام الملكة تكتمل الرحلة بنجاح. مبارك عليكما.',
  },
  completed: {
    key: 'completed', step: 7, title: 'مكتمل', badge: 'اكتملت الرحلة',
    icon: PartyPopper, accent: 'emerald',
    whereYouAre: 'اكتملت رحلة طلب الاهتمام وتم تسجيل النتيجة النهائية.',
    whatToDo: 'في حال التوافق المبارك تكون الرحلة قد توّجت بالنجاح. نبارك لكما.',
    whatsNext: 'هذه نهاية الرحلة. نسأل الله لكما دوام التوفيق والسعادة.',
  },
  declined: {
    key: 'declined', step: -1, title: 'مرفوض', badge: 'تم الاعتذار',
    icon: XCircle, accent: 'rose',
    whereYouAre: 'اعتذر الطرف الآخر عن إكمال هذا الطلب.',
    whatToDo: 'لا بأس — لكل نصيب طريقه. يمكنك مواصلة البحث عن توافق آخر.',
    whatsNext: 'هذا الطلب في الأرشيف الآن. ابدأ رحلة جديدة متى شئت.',
  },
  cancelled: {
    key: 'cancelled', step: -1, title: 'ملغى', badge: 'تم الإلغاء',
    icon: Ban, accent: 'slate',
    whereYouAre: 'تم إلغاء هذا الطلب (إمّا لعدم السداد ضمن المهلة أو بطلب أحد الطرفين).',
    whatToDo: 'يمكنك بدء طلب جديد بعد انتهاء فترة الانتظار إن رغبت.',
    whatsNext: 'هذا الطلب في الأرشيف. لا يلزمك أي إجراء.',
  },
};

// ===== ألوان كل accent (للـ Tailwind — صريحة كي لا يُحذفها الـ purge) =====
export const ACCENT_CLASSES: Record<string, {
  text: string; bg: string; bgSoft: string; border: string; ring: string; dot: string; line: string;
}> = {
  gold:    { text: 'text-amber-700',  bg: 'bg-amber-500',   bgSoft: 'bg-amber-50',   border: 'border-amber-200',   ring: 'ring-amber-200',   dot: 'bg-amber-500',   line: 'bg-amber-400' },
  emerald: { text: 'text-emerald-700', bg: 'bg-emerald-500', bgSoft: 'bg-emerald-50', border: 'border-emerald-200', ring: 'ring-emerald-200', dot: 'bg-emerald-500', line: 'bg-emerald-400' },
  amber:   { text: 'text-amber-700',  bg: 'bg-amber-500',   bgSoft: 'bg-amber-50',   border: 'border-amber-200',   ring: 'ring-amber-200',   dot: 'bg-amber-500',   line: 'bg-amber-400' },
  blue:    { text: 'text-blue-700',    bg: 'bg-blue-500',    bgSoft: 'bg-blue-50',    border: 'border-blue-200',    ring: 'ring-blue-200',    dot: 'bg-blue-500',    line: 'bg-blue-400' },
  indigo:  { text: 'text-indigo-700',  bg: 'bg-indigo-500',  bgSoft: 'bg-indigo-50',  border: 'border-indigo-200',  ring: 'ring-indigo-200',  dot: 'bg-indigo-500',  line: 'bg-indigo-400' },
  rose:    { text: 'text-rose-700',    bg: 'bg-rose-500',    bgSoft: 'bg-rose-50',    border: 'border-rose-200',    ring: 'ring-rose-200',    dot: 'bg-rose-500',    line: 'bg-rose-400' },
  slate:   { text: 'text-slate-600',   bg: 'bg-slate-500',   bgSoft: 'bg-slate-50',   border: 'border-slate-200',   ring: 'ring-slate-200',   dot: 'bg-slate-400',   line: 'bg-slate-300' },
};

// ===== الإجراء الأساسي الوحيد لكل مرحلة (Primary CTA) =====
// role: دور المستخدم الحالي في الطلب — مرسِل أو مستقبِل
export type RequestRole = 'sender' | 'receiver';

export interface PrimaryAction {
  type: 'accept_decline' | 'open_journey' | 'pay_deposit' | 'view_coordination' | 'record_result' | 'none';
  label: string;
  hint: string;
}

export function getPrimaryAction(
  stage: JourneyState,
  role: RequestRole,
  ctx: { selfPaid?: boolean; otherPaid?: boolean } = {},
): PrimaryAction {
  switch (stage) {
    case 'sent':
      // المستقبِل لديه قرار القبول/الرفض، المرسِل ينتظر
      return role === 'receiver'
        ? { type: 'accept_decline', label: 'الرد على الطلب', hint: 'اقبل الطلب أو اعتذر بلطف' }
        : { type: 'none', label: 'بانتظار الرد', hint: 'سنُشعرك فور رد الطرف الآخر' };
    case 'accepted':
      // بعد القبول: استفسار أو سداد الرسوم والتنسيق كلاهما في الصفحة الكاملة
      return { type: 'open_journey', label: 'متابعة الرحلة', hint: 'تواصل مع الأهل أو استفسر' };
    case 'seriousness':
      if (ctx.selfPaid && !ctx.otherPaid) {
        return { type: 'none', label: 'بانتظار سداد الطرف الآخر', hint: 'أكملت السداد من جهتك ✓' };
      }
      if (ctx.selfPaid && ctx.otherPaid) {
        return { type: 'view_coordination', label: 'متابعة التنسيق', hint: 'أكّد الطرفان الجدية والالتزام' };
      }
      return { type: 'open_journey', label: 'تأكيد الجدية أو الاستفسار', hint: 'اختر الاستفسار أو تفعيل تبادل التواصل' };
    case 'coordination':
      return { type: 'view_coordination', label: 'متابعة التنسيق', hint: 'تابع موعد النظرة مع الإدارة' };
    case 'sharia_viewing':
      return { type: 'record_result', label: 'تسجيل نتيجة النظرة', hint: 'توافق للمضي للملكة أو اعتذار مع السبب' };
    case 'engagement':
      return { type: 'open_journey', label: 'إتمام الملكة', hint: 'أكمِل العقد ورسوم السعي النهائية' };
    case 'completed':
      return { type: 'none', label: 'اكتملت الرحلة', hint: 'نسأل الله لكما التوفيق' };
    default:
      return { type: 'none', label: '', hint: '' };
  }
}

// ===== هل يتطلّب هذا الطلب إجراءً فورياً من المستخدم الحالي؟ =====
// يُستخدم لتمييز البطاقات بصرياً وترتيبها أولاً + لوحة الإحصائيات
export function requiresMyAction(
  stage: JourneyState,
  role: RequestRole,
  ctx: { selfPaid?: boolean; otherPaid?: boolean } = {},
): boolean {
  switch (stage) {
    case 'sent':
      return role === 'receiver';            // طلب وارد ينتظر ردّي
    case 'accepted':
      return true;                            // عليّ اختيار استفسار/عربون
    case 'seriousness':
      return !ctx.selfPaid;                   // لم أدفع بعد
    case 'sharia_viewing':
      return true;                            // عليّ تسجيل نتيجة النظرة
    case 'engagement':
      return true;                            // عليّ إتمام الملكة
    default:
      return false;                           // التنسيق/مكتمل/مؤرشف لا يتطلّب إجراءً
  }
}

// تصنيف نوع الإجراء المطلوب (للون الشريط الجانبي والشارة)
export function actionUrgency(
  stage: JourneyState,
  role: RequestRole,
  ctx: { selfPaid?: boolean; otherPaid?: boolean } = {},
): 'pay' | 'respond' | 'continue' | null {
  if (!requiresMyAction(stage, role, ctx)) return null;
  if (stage === 'sent' && role === 'receiver') return 'respond';
  if (stage === 'seriousness' && !ctx.selfPaid) return 'pay';
  if (stage === 'accepted') return 'respond';
  return 'continue';
}

// ===== ربط الحالة القديمة بالمرحلة الجديدة (توافق رجعي مع البيانات القديمة) =====
export function legacyToJourney(status: string, mediationStage?: string): JourneyState {
  switch (status) {
    case 'pending': return 'sent';
    case 'accepted':
    case 'accepted_pending_admin':
    case 'accepted_pending_payment': return 'accepted';
    case 'paid': return 'seriousness';
    case 'in_mediation':
      if (mediationStage === 'evaluating') return 'sharia_viewing';
      if (mediationStage === 'exchanging') return 'coordination';
      return 'coordination';
    case 'introduction': return 'sharia_viewing';
    case 'sharia_viewing': return 'sharia_viewing';
    case 'engagement': return 'engagement';
    case 'completed': return 'completed';
    case 'declined': return 'declined';
    case 'cancelled': return 'cancelled';
    default: return 'sent';
  }
}

export function isTerminal(stage: JourneyState): stage is JourneyTerminal {
  return stage === 'declined' || stage === 'cancelled';
}

// ===== أدوات موحّدة لحساب المرحلة، الدور الحالي، والنص الواضح للواجهة =====
export interface JourneyRequestLike {
  journey_stage: string;
  sender_id: string;
  receiver_id: string;
  sender_paid?: boolean;
  receiver_paid?: boolean;
  sender_viewing_result?: 'success' | 'failed' | null;
  receiver_viewing_result?: 'success' | 'failed' | null;
  guardian_phone?: string | null;
  contact_info?: string | null;
  male_phone?: string | null;
  male_pledged?: boolean;
  female_pledged?: boolean;
  decline_reason?: string | null;
  cancel_reason?: string | null;
}

export type TurnActor = 'me' | 'other' | 'both' | 'system' | 'none';
export type StatusTone = 'urgent' | 'waiting' | 'success' | 'neutral' | 'danger';

export interface JourneyStatusSummary {
  actor: TurnActor;
  actorLabel: string;
  tone: StatusTone;
  title: string;
  description: string;
  nextHint: string;
}

const VALID_STAGES: JourneyState[] = ['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed', 'declined', 'cancelled'];

export function getJourneyStage(req: JourneyRequestLike, currentUserId: string): JourneyState {
  const baseStage = VALID_STAGES.includes(req.journey_stage as JourneyState)
    ? (req.journey_stage as JourneyState)
    : legacyToJourney(req.journey_stage);

  if (baseStage === 'sharia_viewing') {
    if (req.sender_viewing_result === 'success' && req.receiver_viewing_result === 'success') return 'engagement';
  }

  return baseStage;
}

export function getJourneyStatusSummary(
  req: JourneyRequestLike,
  currentUserId: string,
  otherName = 'الطرف الآخر',
): JourneyStatusSummary {
  const stage = getJourneyStage(req, currentUserId);
  const isSender = req.sender_id === currentUserId;
  const role: RequestRole = isSender ? 'sender' : 'receiver';
  const selfPaid = isSender ? !!req.sender_paid : !!req.receiver_paid;
  const otherPaid = isSender ? !!req.receiver_paid : !!req.sender_paid;
  const meta = STAGE_META[stage];

  if (stage === 'declined') {
    return {
      actor: 'none', actorLabel: 'منتهٍ', tone: 'danger',
      title: 'تم الاعتذار عن هذا الطلب',
      description: req.decline_reason ? `سبب الاعتذار: ${req.decline_reason}` : 'انتهت هذه الرحلة باعتذار لطيف، ويمكنك بدء رحلة جديدة متى رغبت.',
      nextHint: 'انتقل للبحث لاختيار توافق آخر مناسب.',
    };
  }

  if (stage === 'cancelled') {
    return {
      actor: 'none', actorLabel: 'مؤرشف', tone: 'neutral',
      title: 'تم إلغاء الطلب ونقله للأرشيف',
      description: req.cancel_reason ? `سبب الإلغاء: ${req.cancel_reason}` : 'لا يلزمك أي إجراء الآن. يمكنك الرجوع للتفاصيل من الأرشيف.',
      nextHint: 'يمكنك بدء طلب جديد عند الرغبة.',
    };
  }

  if (stage === 'completed') {
    return {
      actor: 'none', actorLabel: 'مكتمل', tone: 'success',
      title: 'اكتملت رحلة الطلب بنجاح',
      description: 'تم تسجيل نهاية الرحلة. نسأل الله لكما التوفيق والبركة.',
      nextHint: meta.whatsNext,
    };
  }

  if (stage === 'sent') {
    if (role === 'receiver') {
      return {
        actor: 'me', actorLabel: 'الدور عليك', tone: 'urgent',
        title: 'طلب وارد ينتظر قرارك',
        description: `${otherName} أرسل طلب اهتمام. يمكنك القبول لبدء الرحلة أو الاعتذار بلطف.`,
        nextHint: 'عند القبول ينتقل الطلب لمرحلة الرسوم والاستفسار.',
      };
    }
    return {
      actor: 'other', actorLabel: 'بانتظار الطرف الآخر', tone: 'waiting',
      title: 'تم إرسال طلبك بنجاح',
      description: `لا يلزمك إجراء الآن. ننتظر رد ${otherName} على طلب الاهتمام.`,
      nextHint: meta.whatsNext,
    };
  }

  if (stage === 'accepted') {
    return {
      actor: 'both', actorLabel: 'الدور على الطرفين', tone: 'urgent',
      title: 'تم القبول — ابدأ الخطوة الجادة',
      description: 'يمكنكما طرح استفسار قبل المتابعة أو سداد رسوم المنصة لتفعيل تبادل التواصل.',
      nextHint: 'بعد سداد الطرفين تنتقل الرحلة إلى تبادل التواصل.',
    };
  }

  if (stage === 'seriousness') {
    if (!selfPaid) {
      return {
        actor: 'me', actorLabel: 'الدور عليك', tone: 'urgent',
        title: 'رسوم المنصة بانتظارك',
        description: otherPaid
          ? `${otherName} أكمل السداد. بقي سدادك أنت لبدء تبادل التواصل.`
          : 'أكمل سداد رسوم المنصة لتأكيد الجدية وتفعيل المرحلة التالية.',
        nextHint: meta.whatsNext,
      };
    }
    if (!otherPaid) {
      return {
        actor: 'other', actorLabel: 'بانتظار الطرف الآخر', tone: 'waiting',
        title: 'أكملت دورك في السداد',
        description: `تم تسجيل سدادك بنجاح. ننتظر سداد ${otherName} لفتح تبادل التواصل.`,
        nextHint: 'سيتم إشعارك تلقائيًا عند انتقال الرحلة للتواصل.',
      };
    }
  }

  if (stage === 'coordination') {
    const femaleContactReady = !!(req.guardian_phone || req.contact_info);
    const maleContactReady = !!req.male_phone;
    if (!femaleContactReady || !maleContactReady) {
      return {
        actor: 'both', actorLabel: 'استكمال التواصل', tone: 'urgent',
        title: 'مرحلة تبادل معلومات التواصل',
        description: 'يحتاج الطرفان إلى استكمال بيانات التواصل والتعهدات قبل الانتقال للنظرة الشرعية.',
        nextHint: meta.whatsNext,
      };
    }
    if (!req.male_pledged || !req.female_pledged) {
      return {
        actor: 'both', actorLabel: 'تعهدات مطلوبة', tone: 'waiting',
        title: 'معلومات التواصل جاهزة تقريبًا',
        description: 'بقي إتمام التعهدات قبل إظهار معلومات التواصل للطرفين بشكل آمن.',
        nextHint: 'بعد التعهدات يمكن متابعة النظرة الشرعية.',
      };
    }
    return {
      actor: 'both', actorLabel: 'يمكن المتابعة', tone: 'success',
      title: 'اكتمل تبادل التواصل',
      description: 'يمكنكما الآن تنسيق النظرة الشرعية والمتابعة للمرحلة التالية.',
      nextHint: meta.whatsNext,
    };
  }

  if (stage === 'sharia_viewing') {
    const myResult = isSender ? req.sender_viewing_result : req.receiver_viewing_result;
    const otherResult = isSender ? req.receiver_viewing_result : req.sender_viewing_result;
    if (myResult === 'success' && !otherResult) {
      return {
        actor: 'other', actorLabel: 'بانتظار الطرف الآخر', tone: 'waiting',
        title: 'سجلت توافقك بعد النظرة',
        description: `تم حفظ نتيجتك بنجاح. لا يمكن الانتقال إلى الملكة أو سداد رسومها حتى يسجل ${otherName} نتيجته أيضاً.`,
        nextHint: 'عند تسجيل الطرف الآخر للتوافق تنتقل الرحلة تلقائياً إلى الملكة.',
      };
    }
    return {
      actor: 'me', actorLabel: 'سجّل نتيجتك', tone: 'urgent',
      title: 'بانتظار نتيجة النظرة الشرعية',
      description: 'بعد التواصل واللقاء، سجّل النتيجة بأمانة: توافق للمتابعة أو اعتذار لطيف.',
      nextHint: meta.whatsNext,
    };
  }

  if (stage === 'engagement') {
    return {
      actor: 'me', actorLabel: 'إتمام نهائي', tone: 'urgent',
      title: 'مرحلة الملكة وإتمام العقد',
      description: 'أكمل إجراءات عقد القران ورسوم السعي النهائية لإغلاق الرحلة بنجاح.',
      nextHint: meta.whatsNext,
    };
  }

  return {
    actor: 'system', actorLabel: 'متابعة', tone: 'neutral',
    title: meta.title,
    description: meta.whereYouAre,
    nextHint: meta.whatsNext,
  };
}

// ===== رسوم السعي وباقة الاستفسار =====
export const DEPOSIT_AMOUNT = 500;
export const FINAL_FEE_AMOUNT = 2000;
export const INQUIRY_PACKAGE_PRICE = 100;   // سعر باقة الاستفسار
export const INQUIRY_PACKAGE_CREDITS = 20;   // عدد رسائل الباقة
export const INQUIRY_LOW_CREDITS = 3;        // عتبة التحذير

// ===== أسباب الاعتذار الجاهزة =====
export const DECLINE_REASONS = [
  'عدم توافق في المواصفات الأساسية المطلوبة.',
  'الفارق في العمر كبير جداً.',
  'الحالة الاجتماعية غير مناسبة.',
  'عدم توافق في الأهداف وتطلعات شريك الحياة.',
  'المسافة الجغرافية بين المدن كبيرة.',
  'سبب آخر.',
];

// ===== أسباب إلغاء الطلب الجاهزة =====
export const CANCEL_REASONS = [
  'لم يعد لدي رغبة في إكمال هذا الطلب.',
  'تبيّن عدم التوافق بعد الاستفسار.',
  'ظروف خاصة طرأت.',
  'سبب آخر.',
];
