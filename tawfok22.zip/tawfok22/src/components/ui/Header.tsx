import { useState, useRef, useEffect } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, X, Bell, User as UserIcon, LogOut, ChevronDown, LogIn, UserPlus, Settings, Crown, Sun, Moon } from 'lucide-react';
import Logo from '../ui/Logo';
import { useApp } from '../../lib/AppContext';
import { VerifiedBadge } from '../ui/Badge';
import { getCurrentUserId } from '../../lib/useInterestRequests';
import { getUnifiedUnreadCount } from '../../lib/notifications';

const navLinks = [
  { to: '/', label: 'الرئيسية' },
  { to: '/search', label: 'البحث' },
  { to: '/plans', label: 'الباقات' },
  { to: '/blog', label: 'المدونة' },
  { to: '/about', label: 'من نحن' },
];

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const { user, logout, darkMode, toggleDarkMode, showDarkModeToggle } = useApp();
  const navigate = useNavigate();
  const accountRef = useRef<HTMLDivElement>(null);
  const [unreadNotifs, setUnreadNotifs] = useState(0);

  useEffect(() => {
    let mounted = true;
    const loadUnread = async () => {
      if (!user.isLoggedIn) { if (mounted) setUnreadNotifs(0); return; }
      const count = await getUnifiedUnreadCount(user.memberId || getCurrentUserId());
      if (mounted) setUnreadNotifs(count);
    };
    loadUnread();
    const onFocus = () => loadUnread();
    window.addEventListener('focus', onFocus);
    const timer = window.setInterval(loadUnread, 2500);
    return () => { mounted = false; window.removeEventListener('focus', onFocus); window.clearInterval(timer); };
  }, [user.isLoggedIn, user.memberId]);

  // إغلاق القائمة المنسدلة عند النقر خارجها
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (accountRef.current && !accountRef.current.contains(e.target as Node)) {
        setAccountOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleLogout = () => {
    logout();
    setAccountOpen(false);
    navigate('/');
  };

  return (
    <>
      <header className="sticky top-0 z-50 glass dark:bg-navy-950/90 dark:border-navy-900/60 border-b border-gold-500/20 shadow-sm transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* التخطيط: يمين = روابط، وسط = شعار، يسار = حساب */}
          <div className="relative flex items-center justify-between h-16 lg:h-20">

            {/* يمين: روابط التنقل (ديسكتوب) + زر القائمة (جوال) */}
            <div className="flex items-center gap-1 flex-1">
              <button
                onClick={() => setMobileOpen(true)}
                className="lg:hidden p-2 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-900/60 transition-colors"
                aria-label="القائمة"
              >
                <Menu className="w-6 h-6 text-navy-800 dark:text-cream-200" />
              </button>
              <nav className="hidden lg:flex items-center gap-1">
                {[...navLinks, ...(user ? [{ to: '/requests', label: 'طلباتي' }] : [])].map((link) => (
                  <NavLink
                    key={link.to}
                    to={link.to}
                    className={({ isActive }) =>
                      `px-4 py-2 rounded-xl font-cairo font-semibold text-sm transition-all duration-200 no-tap-highlight ${
                        isActive
                          ? 'text-gold-700 bg-gold-300/15 dark:text-gold-400 dark:bg-gold-500/10'
                          : 'text-navy-700 dark:text-cream-200 hover:text-gold-700 dark:hover:text-gold-400 hover:bg-cream-100 dark:hover:bg-navy-900/50'
                      }`
                    }
                  >
                    {link.label}
                  </NavLink>
                ))}
              </nav>
            </div>

            {/* وسط: الشعار */}
            <div className="absolute right-1/2 translate-x-1/2">
              <Logo />
            </div>

            {/* يسار: الحساب */}
            <div className="flex items-center gap-1.5 flex-1 justify-end">
              {showDarkModeToggle && (
                <button
                  onClick={toggleDarkMode}
                  className="p-2.5 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-900/60 transition-colors text-navy-700 dark:text-cream-200 text-center flex items-center justify-center cursor-pointer"
                  title={darkMode ? "تفعيل الوضع المضيء" : "تفعيل الوضع الداكن"}
                >
                  {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-navy-800" />}
                </button>
              )}

              {user.isLoggedIn && (
                <Link to="/notifications" className="relative p-2.5 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-900/60 transition-colors">
                  <Bell className="w-5 h-5 text-navy-700 dark:text-cream-200" />
                  {unreadNotifs > 0 && (
                    <span className="absolute top-1 left-1 w-5 h-5 bg-rose-deep text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {unreadNotifs}
                    </span>
                  )}
                </Link>
              )}

              {/* أيقونة الحساب مع القائمة المنسدلة */}
              <div className="relative" ref={accountRef}>
                <button
                  onClick={() => setAccountOpen(!accountOpen)}
                  className="flex items-center gap-2 p-1.5 sm:p-2 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-900/60 transition-colors no-tap-highlight"
                  aria-label="الحساب"
                >
                  <div className="w-9 h-9 rounded-full bg-gold-gradient flex items-center justify-center text-navy-900 font-bold">
                    {user.isLoggedIn ? (
                      user.profile.name.charAt(0)
                    ) : (
                      <UserIcon className="w-5 h-5" />
                    )}
                  </div>
                  <ChevronDown className={`w-4 h-4 text-navy-500 transition-transform hidden sm:block ${accountOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* القائمة المنسدلة */}
                {accountOpen && (
                  <div className="absolute left-0 mt-2 w-64 bg-white dark:bg-navy-900 rounded-2xl shadow-luxe border border-cream-200 dark:border-navy-800 overflow-hidden animate-float-up">
                    {user.isLoggedIn ? (
                      <>
                        {/* بطاقة المستخدم */}
                        <div className="p-4 bg-navy-gradient relative overflow-hidden">
                          <div className="absolute inset-0 pattern-arabesque opacity-30" />
                          <div className="relative flex items-center gap-3">
                            <div className="w-11 h-11 rounded-full bg-gold-gradient flex items-center justify-center text-navy-900 font-cairo font-bold text-lg flex-shrink-0">
                              {user.profile.name.charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="font-cairo font-bold text-white truncate">{user.profile.name}</span>
                                {user.profile.verified && <VerifiedBadge />}
                              </div>
                              <span className="text-xs text-cream-200/70 font-tajawal">
                                {user.profile.plan === 'gold' ? 'عضو ذهبي' : user.profile.plan === 'elite' ? 'عضو نخبة' : 'عضو مجاني'}
                              </span>
                            </div>
                          </div>
                        </div>
                        {/* روابط الحساب */}
                        <div className="p-2">
                          <Link to="/profile" onClick={() => setAccountOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-800 transition-colors">
                            <UserIcon className="w-4.5 h-4.5 text-gold-600" />
                            <span className="font-cairo font-semibold text-sm text-navy-800 dark:text-cream-100">ملفي الشخصي</span>
                          </Link>
                          <Link to="/profile/complete" onClick={() => setAccountOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-800 transition-colors">
                            <Settings className="w-4.5 h-4.5 text-gold-600" />
                            <span className="font-cairo font-semibold text-sm text-navy-800 dark:text-cream-100">أكمل ملفك</span>
                          </Link>
                          <Link to="/plans" onClick={() => setAccountOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-cream-100 dark:hover:bg-navy-800 transition-colors">
                            <Crown className="w-4.5 h-4.5 text-gold-600" />
                            <span className="font-cairo font-semibold text-sm text-navy-800 dark:text-cream-100">ترقية الباقة</span>
                          </Link>
                          <div className="my-1 h-px bg-cream-200 dark:bg-navy-850" />
                          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/10 transition-colors text-rose-deep">
                            <LogOut className="w-4.5 h-4.5" />
                            <span className="font-cairo font-semibold text-sm">تسجيل الخروج</span>
                          </button>
                        </div>
                      </>
                    ) : (
                      /* قائمة الضيف - تسجيل الدخول / إنشاء حساب */
                      <div className="p-4 space-y-3">
                        <div className="text-center pb-2">
                          <p className="font-cairo font-bold text-navy-900">مرحبًا بك في توافق</p>
                          <p className="text-xs text-navy-500 font-tajawal mt-0.5">سجّل الدخول للوصول لحسابك</p>
                        </div>
                        <Link
                          to="/login"
                          onClick={() => setAccountOpen(false)}
                          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold text-sm shadow-soft hover:shadow-gold transition-all"
                        >
                          <LogIn className="w-4.5 h-4.5" /> تسجيل الدخول
                        </Link>
                        <Link
                          to="/register"
                          onClick={() => setAccountOpen(false)}
                          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl border-2 border-gold-500 text-navy-900 font-cairo font-bold text-sm hover:bg-gold-300/10 transition-colors"
                        >
                          <UserPlus className="w-4.5 h-4.5" /> إنشاء حساب جديد
                        </Link>
                        <div className="pt-2 border-t border-cream-200 space-y-1">
                          <Link to="/plans" onClick={() => setAccountOpen(false)} className="flex items-center gap-2 px-2 py-2 rounded-lg hover:bg-cream-100 transition-colors text-sm text-navy-600 font-tajawal">
                            <Crown className="w-4 h-4 text-gold-600" /> الباقات والأسعار
                          </Link>
                          <Link to="/support" onClick={() => setAccountOpen(false)} className="flex items-center gap-2 px-2 py-2 rounded-lg hover:bg-cream-100 transition-colors text-sm text-navy-600 font-tajawal">
                            <Settings className="w-4 h-4 text-gold-600" /> الدعم والمساعدة
                          </Link>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-[60]">
          <div className="absolute inset-0 bg-navy-950/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-[85%] max-w-sm bg-cream-50 shadow-2xl flex flex-col animate-float-up">
            <div className="flex items-center justify-between p-5 border-b border-cream-200">
              <Logo />
              <button onClick={() => setMobileOpen(false)} className="p-2 rounded-xl hover:bg-cream-100">
                <X className="w-6 h-6 text-navy-800" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-5 space-y-1">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `block px-4 py-3 rounded-xl font-cairo font-semibold transition-colors ${
                      isActive ? 'text-gold-700 bg-gold-300/15' : 'text-navy-700 hover:bg-cream-100'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              <div className="pt-3 mt-3 border-t border-cream-200 space-y-1">
                {[
                  { to: '/faq', label: 'الأسئلة الشائعة' },
                  { to: '/support', label: 'الدعم الفني' },
                  { to: '/contact', label: 'اتصل بنا' },
                  { to: '/admin', label: 'لوحة الإدارة' },
                ].map((link) => (
                  <NavLink
                    key={link.to}
                    to={link.to}
                    onClick={() => setMobileOpen(false)}
                    className="block px-4 py-3 rounded-xl font-cairo font-medium text-sm text-navy-600 hover:bg-cream-100 transition-colors"
                  >
                    {link.label}
                  </NavLink>
                ))}
              </div>
            </nav>
            <div className="p-5 border-t border-cream-200 space-y-2">
              {user.isLoggedIn ? (
                <>
                  <Link to="/profile" onClick={() => setMobileOpen(false)} className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-navy-900 text-white font-cairo font-bold">
                    <UserIcon className="w-5 h-5" /> ملفي الشخصي
                  </Link>
                  <button onClick={handleLogout} className="flex items-center justify-center gap-2 w-full py-3 rounded-xl border-2 border-rose-deep/20 text-rose-deep font-cairo font-bold">
                    <LogOut className="w-5 h-5" /> تسجيل الخروج
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setMobileOpen(false)} className="block w-full py-3 text-center rounded-xl border-2 border-gold-500 text-navy-900 font-cairo font-bold">
                    تسجيل الدخول
                  </Link>
                  <Link to="/register" onClick={() => setMobileOpen(false)} className="block w-full py-3 text-center rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-soft">
                    إنشاء حساب
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
