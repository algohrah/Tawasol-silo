import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Eye, Ban, CheckCircle2, Mail, Phone, Lock, MapPin,
  ShieldCheck, Crown, Download, Users, Loader2, AlertCircle,
  Fingerprint, Briefcase, GraduationCap, Flag, Send, StickyNote,
  BadgeCheck, UserCheck, UserX, Sparkles, Trash2, KeyRound, Copy, RefreshCw,
  LogIn, Upload, MoreHorizontal, FileSpreadsheet, TrendingUp,
} from 'lucide-react';
import { useAdminMembers, type AdminMemberRow } from '../../lib/useAdminData';
import { useApp } from '../../lib/AppContext';
import { useNavigate } from 'react-router-dom';
import Modal from '../../components/ui/Modal';
import FilterDropdown from '../../components/admin/FilterDropdown';
import ActionMenu from '../../components/admin/ActionMenu';

const ITEMS_PER_PAGE = 10;

const statusConfig: Record<string, { label: string; color: string; dot: string }> = {
  active: { label: 'نشط', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' },
  pending: { label: 'قيد المراجعة', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
  suspended: { label: 'موقوف', color: 'bg-orange-100 text-orange-700', dot: 'bg-orange-500' },
  frozen: { label: 'مُجمّد مؤقتاً', color: 'bg-sky-100 text-sky-700', dot: 'bg-sky-500' },
  banned: { label: 'محظور نهائياً', color: 'bg-rose-100 text-rose-700', dot: 'bg-rose-600' },
};
const planConfig: Record<string, { label: string; color: string }> = {
  free: { label: 'مجاني', color: 'bg-slate-100 text-slate-600' },
  gold: { label: 'ذهبي', color: 'bg-amber-100 text-amber-700' },
  elite: { label: 'نخبة', color: 'bg-purple-100 text-purple-700' },
};

export default function AdminMembers() {
  const {
    members, loading, error, updateMember, deleteMember, resetPassword,
    toggleVerified, setPremium, setNote, toggleFlag, notifyMember,
    bulkDelete, bulkUpdateStatus, bulkSetVerified,
  } = useAdminMembers();
  const { impersonateUser, importMembers, showToast } = useApp();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended' | 'pending' | 'frozen' | 'banned'>('all');
  const [filterPlan, setFilterPlan] = useState<'all' | 'free' | 'gold' | 'elite'>('all');
  const [onlyFlagged, setOnlyFlagged] = useState(false);
  const [selected, setSelected] = useState<AdminMemberRow | null>(null);
  const [revealSensitive, setRevealSensitive] = useState(false);
  const [page, setPage] = useState(1);
  const [localToast, setLocalToast] = useState<string | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState('');

  const showLocalToast = (t: string) => {
    setLocalToast(t);
    setTimeout(() => setLocalToast(null), 2500);
  };

  const impersonateAndGo = (member: AdminMemberRow) => {
    impersonateUser({
      id: member.id,
      nickname: member.nickname,
      gender: member.gender,
      age: member.age,
      country: member.country,
      city: member.city,
      realName: member.realName,
      email: member.email,
      phone: member.phone,
      plan: member.plan,
      password: member.password,
    });
    showLocalToast(`جارٍ الدخول بحساب ${member.nickname}...`);
    setTimeout(() => navigate('/profile'), 400);
  };

  const selectedLive = useMemo(
    () => (selected ? members.find((m) => m.id === selected.id) || selected : null),
    [selected, members]
  );
  useEffect(() => {
    if (selectedLive) setNoteDraft(selectedLive.adminNote || '');
  }, [selectedLive?.id]);

  const [notifyFor, setNotifyFor] = useState<AdminMemberRow | null>(null);
  const [notifyText, setNotifyText] = useState('');
  const [noteDraft, setNoteDraft] = useState('');
  const [deleteFor, setDeleteFor] = useState<AdminMemberRow | null>(null);

  // ===== التحديد المتعدد والإجراءات الجماعية =====
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  // نافذة تأكيد الإجراء الجماعي: {action, label}
  const [bulkConfirm, setBulkConfirm] = useState<{ action: 'ban' | 'freeze' | 'suspend' | 'activate' | 'verify' | 'delete'; label: string } | null>(null);
  const [bulkReason, setBulkReason] = useState('');
  const [bulkBusy, setBulkBusy] = useState(false);
  // نافذة تغيير حالة فردية بسبب (حظر/تجميد/إيقاف)
  const [statusFor, setStatusFor] = useState<{ member: AdminMemberRow; status: 'banned' | 'frozen' | 'suspended' } | null>(null);
  const [statusReasonDraft, setStatusReasonDraft] = useState('');

  const stats = useMemo(
    () => ({
      total: members.length,
      active: members.filter((m) => m.status === 'active').length,
      pending: members.filter((m) => m.status === 'pending').length,
      verified: members.filter((m) => m.verified).length,
      premium: members.filter((m) => m.premium).length,
      flagged: members.filter((m) => m.flagged).length,
    }),
    [members]
  );

  const filtered = useMemo(
    () =>
      members.filter((m) => {
        const matchSearch =
          !search ||
          m.nickname.includes(search) ||
          m.realName.includes(search) ||
          m.email.toLowerCase().includes(search.toLowerCase()) ||
          m.nationalId?.includes(search) ||
          m.phone?.includes(search);
        const matchStatus = filterStatus === 'all' || m.status === filterStatus;
        const matchPlan = filterPlan === 'all' || m.plan === filterPlan;
        const matchFlag = !onlyFlagged || m.flagged;
        return matchSearch && matchStatus && matchPlan && matchFlag;
      }),
    [members, search, filterStatus, filterPlan, onlyFlagged]
  );

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE) || 1;
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  useEffect(() => {
    setPage(1);
  }, [search, filterStatus, filterPlan, onlyFlagged]);

  // ===== منطق التحديد المتعدد =====
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };
  // تحديد/إلغاء تحديد كل الأعضاء المفلترين
  const allFilteredSelected = filtered.length > 0 && filtered.every((m) => selectedIds.has(m.id));
  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      if (allFilteredSelected) {
        const next = new Set(prev);
        filtered.forEach((m) => next.delete(m.id));
        return next;
      }
      const next = new Set(prev);
      filtered.forEach((m) => next.add(m.id));
      return next;
    });
  };
  const clearSelection = () => setSelectedIds(new Set());
  const selectedCount = selectedIds.size;

  // تنفيذ الإجراء الجماعي بعد التأكيد
  const runBulk = async () => {
    if (!bulkConfirm) return;
    const ids = Array.from(selectedIds);
    if (ids.length === 0) { setBulkConfirm(null); return; }
    setBulkBusy(true);
    let ok = false;
    const needsReason = bulkConfirm.action === 'ban' || bulkConfirm.action === 'freeze' || bulkConfirm.action === 'suspend';
    const reason = needsReason ? bulkReason.trim() : '';
    switch (bulkConfirm.action) {
      case 'ban': ok = await bulkUpdateStatus(ids, 'banned', reason); break;
      case 'freeze': ok = await bulkUpdateStatus(ids, 'frozen', reason); break;
      case 'suspend': ok = await bulkUpdateStatus(ids, 'suspended', reason); break;
      case 'activate': ok = await bulkUpdateStatus(ids, 'active'); break;
      case 'verify': ok = await bulkSetVerified(ids, true); break;
      case 'delete': ok = await bulkDelete(ids); break;
    }
    setBulkBusy(false);
    if (ok) {
      showLocalToast(`تم تطبيق "${bulkConfirm.label}" على ${ids.length} عضو ✓`);
      clearSelection();
    } else {
      showToast('تعذّر تنفيذ الإجراء', 'error');
    }
    setBulkConfirm(null);
    setBulkReason('');
  };

  // تغيير حالة فردية بسبب
  const applyStatusChange = async () => {
    if (!statusFor) return;
    const ok = await updateMember(statusFor.member.id, { status: statusFor.status, statusReason: statusReasonDraft.trim() });
    if (ok) showLocalToast(`تم تحديث حالة ${statusFor.member.nickname} ✓`);
    setStatusFor(null);
    setStatusReasonDraft('');
  };

  const handleExport = () => {
    const headers = [
      'المعرّف', 'الاسم المستعار', 'الاسم الحقيقي', 'البريد', 'الهاتف',
      'الهوية', 'الجنس', 'العمر', 'المدينة', 'الباقة', 'الحالة', 'موثق', 'تاريخ الانضمام'
    ];
    const rows = filtered.map((m) => [
      m.id, m.nickname, m.realName, m.email, m.phone, m.nationalId, m.gender === 'male' ? 'ذكر' : 'أنثى',
      m.age, m.city, m.plan, m.status, m.verified ? 'نعم' : 'لا', m.joinedAt,
    ]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `members-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showLocalToast(`تم تصدير ${filtered.length} عضو ✓`);
  };

  const handleImport = () => {
    try {
      const parsed = JSON.parse(importText);
      if (!Array.isArray(parsed)) {
        showToast('البيانات المدخلة غير صالحة', 'error');
        return;
      }
      const valid = parsed.filter((m) => m.nickname && m.email && m.gender);
      if (valid.length === 0) {
        showToast('لم يتم العثور على أعضاء صالحين للاستيراد', 'error');
        return;
      }
      importMembers(valid);
      setImportOpen(false);
      setImportText('');
      showToast(`تم استيراد ${valid.length} عضو بنجاح`, 'success');
    } catch {
      showToast('حدث خطأ أثناء الاستيراد. تأكد من صحة تنسيق JSON.', 'error');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-9 h-9 animate-spin mb-3" />
        <p className="font-cairo text-sm">جارٍ تحميل الأعضاء...</p>
      </div>
    );
  }
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <AlertCircle className="w-10 h-10 text-rose-400 mb-3" />
        <p className="font-cairo text-slate-700 font-bold">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-500" /> إدارة الأعضاء
          </h2>
          <p className="text-sm text-slate-500 font-tajawal">تحكم كامل في حسابات الأعضاء وحالاتهم</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setImportOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-cairo font-semibold text-sm hover:bg-slate-200 transition-colors"
          >
            <Upload className="w-4 h-4" /> استيراد
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors"
          >
            <Download className="w-4 h-4" /> تصدير ({filtered.length})
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'الإجمالي', value: stats.total, icon: Users, color: 'text-slate-700', bg: 'bg-slate-50', onClick: () => { setFilterStatus('all'); setOnlyFlagged(false); } },
          { label: 'نشط', value: stats.active, icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-50', onClick: () => setFilterStatus('active') },
          { label: 'قيد المراجعة', value: stats.pending, icon: Loader2, color: 'text-amber-600', bg: 'bg-amber-50', onClick: () => setFilterStatus('pending') },
          { label: 'موثق', value: stats.verified, icon: BadgeCheck, color: 'text-blue-600', bg: 'bg-blue-50', onClick: () => {} },
          { label: 'مميّز', value: stats.premium, icon: Crown, color: 'text-purple-600', bg: 'bg-purple-50', onClick: () => setFilterPlan('gold') },
          { label: 'معلّم', value: stats.flagged, icon: Flag, color: 'text-rose-600', bg: 'bg-rose-50', onClick: () => setOnlyFlagged(true) },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <button
              key={s.label}
              onClick={s.onClick}
              className={`${s.bg} rounded-2xl p-3 text-right border border-transparent hover:border-slate-200 transition-all`}
            >
              <Icon className={`w-5 h-5 ${s.color} mb-1`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم المستعار أو الحقيقي أو البريد أو الهاتف أو الهوية..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <FilterDropdown
            label="الحالة:"
            value={filterStatus}
            onChange={(v) => setFilterStatus(v as typeof filterStatus)}
            options={(['all', 'active', 'pending', 'suspended', 'frozen', 'banned'] as const).map((s) => ({
              value: s,
              label: s === 'all' ? 'كل الحالات' : statusConfig[s].label,
            }))}
          />
          <FilterDropdown
            label="الباقة:"
            value={filterPlan}
            onChange={(v) => setFilterPlan(v as typeof filterPlan)}
            options={(['all', 'free', 'gold', 'elite'] as const).map((p) => ({
              value: p,
              label: p === 'all' ? 'كل الباقات' : planConfig[p].label,
            }))}
          />
          <button
            onClick={() => setOnlyFlagged((v) => !v)}
            className={`px-3.5 py-2.5 rounded-xl text-sm font-cairo font-bold transition-colors flex items-center gap-1.5 border ${
              onlyFlagged ? 'bg-rose-500 text-white border-rose-500' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Flag className="w-4 h-4" /> المعلّمون فقط
          </button>
        </div>
      </div>

      {/* شريط الإجراءات الجماعية (يظهر عند تحديد عضو أو أكثر) */}
      <AnimatePresence>
        {selectedCount > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="sticky top-2 z-30 bg-navy-900 text-white rounded-2xl shadow-xl border border-navy-800 px-4 py-3 flex flex-wrap items-center gap-2"
          >
            <span className="font-cairo font-bold text-sm flex items-center gap-2">
              <span className="w-7 h-7 rounded-full bg-amber-400 text-navy-900 flex items-center justify-center text-xs font-black">{selectedCount}</span>
              عضو محدّد
            </span>
            <div className="h-5 w-px bg-white/20 mx-1" />
            <div className="flex flex-wrap gap-1.5 mr-auto">
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'verify', label: 'توثيق الأعضاء' }); }}
                className="px-3 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <BadgeCheck className="w-3.5 h-3.5" /> توثيق
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'activate', label: 'تفعيل الأعضاء' }); }}
                className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <CheckCircle2 className="w-3.5 h-3.5" /> تفعيل
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'freeze', label: 'تجميد مؤقت' }); }}
                className="px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <Lock className="w-3.5 h-3.5" /> تجميد مؤقت
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'suspend', label: 'إيقاف' }); }}
                className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <Ban className="w-3.5 h-3.5" /> إيقاف
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'ban', label: 'حظر نهائي' }); }}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <UserX className="w-3.5 h-3.5" /> حظر نهائي
              </button>
              <button onClick={() => { setBulkReason(''); setBulkConfirm({ action: 'delete', label: 'حذف نهائي' }); }}
                className="px-3 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors">
                <Trash2 className="w-3.5 h-3.5" /> حذف نهائي
              </button>
              <button onClick={clearSelection}
                className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-cairo font-bold transition-colors">
                إلغاء التحديد
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop table */}
      <div className="hidden lg:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-4 py-3 w-10">
                <input
                  type="checkbox"
                  checked={allFilteredSelected}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  title="تحديد الكل"
                />
              </th>
              {['العضو', 'البريد', 'الباقة', 'الحالة', 'إجراءات'].map((h) => (
                <th key={h} className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {paginated.map((m) => (
              <tr key={m.id} className={`hover:bg-slate-50 transition-colors ${selectedIds.has(m.id) ? 'bg-amber-50/50' : m.flagged ? 'bg-rose-50/40' : ''}`}>
                <td className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.has(m.id)}
                    onChange={() => toggleSelect(m.id)}
                    className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  />
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`relative w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                        m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                      }`}
                    >
                      {m.nickname.charAt(0)}
                      {m.flagged && <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-white" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</span>
                        {m.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
                        {m.plan === 'elite' && <Crown className="w-3.5 h-3.5 text-purple-500" />}
                        {m.premium && m.plan !== 'elite' && <Crown className="w-3.5 h-3.5 text-amber-500" />}
                      </div>
                      <span className="text-[11px] text-slate-400 font-tajawal">
                        {m.realName} · {m.age} سنة · {m.city}
                      </span>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-xs text-slate-600 font-tajawal">{m.email}</td>
                <td className="px-5 py-3">
                  <span className={`px-2 py-1 rounded-md text-[11px] font-cairo font-bold ${planConfig[m.plan].color}`}>
                    {planConfig[m.plan].label}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-cairo font-bold ${statusConfig[m.status].color}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${statusConfig[m.status].dot}`} />
                    {statusConfig[m.status].label}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-1">
                    <ActionMenu
                      items={[
                        {
                          label: 'عرض التفاصيل',
                          icon: <Eye className="w-4 h-4" />,
                          onClick: () => { setSelected(m); setRevealSensitive(false); },
                        },
                        {
                          label: 'الدخول بحساب العضو',
                          icon: <LogIn className="w-4 h-4" />,
                          variant: 'primary',
                          onClick: () => impersonateAndGo(m),
                        },
                        {
                          label: m.verified ? 'إلغاء التوثيق' : 'توثيق العضو',
                          icon: <BadgeCheck className="w-4 h-4" />,
                          onClick: async () => {
                            await toggleVerified(m.id, !m.verified);
                            showLocalToast(m.verified ? 'تم إلغاء التوثيق' : 'تم التوثيق ✓');
                          },
                        },
                        {
                          label: m.premium ? 'إلغاء التميّز' : 'ترقية لمميّز',
                          icon: <Crown className="w-4 h-4" />,
                          onClick: async () => {
                            await setPremium(m.id, !m.premium);
                            showLocalToast(m.premium ? 'تم إلغاء التميّز' : 'تمت الترقية لمميّز 👑');
                          },
                        },
                        {
                          label: 'تفعيل الحساب',
                          icon: <CheckCircle2 className="w-4 h-4" />,
                          variant: 'success',
                          hidden: m.status === 'active',
                          onClick: async () => {
                            await updateMember(m.id, { status: 'active' });
                            showLocalToast('تم تفعيل العضو ✓');
                          },
                        },
                        {
                          label: 'تجميد مؤقت',
                          icon: <Lock className="w-4 h-4" />,
                          hidden: m.status === 'frozen',
                          onClick: () => { setStatusFor({ member: m, status: 'frozen' }); setStatusReasonDraft(m.statusReason || ''); },
                        },
                        {
                          label: 'إيقاف العضو',
                          icon: <Ban className="w-4 h-4" />,
                          hidden: m.status === 'suspended',
                          onClick: () => { setStatusFor({ member: m, status: 'suspended' }); setStatusReasonDraft(m.statusReason || ''); },
                        },
                        {
                          label: 'حظر نهائي',
                          icon: <UserX className="w-4 h-4" />,
                          variant: 'danger',
                          hidden: m.status === 'banned',
                          onClick: () => { setStatusFor({ member: m, status: 'banned' }); setStatusReasonDraft(m.statusReason || ''); },
                        },
                        {
                          label: m.flagged ? 'إزالة التعليم' : 'تعليم العضو',
                          icon: <Flag className="w-4 h-4" />,
                          onClick: async () => {
                            await toggleFlag(m.id, !m.flagged);
                            showLocalToast(m.flagged ? 'أُزيل التعليم' : 'تم تعليم العضو');
                          },
                        },
                        {
                          label: 'إرسال إشعار',
                          icon: <Send className="w-4 h-4" />,
                          onClick: () => { setNotifyFor(m); setNotifyText(''); },
                        },
                        {
                          label: 'حذف الحساب',
                          icon: <Trash2 className="w-4 h-4" />,
                          variant: 'danger',
                          divider: true,
                          onClick: () => setDeleteFor(m),
                        },
                      ]}
                    />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="text-center py-10 text-slate-400 font-cairo text-sm">لا يوجد أعضاء مطابقون</p>}
      </div>

      {/* Mobile cards */}
      <div className="lg:hidden space-y-3">
        {paginated.map((m) => (
          <div key={m.id} className={`bg-white rounded-2xl p-4 shadow-sm border ${selectedIds.has(m.id) ? 'border-amber-300 ring-1 ring-amber-200' : m.flagged ? 'border-rose-200' : 'border-slate-200'}`}>
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={selectedIds.has(m.id)}
                onChange={() => toggleSelect(m.id)}
                className="w-4 h-4 rounded accent-amber-500 cursor-pointer flex-shrink-0"
              />
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center text-white font-bold ${
                  m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                }`}
              >
                {m.nickname.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</span>
                  {m.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-500" />}
                  {m.premium && <Crown className="w-3.5 h-3.5 text-amber-500" />}
                </div>
                <span className="text-[11px] text-slate-400 font-tajawal">
                  {m.realName} · {m.city}
                </span>
              </div>
              <span className={`px-2 py-1 rounded-md text-[10px] font-cairo font-bold ${statusConfig[m.status].color}`}>
                {statusConfig[m.status].label}
              </span>
            </div>
            <div className="grid grid-cols-5 gap-2 mt-3">
              <button
                onClick={() => { setSelected(m); setRevealSensitive(false); }}
                className="py-2 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center"
                title="عرض"
              >
                <Eye className="w-4 h-4" />
              </button>
              <button
                onClick={() => impersonateAndGo(m)}
                className="py-2 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center"
                title="الدخول بحساب العضو"
              >
                <LogIn className="w-4 h-4" />
              </button>
              <button
                onClick={async () => {
                  await toggleVerified(m.id, !m.verified);
                  showLocalToast(m.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓');
                }}
                className={`py-2 rounded-xl flex items-center justify-center ${
                  m.verified ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <BadgeCheck className="w-4 h-4" />
              </button>
              <button
                onClick={async () => {
                  await setPremium(m.id, !m.premium);
                  showLocalToast(m.premium ? 'أُلغي التميّز' : 'ترقية 👑');
                }}
                className={`py-2 rounded-xl flex items-center justify-center ${
                  m.premium ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <Crown className="w-4 h-4" />
              </button>
              {m.status !== 'active' ? (
                <button
                  onClick={async () => {
                    await updateMember(m.id, { status: 'active' });
                    showLocalToast('تم التفعيل ✓');
                  }}
                  className="py-2 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center"
                  title="تفعيل"
                >
                  <CheckCircle2 className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => { setStatusFor({ member: m, status: 'banned' }); setStatusReasonDraft(m.statusReason || ''); }}
                  className="py-2 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center"
                  title="حظر/تقييد"
                >
                  <Ban className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 flex-wrap">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => setPage(p)}
              className={`w-9 h-9 rounded-lg font-cairo font-bold text-sm ${
                page === p ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Detail modal */}
      <Modal open={!!selectedLive} onClose={() => setSelected(null)} title="ملف العضو" size="lg">
        {selectedLive && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-2xl ${
                  selectedLive.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                }`}
              >
                {selectedLive.nickname.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-cairo font-extrabold text-lg text-slate-900">{selectedLive.nickname}</h3>
                  {selectedLive.verified && <BadgeCheck className="w-5 h-5 text-blue-500" />}
                  {selectedLive.premium && <Crown className="w-5 h-5 text-amber-500" />}
                </div>
                <p className="text-sm text-slate-500 font-tajawal">
                  {selectedLive.age} سنة · {selectedLive.city}، {selectedLive.country}
                </p>
                <div className="flex gap-1.5 mt-1">
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${statusConfig[selectedLive.status].color}`}>
                    {statusConfig[selectedLive.status].label}
                  </span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold ${planConfig[selectedLive.plan].color}`}>
                    {planConfig[selectedLive.plan].label}
                  </span>
                  {selectedLive.flagged && (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-cairo font-bold bg-rose-100 text-rose-700 flex items-center gap-0.5">
                      <Flag className="w-3 h-3" /> معلّم
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* بانر سبب تقييد الحساب (حظر/تجميد/إيقاف) */}
            {selectedLive.status !== 'active' && selectedLive.status !== 'pending' && (
              <div className={`rounded-xl p-3 border ${
                selectedLive.status === 'banned' ? 'bg-rose-50 border-rose-200' : selectedLive.status === 'frozen' ? 'bg-sky-50 border-sky-200' : 'bg-orange-50 border-orange-200'
              }`}>
                <div className="flex items-center gap-1.5 mb-1">
                  {selectedLive.status === 'banned' ? <UserX className="w-4 h-4 text-rose-600" /> :
                   selectedLive.status === 'frozen' ? <Lock className="w-4 h-4 text-sky-600" /> :
                   <Ban className="w-4 h-4 text-orange-600" />}
                  <span className="text-xs font-cairo font-bold text-slate-800">
                    الحساب {statusConfig[selectedLive.status].label}
                  </span>
                </div>
                {selectedLive.statusReason && (
                  <p className="text-xs text-slate-600 font-tajawal leading-relaxed">السبب: {selectedLive.statusReason}</p>
                )}
                {selectedLive.statusChangedAt && (
                  <p className="text-[10px] text-slate-400 font-tajawal mt-1">
                    بواسطة {selectedLive.statusChangedBy || 'الإدارة'} · {new Date(selectedLive.statusChangedAt).toLocaleString('ar-SA')}
                  </p>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: Briefcase, label: 'العمل', value: selectedLive.workType },
                { icon: GraduationCap, label: 'التعليم', value: selectedLive.education },
                { icon: MapPin, label: 'الحي', value: selectedLive.district },
                { icon: TrendingUp, label: 'عدد الطلبات', value: String(selectedLive.requestsCount) },
              ].map((f) => {
                const Icon = f.icon;
                return (
                  <div key={f.label} className="bg-slate-50 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                      <Icon className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-cairo">{f.label}</span>
                    </div>
                    <p className="font-cairo font-bold text-sm text-slate-800">{f.value || '—'}</p>
                  </div>
                );
              })}
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-xs font-cairo font-bold text-rose-700">
                  <Lock className="w-4 h-4" /> بيانات حساسة — للإدارة فقط
                </span>
                <button
                  onClick={() => setRevealSensitive((v) => !v)}
                  className="text-[11px] font-cairo font-bold text-rose-700 bg-white px-2.5 py-1 rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors flex items-center gap-1"
                >
                  <Eye className="w-3 h-3" />
                  {revealSensitive ? 'إخفاء' : 'كشف الكل'}
                </button>
              </div>
              <div className="space-y-1.5">
                {[
                  { icon: Fingerprint, label: 'الاسم الحقيقي', value: selectedLive.realName, sensitive: true },
                  { icon: Mail, label: 'البريد', value: selectedLive.email, sensitive: true },
                  { icon: Phone, label: 'الهاتف', value: selectedLive.phone, sensitive: true },
                  { icon: Fingerprint, label: 'الهوية', value: selectedLive.nationalId, sensitive: true },
                  { icon: KeyRound, label: 'كلمة المرور', value: selectedLive.password, sensitive: true, mono: true },
                ].map((f) => {
                  const Icon = f.icon;
                  return (
                    <div key={f.label} className="flex items-center gap-2 text-sm bg-white/60 rounded-lg px-2 py-1.5">
                      <Icon className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      <span className="text-slate-500 font-cairo text-xs w-24 flex-shrink-0">{f.label}:</span>
                      <span
                        className={`text-slate-800 flex-1 truncate ${f.mono ? 'font-mono' : 'font-tajawal'}`}
                        dir="ltr"
                      >
                        {revealSensitive ? f.value : '•••••••••'}
                      </span>
                      {revealSensitive && (
                        <button
                          onClick={() => {
                            navigator.clipboard?.writeText(f.value);
                            showLocalToast('تم نسخ ' + f.label + ' ✓');
                          }}
                          className="text-slate-400 hover:text-slate-700 flex-shrink-0"
                          title="نسخ"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
              {revealSensitive && (
                <button
                  onClick={async () => {
                    const pw = await resetPassword(selectedLive.id);
                    if (pw) showLocalToast('كلمة المرور الجديدة: ' + pw);
                  }}
                  className="w-full mt-2 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white border border-rose-200 text-rose-600 font-cairo font-bold text-xs hover:bg-rose-100 transition-colors"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> إعادة تعيين كلمة المرور
                </button>
              )}
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-cairo font-bold text-slate-600 mb-1">
                <StickyNote className="w-4 h-4" /> ملاحظة إدارية خاصة
              </label>
              <div className="flex gap-2">
                <input
                  value={noteDraft}
                  onChange={(e) => setNoteDraft(e.target.value)}
                  placeholder="اكتب ملاحظة..."
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm"
                />
                <button
                  onClick={async () => {
                    await setNote(selectedLive.id, noteDraft);
                    showLocalToast('حُفظت الملاحظة ✓');
                  }}
                  className="px-4 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm"
                >
                  حفظ
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={async () => {
                  await toggleVerified(selectedLive.id, !selectedLive.verified);
                  showLocalToast(selectedLive.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓');
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${
                  selectedLive.verified ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <BadgeCheck className="w-4 h-4" /> {selectedLive.verified ? 'موثق' : 'توثيق'}
              </button>
              <button
                onClick={async () => {
                  await setPremium(selectedLive.id, !selectedLive.premium);
                  showLocalToast(selectedLive.premium ? 'أُلغي التميّز' : 'ترقية مميّز 👑');
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${
                  selectedLive.premium ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Crown className="w-4 h-4" /> {selectedLive.premium ? 'مميّز' : 'ترقية'}
              </button>
              {selectedLive.status !== 'active' ? (
                <button
                  onClick={async () => {
                    await updateMember(selectedLive.id, { status: 'active' });
                    showLocalToast('تم التفعيل ✓');
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-bold text-sm"
                >
                  <UserCheck className="w-4 h-4" /> تفعيل
                </button>
              ) : (
                <button
                  onClick={async () => {
                    await updateMember(selectedLive.id, { status: 'suspended' });
                    showLocalToast('تم الإيقاف');
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-rose-100 text-rose-700 font-cairo font-bold text-sm"
                >
                  <UserX className="w-4 h-4" /> إيقاف
                </button>
              )}
              <button
                onClick={async () => {
                  await toggleFlag(selectedLive.id, !selectedLive.flagged);
                  showLocalToast(selectedLive.flagged ? 'أُزيل التعليم' : 'تم التعليم');
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-cairo font-bold text-sm ${
                  selectedLive.flagged ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Flag className="w-4 h-4" /> {selectedLive.flagged ? 'معلّم' : 'تعليم'}
              </button>
            </div>

            <button
              onClick={() => { setNotifyFor(selectedLive); setNotifyText(''); }}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:brightness-105"
            >
              <Send className="w-4 h-4 -scale-x-100" /> إرسال إشعار للعضو
            </button>

            <button
              onClick={() => impersonateAndGo(selectedLive)}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-l from-slate-900 to-slate-800 text-amber-300 font-cairo font-bold text-sm hover:brightness-110 transition-all border border-amber-500/30"
            >
              <LogIn className="w-4 h-4" /> الدخول بحساب العضو
            </button>

            <button
              onClick={() => setDeleteFor(selectedLive)}
              className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-white border-2 border-rose-200 text-rose-600 font-cairo font-bold text-sm hover:bg-rose-50 transition-colors"
            >
              <Trash2 className="w-4 h-4" /> حذف الحساب نهائياً
            </button>
          </div>
        )}
      </Modal>

      {/* Delete confirmation */}
      <Modal open={!!deleteFor} onClose={() => setDeleteFor(null)} title="تأكيد حذف الحساب">
        {deleteFor && (
          <div className="text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-7 h-7 text-rose-500" />
            </div>
            <p className="font-cairo font-bold text-slate-800 mb-1">حذف حساب «{deleteFor.nickname}»؟</p>
            <p className="text-sm text-slate-500 font-tajawal mb-5">سيُزال الحساب نهائياً من قوائم المنصة. لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-2">
              <button
                onClick={() => setDeleteFor(null)}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={async () => {
                  await deleteMember(deleteFor.id);
                  setDeleteFor(null);
                  setSelected(null);
                  showLocalToast('تم حذف الحساب نهائياً');
                }}
                className="flex-1 py-3 rounded-xl bg-rose-deep text-white font-cairo font-bold text-sm hover:brightness-110 transition-all"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* نافذة تأكيد الإجراء الجماعي */}
      <Modal open={!!bulkConfirm} onClose={() => { if (!bulkBusy) { setBulkConfirm(null); setBulkReason(''); } }} title="تأكيد إجراء جماعي">
        {bulkConfirm && (
          <div className="text-center" dir="rtl">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 ${
              bulkConfirm.action === 'delete' || bulkConfirm.action === 'ban' ? 'bg-rose-100' : 'bg-amber-100'
            }`}>
              {bulkConfirm.action === 'delete' ? <Trash2 className="w-7 h-7 text-rose-600" /> :
               bulkConfirm.action === 'ban' ? <UserX className="w-7 h-7 text-rose-600" /> :
               bulkConfirm.action === 'freeze' ? <Lock className="w-7 h-7 text-sky-600" /> :
               bulkConfirm.action === 'verify' ? <BadgeCheck className="w-7 h-7 text-blue-600" /> :
               <CheckCircle2 className="w-7 h-7 text-emerald-600" />}
            </div>
            <p className="font-cairo font-bold text-slate-800 mb-1">
              تطبيق «{bulkConfirm.label}» على <span className="text-amber-600">{selectedCount}</span> عضو؟
            </p>
            <p className="text-sm text-slate-500 font-tajawal mb-4">
              {bulkConfirm.action === 'delete'
                ? 'سيُحذف هؤلاء الأعضاء نهائياً ولا يمكن التراجع عن هذا الإجراء.'
                : 'سيتم تطبيق الإجراء على جميع الأعضاء المحددين دفعة واحدة.'}
            </p>
            {(bulkConfirm.action === 'ban' || bulkConfirm.action === 'freeze' || bulkConfirm.action === 'suspend') && (
              <textarea
                value={bulkReason}
                onChange={(e) => setBulkReason(e.target.value)}
                rows={2}
                placeholder="سبب الإجراء (اختياري — يظهر في ملف العضو)..."
                className="w-full mb-4 px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm text-right"
              />
            )}
            <div className="flex gap-2">
              <button
                onClick={() => { if (!bulkBusy) { setBulkConfirm(null); setBulkReason(''); } }}
                disabled={bulkBusy}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors disabled:opacity-50"
              >
                إلغاء
              </button>
              <button
                onClick={runBulk}
                disabled={bulkBusy}
                className={`flex-1 py-3 rounded-xl text-white font-cairo font-bold text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2 ${
                  bulkConfirm.action === 'delete' || bulkConfirm.action === 'ban' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-navy-900 hover:bg-navy-800'
                }`}
              >
                {bulkBusy && <Loader2 className="w-4 h-4 animate-spin" />}
                {bulkBusy ? 'جارٍ التنفيذ...' : 'تأكيد'}
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* نافذة تغيير حالة فردية بسبب */}
      <Modal open={!!statusFor} onClose={() => { setStatusFor(null); setStatusReasonDraft(''); }} title="تغيير حالة الحساب">
        {statusFor && (
          <div dir="rtl">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 ${
              statusFor.status === 'banned' ? 'bg-rose-100' : statusFor.status === 'frozen' ? 'bg-sky-100' : 'bg-orange-100'
            }`}>
              {statusFor.status === 'banned' ? <UserX className="w-7 h-7 text-rose-600" /> :
               statusFor.status === 'frozen' ? <Lock className="w-7 h-7 text-sky-600" /> :
               <Ban className="w-7 h-7 text-orange-600" />}
            </div>
            <p className="font-cairo font-bold text-slate-800 text-center mb-1">
              {statusFor.status === 'banned' ? 'حظر نهائي' : statusFor.status === 'frozen' ? 'تجميد مؤقت' : 'إيقاف'} لحساب «{statusFor.member.nickname}»
            </p>
            <p className="text-sm text-slate-500 font-tajawal text-center mb-4">
              {statusFor.status === 'banned' ? 'لن يتمكن العضو من الدخول أو الظهور في المنصة.'
               : statusFor.status === 'frozen' ? 'يُجمّد الحساب مؤقتاً ويمكن إعادة تفعيله لاحقاً.'
               : 'يُوقف الحساب مؤقتاً عن النشاط.'}
            </p>
            <label className="block text-xs font-cairo font-bold text-slate-700 mb-1.5">سبب الإجراء (يظهر في ملف العضو):</label>
            <textarea
              value={statusReasonDraft}
              onChange={(e) => setStatusReasonDraft(e.target.value)}
              rows={3}
              placeholder="مثال: مخالفة شروط الاستخدام، بلاغات متكررة..."
              className="w-full mb-4 px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm text-right"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={() => { setStatusFor(null); setStatusReasonDraft(''); }}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={applyStatusChange}
                className={`flex-1 py-3 rounded-xl text-white font-cairo font-bold text-sm transition-all ${
                  statusFor.status === 'banned' ? 'bg-rose-600 hover:bg-rose-700' : statusFor.status === 'frozen' ? 'bg-sky-600 hover:bg-sky-700' : 'bg-orange-600 hover:bg-orange-700'
                }`}
              >
                تأكيد الإجراء
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Notify modal */}
      <Modal open={!!notifyFor} onClose={() => setNotifyFor(null)} title="إرسال إشعار للعضو">
        {notifyFor && (
          <div>
            <p className="text-sm text-slate-500 font-tajawal mb-3">
              سيصل هذا الإشعار إلى <strong className="text-slate-800">{notifyFor.nickname}</strong> داخل المنصة.
            </p>
            <textarea
              value={notifyText}
              onChange={(e) => setNotifyText(e.target.value)}
              rows={4}
              placeholder="نص الإشعار..."
              className="w-full px-3 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {['نرحّب بك في توافق ✨', 'يرجى استكمال توثيق حسابك.', 'تمت مراجعة ملفك بنجاح ✓'].map((t) => (
                <button
                  key={t}
                  onClick={() => setNotifyText(t)}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-[11px] font-cairo hover:bg-slate-200"
                >
                  {t}
                </button>
              ))}
            </div>
            <button
              onClick={async () => {
                if (!notifyText.trim()) return;
                await notifyMember(notifyFor.id, notifyText.trim());
                setNotifyFor(null);
                showLocalToast('تم إرسال الإشعار ✓');
              }}
              disabled={!notifyText.trim()}
              className="w-full mt-4 flex items-center justify-center gap-2 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm disabled:opacity-50"
            >
              <Send className="w-4 h-4 -scale-x-100" /> إرسال الإشعار
            </button>
          </div>
        )}
      </Modal>

      {/* Import modal */}
      <Modal open={importOpen} onClose={() => setImportOpen(false)} title="استيراد الأعضاء" size="lg">
        <div className="space-y-4 text-right" dir="rtl">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
            <p className="text-xs text-blue-800 font-tajawal leading-relaxed">
              ألصق بيانات الأعضاء بصيغة JSON. يجب أن يكون كل عضو محتوياً على: <strong>nickname, email, gender</strong>.
              يمكنك أولاً تصدير الأعضاء والتعديل على الملف ثم إعادة الاستيراد.
            </p>
          </div>
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            rows={8}
            placeholder={`[\n  {\n    "nickname": "أحمد",\n    "email": "ahmed@example.com",\n    "gender": "male",\n    "age": 30,\n    "city": "الرياض"\n  }\n]`}
            className="w-full px-3 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm font-mono text-left"
            dir="ltr"
          />
          <button
            onClick={handleImport}
            disabled={!importText.trim()}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm disabled:opacity-50"
          >
            <Upload className="w-4 h-4" /> استيراد الأعضاء
          </button>
        </div>
      </Modal>

      {/* Toast */}
      <AnimatePresence>
        {localToast && (
          <motion.div
            initial={{ opacity: 0, y: 30, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 30, x: '-50%' }}
            className="fixed bottom-6 left-1/2 z-[100] px-5 py-3 rounded-2xl shadow-2xl font-cairo font-bold text-sm text-white bg-slate-900 flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            {localToast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
