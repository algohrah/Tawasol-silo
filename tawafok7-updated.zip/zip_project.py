import os
import zipfile

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        if 'node_modules' in dirs:
            dirs.remove('node_modules')
        if '.git' in dirs:
            dirs.remove('.git')
        if 'dist' in dirs:
            dirs.remove('dist')
        if 'extracted_project' in dirs:
            dirs.remove('extracted_project')
            
        for file in files:
            if file in ['tawafok.zip', 'tawfok7.zip', 'tawfok7.tar.gz', 'zip_project.py']:
                continue
            file_path = os.path.join(root, file)
            ziph.write(file_path, os.path.relpath(file_path, path))

with zipfile.ZipFile('public/tawfok7.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir('.', zipf)

print("Zip created successfully.")
