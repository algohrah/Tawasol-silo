import fs from 'fs';
import * as archiver from 'archiver';

const createArchive = archiver.create || archiver.default || archiver;

const output = fs.createWriteStream('public/tawfok7.zip');
const archive = createArchive('zip', { zlib: { level: 9 } });

output.on('close', function() {
  console.log(archive.pointer() + ' total bytes');
});

archive.pipe(output);
archive.glob('**/*', {
  ignore: ['node_modules/**', '.git/**', 'dist/**', 'tawafok.zip', 'extracted_project/**', 'public/tawfok7.zip', 'public/tawfok7.tar.gz', 'zip.mjs']
});

archive.finalize();
