import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Heart, Send, Inbox, Sparkles, AlertCircle, CreditCard, CheckCircle2,
  MessageSquare, Search, X, Handshake, Coins, Clock, Ban, Star, ShieldCheck,
} from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { getAvatar, getGenderColors } from '../lib/types';
import { FEE_CONFIG, type RequestStatus } from '../lib/data';
import Modal from '../components/ui/Modal';
import {
  STATUS_CONFIG, RequestStepper, MediationStepper, DECLINE_REASONS,
} from '../components/RequestStatus';
import CoordinationPortal from '../components/CoordinationPortal';

type StatusFilter = 'all' | RequestStatus;

const RatingStars = ({ value, onChange, readOnly = false }: { value: number; onChange?: (val: number) => void; readOnly?: boolean }) => {
  const [hoverValue, setHoverValue] = useState<number | null>(null);
  const activeValue = hoverValue !== null ? hoverValue : value;

  return (
    <div className="flex items-center gap-1.5" dir="ltr">
      {[1, 2, 3, 4, 5].map((starIdx) => {
        const valLeft = starIdx - 0.5;
        const valRight = starIdx;

        return (
          <div key={starIdx} className="relative w-7 h-7 flex items-center justify-center cursor-pointer">
            {/* Left half selector */}
            {!readOnly && onChange && (
              <div 
                className="absolute top-0 left-0 w-3.5 h-7 z-15" 
                onMouseEnter={() => setHoverValue(valLeft)}
                onMouseLeave={() => setHoverValue(null)}
                onClick={() => onChange(valLeft)}
              />
            )}
            {/* Right half selector */}
            {!readOnly && onChange && (
              <div 
                className="absolute top-0 right-0 w-3.5 h-7 z-15" 
                onMouseEnter={() => setHoverValue(valRight)}
                onMouseLeave={() => setHoverValue(null)}
                onClick={() => onChange(valRight)}
              />
            )}
            {/* Star Icon rendered with SVG halves */}
            <svg viewBox="0 0 24 24" className="w-6 h-6 select-none pointer-events-none">
              <defs>
                <linearGradient id={`star-grad-${starIdx}-${activeValue}`}>
                  <stop offset="50%" stopColor={activeValue >= valLeft ? '#f59e0b' : '#e5e7eb'} />
                  <stop offset="50%" stopColor={activeValue >= valRight ? '#f59e0b' : '#e5e7eb'} />
                </linearGradient>
              </defs>
              <path 
                fill={`url(#star-grad-${starIdx}-${activeValue})`}
                stroke={activeValue >= valLeft ? '#d97706' : '#9ca3af'}
                strokeWidth="1.5"
                d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"
              />
            </svg>
          </div>
        );
      })}
      <span className="text-xs font-mono font-bold text-amber-700 ml-1">{value ? value.toFixed(1) : '0.0'} / 5.0</span>
    </div>
  );
};

export default function InterestRequests() {
  const {
    user,
    interestRequests: requests,
    adminUpdateInterestRequestStatus: handleAction,
    adminUpdateInterestRequestDetails: updateDetails,
    members,
    showToast,
    depositQuota,
    setDepositQuota,
    submitExemptRequest,
    topUpWallet,
    payInterestRequestFee,
    payPreExchangeChatFee,
    buyGlobalChatCredits,
    sendPreExchangeChatMessage,
    flagPreExchangeNoMoney,
    giftPreExchangeMessages,
    choosePreExchangeOption,
  } = useApp() as any;

  const [activeTab, setActiveTab] = useState<'active' | 'pending' | 'archived'>('active');
  const [filter, setFilter] = useState<'all' | 'received' | 'sent'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [subStepByReq, setSubStepByReq] = useState<Record<string, number>>({});
  const [activePortalReqId, setActivePortalReqId] = useState<string | null>(null);

  // Rejection modal
  const [declineOpen, setDeclineOpen] = useState(false);
  const [selectedReqId, setSelectedReqId] = useState<string | null>(null);
  const [declineCustomReason, setDeclineCustomReason] = useState('');
  const [selectedPredefined, setSelectedPredefined] = useState('');

  // Cancel modal
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReqId, setCancelReqId] = useState<string | null>(null);

  const [expandedReqId, setExpandedReqId] = useState<string | null>(null);

  // Payment states
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [paymentReqId, setPaymentReqId] = useState<string | null>(null);
  const [selectedAmount, setSelectedAmount] = useState<number>(500);
  const [pledgeAccepted, setPledgeAccepted] = useState(false);
  const [useWallet, setUseWallet] = useState(true);
  const [exemptionReason, setExemptionReason] = useState('');
  const [showExemptionForm, setShowExemptionForm] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState<number>(500);
  const [showTopUpModal, setShowTopUpModal] = useState(false);

  // Evaluation modal
  const [evalOpen, setEvalOpen] = useState(false);
  const [evalReqId, setEvalReqId] = useState<string | null>(null);
  const [evalResult, setEvalResult] = useState<'success' | 'failed'>('success');
  const [evalNote, setEvalNote] = useState('');

  const getMemberById = (id: string) => members.find((m: any) => m.id === id);

  // فلترة وترتيب طبقاً للتقسيم الجديد
  const filtered = useMemo(() => {
    let list = requests;

    // 1. تصفية التبويب الرئيسي (الأطوار الثلاثة)
    if (activeTab === 'active') {
      list = list.filter((r: any) => ['accepted_pending_payment', 'paid', 'in_mediation'].includes(r.status));
    } else if (activeTab === 'pending') {
      list = list.filter((r: any) => r.status === 'pending');
    } else if (activeTab === 'archived') {
      list = list.filter((r: any) => ['completed', 'declined', 'cancelled'].includes(r.status));
    }

    // 2. تصفية صادر/وارد
    if (filter === 'received') {
      list = list.filter((r: any) => r.receiverId === 'm2');
    } else if (filter === 'sent') {
      list = list.filter((r: any) => r.senderId === 'm2');
    }

    // 3. فلترة البحث بالاسم المستعار للطرف الآخر
    if (searchQuery.trim()) {
      list = list.filter((r: any) => {
        const partnerId = r.senderId === 'm2' ? r.receiverId : r.senderId;
        const member = getMemberById(partnerId);
        return member?.nickname.includes(searchQuery.trim());
      });
    }

    // ترتيب ذكي: الأحدث أولاً
    return list.sort((a: any, b: any) => {
      return (b.createdAt || 0) - (a.createdAt || 0);
    });
  }, [requests, activeTab, filter, searchQuery, members]);

  // إحصائيات الأقسام الثلاثة
  const stats = useMemo(() => {
    return {
      active: requests.filter((r: any) => ['accepted_pending_payment', 'paid', 'in_mediation'].includes(r.status)).length,
      pending: requests.filter((r: any) => r.status === 'pending').length,
      archived: requests.filter((r: any) => ['completed', 'declined', 'cancelled'].includes(r.status)).length,
    };
  }, [requests]);

  const receivedPending = requests.filter((r: any) => r.receiverId === 'm2' && r.status === 'pending').length;

  const handleDeclineClick = (reqId: string) => {
    setSelectedReqId(reqId);
    setDeclineCustomReason('');
    setSelectedPredefined('');
    setDeclineOpen(true);
  };

  const submitDecline = () => {
    if (!selectedReqId) return;
    const finalReason = declineCustomReason.trim() || selectedPredefined;
    if (!finalReason) {
      showToast('الرجاء اختيار أو كتابة سبب الرفض', 'error');
      return;
    }
    handleAction(selectedReqId, 'declined', finalReason);
    setDeclineOpen(false);
    setSelectedReqId(null);
  };

  const handleSimulatePayment = (reqId: string) => {
    const req = requests.find((r: any) => r.id === reqId);
    if (!req) return;

    // تفعيل رصيد العربون الموحد والجدية لـ 5 تواصلات
    setDepositQuota({
      hasActiveQuota: true,
      remainingAttempts: 5,
      totalPaidAmount: selectedAmount,
      paidAt: 'الآن',
      selectedTierPrice: selectedAmount,
    });

    const isSender = req.senderId === 'm2';
    const fields: Partial<typeof req> = {};
    
    if (isSender) {
      fields.senderPaid = true;
      fields.senderPaidAmount = selectedAmount;
      fields.senderPaidAt = 'الآن';
    } else {
      fields.receiverPaid = true;
      fields.receiverPaidAmount = selectedAmount;
      fields.receiverPaidAt = 'الآن';
    }

    const partnerPaid = isSender ? req.receiverPaid : req.senderPaid;

    if (partnerPaid) {
      handleAction(reqId, 'paid');
      updateDetails(reqId, {
        ...fields,
        paymentStatus: 'paid',
        paidAt: 'الآن',
      });
      showToast(`🎉 تم اكتمال سداد العربون وتفعيل باقة التواصل الموحد مع 5 أعضاء بنجاح! بدأت مرحلة الوساطة وتنسيق اللقاء.`, 'success');
    } else {
      updateDetails(reqId, fields);
      showToast(`✅ تم استلام دفعة الجدية بقيمة ${selectedAmount} ر.س وتفعيل رصيد التواصل الموحد (5 خيارات)! بانتظار سداد الطرف المقابل لتفعيل وساطة التنسيق.`, 'success');
    }
    
    setPaymentOpen(false);
  };

  const handleActivateQuotaForRequest = (reqId: string) => {
    const req = requests.find((r: any) => r.id === reqId);
    if (!req) return;

    if (!depositQuota.hasActiveQuota || depositQuota.remainingAttempts <= 0) {
      showToast('ليس لديك رصيد في العربون الموحد النشط حالياً لتفعيل هذا التواصل.', 'error');
      return;
    }

    const nextAttempts = Math.max(0, depositQuota.remainingAttempts - 1);
    setDepositQuota((prev: any) => ({
      ...prev,
      remainingAttempts: nextAttempts,
      hasActiveQuota: nextAttempts > 0
    }));

    const isSender = req.senderId === 'm2';
    const fields: Partial<typeof req> = {};
    
    if (isSender) {
      fields.senderPaid = true;
      fields.senderPaidAmount = depositQuota.selectedTierPrice || 500;
      fields.senderPaidAt = 'الآن';
    } else {
      fields.receiverPaid = true;
      fields.receiverPaidAmount = depositQuota.selectedTierPrice || 500;
      fields.receiverPaidAt = 'الآن';
    }

    const partnerPaid = isSender ? req.receiverPaid : req.senderPaid;

    if (partnerPaid) {
      handleAction(reqId, 'paid');
      updateDetails(reqId, {
        ...fields,
        paymentStatus: 'paid',
        paidAt: 'الآن',
      });
      showToast(`🎉 تم تفعيل التواصل بنجاح وتغطية الرسوم من عربون الجدية الموحد الخاص بك! متبقي لديك التواصل مع ${nextAttempts} أعضاء إضافيين.`, 'success');
    } else {
      updateDetails(reqId, fields);
      showToast(`✅ تم تفعيل الجدية لهذا الطرف وتغطية رصيدك! بانتظار سداد الطرف الآخر لتفعيل التنسيق واللقاء. متبقي لديك التواصل مع ${nextAttempts} أعضاء.`, 'success');
    }
  };

  const handleCancel = () => {
    if (!cancelReqId) return;
    handleAction(cancelReqId, 'cancelled');
    showToast('تم إلغاء الطلب', 'info');
    setCancelOpen(false);
    setCancelReqId(null);
  };

  const handleEvaluation = () => {
    if (!evalReqId) return;
    updateDetails(evalReqId, {
      evaluationResult: evalResult,
      evaluationNote: evalNote.trim(),
    });
    setEvalOpen(false);
    setEvalReqId(null);
  };



  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6" dir="rtl">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 mb-6 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-deep/10 flex items-center justify-center">
              <Heart className="w-6 h-6 text-rose-deep fill-rose-deep" />
            </div>
            <div className="text-right">
              <h1 className="font-cairo font-extrabold text-2xl text-navy-900">طلبات الاهتمام</h1>
              <p className="text-navy-600 font-tajawal text-sm mt-0.5">تُعالَج جميع الطلبات تحت إشراف الوسيطة الشرعية</p>
            </div>
          </div>
          
          {/* Wallet & Quota Badges */}
          <div className="flex items-center gap-3 flex-wrap">
            {/* Wallet Balance Badge */}
            <div className="bg-white px-4 py-2.5 rounded-2xl border border-cream-200 shadow-sm flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <Coins className="w-5 h-5 text-amber-600" />
              </div>
              <div className="text-right">
                <span className="block text-[10px] text-slate-400 font-cairo">رصيد محفظتك</span>
                <span className="block text-sm font-cairo font-black text-amber-700">{user.profile.walletBalance} ريال سعودي</span>
              </div>
            </div>

            {/* Deposit Quota Badge/Button */}
            <button
              onClick={() => {
                if (!depositQuota.hasActiveQuota) {
                  setPaymentReqId('general');
                  setPaymentOpen(true);
                } else {
                  showToast('✓ رصيد وسام الجدية والعربون نشط ومتاح لديك لتفعيل التواصل بنجاح.', 'success');
                }
              }}
              className={`px-4 py-2.5 rounded-2xl border shadow-sm flex items-center gap-2.5 transition-all text-right cursor-pointer hover:shadow-md active:scale-98 ${
                depositQuota.hasActiveQuota 
                  ? 'bg-emerald-50/50 border-emerald-150 text-emerald-800 hover:bg-emerald-55' 
                  : 'bg-amber-50/60 border-amber-200 text-amber-800 hover:bg-amber-55 animate-pulse'
              }`}
            >
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                depositQuota.hasActiveQuota ? 'bg-emerald-500/10' : 'bg-amber-500/10'
              }`}>
                {depositQuota.hasActiveQuota ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                ) : (
                  <Star className="w-5 h-5 text-amber-600 fill-amber-600/30" />
                )}
              </div>
              <div className="text-right">
                <span className="block text-[10px] text-slate-500 font-cairo">رصيد عربون الجدية</span>
                <span className={`block text-xs font-cairo font-black ${
                  depositQuota.hasActiveQuota ? 'text-emerald-700' : 'text-amber-700'
                }`}>
                  {depositQuota.hasActiveQuota ? `${depositQuota.remainingAttempts} / 5 خيارات` : 'غير نشط (تفعيل)'}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* التبويبات الرئيسية الثلاثة المقسمة لقائمة الطلبات */}
        <div className="grid grid-cols-3 gap-2 p-1.5 bg-cream-100 rounded-2xl mb-5 shadow-inner">
          <button
            onClick={() => setActiveTab('active')}
            className={`py-3 rounded-xl font-cairo font-black text-xs md:text-sm transition-all relative no-tap-highlight ${
              activeTab === 'active' 
                ? 'bg-navy-900 text-white shadow-md scale-102 border border-navy-950' 
                : 'text-navy-600 hover:text-navy-900'
            }`}
          >
            <span className="flex items-center justify-center gap-1">
              💬 التنسيق والشات
              <span className={`px-1.5 py-0.2 rounded-md text-[10px] ${activeTab === 'active' ? 'bg-gold-500 text-navy-950 font-black' : 'bg-cream-300 text-navy-800'}`}>
                {stats.active}
              </span>
            </span>
          </button>

          <button
            onClick={() => setActiveTab('pending')}
            className={`py-3 rounded-xl font-cairo font-black text-xs md:text-sm transition-all relative no-tap-highlight ${
              activeTab === 'pending' 
                ? 'bg-navy-900 text-white shadow-md scale-102 border border-navy-950' 
                : 'text-navy-600 hover:text-navy-900'
            }`}
          >
            <span className="flex items-center justify-center gap-1">
              📩 طلبات الاهتمام
              {receivedPending > 0 ? (
                <span className="absolute -top-1.5 -left-1.5 px-1.5 py-0.5 text-[9px] font-black bg-rose-deep text-white rounded-full leading-none animate-bounce">
                  {receivedPending} جديد
                </span>
              ) : (
                <span className={`px-1.5 py-0.2 rounded-md text-[10px] ${activeTab === 'pending' ? 'bg-gold-500 text-navy-950 font-black' : 'bg-cream-300 text-navy-800'}`}>
                  {stats.pending}
                </span>
              )}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('archived')}
            className={`py-3 rounded-xl font-cairo font-black text-xs md:text-sm transition-all relative no-tap-highlight ${
              activeTab === 'archived' 
                ? 'bg-navy-900 text-white shadow-md scale-102 border border-navy-950' 
                : 'text-navy-600 hover:text-navy-900'
            }`}
          >
            <span className="flex items-center justify-center gap-1">
              📁 الأرشيف والمغلقة
              <span className={`px-1.5 py-0.2 rounded-md text-[10px] ${activeTab === 'archived' ? 'bg-gold-500 text-navy-950 font-black' : 'bg-cream-300 text-navy-800'}`}>
                {stats.archived}
              </span>
            </span>
          </button>
        </div>

        {/* البحث والمصفيات الفرعية الصادرة/الواردة */}
        <div className="bg-white rounded-3xl p-4 border border-cream-200/60 shadow-soft mb-5 space-y-3">
          <div className="relative">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالاسم المستعار للطرف الآخر..."
              className="w-full pr-11 pl-4 py-2.5 rounded-xl bg-cream-50 border border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900 shadow-inner"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-cairo font-extrabold text-navy-400">تصنيف جهة الطلب:</span>
            <div className="flex gap-1.5">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'received', label: 'الواردة 📥' },
                { id: 'sent', label: 'المرسلة 📤' }
              ].map((subFilter) => (
                <button
                  key={subFilter.id}
                  onClick={() => setFilter(subFilter.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold whitespace-nowrap transition-all ${
                    filter === subFilter.id 
                      ? 'bg-rose-deep text-white shadow-sm' 
                      : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                  }`}
                >
                  {subFilter.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Requests list */}
        <div className="space-y-4">
          {filtered.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-cream-200/60">
              <Inbox className="w-12 h-12 text-navy-200 mx-auto mb-3" />
              <p className="text-navy-500 font-tajawal">لا توجد طلبات مطابقة</p>
            </div>
          ) : (
            filtered.map((req: any, i: number) => {
              const partnerId = req.senderId === 'm2' ? req.receiverId : req.senderId;
              const member = getMemberById(partnerId);
              if (!member) return null;
              const avatar = getAvatar(member.gender);
              const c = getGenderColors(member.gender);
              const sc = STATUS_CONFIG[req.status as RequestStatus] || STATUS_CONFIG.pending;
              const isReceivedType = req.receiverId === 'm2';
              const isSentType = req.senderId === 'm2';
              const isActive = ['pending', 'accepted_pending_payment', 'paid', 'in_mediation'].includes(req.status);

              return (
                <motion.div
                  key={req.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="bg-white rounded-3xl p-5 shadow-soft border border-cream-200/60 hover:border-gold-400/20 transition-all"
                >
                  {/* Header: avatar + name + status badge */}
                  <div className="flex items-start gap-4 mb-4">
                    <Link to={`/member/${member.id}`} className="flex-shrink-0">
                      <div className={`w-14 h-14 rounded-2xl overflow-hidden ${c.bg} flex items-center justify-center bg-white border border-cream-200`}>
                        <img src={avatar} alt="" className="w-full h-full object-contain p-1" />
                      </div>
                    </Link>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <Link to={`/member/${member.id}`}>
                          <h3 className="font-cairo font-black text-sm text-navy-900 hover:text-amber-700 transition-colors">
                            {member.nickname}
                          </h3>
                        </Link>
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-cairo font-black ${sc.badgeBg} ${sc.color}`}>
                          {sc.label}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5 text-[11px] text-navy-505 font-tajawal">
                        <span>{member.age} سنة</span>
                        <span>•</span>
                        <span>{member.city}</span>
                        <span>•</span>
                        <span>{member.education}</span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Status / Description based on state */}
                  <div className={`mb-4 bg-slate-50/70 p-3.5 rounded-2xl border border-cream-200/60 text-xs text-navy-700 leading-relaxed font-tajawal text-right ${expandedReqId === req.id ? 'block' : 'hidden sm:block'}`} dir="rtl">
                    {req.status === 'pending' && (
                      <span>
                        {isSentType 
                          ? "لقد أرسلت طلب الاهتمام إلى هذا العضو. بانتظار مراجعته وقبوله لبدء خطوات التنسيق وميثاق الجدية." 
                          : "لقد تلقيت طلب اهتمام من هذا العضو. يمكنك قبوله لبدء التوافق والتنسيق، أو الرفض بالمعروف."}
                      </span>
                    )}
                    {req.status === 'accepted_pending_payment' && (
                      <span>
                        {!req.preExchangeChoice ? (
                          <span className="text-amber-805 font-bold flex items-center gap-1.5 text-amber-800 font-cairo font-black">
                            <Sparkles className="w-4 h-4 text-amber-600 animate-pulse" /> مبارك، حصل اهتمام مشترك! يرجى الاستمرار لتحديد مسار تواصلك المفضل لبدء المتابعة.
                          </span>
                        ) : req.preExchangeChoice === 'chat' ? (
                          <span className="text-amber-700 font-bold flex items-center gap-1.5 font-tajawal">
                            <MessageSquare className="w-4 h-4 text-amber-500" /> رصيد الاستفسار مفعّل لغرفة الاستفسارات المبكرة قبل العربون الكلي للجدية ومطابقة الأهل.
                          </span>
                        ) : (
                          <span className="text-orange-700 font-bold flex items-center gap-1.5 font-tajawal animate-pulse">
                            <CreditCard className="w-4 h-4 text-orange-500" /> اخترت المسار الرسمي المباشر. يرجى المتابعة لسداد عربون السعي الموحد للحصول على وسام الجدية الكامل.
                          </span>
                        )}
                      </span>
                    )}
                    {['paid', 'in_mediation'].includes(req.status) && (
                      <span className="text-emerald-705 font-bold flex items-center gap-1.5 font-tajawal text-emerald-800">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" /> العربون مدفوع والوساطة شرعية ومستمرة للتنسيق بين الأهل. انقر للدخول لغرفة التنسيق ومتابعة خطوتك الحالية.
                      </span>
                    )}
                    {req.status === 'completed' && (
                      <span className="text-slate-650 font-bold flex items-center gap-1.5 text-slate-800 font-tajawal">
                        🏆 اكتملت المعاملة بنجاح، والحمد لله رب العالمين. مبروك النكاح وعقد القران الميمون!
                      </span>
                    )}
                    {req.status === 'declined' && (
                      <span className="text-rose-700 font-bold font-tajawal">
                        لم يُكتب النصيب في هذا الطلب بالمعروف. سبب الاعتذار: "{req.declineReason || 'البيانات غير متوافقة'}"
                      </span>
                    )}
                    {req.status === 'cancelled' && (
                      <span className="text-slate-500 font-tajawal">
                        تم إلغاء طلب التنسيق والاهتمام بشكل نهائي. {req.refundPercentage !== undefined && req.refundPercentage > 0 && `نسبة قيمة الاسترداد: ${req.refundPercentage}%`}
                      </span>
                    )}
                  </div>

                  {/* Attempts counter for Active requests */}
                  {['paid', 'in_mediation'].includes(req.status) && req.attemptsCount !== undefined && (
                    <div className={`flex items-center gap-2 text-[10px] text-navy-450 font-tajawal mb-4 font-bold bg-amber-500/10 text-amber-800 px-3 py-1.5 rounded-xl w-fit ${expandedReqId === req.id ? 'flex' : 'hidden sm:flex'}`} dir="rtl">
                      <Coins className="w-3.5 h-3.5 text-gold-500" />
                      المحاولات المتبقية للتنسيق والاتصال: {req.attemptsCount} خيارات متبقية
                    </div>
                  )}

                  {/* Actions Row */}
                  <div className={`flex items-center justify-between gap-3 pt-3 border-t border-cream-100 flex-wrap animate-fade-in ${expandedReqId === req.id ? 'flex' : 'hidden sm:flex'}`} dir="rtl">
                    
                    {/* Standard Pending Action buttons */}
                    {req.status === 'pending' && (
                      <div className="flex gap-2 w-full sm:w-auto">
                        {isReceivedType ? (
                          <>
                            <button
                              onClick={() => handleAction(req.id, 'accepted_pending_payment')}
                              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-cairo font-black hover:bg-emerald-700 transition-all shadow-sm cursor-pointer"
                            >
                              <CheckCircle2 className="w-4 h-4" /> قبول الرغبة
                            </button>
                            <button
                              onClick={() => handleDeclineClick(req.id)}
                              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-rose-50 text-rose-600 text-xs font-cairo font-black border border-rose-100 hover:bg-rose-100 transition-all cursor-pointer"
                            >
                              <X className="w-4 h-4" /> اعتذار بالمعروف
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => { setCancelReqId(req.id); setCancelOpen(true); }}
                            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-cream-100 text-navy-500 text-xs font-cairo font-bold hover:bg-rose-50 hover:text-rose-600 transition-all cursor-pointer"
                          >
                            <Ban className="w-3.5 h-3.5" /> إلغاء الطلب
                          </button>
                        )}
                      </div>
                    )}

                    {/* ACTIVE STATE PORTAL ENTRANCES */}
                    {req.status !== 'pending' && ['accepted_pending_payment', 'paid', 'in_mediation', 'completed'].includes(req.status) && (
                      <button
                        onClick={() => setActivePortalReqId(req.id)}
                        className={`px-5 py-3 rounded-2xl font-cairo font-black text-xs transition-colors shadow-md active:scale-[0.98] flex items-center gap-2 cursor-pointer w-full justify-center ${
                          req.status === 'accepted_pending_payment'
                            ? !req.preExchangeChoice
                              ? 'bg-gradient-to-r from-amber-600 to-orange-500 text-white animate-pulse hover:shadow-orange-200 shadow-orange-100'
                              : req.preExchangeChoice === 'chat'
                                ? 'bg-amber-500 hover:bg-amber-600 text-white hover:shadow-md'
                                : 'bg-gradient-to-r from-gold-500 to-amber-600 text-navy-950 border border-gold-400 font-bold hover:shadow-gold'
                            : 'bg-navy-900 hover:bg-navy-850 text-white hover:shadow-md'
                        }`}
                      >
                        {req.status === 'accepted_pending_payment' ? (
                          !req.preExchangeChoice ? (
                            <>
                              <Sparkles className="w-4 h-4" />
                              <span>بدء تحديد خيار وطريقة التواصل</span>
                            </>
                          ) : req.preExchangeChoice === 'chat' ? (
                            <>
                              <MessageSquare className="w-4 h-4" />
                              <span>دخول غرفة الاستفسار والدردشة</span>
                            </>
                          ) : (
                            <>
                              <CreditCard className="w-4 h-4" />
                              <span>سداد العربون الموحد والعهد الشرعي</span>
                            </>
                          )
                        ) : (
                          <>
                            <Handshake className="w-4 h-4 text-amber-400" />
                            <span>دخول غرفة التنسيق والوساطة</span>
                            {req.coordinationStep && (
                              <span className="bg-white/15 text-white text-[9px] px-2 py-0.5 rounded-full font-bold font-cairo">
                                خطوة {req.coordinationStep}
                              </span>
                            )}
                          </>
                        )}
                      </button>
                    )}

                    {/* Link to management / Cancel Option */}
                    {req.status !== 'pending' && ['accepted_pending_payment', 'paid', 'in_mediation', 'completed'].includes(req.status) && (
                      <div className="flex gap-2 mt-2 w-full justify-between items-center text-[11px] text-navy-450 font-tajawal border-t border-cream-50 pt-2 pb-1">
                        <Link
                          to={`/admin-chat?partnerId=${partnerId}`}
                          className="flex items-center gap-1 text-slate-500 hover:text-navy-900 hover:underline font-bold"
                        >
                          <MessageSquare className="w-3 h-3" /> مراسلة الإدارة والاستفسار
                        </Link>
                        {req.status !== 'completed' && (
                          <button
                            type="button"
                            onClick={() => { setCancelReqId(req.id); setCancelOpen(true); }}
                            className="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer font-bold"
                          >
                            إلغاء الطلب بالمعروف
                          </button>
                        )}
                      </div>
                    )}

                  </div>

                  {/* Mobile Accordion Toggle */}
                  <div className="sm:hidden pt-2 text-center border-t border-cream-100 mt-3">
                    <button
                      onClick={() => setExpandedReqId(expandedReqId === req.id ? null : req.id)}
                      className="text-[11px] font-cairo font-bold text-navy-500 hover:text-gold-600 transition-colors"
                    >
                      {expandedReqId === req.id ? 'إخفاء التفاصيل ▲' : 'عرض التفاصيل ▼'}
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>

      {/* Coordination Portal for Active Requests */}
      <CoordinationPortal
        open={activePortalReqId !== null}
        onClose={() => setActivePortalReqId(null)}
        requestId={activePortalReqId || ''}
        requests={requests}
        members={members}
        user={user}
        updateDetails={updateDetails}
        handleAction={handleAction}
        showToast={showToast}
      />

      {/* Decline Modal */}
      <Modal open={declineOpen} onClose={() => setDeclineOpen(false)} title="سبب الرفض">
        <div className="space-y-4 text-right" dir="rtl">
          <p className="text-xs text-navy-500 font-tajawal">اختر سبباً أو اكتب سبباً خاصاً:</p>
          <div className="space-y-1.5">
            {DECLINE_REASONS.map(reason => (
              <button
                key={reason}
                onClick={() => { setSelectedPredefined(reason); setDeclineCustomReason(''); }}
                className={`w-full text-right p-3 rounded-xl border text-xs font-tajawal font-bold transition-all ${
                  selectedPredefined === reason
                    ? 'bg-rose-50 border-rose-300 text-rose-800'
                    : 'bg-cream-50 border-cream-200 text-navy-600 hover:bg-cream-100'
                }`}
              >
                {reason}
              </button>
            ))}
          </div>
          <textarea
            value={declineCustomReason}
            onChange={e => { setDeclineCustomReason(e.target.value); setSelectedPredefined(''); }}
            placeholder="أو اكتب سبباً خاصاً..."
            rows={3}
            className="w-full text-xs font-tajawal p-3 rounded-xl border border-cream-200 bg-white focus:outline-none focus:border-rose-400"
          />
          <button
            onClick={submitDecline}
            className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-sm transition-colors no-tap-highlight"
          >
            تأكيد الرفض
          </button>
        </div>
      </Modal>

      {/* Payment Modal */}
      <Modal open={paymentOpen} onClose={() => setPaymentOpen(false)} title="سداد عربون السعي والتنسيق">
        <div className="space-y-4 text-right" dir="rtl">
          {/* Explanation Banner */}
          <div className="bg-orange-50 rounded-2xl p-4 border border-orange-200/60 font-tajawal text-xs text-orange-950 space-y-2 leading-relaxed">
            <h4 className="font-bold font-cairo text-orange-850 flex items-center gap-1">
              <Sparkles className="w-4 h-4" /> لماذا ندفع العربون؟
            </h4>
            <p>
              يُمثل العربون <strong>ميثاق جدية والتزام</strong> من الطرفين في المضي قُدماً، ولضمان تغطية تكلفة العمل والمتابعة اليومية التي تقوم بها المنسقة لكل ملف لجدولة المواعيد.
            </p>
            <p className="text-[10px] text-orange-700">
              * بعد اللقاء، في حال عدم النصيب، تسترد 50% من العربون المودع فوراً وبشكل تلقائي.
            </p>
          </div>

          {/* Flexible pricing selections */}
          <div className="space-y-2">
            <label className="text-xs font-bold font-cairo text-navy-800">اختر قيمة العربون المناسب لقدرتك المالية:</label>
            <div className="space-y-2">
              {[
                { 
                  val: 500, 
                  title: '500 ريال (عربون السعي الأساسي)', 
                  desc: 'الالتزام والجدية التامة لدعم تشغيل وساطة المنصة الشرعية بفاعلية.' 
                },
                { 
                  val: 250, 
                  title: '250 ريال (تيسير الحالات الشرعي)', 
                  desc: 'برنامج التخفيف والتيسير لدعم الجادين غير المقتدرين على سداد العربون كاملاً.' 
                },
                { 
                  val: 100, 
                  title: '100 ريال (رسم جدية رمزي)', 
                  desc: 'لتأكيد النية الصادقة ريثما تتواصل الإدارة لمساعدتك وتسهيل التنسيق.' 
                }
              ].map(opt => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => setSelectedAmount(opt.val)}
                  className={`w-full text-right p-3 rounded-xl border transition-all flex items-start gap-3 ${
                    selectedAmount === opt.val 
                      ? 'border-orange-500 bg-orange-50/50 text-orange-950 ring-2 ring-orange-500/20' 
                      : 'border-cream-200 bg-white hover:bg-cream-50 text-navy-600'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center mt-0.5 ${
                    selectedAmount === opt.val ? 'border-orange-600' : 'border-navy-200'
                  }`}>
                    {selectedAmount === opt.val && <span className="w-2 h-2 rounded-full bg-orange-600" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block font-cairo font-bold text-xs">{opt.title}</span>
                    <span className="block font-tajawal text-[10px] text-navy-400 mt-0.5">{opt.desc}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* IBAN details */}
          <div className="bg-cream-50 rounded-xl p-3 border border-cream-200 space-y-1.5 text-xs text-navy-700 leading-none">
            <p className="font-cairo font-bold text-navy-900 text-xs mb-1.5">الحساب البنكي المعتمد:</p>
            <div className="flex justify-between items-center py-0.5"><span className="text-navy-400">البنك:</span><span className="font-bold font-tajawal text-navy-900">مصرف الراجحي</span></div>
            <div className="flex justify-between items-center py-0.5"><span className="text-navy-400">المستفيد:</span><span className="font-bold font-tajawal text-navy-900">منصة توافق لخدمات الزواج</span></div>
            <div className="flex justify-between items-center py-0.5 gap-2">
              <span className="text-navy-400">الأيبان:</span>
              <span className="font-mono font-bold text-navy-900 text-xs overflow-x-auto select-all">SA938000018274930192849</span>
            </div>
          </div>

          {/* Simulate Action Button */}
          <button
            onClick={() => paymentReqId && handleSimulatePayment(paymentReqId)}
            className="w-full py-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-cairo font-bold text-sm transition-colors no-tap-highlight flex items-center justify-center gap-2 shadow-sm"
          >
            <CreditCard className="w-4 h-4" /> تأكيد سداد {selectedAmount} ريال في البنك
          </button>
        </div>
      </Modal>

      {/* Cancel Modal */}
      <Modal open={cancelOpen} onClose={() => setCancelOpen(false)} title="تأكيد الإلغاء">
        <div className="space-y-4 text-right" dir="rtl">
          <p className="text-sm text-navy-700 font-tajawal">
            هل أنت متأكد من إلغاء هذا الطلب؟
            {['paid', 'in_mediation'].includes(requests.find((r: any) => r.id === cancelReqId)?.status || '') &&
              ' سيتم استرداد 50% من العربون قبل اللقاء، و0% بعده.'
            }
          </p>
          <div className="flex gap-2">
            <button
              onClick={handleCancel}
              className="flex-1 py-3 rounded-xl bg-rose-600 text-white font-cairo font-bold text-sm hover:bg-rose-700 transition-colors no-tap-highlight"
            >
              تأكيد الإلغاء
            </button>
            <button
              onClick={() => setCancelOpen(false)}
              className="px-6 py-3 rounded-xl bg-cream-100 text-navy-600 font-cairo font-bold text-sm hover:bg-cream-200 transition-colors no-tap-highlight"
            >
              تراجع
            </button>
          </div>
        </div>
      </Modal>

      {/* Evaluation Modal */}
      <Modal open={evalOpen} onClose={() => setEvalOpen(false)} title="تقييم تجربة اللقاء">
        <div className="space-y-4 text-right" dir="rtl">
          <p className="text-xs text-navy-500 font-tajawal">هل تم اللقاء بنجاح وهل ترغب في المتابعة؟</p>
          <div className="flex gap-2">
            <button
              onClick={() => setEvalResult('success')}
              className={`flex-1 py-3 rounded-xl font-cairo font-bold text-xs transition-colors ${
                evalResult === 'success' ? 'bg-emerald-600 text-white' : 'bg-cream-50 text-navy-600 border border-cream-200'
              }`}
            >
              موفق ونرغب بالمتابعة عقد النكاح
            </button>
            <button
              onClick={() => setEvalResult('failed')}
              className={`flex-1 py-3 rounded-xl font-cairo font-bold text-xs transition-colors ${
                evalResult === 'failed' ? 'bg-rose-600 text-white' : 'bg-cream-50 text-navy-600 border border-cream-200'
              }`}
            >
              غير موفق ونرغب بإغلاق الطلب
            </button>
          </div>
          <textarea
            value={evalNote}
            onChange={e => setEvalNote(e.target.value)}
            placeholder="اكتب انطباعك أو أي ملاحظات للوسيطة (اختياري)..."
            rows={3}
            className="w-full text-xs font-tajawal p-3 rounded-xl border border-cream-200 bg-white focus:outline-none focus:border-gold-500"
          />
          <button
            onClick={handleEvaluation}
            className="w-full py-3 rounded-xl bg-navy-900 hover:bg-navy-800 text-white font-cairo font-bold text-sm transition-colors"
          >
            إرسال التقييم
          </button>
        </div>
      </Modal>

      {/* Top Up Wallet Modal */}
      <Modal open={showTopUpModal} onClose={() => setShowTopUpModal(false)} title="شحن رصيد المحفظة">
        <div className="space-y-4 text-right" dir="rtl">
          <p className="text-xs text-navy-500 font-tajawal">اختر أو اكتب المبلغ المراد شحنه في محفظتك الإلكترونية:</p>
          <div className="grid grid-cols-3 gap-2">
            {[100, 250, 500].map(amt => (
              <button
                key={amt}
                onClick={() => setTopUpAmount(amt)}
                className={`py-2.5 rounded-xl border font-cairo font-bold text-xs transition-all ${
                  topUpAmount === amt ? 'bg-amber-500 text-white border-amber-500' : 'bg-white text-navy-600 border-cream-200 hover:bg-cream-50'
                }`}
              >
                {amt} ريال
              </button>
            ))}
          </div>
          <input
            type="number"
            value={topUpAmount}
            onChange={(e) => setTopUpAmount(Number(e.target.value))}
            placeholder="أو اكتب مبلغاً مخصصاً..."
            className="w-full p-2.5 rounded-xl border border-cream-200 focus:outline-none focus:border-amber-400 font-tajawal text-xs text-slate-900 bg-slate-50"
          />
          <button
            onClick={() => {
              topUpWallet(topUpAmount);
              setShowTopUpModal(false);
            }}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-sm transition-colors shadow-sm"
          >
            تأكيد الشحن الفوري
          </button>
        </div>
      </Modal>
    </div>
  );
}
