import { useState, useMemo } from 'react';
import {
  Heart, Clock, CheckCircle2, XCircle, MessageSquare, Sparkles,
  AlertCircle, ShieldCheck, Mail, Phone, Lock, MapPin, Crown, Send,
  Search, ChevronDown, Star, Users, X, Filter, Calendar, CreditCard,
  TrendingUp, Percent, UserCheck, Venus, Mars, Handshake, PartyPopper, Ban,
} from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { motion, AnimatePresence } from 'framer-motion';
import Modal from '../../components/ui/Modal';
import { type AdminMember } from '../../lib/admin-data';

type Priority = 'high' | 'normal' | 'low';
type SortBy = 'newest' | 'compat' | 'priority';

const priorityConfig: Record<Priority, { label: string; color: string; icon: typeof Star }> = {
  high: { label: 'أولوية عالية', color: 'bg-red-100 text-red-700 border-red-200', icon: Star },
  normal: { label: 'أولوية عادية', color: 'bg-slate-100 text-slate-600 border-slate-200', icon: Star },
  low: { label: 'أولوية منخفضة', color: 'bg-sky-100 text-sky-700 border-sky-200', icon: Star },
};

export default function AdminRequests() {
  const {
    interestRequests: requests,
    adminUpdateInterestRequestStatus,
    adminUpdateInterestRequestDetails,
    members,
    adminMembers,
    calculateCompat,
    supportTickets,
    sendSupportMessage,
    createSupportTicket,
    showToast,
    adminCancelAndRefund,
    adminProcessExemptRequest,
    exemptRequests,
    currentAdminPermissions,
  } = useApp();

  // الفلاتر
  const [filter, setFilter] = useState<'all' | 'pending' | 'accepted_pending_admin' | 'accepted_pending_payment' | 'paid' | 'in_mediation' | 'completed' | 'declined' | 'cancelled'>('all');
  const [search, setSearch] = useState('');
  const [cityFilter, setCityFilter] = useState('all');
  const [compatFilter, setCompatFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [genderFilter, setGenderFilter] = useState<'all' | 'male' | 'female'>('all');
  const [verifiedFilter, setVerifiedFilter] = useState<'all' | 'verified' | 'unverified'>('all');
  const [priorityFilter, setPriorityFilter] = useState<'all' | Priority>('all');
  const [sortBy, setSortBy] = useState<SortBy>('newest');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const [priorityMap, setPriorityMap] = useState<Record<string, Priority>>({});

  // Cycle priority for requests
  const cyclePriority = (reqId: string) => {
    const current = getPriority(reqId);
    const next: Priority = current === 'normal' ? 'high' : current === 'high' ? 'low' : 'normal';
    setPriorityMap(prev => ({ ...prev, [reqId]: next }));
    showToast(`تم تغيير الأولوية للطلب إلى: ${priorityConfig[next].label}`, 'info');
  };

  // State for the expanded coordination panels
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [meetingDate, setMeetingDate] = useState('');
  const [meetingNotes, setMeetingNotes] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'waiting_for_payment' | 'paid'>('waiting_for_payment');

  // New features state
  const [selectedMember, setSelectedMember] = useState<AdminMember | null>(null);
  const [messagingOpen, setMessagingOpen] = useState(false);
  const [messagingTarget, setMessagingTarget] = useState<'sender' | 'receiver' | 'both'>('sender');
  const [activeReq, setActiveReq] = useState<any | null>(null);
  const [adminMsgText, setAdminMsgText] = useState('');

  // Decline modal state
  const [declineModal, setDeclineModal] = useState<{ id: string } | null>(null);
  const [declineReason, setDeclineReason] = useState('');

  // Compare modal state
  const [compareModal, setCompareModal] = useState<any | null>(null);

  // Confirm action state
  const [confirmAction, setConfirmAction] = useState<{ id: string; action: any } | null>(null);

  const getMemberById = (id: string) => members.find(m => m.id === id);

  // Get all unique cities
  const allCities = useMemo(() => {
    const cities = new Set<string>();
    requests.forEach(r => {
      const s = getMemberById(r.senderId);
      const rc = getMemberById(r.receiverId);
      if (s) cities.add(s.city);
      if (rc) cities.add(rc.city);
    });
    return Array.from(cities).sort();
  }, [requests, members]);

  const getPriority = (reqId: string): Priority => priorityMap[reqId] || 'normal';

  const filtered = useMemo(() => {
    let result = requests.filter(r => {
      const matchStatus = filter === 'all' || r.status === filter;
      const sender = getMemberById(r.senderId);
      const receiver = getMemberById(r.receiverId);
      const matchSearch = !search ||
        sender?.nickname.includes(search) ||
        receiver?.nickname.includes(search) ||
        r.message.includes(search);
      const matchCity = cityFilter === 'all' ||
        sender?.city === cityFilter ||
        receiver?.city === cityFilter;
      let matchCompat = true;
      if (compatFilter !== 'all' && sender && receiver) {
        const compat = calculateCompat ? calculateCompat(sender, receiver) : 85;
        if (compatFilter === 'high') matchCompat = compat >= 90;
        else if (compatFilter === 'medium') matchCompat = compat >= 75 && compat < 90;
        else if (compatFilter === 'low') matchCompat = compat < 75;
      }
      const matchGender = genderFilter === 'all' ||
        (sender && sender.gender === genderFilter) ||
        (receiver && receiver.gender === genderFilter);
      const matchVerified = verifiedFilter === 'all' ||
        (verifiedFilter === 'verified' && sender?.verified && receiver?.verified) ||
        (verifiedFilter === 'unverified' && (!sender?.verified || !receiver?.verified));
      const matchPriority = priorityFilter === 'all' || getPriority(r.id) === priorityFilter;
      return matchStatus && matchSearch && matchCity && matchCompat && matchGender && matchVerified && matchPriority;
    });

    // الترتيب
    result = [...result].sort((a, b) => {
      if (sortBy === 'compat') {
        const sa = getMemberById(a.senderId)!;
        const ra = getMemberById(a.receiverId)!;
        const sb = getMemberById(b.senderId)!;
        const rb = getMemberById(b.receiverId)!;
        const ca = calculateCompat ? calculateCompat(sa, ra) : 85;
        const cb = calculateCompat ? calculateCompat(sb, rb) : 85;
        return cb - ca;
      }
      if (sortBy === 'priority') {
        const order: Record<Priority, number> = { high: 0, normal: 1, low: 2 };
        return order[getPriority(a.id)] - order[getPriority(b.id)];
      }
      return 0; // newest (الترتيب الأصلي)
    });

    return result;
  }, [requests, filter, search, cityFilter, compatFilter, genderFilter, verifiedFilter, priorityFilter, sortBy, members, priorityMap]);

  const handleAction = (id: string, status: 'pending' | 'accepted' | 'declined', declineReason?: string) => {
    adminUpdateInterestRequestStatus(id, status, declineReason);
  };

  const handleConfirmAction = () => {
    if (!confirmAction) return;
    handleAction(confirmAction.id, confirmAction.action);
    showToast(`تم تحديث حالة الطلب بنجاح`, 'success');
    setConfirmAction(null);
  };

  const handleConfirmDecline = () => {
    if (!declineModal) return;
    if (!declineReason.trim()) {
      showToast('الرجاء كتابة سبب الرفض', 'error');
      return;
    }
    handleAction(declineModal.id, 'declined', declineReason);
    showToast('تم رفض الطلب بنجاح', 'info');
    setDeclineModal(null);
    setDeclineReason('');
  };

  const statusConfig: Record<string, { label: string; color: string; icon: typeof Clock }> = {
    pending: { label: 'قيد الانتظار', color: 'bg-amber-100 text-amber-700', icon: Clock },
    accepted_pending_admin: { label: 'بانتظار موافقة الإدارة ⏳', color: 'bg-blue-100 text-blue-700 border border-blue-200', icon: Clock },
    accepted_pending_payment: { label: 'مقبول — بانتظار سداد رسوم تأكيد الجدية ثنائياً 💳', color: 'bg-orange-100 text-orange-700', icon: CreditCard },
    accepted: { label: 'مقبول', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle2 },
    paid: { label: 'كلا الطرفين أكدا الجدية — جاهز للوساطة ✅', color: 'bg-emerald-150 text-emerald-800', icon: CheckCircle2 },
    in_mediation: { label: 'الوساطة جارية 🤝', color: 'bg-blue-100 text-blue-700', icon: Handshake },
    completed: { label: 'مكتمل 🎉', color: 'bg-emerald-700 text-white', icon: PartyPopper },
    declined: { label: 'مرفوض', color: 'bg-rose-100 text-rose-700', icon: XCircle },
    cancelled: { label: 'ملغى', color: 'bg-slate-100 text-slate-500', icon: Ban },
  };

  const handleSendMessage = () => {
    if (!adminMsgText.trim() || !activeReq) return;
    const sMember = getMemberById(activeReq.senderId);
    const rMember = getMemberById(activeReq.receiverId);
    if (!sMember || !rMember) return;

    const targets: string[] = [];
    if (messagingTarget === 'sender' || messagingTarget === 'both') targets.push(activeReq.senderId);
    if (messagingTarget === 'receiver' || messagingTarget === 'both') targets.push(activeReq.receiverId);

    targets.forEach(userId => {
      const isSender = userId === sMember.id;
      const partnerName = isSender ? rMember.nickname : sMember.nickname;
      const expectedSubject = `تنسيق اللقاء الشرعي - ${partnerName}`;
      let ticket = supportTickets.find(t => t.userId === userId && t.subject === expectedSubject);
      if (!ticket) {
        ticket = createSupportTicket(expectedSubject, 'استفسار عام', `أهلاً بك. تم إرسال ملفك للتنسيق الشرعي بناءً على قبول طلب التوافق المتبادل.`, userId);
      }
      sendSupportMessage(ticket.id, adminMsgText, 'admin');
    });

    setAdminMsgText('');
    setMessagingOpen(false);
    showToast('تم إرسال الرسالة الإدارية وتوصيلها بنجاح لصندوق الأعضاء المعنيين! 📨', 'success');
  };

  const resetFilters = () => {
    setFilter('all');
    setSearch('');
    setCityFilter('all');
    setCompatFilter('all');
    setGenderFilter('all');
    setVerifiedFilter('all');
    setPriorityFilter('all');
    setSortBy('newest');
    showToast('تم إعادة تعيين الفلاتر', 'info');
  };

  // Stats
  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending').length,
    accepted: requests.filter(r => r.status === 'accepted_pending_payment' || r.status === 'paid' || r.status === 'in_mediation' || r.status === 'completed').length,
    declined: requests.filter(r => r.status === 'declined').length,
    highPriority: Object.values(priorityMap).filter(p => p === 'high').length,
    acceptanceRate: requests.length > 0 ? Math.round((requests.filter(r => r.status === 'accepted_pending_payment' || r.status === 'paid' || r.status === 'in_mediation' || r.status === 'completed').length / requests.length) * 100) : 0,
  };

  const activeFiltersCount = [
    filter !== 'all', search !== '', cityFilter !== 'all', compatFilter !== 'all',
    genderFilter !== 'all', verifiedFilter !== 'all', priorityFilter !== 'all',
  ].filter(Boolean).length;

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h2 className="font-cairo font-extrabold text-2xl text-slate-900">وسيط التوفيق وإدارة طلبات الاهتمام</h2>
        <p className="text-sm text-slate-500 font-tajawal">متابعة طلبات الاهتمام المتبادلة بين الخاطبين، والمصالحة الشرعية بإشراف الإدارة</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'إجمالي الطلبات', value: stats.total, icon: Heart, color: 'bg-slate-100 text-slate-700' },
          { label: 'قيد الانتظار', value: stats.pending, icon: Clock, color: 'bg-amber-100 text-amber-700' },
          { label: 'مقبولة', value: stats.accepted, icon: CheckCircle2, color: 'bg-emerald-100 text-emerald-700' },
          { label: 'مرفوضة', value: stats.declined, icon: XCircle, color: 'bg-rose-100 text-rose-700' },
          { label: 'أولوية عالية', value: stats.highPriority, icon: Star, color: 'bg-red-100 text-red-700' },
          { label: 'نسبة القبول', value: `${stats.acceptanceRate}%`, icon: Percent, color: 'bg-indigo-100 text-indigo-700' },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/80 text-center">
            <div className={`w-9 h-9 rounded-xl mx-auto flex items-center justify-center mb-2 ${s.color}`}>
              <s.icon className="w-4.5 h-4.5" />
            </div>
            <div className="font-cairo font-black text-xl text-slate-950">{s.value}</div>
            <div className="text-[10px] text-slate-500 font-tajawal">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Exemption Requests Section */}
      {exemptRequests && exemptRequests.filter(ex => ex.status === 'pending').length > 0 && (
        <div className="bg-gradient-to-br from-amber-50 to-cream-50 rounded-2xl p-5 border border-amber-200 shadow-sm space-y-4 text-right animate-fade-in" dir="rtl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Star className="w-4 h-4 text-amber-600 fill-amber-500" />
            </div>
            <div>
              <h3 className="font-cairo font-black text-sm text-amber-900">طلبات التسهيل والإعفاء المالي المعلقة ⚖️</h3>
              <p className="text-[11px] text-slate-500 font-tajawal">يرجى مراجعة ظروف الأعضاء واتخاذ قرار الإعفاء (السماح بالتواصل مجاناً) أو الرفض.</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {exemptRequests.filter(ex => ex.status === 'pending').map((ex) => {
              const req = requests.find(r => r.id === ex.requestId);
              const sender = req ? getMemberById(req.senderId) : null;
              const receiver = req ? getMemberById(req.receiverId) : null;
              
              return (
                <div key={ex.id} className="bg-white p-4 rounded-xl border border-cream-200 shadow-sm space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <span className="text-xs font-cairo font-bold text-slate-950">{ex.userNickname}</span>
                      <span className="text-[10px] text-slate-400 font-tajawal block">تاريخ الطلب: {new Date(ex.createdAt).toLocaleDateString('ar-EG')}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-amber-100 text-amber-800 font-cairo font-bold">معلق</span>
                  </div>
                  
                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-600 font-tajawal leading-relaxed">
                    "{ex.reason}"
                  </div>
                  
                  {sender && receiver && (
                    <div className="text-[10px] text-slate-500 font-cairo">
                      الطلب المرتبط: <strong className="text-slate-900">{sender.nickname}</strong> ➔ <strong className="text-slate-900">{receiver.nickname}</strong>
                    </div>
                  )}
                  
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => adminProcessExemptRequest(ex.id, 'approve')}
                      className="flex-1 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-cairo font-bold transition-colors cursor-pointer"
                    >
                      قبول وإعفاء مجاني ✓
                    </button>
                    <button
                      onClick={() => adminProcessExemptRequest(ex.id, 'reject')}
                      className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-cairo font-bold transition-colors cursor-pointer"
                    >
                      رفض
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Search + Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث باسم المرسل أو المستلم أو محتوى الرسالة..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm"
          />
        </div>

        {/* الفلاتر الأساسية */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Status filter */}
          <div className="flex flex-wrap gap-1.5">
            {(['all', 'pending', 'accepted_pending_admin', 'accepted_pending_payment', 'paid', 'in_mediation', 'completed', 'declined', 'cancelled'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold transition-all ${
                  filter === f ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f === 'all' ? 'الكل' : (statusConfig[f]?.label || f)}
              </button>
            ))}
          </div>

          <div className="h-5 w-px bg-slate-200" />

          {/* City filter */}
          <select
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg text-xs font-cairo font-bold bg-slate-100 text-slate-600 border-0 focus:outline-none cursor-pointer"
          >
            <option value="all">كل المدن</option>
            {allCities.map(c => <option key={c} value={c}>{c}</option>)}
          </select>

          {/* Compat filter */}
          <select
            value={compatFilter}
            onChange={(e) => setCompatFilter(e.target.value as any)}
            className="px-3 py-1.5 rounded-lg text-xs font-cairo font-bold bg-slate-100 text-slate-600 border-0 focus:outline-none cursor-pointer"
          >
            <option value="all">كل نسب التوافق</option>
            <option value="high">توافق عالي (90%+)</option>
            <option value="medium">توافق متوسط (75-89%)</option>
            <option value="low">توافق منخفض (&lt;75%)</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortBy)}
            className="px-3 py-1.5 rounded-lg text-xs font-cairo font-bold bg-slate-100 text-slate-600 border-0 focus:outline-none cursor-pointer"
          >
            <option value="newest">الأحدث</option>
            <option value="compat">الأعلى توافقاً</option>
            <option value="priority">حسب الأولوية</option>
          </select>

          {/* Advanced filters toggle */}
          <button
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold transition-all flex items-center gap-1.5 ${
              showAdvancedFilters || activeFiltersCount > 3 ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Filter className="w-3.5 h-3.5" /> فلاتر متقدمة
            {activeFiltersCount > 0 && (
              <span className="bg-indigo-600 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center">{activeFiltersCount}</span>
            )}
          </button>

          {activeFiltersCount > 0 && (
            <button
              onClick={resetFilters}
              className="px-3 py-1.5 rounded-lg text-xs font-cairo font-bold bg-rose-50 text-rose-600 hover:bg-rose-100 transition-all flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" /> مسح الفلاتر
            </button>
          )}
        </div>

        {/* الفلاتر المتقدمة */}
        <AnimatePresence>
          {showAdvancedFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-slate-100">
                {/* Gender filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-500 font-cairo font-bold">الجنس:</span>
                  <div className="flex gap-1">
                    {([
                      { v: 'all', l: 'الكل' },
                      { v: 'male', l: 'ذكور' },
                      { v: 'female', l: 'إناث' },
                    ] as const).map(g => (
                      <button
                        key={g.v}
                        onClick={() => setGenderFilter(g.v)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold transition-all ${
                          genderFilter === g.v ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {g.l}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="h-5 w-px bg-slate-200" />

                {/* Verified filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-500 font-cairo font-bold">التوثيق:</span>
                  <div className="flex gap-1">
                    {([
                      { v: 'all', l: 'الكل' },
                      { v: 'verified', l: 'موثق' },
                      { v: 'unverified', l: 'غير موثق' },
                    ] as const).map(v => (
                      <button
                        key={v.v}
                        onClick={() => setVerifiedFilter(v.v)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold transition-all ${
                          verifiedFilter === v.v ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {v.l}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="h-5 w-px bg-slate-200" />

                {/* Priority filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-500 font-cairo font-bold">الأولوية:</span>
                  <div className="flex gap-1">
                    {([
                      { v: 'all', l: 'الكل' },
                      { v: 'high', l: 'عالية' },
                      { v: 'normal', l: 'عادية' },
                      { v: 'low', l: 'منخفضة' },
                    ] as const).map(p => (
                      <button
                        key={p.v}
                        onClick={() => setPriorityFilter(p.v)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-cairo font-bold transition-all ${
                          priorityFilter === p.v ? 'bg-red-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {p.l}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Requests list */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-slate-200/80">
            <Heart className="w-12 h-12 text-slate-200 mx-auto mb-2" />
            <p className="text-slate-500 font-tajawal">لا توجد طلبات اهتمام مطابقة لهذا الفلتر</p>
          </div>
        ) : (
          filtered.map((req) => {
            const sender = getMemberById(req.senderId);
            const receiver = getMemberById(req.receiverId);
            if (!sender || !receiver) return null;

            const compat = calculateCompat ? calculateCompat(sender, receiver) : 85;
            const sc = statusConfig[req.status] || statusConfig.pending;
            const isExpanded = expandedId === req.id;
            const prio = getPriority(req.id);
            const PrioIcon = priorityConfig[prio].icon;

            return (
              <motion.div
                key={req.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-white rounded-3xl shadow-sm border overflow-hidden ${
                  prio === 'high' ? 'border-red-200' : 'border-slate-200/60'
                }`}
              >
                {/* Priority bar + header */}
                <div className={`h-1 ${prio === 'high' ? 'bg-red-500' : prio === 'low' ? 'bg-sky-400' : 'bg-slate-200'}`} />

                <div className="p-5">
                  {/* Top row: status + priority + compare */}
                  <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold font-cairo ${sc.color}`}>
                        <sc.icon className="w-3 h-3" /> {sc.label}
                      </span>
                      <button
                        onClick={() => cyclePriority(req.id)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold font-cairo border transition-all ${priorityConfig[prio].color}`}
                      >
                        <PrioIcon className={`w-3 h-3 ${prio === 'high' ? 'fill-current' : ''}`} /> {priorityConfig[prio].label}
                      </button>
                      {/* شارات إضافية */}
                      {sender.verified && receiver.verified && (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold font-cairo bg-sky-50 text-sky-700">
                          <ShieldCheck className="w-3 h-3" /> موثقان
                        </span>
                      )}
                      
                      {/* Dual payment state indications for Admin */}
                      {req.status === 'accepted_pending_payment' && (
                        <>
                          {req.senderPaid ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold font-cairo bg-emerald-50 text-emerald-700">
                              <CreditCard className="w-3 h-3 text-emerald-600" /> تم سداد المرسل ({req.senderPaidAmount} ر.س)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold font-cairo bg-amber-50 text-amber-700 font-semibold border border-amber-100">
                              <CreditCard className="w-3 h-3 text-amber-500" /> المرسل معلّق الدفع
                            </span>
                          )}

                          {req.receiverPaid ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold font-cairo bg-emerald-50 text-emerald-700">
                              <CreditCard className="w-3 h-3 text-emerald-600" /> تم سداد المستقبل ({req.receiverPaidAmount} ر.س)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold font-cairo bg-amber-50 text-amber-700 font-semibold border border-amber-100">
                              <CreditCard className="w-3 h-3 text-amber-500" /> المستقبل معلّق الدفع
                            </span>
                          )}
                        </>
                      )}
                      {req.status === 'paid' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold font-cairo bg-emerald-600 text-white shadow-sm">
                          <CreditCard className="w-3 h-3" /> العربون مستلم من الطرفين ✓
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => setCompareModal(req)}
                      className="px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 text-xs font-cairo font-bold transition-colors flex items-center gap-1.5"
                    >
                      <Users className="w-3.5 h-3.5" /> مقارنة الطرفين
                    </button>
                  </div>

                  {/* Side by side display of matches */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 items-center gap-4 bg-slate-50/70 p-4 rounded-2xl border border-slate-100">
                    {/* Sender */}
                    <div className="lg:col-span-5 flex items-center gap-3">
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0 ${sender.gender === 'male' ? 'bg-blue-600' : 'bg-rose-500'}`}>
                        {sender.nickname.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-cairo font-bold text-slate-900 text-sm truncate">{sender.nickname}</p>
                          {sender.verified && <ShieldCheck className="w-3.5 h-3.5 text-sky-500 flex-shrink-0" />}
                          {sender.premium && <Crown className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                          <span className={`inline-flex items-center gap-0.5 text-[10px] font-bold ${sender.gender === 'male' ? 'text-blue-600' : 'text-rose-600'}`}>
                            {sender.gender === 'male' ? <Mars className="w-3 h-3" /> : <Venus className="w-3 h-3" />}
                          </span>
                          <button
                            onClick={() => {
                              const fullAdminRecord = adminMembers.find(m => m.id === sender.id);
                              if (fullAdminRecord) setSelectedMember(fullAdminRecord);
                            }}
                            className="px-2 py-0.5 rounded text-[10px] bg-sky-50 text-sky-700 hover:bg-sky-100 transition-colors font-cairo font-bold"
                          >
                            الملف الكامل
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-500 font-tajawal truncate">
                          {sender.gender === 'male' ? 'خاطب' : 'مخطوبة'} · {sender.age} سنة · {sender.city} · {sender.education}
                        </p>
                      </div>
                    </div>

                    {/* Compat + arrow */}
                    <div className="lg:col-span-2 text-center py-1.5 flex flex-col items-center justify-center border-y lg:border-y-0 lg:border-x border-slate-200/50 px-2">
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full mb-1 ${
                        compat >= 90 ? 'bg-emerald-100 text-emerald-700' : compat >= 75 ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                        التوافق {compat}%
                      </span>
                      <div className="flex items-center gap-1.5 text-slate-400">
                        <span className="text-[10px] font-bold font-cairo text-slate-500">أرسل إلى</span>
                        <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
                      </div>
                    </div>

                    {/* Receiver */}
                    <div className="lg:col-span-5 flex items-center gap-3 lg:justify-end">
                      <div className="min-w-0 lg:text-right order-2 lg:order-1">
                        <div className="flex items-center gap-2 lg:justify-end flex-wrap">
                          <p className="font-cairo font-bold text-slate-900 text-sm truncate">{receiver.nickname}</p>
                          {receiver.verified && <ShieldCheck className="w-3.5 h-3.5 text-sky-500 flex-shrink-0" />}
                          {receiver.premium && <Crown className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                          <span className={`inline-flex items-center gap-0.5 text-[10px] font-bold ${receiver.gender === 'male' ? 'text-blue-600' : 'text-rose-600'}`}>
                            {receiver.gender === 'male' ? <Mars className="w-3 h-3" /> : <Venus className="w-3 h-3" />}
                          </span>
                          <button
                            onClick={() => {
                              const fullAdminRecord = adminMembers.find(m => m.id === receiver.id);
                              if (fullAdminRecord) setSelectedMember(fullAdminRecord);
                            }}
                            className="px-2 py-0.5 rounded text-[10px] bg-sky-50 text-sky-700 hover:bg-sky-100 transition-colors font-cairo font-bold"
                          >
                            الملف الكامل
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-500 font-tajawal truncate text-right">
                          {receiver.gender === 'male' ? 'خاطب' : 'مخطوبة'} · {receiver.age} سنة · {receiver.city} · {receiver.education}
                        </p>
                      </div>
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0 order-1 lg:order-2 ${receiver.gender === 'male' ? 'bg-blue-600' : 'bg-rose-500'}`}>
                        {receiver.nickname.charAt(0)}
                      </div>
                    </div>
                  </div>

                  {/* Message */}
                  <div className="flex items-start gap-2.5 p-3.5 bg-slate-50/50 border border-slate-100 rounded-xl mt-3.5">
                    <MessageSquare className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
                    <div className="text-right">
                      <span className="block text-[10px] font-bold text-slate-400 font-cairo mb-0.5">نص رسالة الاهتمام:</span>
                      <p className="text-sm text-slate-700 font-tajawal leading-relaxed">{req.message}</p>
                    </div>
                  </div>

                   {/* Accepted coordination info */}
                  {['accepted', 'accepted_pending_payment', 'paid', 'in_mediation', 'completed'].includes(req.status) && (
                    <div className="p-3.5 bg-emerald-50/45 border border-emerald-100/80 rounded-xl mt-3 space-y-2.5 text-right">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-emerald-600" />
                          <span className="text-xs font-bold text-emerald-800 font-cairo">تنسيق التواصل والوضع المالي للطلب:</span>
                        </div>
                        {req.status === 'accepted_pending_payment' && (
                          <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-tajawal font-bold">بانتظار اكتمال السداد من الطرفين</span>
                        )}
                      </div>

                      {/* Payment info for Admin */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs border-y border-dashed border-emerald-200 py-2 my-1">
                        <div className="space-y-1">
                          <p className="text-slate-400">سداد المرسل ({sender.nickname}):</p>
                          {req.senderPaid ? (
                            <p className="text-emerald-700 font-bold font-tajawal">✓ تم دفع {req.senderPaidAmount || 500} ر.س ({req.senderPaidAt || 'مؤخراً'})</p>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <p className="text-amber-700 font-semibold font-tajawal">✗ لم يسدد حتى الآن</p>
                              <button
                                onClick={() => {
                                  adminUpdateInterestRequestDetails(req.id, {
                                    senderPaid: true,
                                    senderPaidAmount: 500,
                                    senderPaidAt: 'الآن'
                                  });
                                  if (req.receiverPaid) {
                                    adminUpdateInterestRequestStatus(req.id, 'paid');
                                  }
                                }}
                                className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-650 hover:bg-emerald-700 text-white font-cairo cursor-pointer transition-colors"
                              >
                                تسجيل سداد
                              </button>
                            </div>
                          )}
                        </div>
                        <div className="space-y-1">
                          <p className="text-slate-400">سداد المستقبل ({receiver.nickname}):</p>
                          {req.receiverPaid ? (
                            <p className="text-emerald-700 font-bold font-tajawal">✓ تم دفع {req.receiverPaidAmount || 500} ر.س ({req.receiverPaidAt || 'مؤخراً'})</p>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <p className="text-amber-700 font-semibold font-tajawal">✗ لم يسدد حتى الآن</p>
                              <button
                                onClick={() => {
                                  adminUpdateInterestRequestDetails(req.id, {
                                    receiverPaid: true,
                                    receiverPaidAmount: 500,
                                    receiverPaidAt: 'الآن'
                                  });
                                  if (req.senderPaid) {
                                    adminUpdateInterestRequestStatus(req.id, 'paid');
                                  }
                                }}
                                className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-650 hover:bg-emerald-700 text-white font-cairo cursor-pointer transition-colors"
                              >
                                تسجيل سداد
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      {req.meetingDate && <p className="text-xs text-slate-700 font-tajawal"><strong>الموعد المجدول للقاء الشرعي:</strong> {req.meetingDate}</p>}
                      {req.meetingNotes && <p className="text-xs text-slate-600 font-tajawal"><strong>إرشادات التواصل:</strong> {req.meetingNotes}</p>}
                      {req.adminNotes && <p className="text-xs text-slate-500 font-tajawal"><strong>ملاحظات داخلية للوساطة:</strong> {req.adminNotes}</p>}
                    </div>
                  )}

                  {/* Declined reason */}
                  {req.status === 'declined' && (
                    <div className="p-3.5 bg-rose-50/45 border border-rose-100 rounded-xl mt-3 space-y-1 text-right">
                      <span className="block text-xs font-bold text-rose-800 font-cairo">سبب الرفض:</span>
                      <p className="text-xs text-slate-700 font-tajawal font-semibold leading-relaxed">"{req.declineReason || 'لم يتم ذكر سبب محدد.'}"</p>
                    </div>
                  )}

                  {/* Pending Admin Approval Banner */}
                  {req.status === 'accepted_pending_admin' && (
                    <div className="p-3.5 bg-blue-50 border border-blue-100 rounded-xl mt-3 space-y-2 text-right flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 animate-pulse">
                      <div>
                        <span className="block text-xs font-bold text-blue-800 font-cairo">⏳ بانتظار موافقة الإدارة والتحقق:</span>
                        <p className="text-xs text-slate-700 font-tajawal leading-relaxed">
                          لقد وافق الطرف الآخر مبدئياً على طلب الاهتمام، ويرجى التحقق من الملفين والموافقة لبدء سداد الرسوم.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          if (confirm('هل أنت متأكد من الموافقة على هذا الطلب وتفعيل مرحلة سداد رسوم تأكيد الجدية ثنائياً؟')) {
                            adminUpdateInterestRequestStatus(req.id, 'accepted');
                          }
                        }}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-cairo font-black transition-colors shadow-sm cursor-pointer whitespace-nowrap self-end sm:self-auto"
                      >
                        الموافقة والتحقق ✓
                      </button>
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-100">
                    <span className="text-xs text-slate-400 font-tajawal">{req.time}</span>
                    <div className="flex flex-wrap gap-2">
                      {/* WhatsApp link */}
                      {(() => {
                        if (!currentAdminPermissions.view_sensitive_data) return null;
                        const adminRec = adminMembers.find(m => m.id === req.senderId);
                        const phone = adminRec?.phone?.replace(/[^0-9]/g, '') || '';
                        if (!phone) return null;
                        return (
                          <a
                            href={`https://wa.me/${phone}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 rounded-lg border border-green-200 bg-green-50 hover:bg-green-100 text-green-700 text-xs font-cairo font-bold transition-colors flex items-center gap-1.5"
                          >
                            <MessageSquare className="w-3.5 h-3.5" /> واتساب المرسل
                          </a>
                        );
                      })()}

                      {/* Send message */}
                      <button
                        onClick={() => { setActiveReq(req); setMessagingTarget('sender'); setMessagingOpen(true); }}
                        className="px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-cairo font-bold transition-colors flex items-center gap-1.5"
                      >
                        <Send className="w-3.5 h-3.5" /> رسالة مباشرة
                      </button>

                      {/* Coordination toggle */}
                      <button
                        onClick={() => {
                          if (isExpanded) { setExpandedId(null); }
                          else {
                            setExpandedId(req.id);
                            setNotes(req.adminNotes || '');
                            setMeetingDate(req.meetingDate || '');
                            setMeetingNotes(req.meetingNotes || '');
                            setPaymentStatus(req.paymentStatus || 'waiting_for_payment');
                          }
                        }}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-cairo font-bold transition-colors flex items-center gap-1.5 ${
                          isExpanded ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                        {isExpanded ? 'إغلاق' : 'تنسيق ومتابعة'}
                      </button>

                      {/* Status actions */}
                      <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 p-1 rounded-xl">
                        <button
                          onClick={() => setConfirmAction({ id: req.id, action: 'accepted' })}
                          className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold transition-all ${
                            ['accepted', 'accepted_pending_payment', 'paid', 'in_mediation', 'completed'].includes(req.status) ? 'bg-emerald-600 text-white shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          قبول
                        </button>
                        <button
                          onClick={() => setDeclineModal({ id: req.id })}
                          className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold transition-all ${
                            req.status === 'declined' ? 'bg-rose-600 text-white shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          رفض
                        </button>
                        <button
                          onClick={() => setConfirmAction({ id: req.id, action: 'pending' })}
                          className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold transition-all ${
                            req.status === 'pending' ? 'bg-amber-500 text-white shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          تعليق
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Coordination Panel */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="mt-4 p-4 border-t border-slate-200 bg-slate-50 rounded-2xl space-y-4">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-amber-500" />
                            <h4 className="font-cairo font-extrabold text-sm text-slate-800">لوحة التنسيق والمتابعة</h4>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1 text-right">
                              <label className="block text-xs font-bold text-slate-700 font-cairo">ملاحظات سرية (داخلية):</label>
                              <textarea
                                value={notes}
                                onChange={(e) => setNotes(e.target.value)}
                                placeholder="اكتب تفاصيل الاتصال التلفوني ومواقف الأهل..."
                                className="w-full text-xs font-tajawal p-3 rounded-xl border border-slate-200 focus:ring-1 focus:ring-slate-900 bg-white text-right"
                                rows={3.5}
                              />
                            </div>
                            <div className="space-y-3 text-right">
                              <div>
                                <label className="block text-xs font-bold text-slate-700 font-cairo mb-1">موعد التواصل الشرعي:</label>
                                <input
                                  type="text"
                                  value={meetingDate}
                                  onChange={(e) => setMeetingDate(e.target.value)}
                                  placeholder="مثال: الخميس المقبل الساعة 8:30 م"
                                  className="w-full text-xs font-tajawal p-2 rounded-xl border border-slate-200 focus:ring-1 focus:ring-slate-900 bg-white text-right"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-bold text-slate-700 font-cairo mb-1">إرشادات اللقاء:</label>
                                <input
                                  type="text"
                                  value={meetingNotes}
                                  onChange={(e) => setMeetingNotes(e.target.value)}
                                  placeholder="مثال: مكالمة بإشراف د. منى السالم"
                                  className="w-full text-xs font-tajawal p-2 rounded-xl border border-slate-200 focus:ring-1 focus:ring-slate-900 bg-white text-right"
                                />
                              </div>
                              {/* حالة الدفع */}
                              <div>
                                <label className="block text-xs font-bold text-slate-700 font-cairo mb-1">حالة العربون (500 ريال):</label>
                                <div className="flex gap-2">
                                  <button
                                    onClick={() => setPaymentStatus('waiting_for_payment')}
                                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-cairo font-bold transition-all ${
                                      paymentStatus === 'waiting_for_payment' ? 'bg-amber-500 text-white' : 'bg-white text-slate-600 border border-slate-200'
                                    }`}
                                  >
                                    بانتظار الدفع
                                  </button>
                                  <button
                                    onClick={() => setPaymentStatus('paid')}
                                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-cairo font-bold transition-all ${
                                      paymentStatus === 'paid' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600 border border-slate-200'
                                    }`}
                                  >
                                    تم الدفع ✓
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Cancel & Refund Actions for Admin */}
                          {['accepted_pending_payment', 'paid', 'in_mediation'].includes(req.status) && (
                            <div className="p-3 bg-red-50/50 border border-red-100 rounded-xl space-y-2 text-right">
                              <span className="block text-[10px] font-bold text-red-800 font-cairo">إجراءات الإلغاء والاسترداد المالي (للإدارة):</span>
                              <div className="flex flex-wrap gap-2">
                                <button
                                  onClick={() => {
                                    if (confirm('هل أنت متأكد من إلغاء هذا الطلب وإرجاع كامل المبلغ (100%) لمحفظة الأعضاء؟')) {
                                      adminCancelAndRefund(req.id, 'full');
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-cairo font-bold transition-colors shadow-sm cursor-pointer"
                                >
                                  🔴 إلغاء يدوي + استرداد كامل (100%)
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm('هل أنت متأكد من إنهاء الوساطة وإرجاع نصف الرسوم (50%) لمحفظة الأعضاء؟')) {
                                      adminCancelAndRefund(req.id, 'partial');
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-cairo font-bold transition-colors shadow-sm cursor-pointer"
                                >
                                  🟡 إنهاء الوساطة + استرداد جزئي (50%)
                                </button>
                              </div>
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2 justify-between items-center pt-2 border-t border-slate-200/50">
                            <button
                              onClick={() => {
                                const msg = `السلام عليكم ورحمة الله، نبشركم بوجود توافق بنسبة ${compat}% بين ${sender.nickname} و${receiver.nickname}. يسعدنا التقريب والتنسيق المباشر.`;
                                navigator.clipboard.writeText(msg);
                                showToast('تم نسخ رسالة التوفيق!', 'success');
                              }}
                              className="px-3.5 py-2 rounded-xl bg-amber-500/10 text-amber-700 text-xs font-cairo font-bold hover:bg-amber-500/20 transition-all flex items-center gap-1.5"
                            >
                              ✍️ نسخ رسالة التوفيق
                            </button>
                            <button
                              onClick={() => {
                                adminUpdateInterestRequestDetails(req.id, {
                                  adminNotes: notes,
                                  meetingDate,
                                  meetingNotes,
                                  paymentStatus,
                                });
                                showToast('تم حفظ التنسيق بنجاح ✓', 'success');
                              }}
                              className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-cairo font-bold hover:bg-slate-800 transition-colors shadow-sm"
                            >
                              حفظ التنسيق ✓
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Member details modal */}
      <Modal open={!!selectedMember} onClose={() => setSelectedMember(null)} title="تفاصيل وبيانات العضو الحساسة" size="lg">
        {selectedMember && <MemberDetailsView member={selectedMember} currentAdminPermissions={currentAdminPermissions} />}
      </Modal>

      {/* Messaging modal */}
      <Modal open={messagingOpen} onClose={() => setMessagingOpen(false)} title="إرسال رسالة رسمية للشركاء">
        {activeReq && (
          <div className="space-y-4 font-cairo text-right" dir="rtl">
            <p className="text-xs text-slate-500 leading-relaxed">
              يمكنك كمدير إرسال توجيه بخصوص طلب التوافق. ستصل الرسالة مباشرة للأعضاء المحددين.
            </p>
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">تحديد المستلم:</label>
              <div className="grid grid-cols-3 gap-2">
                {(['sender', 'receiver', 'both'] as const).map(t => {
                  const name = t === 'sender' ? getMemberById(activeReq.senderId)?.nickname :
                               t === 'receiver' ? getMemberById(activeReq.receiverId)?.nickname : 'كلاهما';
                  return (
                    <button
                      key={t}
                      onClick={() => setMessagingTarget(t)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold text-center border transition-all ${
                        messagingTarget === t ? 'bg-indigo-900 text-white border-indigo-900' : 'bg-white text-slate-700 border-slate-200'
                      }`}
                    >
                      {t === 'sender' ? 'المرسل' : t === 'receiver' ? 'المستلم' : 'كلاهما'} ({name})
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">محتوى الرسالة:</label>
              <textarea
                value={adminMsgText}
                onChange={(e) => setAdminMsgText(e.target.value)}
                placeholder="اكتب التوجيه أو رسالة التنسيق الشرعي..."
                rows={4}
                className="w-full text-xs font-tajawal p-3 rounded-xl border border-slate-200 bg-white text-right focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!adminMsgText.trim()}
              className="w-full py-3 rounded-xl bg-slate-900 text-white font-bold text-sm disabled:opacity-50 hover:bg-slate-800 transition-colors"
            >
              إرسال وتوصيل الرسالة 🚀
            </button>
          </div>
        )}
      </Modal>

      {/* Decline reason modal */}
      <Modal open={!!declineModal} onClose={() => { setDeclineModal(null); setDeclineReason(''); }} title="سبب رفض الطلب">
        <div className="space-y-4 text-right" dir="rtl">
          <p className="text-xs text-slate-500 font-tajawal">اكتب سبب الرفض الذي سيظهر للطرف الآخر:</p>
          <textarea
            value={declineReason}
            onChange={(e) => setDeclineReason(e.target.value)}
            placeholder="مثال: المواصفات غير متوافقة، المسافة بين المدن كبيرة..."
            rows={4}
            className="w-full text-sm font-tajawal p-3 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-rose-400"
            autoFocus
          />
          <div className="flex gap-2">
            <button
              onClick={handleConfirmDecline}
              className="flex-1 py-3 rounded-xl bg-rose-600 text-white font-cairo font-bold text-sm hover:bg-rose-700 transition-colors"
            >
              تأكيد الرفض
            </button>
            <button
              onClick={() => { setDeclineModal(null); setDeclineReason(''); }}
              className="px-6 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
            >
              إلغاء
            </button>
          </div>
        </div>
      </Modal>

      {/* Confirm action modal */}
      <Modal open={!!confirmAction} onClose={() => setConfirmAction(null)} title="تأكيد الإجراء">
        <div className="space-y-4 text-right" dir="rtl">
          <p className="text-sm text-slate-700 font-tajawal">
            هل أنت متأكد من {confirmAction?.action === 'accepted' ? 'قبول' : 'تعليق'} هذا الطلب؟
          </p>
          <div className="flex gap-2">
            <button
              onClick={handleConfirmAction}
              className={`flex-1 py-3 rounded-xl text-white font-cairo font-bold text-sm transition-colors ${
                confirmAction?.action === 'accepted' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-500 hover:bg-amber-600'
              }`}
            >
              تأكيد
            </button>
            <button
              onClick={() => setConfirmAction(null)}
              className="px-6 py-3 rounded-xl bg-slate-100 text-slate-600 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
            >
              إلغاء
            </button>
          </div>
        </div>
      </Modal>

      {/* Compare modal — محسّن بعرض جميع الحقول */}
      <Modal open={!!compareModal} onClose={() => setCompareModal(null)} title="مقارنة الطرفين جنباً إلى جنب" size="lg">
        {compareModal && (() => {
          const s = getMemberById(compareModal.senderId);
          const r = getMemberById(compareModal.receiverId);
          if (!s || !r) return null;
          const compat = calculateCompat ? calculateCompat(s, r) : 85;
          const rows = [
            { label: 'الاسم المستعار', s: s.nickname, r: r.nickname },
            { label: 'الجنس', s: s.gender === 'male' ? 'ذكر' : 'أنثى', r: r.gender === 'male' ? 'ذكر' : 'أنثى' },
            { label: 'العمر', s: `${s.age} سنة`, r: `${r.age} سنة` },
            { label: 'الدولة', s: s.country, r: r.country },
            { label: 'المدينة', s: s.city, r: r.city },
            { label: 'الحي', s: s.district || 'غير محدد', r: r.district || 'غير محدد' },
            { label: 'الجنسية', s: s.nationality, r: r.nationality },
            { label: 'المذهب', s: s.sect, r: r.sect },
            { label: 'الحالة الاجتماعية', s: s.maritalLabel, r: r.maritalLabel },
            { label: 'الأبناء', s: s.hasChildren ? s.childrenCount : 'لا', r: r.hasChildren ? r.childrenCount : 'لا' },
            { label: 'الطول', s: `${s.height} سم`, r: `${r.height} سم` },
            { label: 'الوزن', s: `${s.weight} كجم`, r: `${r.weight} كجم` },
            { label: 'لون البشرة', s: s.skinColor, r: r.skinColor },
            { label: 'العرق', s: s.ethnicity || 'غير محدد', r: r.ethnicity || 'غير محدد' },
            { label: 'الحالة الصحية', s: s.health, r: r.health },
            { label: 'التدخين', s: s.smoking, r: r.smoking },
            { label: 'المؤهل', s: s.education, r: r.education },
            { label: 'نوع العمل', s: s.workType, r: r.workType },
            { label: 'السكن', s: s.housing, r: r.housing },
          ];
          return (
            <div className="space-y-4 text-right" dir="rtl">
              <div className="text-center bg-slate-50 rounded-2xl p-4">
                <p className="text-xs text-slate-500 font-tajawal mb-1">نسبة التوافق بين الطرفين</p>
                <p className={`font-cairo font-black text-3xl ${compat >= 90 ? 'text-emerald-600' : compat >= 75 ? 'text-amber-600' : 'text-rose-600'}`}>{compat}%</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-slate-200">
                      <th className="py-2 px-2 text-right font-cairo font-bold text-slate-500">الوجه</th>
                      <th className="py-2 px-2 text-center font-cairo font-bold text-blue-700">{s.nickname}</th>
                      <th className="py-2 px-2 text-center font-cairo font-bold text-rose-700">{r.nickname}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, i) => (
                      <tr key={i} className="border-b border-slate-100">
                        <td className="py-2 px-2 text-slate-500 font-tajawal">{row.label}</td>
                        <td className="py-2 px-2 text-center font-cairo font-semibold text-slate-800">{row.s}</td>
                        <td className="py-2 px-2 text-center font-cairo font-semibold text-slate-800">{row.r}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="space-y-2">
                <div className="bg-slate-50 rounded-xl p-3">
                  <h4 className="font-cairo font-bold text-slate-900 text-xs mb-1">نبذة {s.nickname}:</h4>
                  <p className="text-xs text-slate-600 font-tajawal">{s.bio || 'لم يكتب نبذة.'}</p>
                </div>
                <div className="bg-slate-50 rounded-xl p-3">
                  <h4 className="font-cairo font-bold text-slate-900 text-xs mb-1">نبذة {r.nickname}:</h4>
                  <p className="text-xs text-slate-600 font-tajawal">{r.bio || 'لم يكتب نبذة.'}</p>
                </div>
                <div className="bg-amber-50 rounded-xl p-3">
                  <h4 className="font-cairo font-bold text-amber-900 text-xs mb-1">مواصفات الشريك التي يطلبها {s.nickname}:</h4>
                  <p className="text-xs text-slate-700 font-tajawal">{s.aboutPartner || 'لم يحدد.'}</p>
                </div>
                <div className="bg-amber-50 rounded-xl p-3">
                  <h4 className="font-cairo font-bold text-amber-900 text-xs mb-1">مواصفات الشريك التي يطلبها {r.nickname}:</h4>
                  <p className="text-xs text-slate-700 font-tajawal">{r.aboutPartner || 'لم يحدد.'}</p>
                </div>
              </div>
            </div>
          );
        })()}
      </Modal>
    </div>
  );
}

// Compact Member details view
function MemberDetailsView({ member, currentAdminPermissions }: { member: AdminMember, currentAdminPermissions: any }) {
  const [showPassword, setShowPassword] = useState(false);

  const sections = [
    {
      title: 'بيانات الحساب الحساسة', icon: Lock, color: 'text-rose-600 bg-rose-50',
      fields: [
        { label: 'الاسم الحقيقي', value: currentAdminPermissions.view_sensitive_data ? (member.realName || '—') : '*** مخفي ***', icon: null },
        { label: 'البريد الإلكتروني', value: currentAdminPermissions.view_sensitive_data ? member.email : '*** مخفي ***', icon: Mail },
        { label: 'رقم الجوال', value: currentAdminPermissions.view_sensitive_data ? (member.phone || '—') : '*** مخفي ***', icon: Phone },
        { label: 'كلمة المرور', value: currentAdminPermissions.view_sensitive_data ? (showPassword ? member.password : '••••••••') : '***', icon: Lock, action: currentAdminPermissions.view_sensitive_data ? () => setShowPassword(!showPassword) : undefined, actionLabel: currentAdminPermissions.view_sensitive_data ? (showPassword ? 'إخفاء' : 'إظهار') : undefined },
      ],
    },
    {
      title: 'المعلومات الأساسية', icon: MapPin, color: 'text-blue-600 bg-blue-50',
      fields: [
        { label: 'الاسم المستعار', value: member.nickname, icon: null },
        { label: 'الجنس', value: member.gender === 'male' ? 'ذكر' : 'أنثى', icon: null },
        { label: 'العمر', value: `${member.age} سنة`, icon: null },
        { label: 'الدولة', value: member.country, icon: null },
        { label: 'المدينة', value: member.city, icon: null },
        { label: 'الحي', value: member.district || 'غير محدد', icon: null },
        { label: 'الجنسية', value: member.nationality, icon: null },
        { label: 'المذهب', value: member.sect, icon: null },
      ],
    },
    {
      title: 'الصفات الشخصية', icon: ShieldCheck, color: 'text-emerald-600 bg-emerald-50',
      fields: [
        { label: 'الطول', value: `${member.height} سم`, icon: null },
        { label: 'الوزن', value: `${member.weight} كجم`, icon: null },
        { label: 'لون البشرة', value: member.skinColor, icon: null },
        { label: 'العرق', value: member.ethnicity || 'غير محدد', icon: null },
        { label: 'الحالة الصحية', value: member.health, icon: null },
        { label: 'التدخين', value: member.smoking, icon: null },
      ],
    },
    {
      title: 'الحالة الاجتماعية', icon: Heart, color: 'text-rose-600 bg-rose-50',
      fields: [
        { label: 'الحالة', value: member.maritalLabel, icon: null },
        { label: 'الأبناء', value: member.hasChildren ? member.childrenCount : 'لا يوجد', icon: null },
      ],
    },
    {
      title: 'العمل والمؤهل', icon: Crown, color: 'text-amber-600 bg-amber-50',
      fields: [
        { label: 'المؤهل', value: member.education, icon: null },
        { label: 'العمل', value: member.workType, icon: null },
        { label: 'السكن', value: member.housing, icon: null },
      ],
    },
  ];

  return (
    <div className="space-y-4 max-h-[80vh] overflow-y-auto p-1 text-right" dir="rtl">
      <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white font-bold text-xl ${member.gender === 'male' ? 'bg-blue-600' : 'bg-rose-500'}`}>
          {member.nickname.charAt(0)}
        </div>
        <div className="flex-1">
          <h3 className="font-cairo font-bold text-base text-slate-900 flex items-center gap-1.5">
            {member.nickname}
            {member.verified && <ShieldCheck className="w-5 h-5 text-sky-500" />}
            {member.premium && <Crown className="w-4 h-4 text-amber-500" />}
          </h3>
          <p className="text-xs text-slate-500 font-tajawal">{member.realName}</p>
        </div>
      </div>
      {sections.map((section) => {
        const SectionIcon = section.icon;
        return (
          <div key={section.title} className="space-y-2">
            <div className="flex items-center gap-2">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${section.color}`}>
                <SectionIcon className="w-4 h-4" />
              </div>
              <h4 className="font-cairo font-bold text-slate-950 text-xs">{section.title}</h4>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {section.fields.map((field: any) => {
                const FieldIcon = field.icon;
                return (
                  <div key={field.label} className="flex items-center justify-between gap-1.5 px-3 py-2 bg-slate-50 rounded-xl">
                    <span className="text-[10px] text-slate-500 font-tajawal">{field.label}</span>
                    <div className="flex items-center gap-1.5">
                      {FieldIcon && <FieldIcon className="w-3.5 h-3.5 text-slate-400" />}
                      <span className="text-xs font-cairo font-bold text-slate-900 truncate max-w-[120px]">{field.value}</span>
                      {field.action && (
                        <button onClick={field.action} className="text-[9px] text-amber-600 font-cairo font-black hover:underline">{field.actionLabel}</button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
      <div className="space-y-2 pt-2">
        <div className="bg-slate-50 rounded-xl p-3">
          <h4 className="font-cairo font-bold text-slate-900 text-xs mb-1">نبذة:</h4>
          <p className="text-xs text-slate-600 font-tajawal leading-relaxed">{member.bio || 'لم يكتب نبذة.'}</p>
        </div>
        <div className="bg-amber-50 rounded-xl p-3">
          <h4 className="font-cairo font-bold text-amber-900 text-xs mb-1">مواصفات الشريك المطلوب:</h4>
          <p className="text-xs text-slate-700 font-tajawal leading-relaxed">{member.aboutPartner || 'لم يحدد.'}</p>
        </div>
      </div>
    </div>
  );
}
