import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Users, UserPlus, Heart, DollarSign, ShieldCheck, Ticket,
  TrendingUp, TrendingDown, Bell, ShieldAlert, MessageSquare,
  Plus, Send, FileText, Eye,
} from 'lucide-react';
import { DASHBOARD_STATS, RECENT_ACTIVITY } from '../../lib/admin-data';
import { useApp } from '../../lib/AppContext';

const iconMap: Record<string, typeof Users> = {
  users: Users, 'user-plus': UserPlus, heart: Heart, dollar: DollarSign, shield: ShieldCheck, ticket: Ticket,
};

export default function AdminDashboard() {
  const { interestRequests, reports, supportTickets, adminMembers } = useApp();

  const pendingRequests = interestRequests.filter(r => r.status === 'pending').length;
  const pendingReports = reports.filter(r => r.status === 'pending').length;
  const openTickets = supportTickets.filter(t => t.status === 'open' || t.status === 'in_progress').length;
  const pendingMembers = adminMembers.filter(m => m.status === 'pending').length;

  // المهام المعلّقة
  const pendingTasks = [
    { label: 'طلبات اهتمام معلّقة', value: pendingRequests, to: '/admin/requests', icon: Heart, color: 'text-rose-600 bg-rose-50' },
    { label: 'بلاغات قيد المراجعة', value: pendingReports, to: '/admin/reports', icon: ShieldAlert, color: 'text-red-600 bg-red-50' },
    { label: 'تذاكر دعم مفتوحة', value: openTickets, to: '/admin/messages', icon: MessageSquare, color: 'text-amber-600 bg-amber-50' },
    { label: 'أعضاء قيد المراجعة', value: pendingMembers, to: '/admin/members', icon: UserPlus, color: 'text-sky-600 bg-sky-50' },
  ];

  // إجراءات سريعة
  const quickActions = [
    { label: 'إرسال إشعار', desc: 'إشعار جماعي للأعضاء', to: '/admin/notifications', icon: Send, color: 'bg-amber-500' },
    { label: 'تدوينة جديدة', desc: 'اكتب مقالاً جديداً', to: '/admin/blog', icon: FileText, color: 'bg-blue-500' },
    { label: 'إدارة الباقات', desc: 'تعديل الأسعار والميزات', to: '/admin/plans', icon: DollarSign, color: 'bg-emerald-500' },
    { label: 'إعدادات الموقع', desc: 'تخصيص هوية المنصة', to: '/admin/site', icon: ShieldCheck, color: 'bg-purple-500' },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-l from-slate-900 to-slate-800 rounded-2xl p-6 sm:p-8 relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl" />
        <div className="relative">
          <h2 className="font-cairo font-extrabold text-2xl text-white">مرحبًا بك في لوحة التحكم 👋</h2>
          <p className="text-slate-400 font-tajawal mt-1">نظرة عامة على أداء منصة توافق اليوم</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <span className="px-3 py-1.5 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-cairo font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> المنصة تعمل
            </span>
            <span className="px-3 py-1.5 rounded-full bg-amber-500/15 text-amber-400 text-xs font-cairo font-bold">+154K عضو</span>
          </div>
        </div>
      </motion.div>

      {/* Pending Tasks Summary */}
      <div>
        <h3 className="font-cairo font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-500" /> مهام معلّقة
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {pendingTasks.map((task, i) => {
            const Icon = task.icon;
            return (
              <motion.div
                key={task.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  to={task.to}
                  className="block bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${task.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className={`font-cairo font-extrabold text-2xl ${task.value > 0 ? 'text-slate-900' : 'text-slate-300'}`}>
                        {task.value}
                      </div>
                      <div className="text-[11px] text-slate-500 font-tajawal truncate">{task.label}</div>
                    </div>
                  </div>
                  {task.value > 0 && (
                    <div className="mt-2 text-[10px] text-amber-600 font-cairo font-bold flex items-center gap-1 group-hover:gap-2 transition-all">
                      <Eye className="w-3 h-3" /> مراجعة الآن
                    </div>
                  )}
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="font-cairo font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Plus className="w-5 h-5 text-amber-500" /> إجراءات سريعة
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {quickActions.map((action, i) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={action.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  to={action.to}
                  className="block bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 transition-all group"
                >
                  <div className={`w-10 h-10 rounded-xl ${action.color} flex items-center justify-center mb-2`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <h4 className="font-cairo font-bold text-slate-900 text-sm">{action.label}</h4>
                  <p className="text-[11px] text-slate-400 font-tajawal">{action.desc}</p>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Stats grid */}
      <div>
        <h3 className="font-cairo font-bold text-slate-900 mb-3">الإحصائيات العامة</h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {DASHBOARD_STATS.map((stat, i) => {
            const Icon = iconMap[stat.icon] || Users;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-11 h-11 rounded-xl bg-slate-100 flex items-center justify-center">
                    <Icon className="w-5.5 h-5.5 text-slate-700" />
                  </div>
                  <span className={`flex items-center gap-0.5 text-xs font-bold ${stat.trend === 'up' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {stat.trend === 'up' ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    {stat.change}
                  </span>
                </div>
                <div className="font-cairo font-extrabold text-2xl text-slate-900">{stat.value}</div>
                <div className="text-sm text-slate-500 font-tajawal mt-0.5">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Recent activity */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-cairo font-bold text-slate-900">آخر النشاطات</h3>
          <span className="text-xs text-slate-400 font-tajawal">آخر تحديث: الآن</span>
        </div>
        <div className="divide-y divide-slate-50">
          {RECENT_ACTIVITY.map((activity, i) => {
            const Icon = iconMap[activity.icon] || Users;
            const colors: Record<string, string> = {
              member: 'bg-blue-50 text-blue-600', request: 'bg-rose-50 text-rose-600',
              payment: 'bg-emerald-50 text-emerald-600', verification: 'bg-amber-50 text-amber-600',
              ticket: 'bg-purple-50 text-purple-600',
            };
            return (
              <div key={i} className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50 transition-colors">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${colors[activity.type]}`}>
                  <Icon className="w-4.5 h-4.5" />
                </div>
                <p className="flex-1 text-sm text-slate-700 font-tajawal">{activity.text}</p>
                <span className="text-xs text-slate-400 font-tajawal whitespace-nowrap">{activity.time}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
