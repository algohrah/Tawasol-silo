import {
  Clock, CreditCard, CheckCircle2, Handshake, PartyPopper,
  XCircle, Ban, type LucideIcon,
} from 'lucide-react';
import type { RequestStatus, MediationStage, InterestRequest } from '../lib/data';

// ===== إعدادات الحالات =====
export const STATUS_CONFIG: Record<RequestStatus | 'accepted', {
  label: string;
  shortLabel: string;
  color: string;
  badgeBg: string;
  icon: LucideIcon;
}> = {
  pending: {
    label: 'قيد الانتظار',
    shortLabel: 'معلّق',
    color: 'text-gold-600',
    badgeBg: 'bg-gold-300/15 text-gold-700',
    icon: Clock,
  },
  accepted_pending_admin: {
    label: 'مقبول — بانتظار موافقة الإدارة والتحقق ⏳',
    shortLabel: 'بانتظار الإدارة',
    color: 'text-blue-500',
    badgeBg: 'bg-blue-50 text-blue-700 border border-blue-100',
    icon: Clock,
  },
  accepted: {
    label: 'مقبول — بانتظار سداد العربون',
    shortLabel: 'بانتظار الدفع',
    color: 'text-orange-600',
    badgeBg: 'bg-orange-100 text-orange-700',
    icon: CreditCard,
  },
  accepted_pending_payment: {
    label: 'تمت الموافقة — بانتظار سداد رسوم تأكيد الجدية ثنائياً',
    shortLabel: 'بانتظار الدفع',
    color: 'text-orange-600',
    badgeBg: 'bg-orange-100 text-orange-700',
    icon: CreditCard,
  },
  paid: {
    label: 'كلا الطرفين أكدا الجدية — جاهز للوساطة',
    shortLabel: 'أكدا الجدية',
    color: 'text-emerald-600',
    badgeBg: 'bg-emerald-100 text-emerald-700',
    icon: CheckCircle2,
  },
  in_mediation: {
    label: 'الوساطة جارية',
    shortLabel: 'في الوساطة',
    color: 'text-blue-600',
    badgeBg: 'bg-blue-100 text-blue-700',
    icon: Handshake,
  },
  completed: {
    label: 'مكتمل',
    shortLabel: 'مكتمل',
    color: 'text-emerald-700',
    badgeBg: 'bg-emerald-700 text-white',
    icon: PartyPopper,
  },
  declined: {
    label: 'مرفوض',
    shortLabel: 'مرفوض',
    color: 'text-rose-600',
    badgeBg: 'bg-rose-100 text-rose-700',
    icon: XCircle,
  },
  cancelled: {
    label: 'ملغى',
    shortLabel: 'ملغى',
    color: 'text-slate-500',
    badgeBg: 'bg-slate-100 text-slate-500',
    icon: Ban,
  },
};

// ===== مراحل الوساطة =====
export const MEDIATION_STAGES: { stage: MediationStage; label: string; desc: string }[] = [
  { stage: 'scheduling', label: 'تنسيق موعد', desc: 'الإدارة تنسّق موعد اللقاء أو الاتصال' },
  { stage: 'confirming', label: 'تأكيد الموعد', desc: 'تم تأكيد الموعد مع الطرفين' },
  { stage: 'exchanging', label: 'تبادل الأرقام', desc: 'إرسال أرقام التواصل للطرفين' },
  { stage: 'evaluating', label: 'تقييم النتيجة', desc: 'تقييم التجربة بعد اللقاء' },
];

// ===== ترتيب المراحل للـ Stepper =====
const STEPPER_STEPS: { status: RequestStatus; label: string }[] = [
  { status: 'pending', label: 'مرسل' },
  { status: 'accepted_pending_payment', label: 'بانتظار الدفع' },
  { status: 'paid', label: 'أكدا الجدية' },
  { status: 'in_mediation', label: 'وساطة' },
  { status: 'completed', label: 'مكتمل' },
];

const STATUS_ORDER: Record<RequestStatus | 'accepted', number> = {
  pending: 0,
  accepted_pending_admin: 1,
  accepted_pending_payment: 1,
  accepted: 1,
  paid: 2,
  in_mediation: 3,
  completed: 4,
  declined: -1,
  cancelled: -1,
};

// ===== مكوّن Stepper بصري =====
export function RequestStepper({ status }: { status: RequestStatus | 'accepted' }) {
  if (status === 'declined' || status === 'cancelled') return null;

  const currentStep = STATUS_ORDER[status];

  return (
    <div className="flex items-center gap-1 my-3" dir="rtl">
      {STEPPER_STEPS.map((step, idx) => {
        const isDone = idx < currentStep;
        const isCurrent = idx === currentStep;
        const isFuture = idx > currentStep;

        return (
          <div key={step.status} className="flex items-center flex-1 last:flex-none">
            {/* الدائرة */}
            <div className="flex flex-col items-center gap-1 flex-shrink-0">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                  isDone
                    ? 'bg-emerald-500 text-white'
                    : isCurrent
                    ? 'bg-gold-gradient text-navy-900 ring-4 ring-gold-300/20'
                    : 'bg-cream-100 text-navy-300'
                }`}
              >
                {isDone ? '✓' : idx + 1}
              </div>
              <span
                className={`text-[9px] font-cairo font-bold whitespace-nowrap ${
                  isDone || isCurrent ? 'text-navy-700' : 'text-navy-300'
                }`}
              >
                {step.label}
              </span>
            </div>
            {/* الخط الواصل */}
            {idx < STEPPER_STEPS.length - 1 && (
              <div
                className={`h-0.5 flex-1 mx-1 rounded-full transition-all ${
                  isDone ? 'bg-emerald-400' : isFuture ? 'bg-cream-200' : 'bg-gold-300'
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ===== مكوّن Stepper لمراحل الوساطة =====
export function MediationStepper({ stage }: { stage?: MediationStage }) {
  if (!stage) return null;

  const currentIdx = MEDIATION_STAGES.findIndex(s => s.stage === stage);

  return (
    <div className="bg-blue-50/50 rounded-2xl p-3 my-3 border border-blue-100">
      <p className="text-[10px] font-cairo font-bold text-blue-800 mb-2">مراحل الوساطة والتنسيق</p>
      <div className="flex items-center gap-1" dir="rtl">
        {MEDIATION_STAGES.map((s, idx) => {
          const isDone = idx < currentIdx;
          const isCurrent = idx === currentIdx;
          return (
            <div key={s.stage} className="flex items-center flex-1 last:flex-none">
              <div className="flex flex-col items-center gap-0.5 flex-shrink-0">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold transition-all ${
                    isDone
                      ? 'bg-blue-500 text-white'
                      : isCurrent
                      ? 'bg-blue-600 text-white ring-2 ring-blue-200'
                      : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  {isDone ? '✓' : idx + 1}
                </div>
                <span
                  className={`text-[8px] font-cairo font-bold whitespace-nowrap ${
                    isDone || isCurrent ? 'text-blue-800' : 'text-slate-400'
                  }`}
                >
                  {s.label}
                </span>
              </div>
              {idx < MEDIATION_STAGES.length - 1 && (
                <div
                  className={`h-0.5 flex-1 mx-1 rounded-full ${
                    isDone ? 'bg-blue-400' : 'bg-slate-200'
                  }`}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ===== أسباب الرفض الجاهزة =====
export const DECLINE_REASONS = [
  'عدم توافق في المواصفات الأساسية المطلوبة.',
  'الفارق في العمر كبير جداً.',
  'الحالة الاجتماعية غير مناسبة.',
  'عدم توافق في الأهداف وتطلعات شريك الحياة.',
  'المسافة الجغرافية بين المدن كبيرة.',
  'سبب آخر (اكتب التفاصيل).',
];
