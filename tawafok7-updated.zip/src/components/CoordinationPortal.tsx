/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/set-state-in-effect */
/* eslint-disable react-hooks/purity */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, CheckCircle2, MessageSquare, CreditCard, Sparkles,
  Handshake, ShieldCheck, Send, UserCheck, Star, ThumbsUp, ThumbsDown,
  ArrowRight, Info, HelpCircle, Phone, Heart, Users, Receipt, Award, Lock, Check, Ban,
  Clock, Calendar
} from 'lucide-react';

interface CoordinationPortalProps {
  open: boolean;
  onClose: () => void;
  requestId: string;
  requests: any[];
  members: any[];
  user: any;
  updateDetails: (id: string, fields: any) => void;
  handleAction: (id: string, status: any, declineReason?: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const PRESET_MESSAGES = [
  "ما هي خطتك للسكن بعد الزواج؟ (مستقل، مع الأهل، في أي مدينة؟)",
  "هل تؤيد/تؤيدين عمل الزوجة بعد الزواج؟",
  "هل تعاني من أي أمراض مزمنة أو وراثية؟",
  "ما هي نظرتك لتوزيع المسؤوليات المالية في المنزل؟",
  "هل ترغب/ترغبين في الإنجاب مبكراً أم تفضل/تفضلين التأجيل؟",
  "ما هي الصفات التي لا يمكنك التنازل عنها في شريك الحياة؟",
];

const STAGE4_QUICK_REPLIES = [
  "السلام عليكم ورحمة الله وبركاته",
  "موافق على الموعد المقترح",
  "أحتاج وقتاً للتفكير والاستخارة",
  "شكراً لكم على جهودكم الطيبة"
];

export default function CoordinationPortal({
  open,
  onClose,
  requestId,
  requests,
  members,
  user,
  updateDetails,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  handleAction,
  showToast,
}: CoordinationPortalProps) {
  // FIND THE REQUEST
  const req = requests.find((r: any) => r.id === requestId);
  if (!req) return null;

  // READ AND ASSIGN GENDER PERSPECTIVE
  // We allow simulation toggle so the reviewer can test both Bride (female) and Groom (male) views!
  const [simRole, setSimRole] = useState<'female' | 'male'>(
    req.genderSimulationRole || (user?.gender === 'female' ? 'female' : 'male')
  );

  const partnerId = req.senderId === 'm2' ? req.receiverId : req.senderId;
  const partner = members.find((m: any) => m.id === partnerId) || {
    id: partnerId,
    nickname: 'عضو توافق',
    age: '27',
    city: 'الرياض',
    education: 'بكالوريوس',
    gender: simRole === 'female' ? 'male' : 'female',
  };

  // LOCAL AND PERSISTED STATES
  const currentStep = req.coordinationStep || 1;

  // Phase 1 States
  const [userPaid, setUserPaid] = useState<boolean>(!!req.userDepositPaid);
  const [partnerPaid, setPartnerPaid] = useState<boolean>(!!req.partnerDepositPaid);
  const [selectedPath, setSelectedPath] = useState<'chat' | 'direct' | null>(req.preExchangeChoice || null);

  // Inquiry Chat States (20 messages for 100 SAR)
  const [inquiryActive, setInquiryActive] = useState<boolean>(!!req.inquiryActive);
  const [inquiryCredits, setInquiryCredits] = useState<number>(typeof req.inquiryCredits === 'number' ? req.inquiryCredits : 3);
  const [creditsPayerRole, setCreditsPayerRole] = useState<'female' | 'male' | ''>(req.creditsPayerRole || '');

  // Phase 2 States (Female Contact details & Male Response)
  const [contactForm, setContactForm] = useState({
    role: req.femaleContactRole || 'والدي',
    phone: req.femaleContactPhone || '',
    extra: req.femaleContactExtra || '',
    submitted: !!req.femaleContactSubmitted
  });

  const [maleResponse, setMaleResponse] = useState<string>(req.maleConfirmationText || '');
  const [maleSubmitted, setMaleSubmitted] = useState<boolean>(!!req.maleConfirmationSubmitted);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [stage2Agreed, setStage2Agreed] = useState<boolean>(!!req.stage2Agreed);

  // Phase 2 Clipboard & Pledge States
  const [copied, setCopied] = useState<boolean>(false);
  const [groomPledged, setGroomPledged] = useState<boolean>(false);

  // Phase 3 States (Sharia Look acceptance)
  const [userSharia, setUserSharia] = useState<'none' | 'yes' | 'no'>(req.userShariaChoice || 'none');
  const [partnerSharia, setPartnerSharia] = useState<'none' | 'yes' | 'no'>(req.partnerShariaChoice || 'none');
  const [shariaReason, setShariaReason] = useState<string>(req.shariaNoAcceptReason || '');

  // Phase 4 States (Nikah & Final Fees Approval)
  const [nikahConfirmed, setNikahConfirmed] = useState<boolean>(!!req.marriageConfirmed);
  const [finalFeesPaid, setFinalFeesPaid] = useState<boolean>(!!req.remainingFeesPaid);
  const [rating, setRating] = useState<number>(req.finalRating || 5);
  const [reviewText, setReviewText] = useState<string>(req.finalReviewText || '');

  // Phase 3 Local Appointment States
  const [appDate, setAppDate] = useState<string>(req.appointmentDate || '2026-07-15');
  const [appTime, setAppTime] = useState<string>(req.appointmentTime || '17:00');
  const [appLocation, setAppLocation] = useState<string>(req.appointmentLocation || 'منزل والد الأخت الكريمة بالرياض');
  const [appCreated, setAppCreated] = useState<boolean>(!!req.appointmentCreated);

  // Chat engine state
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<any[]>(req.coordinationMessages || []);
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // SYNCHRONIZE SIMULATION VALUE
  useEffect(() => {
    if (req) {
      setUserPaid(!!req.userDepositPaid);
      setPartnerPaid(!!req.partnerDepositPaid);
      setSelectedPath(req.preExchangeChoice || null);
      setInquiryActive(!!req.inquiryActive);
      setInquiryCredits(typeof req.inquiryCredits === 'number' ? req.inquiryCredits : 0);
      setCreditsPayerRole(req.creditsPayerRole || '');
      setContactForm({
        role: req.femaleContactRole || 'والدي',
        phone: req.femaleContactPhone || '',
        extra: req.femaleContactExtra || '',
        submitted: !!req.femaleContactSubmitted
      });
      setMaleResponse(req.maleConfirmationText || '');
      setMaleSubmitted(!!req.maleConfirmationSubmitted);
      setStage2Agreed(!!req.stage2Agreed);
      setUserSharia(req.userShariaChoice || 'none');
      setPartnerSharia(req.partnerShariaChoice || 'none');
      setShariaReason(req.shariaNoAcceptReason || '');
      setNikahConfirmed(!!req.marriageConfirmed);
      setFinalFeesPaid(!!req.remainingFeesPaid);
      setRating(req.finalRating || 5);
      setReviewText(req.finalReviewText || '');
      setMessages(req.coordinationMessages || []);
      setAppDate(req.appointmentDate || '2026-07-15');
      setAppTime(req.appointmentTime || '17:00');
      setAppLocation(req.appointmentLocation || 'منزل والد الأخت الكريمة بالرياض');
      setAppCreated(!!req.appointmentCreated);
    }
  }, [requestId, req]);

  // SCROLL CHAT ENGINE
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // INITIALIZE FIRST SEED MESSAGES IF EMPTY
  useEffect(() => {
    if (open && (!req.coordinationMessages || req.coordinationMessages.length === 0)) {
      const seedMsgs = [
        {
          id: 'msg-init-1',
          sender: 'system',
          text: 'مرحباً بكما في ميثاق التنسيق الهادئ والآمن تحت إشراف فضيلة المنسقة الشرعية لمنصة توافق. يرجى تداول الاستفسارات المتبادلة بأسلوب لائق ومحترم بما يرضي الله.',
          time: '01:00 م'
        },
        {
          id: 'msg-init-2',
          sender: 'mediator',
          text: `مساء الخير للجميع، أنا منسقتكم الشرعية المتابعة لتوافقكما الميمون. قمت بمراجعة بياناتكما وأرى نسبة تطابق طيبة والحمد لله. تفضلوا بطرح أسئلتكم التمهيدية بكل أريحية.`,
          time: '01:02 م'
        }
      ];
      setMessages(seedMsgs);
      updateDetails(req.id, { coordinationMessages: seedMsgs });
    }
  }, [open, requestId]);

  // STEP ENGINE UPDATER
  const updateStepLocally = (stepNum: number) => {
    updateDetails(req.id, { coordinationStep: stepNum });
    showToast(`تم الانتقال لخطوة: ${getStepLabel(stepNum)}`, 'info');
  };

  const getStepLabel = (step: number) => {
    switch (step) {
      case 1: return 'سداد العربون والجدية';
      case 2: return 'تبادل قنوات التواصل';
      case 3: return 'النظرة الشرعية والتوافق';
      case 4: return 'عقد القران والتقييم الختامي';
      default: return '';
    }
  };

  // ACTIONS FOR SIMULATING PARTNER FOR OUTSTANDING UX
  const triggerSimulationPartnerAction = () => {
    if (currentStep === 1) {
      const nextVal = !partnerPaid;
      setPartnerPaid(nextVal);
      updateDetails(req.id, { partnerDepositPaid: nextVal });
      showToast(nextVal ? '🔄 محاكاة: قام الطرف الآخر بدفع عربون الجدية بنجاح!' : '🔄 محاكاة: تم إلغاء دفع الطرف الآخر', 'info');
    } else if (currentStep === 2) {
      if (simRole === 'male') {
        // We are simulating male, so the female (partner) will initiate and send contact details
        const details = {
          femaleContactRole: 'والدي الكريم',
          femaleContactPhone: '0554433221',
          femaleContactExtra: 'الاتصال مناسب يومياً بعد العصر مباشرة جزاكم الله خيراً.',
          femaleContactSubmitted: true,
        };
        setContactForm({
          role: 'والدي الكريم',
          phone: '0554433221',
          extra: 'الاتصال مناسب يومياً بعد العصر مباشرة جزاكم الله خيراً.',
          submitted: true
        });
        updateDetails(req.id, details);

        // Add to messages list
        const sysMsg = {
          id: 'msg-sim-' + Math.random(),
          sender: 'partner',
          text: `قامت الأخت الكريمة بإرسال قنوات اتصال أهلها للربط الرسمي:
القرابة: والدي الكريم
رقم الهاتف: 0554433221
ملاحظة: الاتصال مناسب يومياً بعد العصر مباشرة جزاكم الله خيراً.`,
          time: 'الآن'
        };
        const nextMsgs = [...messages, sysMsg];
        setMessages(nextMsgs);
        updateDetails(req.id, { coordinationMessages: nextMsgs, ...details });
        showToast('🔄 محاكاة: قامت الأخت الكريمة بإدخال وإرسال معلومات هاتف ولي أمرها!', 'success');
      } else {
        // We are simulating female, so male (partner) replies to our contact details
        const maleResponseSim = "سيتواصل والدي الكريم مع والدكم الفاضل للتنسيق والتشرف بالمعرفة الطيبة على هذا الرقم خلال اليومين القادمين بإذن الله.";
        setMaleResponse(maleResponseSim);
        setMaleSubmitted(true);
        updateDetails(req.id, { maleConfirmationText: maleResponseSim, maleConfirmationSubmitted: true });

        const partnerMsg = {
          id: 'msg-sim-' + Math.random(),
          sender: 'partner',
          text: `تأكيد الأخ الفاضل: سيتواصل والدي الكريم مع والدكم الفاضل للتنسيق والتشرف بالمعرفة الطيبة على الرقم المذكور خلال اليومين القادمين بإذن الله.`,
          time: 'الآن'
        };
        const nextMsgs = [...messages, partnerMsg];
        setMessages(nextMsgs);
        updateDetails(req.id, { coordinationMessages: nextMsgs });
        showToast('🔄 محاكاة: قام الأخ بإرسال تأكيد التواصل والاتصال بالوالد!', 'success');
      }
    } else if (currentStep === 3) {
      const nextChoice = partnerSharia === 'yes' ? 'no' : 'yes';
      setPartnerSharia(nextChoice);
      updateDetails(req.id, { partnerShariaChoice: nextChoice });
      showToast(nextChoice === 'yes' ? '🔄 محاكاة: أكد الطرف الآخر القبول والموافقة المبدئية!' : '🔄 محاكاة: اعتذر الطرف الآخر عن عدم حدوث النصيب بالمعروف', 'info');
    }
  };

  // CHAT HANDLERS
  const handleStartInquiry = () => {
    setInquiryActive(true);
    setInquiryCredits(3);
    
    // Append system message about inquiry package activation
    const newSysMsg = {
      id: 'msg-sys-inq-' + Math.random(),
      sender: 'system',
      text: `تم تفعيل الاستفسار المبدئي المجاني (3 رسائل). يرجى طرح الأسئلة الجوهرية فقط لضمان الجدية.`,
      time: 'الآن'
    };
    const nextMsgs = [...messages, newSysMsg];
    setMessages(nextMsgs);
    
    updateDetails(req.id, {
      inquiryActive: true,
      inquiryCredits: 3,
      preExchangeChoice: 'chat',
      coordinationMessages: nextMsgs
    });

    showToast('تم بدء الاستفسار المبدئي المجاني بنجاح!', 'success');
  };

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;

    const isStep1Chat = currentStep === 1 && selectedPath === 'chat';

    if (isStep1Chat) {
      if (inquiryCredits <= 0) {
        showToast('⚠️ لا يوجد رصيد رسائل كافٍ! يرجى إعادة شحن الباقة للاستمرار في الاستفسار.', 'error');
        return;
      }

      // Decrement 1 message for user msg
      const nextCredits1 = Math.max(0, inquiryCredits - 1);
      setInquiryCredits(nextCredits1);

      const userMsg = {
        id: 'msg-user-' + Math.random(),
        sender: 'user',
        text: chatInput.trim(),
        time: 'الآن'
      };

      const nextMsgs = [...messages, userMsg];
      setMessages(nextMsgs);
      setChatInput('');
      updateDetails(req.id, { inquiryCredits: nextCredits1, coordinationMessages: nextMsgs });

      // Mock response after delay also decrements since receiver chats free but depletes payer balance
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        const partnerReplies = [
          "سؤال كريم جزاكم الله خيراً.. بالنسبة لي هذا مناسب ومتوافق مع تطلعاتي.",
          "أهلاً بك، أشكرك على صراحتك البالغة. أحترم هذا التوجه كثيراً.",
          "نعم، والداي على استعداد للتنسيق المباشر وبدء المكالمة فوراً.",
          "أنا جاهزة لتلقي قنوات الاتصال والبدء في المراحل الرسمية."
        ];
        const randomReply = partnerReplies[Math.floor(Math.random() * partnerReplies.length)];
        const partnerMsg = {
          id: 'msg-part-' + Math.random(),
          sender: 'partner',
          text: randomReply,
          time: 'الآن'
        };

        const nextCredits2 = Math.max(0, nextCredits1 - 1);
        setInquiryCredits(nextCredits2);

        const updatedList = [...nextMsgs, partnerMsg];
        setMessages(updatedList);
        updateDetails(req.id, { inquiryCredits: nextCredits2, coordinationMessages: updatedList });
        showToast('💬 المستقبل استفسر مجاناً! تم خصم رسالة الرد من رصيد الدافع.', 'info');
      }, 1200);

    } else {
      // Normal free chat for Step 2+
      const userMsg = {
        id: 'msg-user-' + Math.random(),
        sender: 'user',
        text: chatInput.trim(),
        time: 'الآن'
      };

      const nextMsgs = [...messages, userMsg];
      setMessages(nextMsgs);
      setChatInput('');
      updateDetails(req.id, { coordinationMessages: nextMsgs });

      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        const partnerReplies = [
          "سؤال كريم جزاكم الله خيراً.. بالنسبة لي هذا مناسب ومتوافق مع تطلعاتي.",
          "أهلاً بك، أشكرك على صراحتك البالغة. أحترم هذا التوجه كثيراً.",
          "نعم، والداي على استعداد للتنسيق المباشر وبدء المكالمة فوراً.",
          "أنا جاهزة لتلقي قنوات الاتصال والبدء في المراحل الرسمية."
        ];
        const randomReply = partnerReplies[Math.floor(Math.random() * partnerReplies.length)];
        const partnerMsg = {
          id: 'msg-part-' + Math.random(),
          sender: 'partner',
          text: randomReply,
          time: 'الآن'
        };
        const updatedList = [...nextMsgs, partnerMsg];
        setMessages(updatedList);
        updateDetails(req.id, { coordinationMessages: updatedList });
      }, 1200);
    }
  };

  const handleSendPreset = (text: string) => {
    const isStep1Chat = currentStep === 1 && selectedPath === 'chat';

    if (isStep1Chat) {
      if (inquiryCredits <= 0) {
        showToast('⚠️ لا يوجد رصيد رسائل! يرجى شحن الباقة للاستمرار.', 'error');
        return;
      }

      // Decrement 1 message for user msg
      const nextCredits1 = Math.max(0, inquiryCredits - 1);
      setInquiryCredits(nextCredits1);

      const userMsg = {
        id: 'msg-user-' + Math.random(),
        sender: 'user',
        text: text,
        time: 'الآن'
      };
      const nextMsgs = [...messages, userMsg];
      setMessages(nextMsgs);
      updateDetails(req.id, { inquiryCredits: nextCredits1, coordinationMessages: nextMsgs });

      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        const partnerMsg = {
          id: 'msg-part-' + Math.random(),
          sender: 'partner',
          text: "بارك الله لكما وفي مسعاكما الكريم. بالنسبة لي السكن والمستقبل يتناسق تماماً مع هذا الرأي الطيب.",
          time: 'الآن'
        };

        const nextCredits2 = Math.max(0, nextCredits1 - 1);
        setInquiryCredits(nextCredits2);

        const updatedList = [...nextMsgs, partnerMsg];
        setMessages(updatedList);
        updateDetails(req.id, { inquiryCredits: nextCredits2, coordinationMessages: updatedList });
        showToast('💬 المستقبل تواصل مجاناً! خصمت من رصيد الدافع.', 'info');
      }, 1000);

    } else {
      const userMsg = {
        id: 'msg-user-' + Math.random(),
        sender: 'user',
        text: text,
        time: 'الآن'
      };
      const nextMsgs = [...messages, userMsg];
      setMessages(nextMsgs);
      updateDetails(req.id, { coordinationMessages: nextMsgs });

      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        const partnerMsg = {
          id: 'msg-part-' + Math.random(),
          sender: 'partner',
          text: "بارك الله لكما وفي مسعاكما الكريم. بالنسبة لي السكن والمستقبل يتناسق تماماً مع هذا الرأي الطيب.",
          time: 'الآن'
        };
        const updatedList = [...nextMsgs, partnerMsg];
        setMessages(updatedList);
        updateDetails(req.id, { coordinationMessages: updatedList });
      }, 1000);
    }
  };

  // PHASE 1 DEVELOPMENTS: Choose Pathway & Deposit Payment
  const handleSelectPath = (path: 'chat' | 'direct') => {
    setSelectedPath(path);
    updateDetails(req.id, { preExchangeChoice: path });
    showToast(`تم اختيار مسار: ${path === 'chat' ? 'الدردشة الاستفسارية المبدئية' : 'الربط المباشر لتبادل الأرقام'}`, 'success');
  };

  const handleUserPayDeposit = () => {
    setUserPaid(true);
    updateDetails(req.id, { userDepositPaid: true });
    showToast('💳 تم سداد عربون الجدية وتأمين المصلحة بـ 500 ريال بنجاح! نثمن جديتك الرائعة.', 'success');
  };

  const handleGoToPhase2 = () => {
    updateDetails(req.id, { coordinationStep: 2, status: 'in_mediation' });
    showToast('💬 تم تفعيل المرحلة الثانية بنجاح: مرحلة تبادل قنوات التواصل الرسمية!', 'success');
  };

  // PHASE 2 DEVELOPMENTS: Female Contact Submission & Male Response
  const handleFemaleSubmitContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.phone.trim()) {
      showToast('يرجى كتابة رقم الهاتف أولاً للتنسيق', 'error');
      return;
    }
    const updatedForm = { ...contactForm, submitted: true };
    setContactForm(updatedForm);

    const details = {
      femaleContactRole: contactForm.role,
      femaleContactPhone: contactForm.phone,
      femaleContactExtra: contactForm.extra,
      femaleContactSubmitted: true,
    };
    updateDetails(req.id, details);

    // Append beautiful template message representing contact info
    const contactMsg = {
      id: 'msg-contact-' + Math.random(),
      sender: 'user',
      text: `تم إرسال قنوات التواصل الرسمية لبيتي للبدء بالخطوات الرسمية:
القرابة لولي الأمر: ${contactForm.role}
رقم الهاتف: ${contactForm.phone}
ملاحظات إضافية: ${contactForm.extra || 'لا يوجد ملاحظات إضافية. تفضلوا بالاتصال في الوقت المناسب.'}`,
      time: 'الآن'
    };
    const nextMsgs = [...messages, contactMsg];
    setMessages(nextMsgs);
    updateDetails(req.id, { coordinationMessages: nextMsgs, ...details });
    showToast('✉️ تم إرسال معلومات اتصال ولي أمرك للأخ الفاضل بكل كرامة وخصوصية.', 'success');
  };

  const handleMaleSubmitConfirmation = () => {
    if (!maleResponse.trim()) {
      showToast('يرجى صياغة رد الأهل ووسيلة تواصلكم لتأكيد البدء', 'error');
      return;
    }
    setMaleSubmitted(true);
    updateDetails(req.id, { maleConfirmationText: maleResponse, maleConfirmationSubmitted: true });

    const replyMsg = {
      id: 'msg-confirm-' + Math.random(),
      sender: 'user',
      text: `تأكيد الأخ الفاضل وسيلة تواصل عائلته: ${maleResponse}`,
      time: 'الآن'
    };
    const nextMsgs = [...messages, replyMsg];
    setMessages(nextMsgs);
    updateDetails(req.id, { coordinationMessages: nextMsgs });
    showToast('🤝 تم إرسال ردك وتأكيد اتصال والدك الكرام بنجاح!', 'success');
  };

  const handleSetAgreed = () => {
    setStage2Agreed(true);
    updateDetails(req.id, { stage2Agreed: true, coordinationStep: 3 });
    showToast('🎉 تم تأكيد الاتفاق الرسمي وتلقي بيانات الأهل! تم الانتقال إلى مرحلة متابعة النظرة الشرعية.', 'success');
  };

  // PHASE 3 DEVELOPMENTS: Sharia Look Confirmation
  const handleShariaAnswer = (choice: 'yes' | 'no') => {
    setUserSharia(choice);
    updateDetails(req.id, { userShariaChoice: choice });
    if (choice === 'yes') {
      showToast('👍 تم تسجيل قبولك المبدئي ومباركتك للقاء النظرة الشرعية بنجاح!', 'success');
    } else {
      showToast('ℹ️ تم تسجيل اعتذارك بالمعروف، بانتظار إيضاح السبب لطفا لحفظ الحقوق.', 'info');
    }
  };

  const handleDismissWithGrace = () => {
    if (!shariaReason.trim()) {
      showToast('يرجى كتابة سبب الاعتذار لطفا للأرشفة والمتابعة', 'error');
      return;
    }
    updateDetails(req.id, {
      shariaNoAcceptReason: shariaReason,
      status: 'declined', // Archiving the request as declined
      coordinationStep: 3,
    });
    showToast('🕊️ تم تسجيل اعتذارك بكل لطف وإبلاغ الإدارة. تم رد العربون لحسابك تماشياً مع سياسة الخصوصية الذكية لشركة توافق.', 'info');
    onClose();
  };

  const handleGoToPhase4 = () => {
    updateDetails(req.id, { coordinationStep: 4 });
    showToast('💍 مبروك التوافق! تم الانتقال لخطوة عقد القران المبارك وتوثيق الزفاف.', 'success');
  };

  // PHASE 4 DEVELOPMENTS: Marriage ceremony & Evaluation
  const handleConfirmMarriage = () => {
    setNikahConfirmed(true);
    updateDetails(req.id, { marriageConfirmed: true });
    showToast('🎉 تهانينا القلبية الصادقة! اللهم بارك لهما واجمع بينهما في خير.', 'success');
  };

  const handlePayRemainingFees = () => {
    setFinalFeesPaid(true);
    updateDetails(req.id, { remainingFeesPaid: true, status: 'completed' });
    showToast('🏆 تم دفع متبقي رسوم السعي وتوثيق العهد بنجاح! مبروك اكتمال ملف عائلتك بنجاح تام.', 'success');
  };

  const handleSaveEvaluation = () => {
    updateDetails(req.id, {
      finalRating: rating,
      finalReviewText: reviewText,
      coordinationStep: 4,
    });
    showToast('🌸 شكراً جزيلاً لتقييمك الرائع ومشاركتنا فرحتك! تم نشر كلمتك في لوحة شرف توافق.', 'success');
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 md:p-4">
          {/* Overlay background */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-navy-950/75 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Dialog Container */}
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            transition={{ type: 'spring', damping: 28, stiffness: 240 }}
            className="relative w-full md:max-w-4xl h-[100dvh] md:h-[92vh] bg-cream-50 md:rounded-3xl shadow-2xl flex flex-col overflow-hidden text-right mt-auto md:mt-0"
            dir="rtl"
          >
            {/* Simulation Dev Bar - Elegant top helper */}
            <div className="bg-amber-500/10 border-b border-amber-500/15 p-2 px-4 flex flex-wrap items-center justify-between gap-2 z-20">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-[10.5px] font-cairo font-extrabold text-amber-900">أداة المحاكاة والتحكم للتطوير والتقييم 🛠️:</span>
                <span className="text-[10px] font-tajawal text-amber-800 bg-white/60 px-2 py-0.5 rounded-md border border-amber-200/50">
                  تفعل لك اختبار الواجهتين والطرف الآخر بسرعة!
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-white rounded-lg border border-amber-300 p-0.5 shadow-sm">
                  <button
                    onClick={() => {
                      setSimRole('female');
                      updateDetails(req.id, { genderSimulationRole: 'female' });
                      showToast('👩 تم التبديل لعرض الشاشة من منظور الأخت الكريمة', 'info');
                    }}
                    className={`px-2.5 py-1 text-[10px] font-cairo font-bold rounded-md transition-colors cursor-pointer ${
                      simRole === 'female' ? 'bg-rose-550 text-white shadow-sm' : 'text-slate-650 hover:bg-slate-10'
                    }`}
                  >
                    منظور الأخت 👩
                  </button>
                  <button
                    onClick={() => {
                      setSimRole('male');
                      updateDetails(req.id, { genderSimulationRole: 'male' });
                      showToast('👨 تم التبديل لعرض الشاشة من منظور الأخ الفاضل', 'info');
                    }}
                    className={`px-2.5 py-1 text-[10px] font-cairo font-bold rounded-md transition-colors cursor-pointer ${
                      simRole === 'male' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-650 hover:bg-slate-10'
                    }`}
                  >
                    منظور الأخ 👨
                  </button>
                </div>

                <button
                  onClick={triggerSimulationPartnerAction}
                  className="bg-navy-900 text-white px-3 py-1 text-[10px] font-cairo font-black rounded-lg hover:bg-navy-800 border border-slate-700 shadow-sm flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>محاكاة رد الطرف الآخر 🔄</span>
                </button>
              </div>
            </div>

            {/* Header section with partner description */}
            <div className="bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 p-5 text-white flex items-center justify-between gap-3 flex-shrink-0 border-b border-cream-200/10">
              <div className="flex items-center gap-4">
                <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600/20 border border-amber-500/20 flex items-center justify-center text-amber-400 shadow-inner">
                  <Heart className="w-6.5 h-6.5 text-amber-400 fill-amber-400 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-cairo font-black text-md md:text-lg flex items-center gap-2 tracking-tight">
                    غرفة المنسقة والميثاق الرسمي
                    <span className="text-[10px] font-bold bg-amber-500 text-navy-950 px-2.5 py-0.5 rounded-full shadow-sm">
                      تواصل آمن وموثوق 🔒
                    </span>
                  </h3>
                  <p className="text-xs text-amber-100/80 font-tajawal mt-0.5 animate-pulse">
                    متابعتك مع: <strong className="text-white text-sm">{partner.nickname}</strong> • {partner.age} سنة • لمدينة الرياض • درجة العلمي {partner.education}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-all active:scale-95 cursor-pointer border border-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Progress bar of the 4 Stages */}
            <div className="bg-white px-6 py-4.5 border-b border-cream-200 shadow-tiny flex-shrink-0">
              <div className="flex items-center justify-between max-w-3xl mx-auto relative">
                {/* Connector Line backgrounds */}
                <div className="absolute top-1/2 left-3 right-3 h-0.8 bg-slate-100 -translate-y-1/2 z-0" />
                <div
                  className="absolute top-1/2 right-3 h-0.8 bg-gradient-to-l from-amber-500 to-orange-500 -translate-y-1/2 z-0 transition-all duration-350"
                  style={{ width: `${((currentStep - 1) / 3) * 100}%`, right: '12px' }}
                />

                {[
                  { step: 1, label: 'أولاً: العربون والجدية', desc: 'سداد والتزام موحد', icon: Receipt },
                  { step: 2, label: 'ثانياً: قنوات التواصل', desc: 'أولوية الأخت الفاضلة', icon: MessageSquare },
                  { step: 3, label: 'ثالثاً: النظرة والوفاق', desc: 'اتفاق وتأكيد العائلتين', icon: Users },
                  { step: 4, label: 'رابعاً: عقد القران وتوثيقه', desc: 'اكتمال مكلل بالنجاح', icon: Award }
                ].map((s) => {
                  const CurrentIcon = s.icon;
                  const isCurrent = currentStep === s.step;
                  const isCompleted = currentStep > s.step;

                  return (
                    <button
                      key={s.step}
                      disabled={s.step > currentStep + 1}
                      onClick={() => updateStepLocally(s.step)}
                      className="relative z-10 flex flex-col items-center group cursor-pointer focus:outline-none"
                    >
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all duration-300 ${
                          isCompleted
                            ? 'bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-md ring-4 ring-emerald-100'
                            : isCurrent
                              ? 'bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-lg ring-4 ring-amber-100 scale-110'
                              : 'bg-white text-slate-400 border-2 border-slate-200 group-hover:border-amber-400'
                        }`}
                      >
                        {isCompleted ? <Check className="w-5 h-5 stroke-[3px]" /> : <CurrentIcon className="w-5 h-5" />}
                      </div>
                      <span className={`text-[11.5px] font-cairo font-black mt-2 transition-colors ${
                        isCurrent ? 'text-amber-600' : isCompleted ? 'text-emerald-700' : 'text-slate-500'
                      }`}>
                        {s.label}
                      </span>
                      <span className="text-[9.5px] font-tajawal text-slate-400 hidden sm:inline-block max-w-[120px] text-center mt-0.5">
                        {s.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Scrollable Panel Contents */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/40">

              {/* ======================= PHASE 1: العربون والجدية ======================= */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  {/* guiding banner */}
                  <div className="bg-gradient-to-br from-amber-50 to-orange-50/40 rounded-3xl p-5 border border-amber-200/50 text-right space-y-3 shadow-soft">
                    <h4 className="font-cairo font-black text-sm text-amber-900 flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-amber-600" />
                      المرحلة الأولى: بوابة الجدية والتعارف المبدئي الآمن
                    </h4>
                    <p className="text-xs font-tajawal text-slate-700 leading-relaxed">
                      بروتوكول منصة توافق ينص على تيسير مساعي الارتباط النبيل وحفظ خصوصية الأسر بكل كرامة. نوفر لك مسارين آمنين للتعارف الأولي: إما الاستفسار المبرمج المحدود للتأكد من الأساسيات، أو التنسيق العائلي المباشر لتبادل الأرقام الرسمية.
                    </p>
                  </div>

                  {/* واجهة الاختيار السريع لمدخل التواصل */}
                  {!selectedPath ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      {/* مسار الاستفسار المبدئي والشرعي بـ 100 ريال */}
                      <div className="bg-white rounded-3xl p-6 border border-cream-200 shadow-soft hover:shadow-md transition-all flex flex-col justify-between text-right relative overflow-hidden group">
                        <div className="absolute top-0 right-0 left-0 h-1 bg-amber-500" />
                        <div className="space-y-4">
                          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
                            <MessageSquare className="w-6 h-6 animate-pulse" />
                          </div>
                          <h4 className="font-cairo font-black text-base text-navy-950">1. باقة الاستفسار العائلي المبدئي 🎯</h4>
                          <p className="text-xs font-tajawal text-slate-650 leading-relaxed">
                            دردشة خاصة تحت كنف وإشراف المنسقة لطرح الأسئلة الأساسية (طبيعة العيش، والعمل، والمستقبل) قبل تبادل الهواتف. تفعيل الجلسة بـ <strong className="text-amber-700">100 ريال فقط</strong> تمنحك ٢٠ رسالة، والطرف الآخر يرد عليك <span className="font-bold text-emerald-600">مجاناً تماماً</span> دون أي تكاليف!
                          </p>
                          <span className="inline-block text-[10px] font-bold bg-amber-50 text-amber-800 rounded-lg px-2.5 py-1">
                            توفير مالي • ٢٠ رسالة استفسارية • المستقبل مجاناً
                          </span>
                        </div>
                        <button
                          onClick={() => handleSelectPath('chat')}
                          className="mt-6 w-full py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-cairo font-extrabold text-xs transition-all shadow-sm active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          اختيار مسار الاستفسار المبدئي
                          <ArrowRight className="w-4 h-4 transform rotate-180" />
                        </button>
                      </div>

                      {/* المسار المباشر بـ 500 ريال */}
                      <div className="bg-white rounded-3xl p-6 border border-cream-200 shadow-soft hover:shadow-md transition-all flex flex-col justify-between text-right relative overflow-hidden">
                        <div className="absolute top-0 right-0 left-0 h-1 bg-emerald-500" />
                        <div className="space-y-4">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
                            <UserCheck className="w-6 h-6 animate-bounce" />
                          </div>
                          <h4 className="font-cairo font-black text-base text-navy-950">2. المسار السريع (الربط المباشر لتبادل الأرقام) ⚡</h4>
                          <p className="text-xs font-tajawal text-slate-650 leading-relaxed">
                            اختصاراً للوقت والتنسيق الرسمي؛ الانتقال المباشر لدفع عربون الجدية الكامل (<strong className="text-emerald-700">500 ريال</strong>) من كلا الجانبين لفتح منصة التبادل الفوري لهواتف الأهل وبدء التنسيق مباشرة في مجلس العائلة.
                          </p>
                          <span className="inline-block text-[10px] font-bold bg-emerald-50 text-emerald-700 rounded-lg px-2.5 py-1">
                            توصية الإدارة • تبادل مباشر للأرقام • التقديم للمرحلة الثانية فوراً
                          </span>
                        </div>
                        <button
                          onClick={() => handleSelectPath('direct')}
                          className="mt-6 w-full py-3.5 rounded-2xl bg-navy-900 hover:bg-navy-850 text-white font-cairo font-extrabold text-xs transition-all shadow-sm active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          تخطي والتقدم للربط المباشر
                          <ArrowRight className="w-4 h-4 transform rotate-180" />
                        </button>
                      </div>
                    </div>
                  ) : selectedPath === 'chat' && !inquiryActive ? (
                    /* بوابة تفعيل باقة الاستفسار بـ 100 ريال */
                    <div className="space-y-6">
                      <button
                        onClick={() => {
                          setSelectedPath(null);
                          updateDetails(req.id, { preExchangeChoice: null });
                        }}
                        className="text-[11px] font-cairo font-semibold text-slate-500 hover:text-navy-900 flex items-center gap-1 cursor-pointer bg-white px-3 py-1.5 rounded-xl border border-slate-200"
                      >
                        ← الرجوع للاختيار المبدئي للمسار
                      </button>

                      <div className="bg-white rounded-3xl p-8 border border-cream-250 shadow-soft max-w-xl mx-auto space-y-6 text-center">
                        <div className="w-16 h-16 rounded-3xl bg-amber-500/10 text-amber-600 flex items-center justify-center mx-auto mb-2 border border-amber-500/20 shadow-inner">
                          <MessageSquare className="w-8 h-8 text-amber-550 animate-pulse" />
                        </div>
                        
                        <div className="space-y-2">
                          <span className="text-[10px] bg-amber-100 text-amber-800 font-cairo font-black px-3 py-1 rounded-full shadow-xs">
                            خدمة مبسطة ومبتكرة للتعارف الشرعي 🤝
                          </span>
                          <h4 className="font-cairo font-black text-lg text-navy-900">غرفة الاستفسار المبدئي بـ ٢٠ رسالة حوارية</h4>
                          <p className="text-xs font-tajawal text-slate-500 leading-relaxed">
                            هل تود طرح أسئلة هادئة وبسيطة حول وجهات النظر والتطلعات قبل اتخاذ الخطوة الأكبر؟ فعل الباقة بـ ١٠٠ ريال لتمنح نفسك مساحة حوارية مكونة من ٢٠ رسالة، ويستمتع الطرف الآخر <strong className="text-emerald-600">بالرد المجاني بالكامل من رصيدك المتاح</strong>!
                          </p>
                        </div>

                        {/* Package summary pricing */}
                        <div className="p-5 rounded-2.5xl bg-gradient-to-br from-cream-50 to-amber-50/20 border border-amber-200/60 max-w-md mx-auto grid grid-cols-2 divide-x divide-x-reverse divide-cream-100 text-right">
                          <div className="pr-4 space-y-1">
                            <span className="text-[11px] font-tajawal text-slate-400 block">تكلفة تفعيل المحادثة</span>
                            <span className="text-xl font-cairo font-black text-amber-700">100 ريال فقط</span>
                          </div>
                          <div className="pl-4 space-y-1">
                            <span className="text-[11px] font-tajawal text-slate-400 block">رصيد الاتصالات الممنوح</span>
                            <span className="text-xl font-cairo font-black text-navy-950 flex items-center gap-1">
                              20 رسالة <span className="text-xs text-slate-500">متبادلة</span>
                            </span>
                          </div>
                        </div>

                        {/* Benefits lists */}
                        <ul className="text-xs text-slate-650 font-tajawal space-y-2 max-w-md mx-auto list-none text-right pr-2">
                          <li className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                            <span><strong>المستقبل يرد مجاناً:</strong> الطرف الآخر لن يدفع شيئاً ليرد على أسئلتك، وتخصم الرسائل تلقائياً من باقتك.</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                            <span><strong>الاحترام الكامل:</strong> تشرف المنسقة الشرعية على المحادثة لضمان الالتزام ومراعاة الخصوصية الفائقة.</span>
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                            <span><strong>الحرية والربط السريع:</strong> يمكنك في أي وقت ترقية المسار ودفع العربون 500 ريال للانتقال للهواتف الرسمية.</span>
                          </li>
                        </ul>

                        <div className="pt-2">
                          <button
                            onClick={handleStartInquiry}
                            className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-650 hover:to-amber-700 text-white font-cairo font-black text-xs transition-all shadow-md active:scale-97 cursor-pointer flex items-center justify-center gap-2"
                          >
                            <MessageSquare className="w-5 h-5" />
                            بدء الاستفسار المبدئي المجاني (3 رسائل)
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : selectedPath === 'chat' && inquiryActive ? (
                    /* غرفة الرسائل للاستفسار المفتوحة مع رصيد */
                    <div className="space-y-4">
                      {/* Back button and upgrade choice */}
                      <div className="flex flex-wrap items-center justify-between gap-2.5">
                        <button
                          onClick={() => {
                            setSelectedPath(null);
                            updateDetails(req.id, { preExchangeChoice: null });
                          }}
                          className="text-[11px] font-cairo font-semibold text-slate-500 hover:text-navy-900 flex items-center gap-1 cursor-pointer bg-white px-3 py-1.5 rounded-xl border border-slate-200"
                        >
                          ← سحب وإلغاء الاستفسار
                        </button>

                        <button
                          onClick={() => {
                            setSelectedPath('direct');
                            updateDetails(req.id, { preExchangeChoice: 'direct' });
                            showToast('🔄 تم تفعيل مسار تبادل الهاتف وسداد العربون المباشر!', 'success');
                          }}
                          className="text-[11px] font-cairo font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1.5 cursor-pointer bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-250 animate-pulse"
                        >
                          💸 الترقية للربط العائلي المباشر (سداد العربون 500 ر.س)
                        </button>
                      </div>

                      {/* Core credit bar and gauge card */}
                      <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-200 rounded-3xl p-5 flex flex-wrap items-center justify-between gap-4 text-right">
                        <div className="space-y-1">
                          <h5 className="font-cairo font-black text-xs text-amber-950 flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping inline-block" />
                            باقة الاستفسارات الشرعية المبدئية 💬
                          </h5>
                          <p className="text-[11px] font-tajawal text-slate-600 leading-relaxed">
                            هذه المرحلة مخصصة لجس النبض مبدئياً وتقتصر على أسئلة جوهرية لضمان الجدية.
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-2xl border border-amber-200/50 shadow-tiny">
                          <div className="text-left font-cairo">
                            <span className="block text-[10px] text-slate-400 font-tajawal leading-none">رصيد الرسائل المتبقي</span>
                            <span className="font-black text-lg text-amber-700 font-mono inline-block mt-0.5">{inquiryCredits} <span className="text-[11px] text-slate-500">استفسار</span></span>
                          </div>
                        </div>
                      </div>

                      {/* The Chat sandbox inline inside Step 1 */}
                      <div className="bg-white rounded-3xl border border-cream-250 shadow-soft overflow-hidden flex flex-col h-[480px] relative">
                        {/* Lock Overlay if credit is depleted */}
                        {inquiryCredits <= 0 && (
                          <div className="absolute inset-0 bg-navy-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20 rounded-3xl">
                            <div className="max-w-md bg-white p-7 rounded-3xl border border-cream-200 shadow-2xl space-y-4 text-right" dir="rtl">
                              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center mx-auto">
                                <Lock className="w-6 h-6" />
                              </div>
                              <h5 className="font-cairo font-black text-base text-navy-950 text-center">انتهت فترة الاستفسار المبدئي 🔒</h5>
                              <p className="text-xs font-tajawal text-slate-505 leading-relaxed text-center">
                                تم انتهاء فترة الاستفسار المبدئي المجانية. الرجاء سداد عربون الجدية لفتح التنسيق الكامل وتحديد موعد اللقاء الرسمي.
                              </p>
                              
                              <div className="pt-2">
                                <button
                                  onClick={() => {
                                    setSelectedPath('direct');
                                    updateDetails(req.id, { preExchangeChoice: 'direct' });
                                    showToast('🔄 تم تنشيط مسار سداد العربون والربط الرسمي الفوري!', 'success');
                                  }}
                                  className="w-full py-3 bg-navy-900 hover:bg-navy-850 text-white font-cairo font-bold text-xs rounded-xl transition-all shadow-sm flex items-center justify-center gap-1 cursor-pointer"
                                >
                                  <UserCheck className="w-4 h-4" />
                                  سداد عربون الجدية (500 ر.س)
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Custom status top row */}
                        <div className="bg-slate-50 border-b border-cream-100 px-5 py-3 flex items-center justify-between text-right flex-shrink-0">
                          <div className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                            <span className="text-xs font-cairo font-black text-slate-800">قناة تواصل آمنة: {partner.nickname}</span>
                          </div>
                          <span className="text-[10px] bg-amber-50 border border-amber-200/50 text-amber-800 font-cairo font-bold px-2.5 py-0.8 rounded-md flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                            تحت إشراف منسقة توافق لضمان المروءة والنزاهة
                          </span>
                        </div>

                        {/* Message list */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/20">
                          {messages.length === 0 && (
                            <div className="text-center py-10 space-y-2">
                              <span className="text-slate-300 text-3xl">💬</span>
                              <p className="text-xs text-slate-400 font-tajawal">مرحباً بكما في الدردشة الاستفسارية المبدئية! تفضلا بطرح أسئلتكما بوقار متبادل.</p>
                            </div>
                          )}
                          {messages.map((m) => {
                            const isMe = m.sender === 'user';
                            const isSys = m.sender === 'system';
                            const isMed = m.sender === 'mediator';

                            if (isSys) {
                              return (
                                <div key={m.id} className="flex justify-center">
                                  <div className="bg-amber-50/80 border border-amber-250/50 rounded-2xl px-4 py-2.5 text-center text-[10px] text-amber-900 font-tajawal max-w-sm leading-relaxed">
                                    {m.text}
                                  </div>
                                </div>
                              );
                            }

                            if (isMed) {
                              return (
                                <div key={m.id} className="flex items-start gap-2 max-w-lg">
                                  <div className="w-8 h-8 rounded-xl bg-navy-900 text-white flex items-center justify-center text-[9px] font-cairo font-black flex-shrink-0 shadow-inner">
                                    المنسقة
                                  </div>
                                  <div className="bg-navy-900 text-slate-100 rounded-2xl rounded-tr-none p-3 text-[11px] font-tajawal leading-relaxed shadow-sm">
                                    <span className="block font-cairo font-bold text-[9.5px] text-amber-400 mb-1">المنسقة الشرعية:</span>
                                    {m.text}
                                  </div>
                                </div>
                              );
                            }

                            return (
                              <div key={m.id} className={`flex ${isMe ? 'justify-start' : 'justify-end'}`}>
                                <div className={`max-w-md rounded-2.5xl p-3 text-xs font-tajawal leading-relaxed shadow-sm ${
                                  isMe
                                    ? 'bg-amber-500 text-white rounded-tl-none'
                                    : 'bg-white border border-slate-200 text-navy-850 rounded-tr-none'
                                }`}>
                                  <span className="block font-cairo font-extrabold text-[9px] mb-1 opacity-70">
                                    {isMe ? 'أنت' : partner.nickname}
                                  </span>
                                  <div className="whitespace-pre-line">{m.text}</div>
                                </div>
                              </div>
                            );
                          })}

                          {isTyping && (
                            <div className="flex justify-end animate-pulse">
                              <div className="bg-white border border-slate-100 rounded-xl rounded-tr-none px-3.5 py-2 text-xs text-slate-400 font-tajawal flex items-center gap-1">
                                <span>يكتب الطرف الآخر الآن للتجاوب...</span>
                              </div>
                            </div>
                          )}
                          <div ref={chatEndRef} />
                        </div>

                        {/* Presets Row */}
                        <div className="p-2 border-t border-cream-100 bg-cream-50/50 flex flex-wrap gap-1.5 justify-end flex-shrink-0">
                          <span className="text-[9px] font-cairo text-slate-400 self-center ml-2 font-bold">مواضيع استفسار مقترحة:</span>
                          <button
                            onClick={() => handleSendPreset("كيف تتطلع للأهداف الحياتية بخصوص السكن وتجهيزاته المناسبة مستقبلاً؟")}
                            className="bg-white hover:bg-amber-50/30 text-[10px] text-slate-700 px-2.5 py-1 rounded-xl border border-slate-200 font-tajawal transition-colors cursor-pointer"
                          >
                            تطلعات السكن وتجهيزاته...
                          </button>
                          <button
                            onClick={() => handleSendPreset("هل تحبذ استكمال الفتاة للمساعي التعليمية والمهنية الأكاديمية بعد عقد الوفاق؟")}
                            className="bg-white hover:bg-amber-50/30 text-[10px] text-slate-700 px-2.5 py-1 rounded-xl border border-slate-200 font-tajawal transition-colors cursor-pointer"
                          >
                            استكمال التعليم والوظيفة...
                          </button>
                          <button
                            onClick={() => handleSendPreset("كيف تتطلعون لتنسيق تفاصيل السفر والاستقرار العائلي المتوازن؟")}
                            className="bg-white hover:bg-amber-50/30 text-[10px] text-slate-700 px-2.5 py-1 rounded-xl border border-slate-200 font-tajawal transition-colors cursor-pointer"
                          >
                            تفاصيل السفر والاستقرار...
                          </button>
                        </div>

                        {/* Guided Q&A Input */}
                        <div className="p-2.5 border-t border-cream-200 bg-white flex flex-col gap-2 flex-shrink-0 pb-safe">
                          <div className="text-[10px] text-amber-700 font-tajawal text-center font-bold">
                            يُسمح بطرح أسئلة محددة ومهمة فقط عبر الإدارة لضمان الجدية (متبقي {inquiryCredits} استفسار)
                          </div>
                          <select
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            className="w-full p-2.5 text-xs text-navy-900 bg-slate-50 rounded-xl border border-slate-250 focus:outline-none focus:border-amber-400 font-tajawal text-right"
                          >
                            <option value="" disabled>اختر سؤالاً من القائمة لطرحه...</option>
                            {PRESET_MESSAGES.map((msg, idx) => (
                              <option key={idx} value={msg}>{msg}</option>
                            ))}
                          </select>
                          <button
                            onClick={handleSendMessage}
                            disabled={!chatInput || inquiryCredits <= 0}
                            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <Send className="w-4 h-4 transform rotate-180" /> إرسال الاستفسار للوسيطة
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* بوابة تحصيل العربون وتتبع سداد الطرفين */
                    <div className="space-y-6">
                      {/* Back to change path helper */}
                      <button
                        onClick={() => {
                          setSelectedPath(null);
                          updateDetails(req.id, { preExchangeChoice: null });
                        }}
                        className="text-[11px] font-cairo font-semibold text-slate-500 hover:text-navy-900 flex items-center gap-1 cursor-pointer bg-white px-3 py-1.5 rounded-xl border border-slate-200"
                      >
                        ← الرجوع لتغيير وتحديد المسار مجدداً
                      </button>

                      <div className="bg-white rounded-3xl p-6 border border-cream-200 shadow-soft space-y-6 text-center">
                        <div className="max-w-md mx-auto space-y-2">
                          <h4 className="font-cairo font-black text-base text-navy-900">بوابة تحصيل العربون ونظام تتبع الجدية المشترك</h4>
                          <p className="text-xs font-tajawal text-slate-500">
                            تنص لائحة منصة توافق التنظيمية على سداد مبلغ العربون الموحد (500 ريال) بشكل مستقل لدى كلا الطرفين (الأخ والأخت الفاضلة) لتأكيد الانتماء والنية الصادقة والجدية الكاملة قبل تبادل الأرقام.
                          </p>
                        </div>

                        {/* Live Double indicator tracking */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
                          {/* User state check */}
                          <div className={`p-5 rounded-2xl border text-right transition-colors ${
                            userPaid
                              ? 'bg-emerald-50/70 border-emerald-250 text-emerald-905'
                              : 'bg-slate-50 border-slate-200 text-slate-800'
                          }`}>
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold font-cairo bg-slate-200/50 text-slate-700 px-2.5 py-1 rounded-md">حسابك الخاص</span>
                              <div className={`w-3 h-3 rounded-full ${userPaid ? 'bg-emerald-500 animate-pulse' : 'bg-rose-450'}`} />
                            </div>
                            <h5 className="font-cairo font-black text-sm mt-3">حالة سدادك لعربون الجدية:</h5>
                            <p className="text-[11.5px] font-tajawal mt-1 mb-3">
                              {userPaid 
                                ? 'تم سداد مبلغ 500 ريال بنجاح ✓ رصيدك مسجل بأمان.' 
                                : 'مستحق ومطالب بالسداد لإثبات تطلعاتك الصادقة.'}
                            </p>
                            {!userPaid ? (
                              <button
                                onClick={handleUserPayDeposit}
                                className="w-full py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-cairo font-bold text-xs rounded-xl transition-all shadow-sm active:scale-97 cursor-pointer flex items-center justify-center gap-1.5"
                              >
                                <CreditCard className="w-4 h-4" />
                                سداد 500 ريال الآن
                              </button>
                            ) : (
                              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 font-cairo">
                                <CheckCircle2 className="w-4.5 h-4.5 animate-bounce text-emerald-500" /> تم تأمين العربون
                              </span>
                            )}
                          </div>

                          {/* Partner state check */}
                          <div className={`p-5 rounded-2xl border text-right transition-colors ${
                            partnerPaid
                              ? 'bg-emerald-50/70 border-emerald-250 text-emerald-900'
                              : 'bg-slate-50 border-slate-200 text-slate-800'
                          }`}>
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold font-cairo bg-slate-200/50 text-slate-700 px-2.5 py-1 rounded-md">الطرف الآخر ({partner.nickname})</span>
                              <div className={`w-3 h-3 rounded-full ${partnerPaid ? 'bg-emerald-500 animate-pulse' : 'bg-amber-550'}`} />
                            </div>
                            <h5 className="font-cairo font-black text-sm mt-3">حالة الطرف الآخر:</h5>
                            <p className="text-[11.5px] font-tajawal mt-1 mb-3">
                              {partnerPaid 
                                ? 'أكمل دفعة العربون والجدية بكل نزاهة ✓ جاهز للربط.' 
                                : 'بانتظار استكمال الطرف الآخر لخطوة السداد في حسابه.'}
                            </p>
                            {!partnerPaid ? (
                              <div className="space-y-1.5 text-center">
                                <span className="text-xs text-slate-400 font-tajawal bg-slate-200/40 px-2.5 py-1 rounded-md inline-block">بانتظار السداد...</span>
                                <div className="text-[9px] text-amber-800 leading-normal bg-amber-50 rounded p-1">
                                  💡 تلميح للتجربة السريعة: اضغط على زر "محاكاة رد الطرف الآخر 🔄" بالأعلى لجعله يدفع!
                                </div>
                              </div>
                            ) : (
                              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 font-cairo">
                                <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500" /> الطرف الآخر قام بالسداد
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Safe blocking condition / Progression check */}
                        <div className="max-w-2xl mx-auto pt-4 border-t border-cream-100">
                          {userPaid && partnerPaid ? (
                            <div className="space-y-4 text-center">
                              <div className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold font-cairo">
                                <Sparkles className="w-4 h-4 text-emerald-600 animate-spin" />
                                بفضل الله، اكتمل دفع العربون بنجاح من كلا الجانبين!
                              </div>
                              <button
                                onClick={handleGoToPhase2}
                                className="w-full sm:w-auto px-10 py-4.5 bg-navy-900 hover:bg-navy-850 text-white rounded-2xl font-cairo font-black text-xs shadow-lg transition-all animate-bounce hover:translate-y-[-2px] cursor-pointer flex items-center justify-center gap-2 mx-auto"
                              >
                                المضي تالياً لعرض قنوات التواصل والدخول للدردشة التنسيقية
                                <ArrowRight className="w-4.5 h-4.5" />
                              </button>
                            </div>
                          ) : (
                            <div className="bg-rose-50 border border-rose-150 p-4.5 rounded-2xl flex items-start gap-3 justify-start text-right">
                              <Lock className="w-5.5 h-5.5 text-rose-500 flex-shrink-0 mt-0.5" />
                              <div className="space-y-1">
                                <strong className="block text-xs font-cairo text-rose-900">مسار التواصل المباشر مغلق مؤقتاً</strong>
                                <p className="text-[11px] font-tajawal text-rose-800 leading-normal">
                                  لحفظ كرامة التعارف وتنفيذ سياسة "ضمان الحقوق والجدية"، لن نتمكن من كشف قنوات تواصل وهاتف الولي أو تشغيل نافذة الدردشة الرسمية التنسيقية إلا بعد التزام وسداد كلا الطرفين بنجاح.
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ======================= PHASE 2: قنوات التواصل والدردشة ======================= */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  {/* Premium Family Journey Roadmap & Stepper instead of a basic banner */}
                  <div className="bg-gradient-to-r from-navy-900 via-navy-950 to-indigo-950 rounded-3xl p-6 text-white text-right space-y-4 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full -translate-x-10 -translate-y-10 blur-xl pointer-events-none" />
                    <div className="absolute bottom-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full translate-x-20 translate-y-20 blur-2xl pointer-events-none" />
                    
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                      <div className="space-y-1">
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 font-cairo font-extrabold px-3 py-1 rounded-full border border-amber-500/30">
                          المرحلة الثانية: التنسيق الأسري والربط الرسمي قبالة النظرة الشرعية 🕊️
                        </span>
                        <h4 className="font-cairo font-black text-base text-white mt-1">تسهيل قنوات الاتصال برعاية المروءة الإسلامية</h4>
                      </div>
                      <div className="text-left font-mono text-[11px] text-slate-350">
                        حالة المسار: <span className="text-emerald-400 font-bold">نشط ومؤمن بنجاح ✓</span>
                      </div>
                    </div>

                    {/* Interactive horizontal stepper timeline */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                      <div className={`p-3 rounded-2xl border text-right transition-all ${
                        contactForm.submitted 
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-250' 
                          : 'bg-white/5 border-white/10 text-slate-300'
                      }`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                            contactForm.submitted ? 'bg-emerald-500 text-white' : 'bg-white/15 text-white'
                          }`}>١</span>
                          <span className="font-cairo font-bold text-xs">تقديم قنوات الولي</span>
                        </div>
                        <p className="text-[10.5px] font-tajawal text-slate-300 leading-tight">الأخت الكريمة تقدم هاتف وليها الشرعي بكل فخر واحتشام.</p>
                      </div>

                      <div className={`p-3 rounded-2xl border text-right transition-all ${
                        maleSubmitted 
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-250' 
                          : contactForm.submitted 
                            ? 'bg-amber-500/15 border-amber-500/40 text-amber-200' 
                            : 'bg-white/5 border-white/10 text-slate-300'
                      }`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                            maleSubmitted ? 'bg-emerald-500 text-white' : contactForm.submitted ? 'bg-amber-500 text-slate-950' : 'bg-white/15 text-white'
                          }`}>٢</span>
                          <span className="font-cairo font-bold text-xs">ميثاق الشرف والقبول</span>
                        </div>
                        <p className="text-[10.5px] font-tajawal text-slate-305 leading-tight">المتقدم يتعهد بميثاق الوقار ويؤكد نية الاتصال بالولي للتشرف.</p>
                      </div>

                      <div className={`p-3 rounded-2xl border text-right transition-all ${
                        stage2Agreed || (contactForm.submitted && maleSubmitted)
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-250' 
                          : 'bg-white/5 border-white/10 text-slate-300'
                      }`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="w-5 h-5 rounded-full bg-white/15 text-white flex items-center justify-center text-[10px] font-bold">٣</span>
                          <span className="font-cairo font-bold text-xs">المكالمة العائلية 📞</span>
                        </div>
                        <p className="text-[10.5px] font-tajawal text-slate-305 leading-tight">الاتصال الرسمي الهاتفي الخارجي للحديث والاتفاق على النظرة.</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {/* Left Column: Flow interface prioritized for Gender */}
                    <div className="lg:col-span-5 space-y-4">
                      {simRole === 'female' ? (
                        /* BRIDE/FEMALE VIEW */
                        <div className="bg-white rounded-3xl p-6 border-2 border-rose-100 shadow-xl space-y-5 relative overflow-hidden text-right">
                          <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-l from-rose-500 to-amber-500" />
                          <div className="space-y-2">
                            <span className="inline-block text-[9.5px] font-cairo font-extrabold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-md border border-rose-200/50">
                              ركن العروس الأبية 🌹
                            </span>
                            <h4 className="font-cairo font-black text-sm text-navy-950 leading-relaxed">أختي الفاضلة، تفضلي بتدوين وسيط الاتصال العائلي</h4>
                            <p className="text-[11px] font-tajawal text-slate-500 leading-normal">
                              لأجل كرمك وتسهيل رغبة المتقدم للاتصال بالبيت من بابه الشرعي، حددي تفاصيل ولي أمرك المباشر بكل أريحية. لن يرى المتقدم هذه التفاصيل إلا تحت ميثاق الشرف المصادق عليه.
                            </p>
                          </div>

                          {contactForm.submitted ? (
                            <div className="space-y-4">
                              {/* Classic Certificate Form layout representing "Wali Card" */}
                              <div className="bg-gradient-to-br from-rose-50/70 to-amber-50/45 border border-rose-100 p-5 rounded-3xl text-xs font-tajawal space-y-3 shadow-md relative">
                                <span className="absolute top-3 left-3 text-2xl opacity-15">👑</span>
                                <strong className="font-cairo text-xs text-rose-900 block border-b border-rose-100 pb-2">بطاقة تواصل الولي المعتمدة منصة توافق:</strong>
                                <div className="space-y-2 text-slate-700">
                                  <div className="flex justify-between items-center bg-white/75 p-2 rounded-xl">
                                    <span className="font-cairo text-[11px] text-slate-400">صلة قرابة الولي:</span>
                                    <span className="font-cairo font-black text-xs text-rose-600">{contactForm.role}</span>
                                  </div>
                                  <div className="flex justify-between items-center bg-white/75 p-2 rounded-xl">
                                    <span className="font-cairo text-[11px] text-slate-400">رقم الهاتف الرسمي:</span>
                                    <span className="font-mono font-bold text-xs text-slate-800 select-all tracking-wider">{contactForm.phone}</span>
                                  </div>
                                  <div className="bg-white/75 p-2 rounded-xl">
                                    <span className="font-cairo text-[10px] text-slate-400 block mb-1">تعليماتكِ الخاصة للاتصال بكِ:</span>
                                    <p className="italic font-tajawal text-[11px] text-slate-600 bg-rose-50/40 p-2 rounded-lg">"{contactForm.extra || 'لا توجد تعليمات خاصة إضافية'}"</p>
                                  </div>
                                </div>
                              </div>

                              <div className="bg-emerald-50 border border-emerald-250 p-4 rounded-2xl flex items-start gap-2.5">
                                <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                                <div className="space-y-1">
                                  <span className="font-cairo text-xs font-bold text-emerald-900 block">تم إرسال بطاقة الولي للطرف الآخر بنجاح</span>
                                  <p className="text-[10.5px] font-tajawal text-slate-600">
                                    المتكامل المتقدم أخي الكريم بانتظار قراءة وتوقيع "معهد المروءة" ليتم حجب الاتصال مجدداً لتباشر عائلته الاتصال بوالدكم بحول الله.
                                  </p>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <form onSubmit={handleFemaleSubmitContact} className="space-y-4.5 text-right">
                              <div className="space-y-1.5">
                                <label className="text-xs font-cairo font-bold text-slate-700">صلة قرابة الولي المنسق:</label>
                                <select
                                  value={contactForm.role}
                                  onChange={(e) => setContactForm({ ...contactForm, role: e.target.value })}
                                  className="w-full p-2.5 text-xs text-navy-900 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-rose-500 font-tajawal"
                                >
                                  <option value="والدي">والدي الكريم (الأب)</option>
                                  <option value="أخي">أخي العزيز</option>
                                  <option value="والدتي">والدتي الكريمة</option>
                                  <option value="عمي">عمي الفاضل</option>
                                  <option value="أخرى">أخرى لشروط تواصل خاصة</option>
                                </select>
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-xs font-cairo font-bold text-slate-700">رقم هاتف ولي الأمر للتنسيق:</label>
                                <div className="relative">
                                  <input
                                    type="tel"
                                    value={contactForm.phone}
                                    onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                                    placeholder="مثال: 0554433221"
                                    className="w-full p-3 text-xs text-left bg-slate-50 text-navy-900 rounded-xl border border-slate-200 focus:outline-none focus:border-rose-500 font-tajawal"
                                    dir="ltr"
                                  />
                                  <Phone className="absolute right-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                                </div>
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-xs font-cairo font-bold text-slate-700">ملاحظات تواصل خاصة (اختياري):</label>
                                <textarea
                                  value={contactForm.extra}
                                  onChange={(e) => setContactForm({ ...contactForm, extra: e.target.value })}
                                  placeholder="مثال: يفضل الاتصال من الوالد بعد صلاة المغرب ليكون متفرغاً للحديث، جزاكم الله خيراً."
                                  rows={2}
                                  className="w-full p-3 text-xs text-navy-900 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-rose-500 font-tajawal"
                                />
                              </div>

                              <button
                                type="submit"
                                className="w-full py-3.5 rounded-2xl bg-rose-550 hover:bg-rose-605 text-white font-cairo font-black text-xs shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                              >
                                <Send className="w-4 h-4 transform rotate-180" />
                                إرسال وتوثيق معلومات ولي أمري
                              </button>
                            </form>
                          )}
                        </div>
                      ) : (
                        /* GROOM/MALE VIEW */
                        <div className="bg-white rounded-3xl p-6 border-2 border-indigo-100 shadow-xl space-y-5 relative overflow-hidden text-right">
                          <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-l from-indigo-600 to-blue-500" />
                          <div className="space-y-2">
                            <span className="inline-block text-[9.5px] font-cairo font-extrabold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-md border border-indigo-200/50">
                              ركن الخاطب المتقدم 👨
                            </span>
                            <h4 className="font-cairo font-black text-sm text-navy-950 leading-relaxed">أخي الكريم، بانتظار قنوات الاتصال بروح المروءة والنزاهة</h4>
                            <p className="text-[11.5px] font-tajawal text-slate-500 leading-normal">
                              لخصوصية الأخت الفاضلة وأسرتها، فإن المبادرة حق كريم لها أولاً برفع رقم الولي. بمجرد وضوح بياناتها، ستخضع لـ "معهد مروءة الرجال والشهامة" وتستطيع الوصول والتنسيق مباشرة.
                            </p>
                          </div>

                          {!contactForm.submitted ? (
                            <div className="bg-amber-50 rounded-2.5xl p-4.5 border border-amber-200 text-[11px] font-tajawal text-amber-850 space-y-2.5 leading-relaxed">
                              <p className="font-cairo font-bold text-xs text-amber-900 flex items-center gap-1.5">
                                <Info className="w-4.5 h-4.5 text-amber-600 animate-pulse" />
                                في انتظار مبادرة الأخت الكريمة...
                              </p>
                              <p>
                                ريثما يتم إعداد الأخت الفاضلة لبيانات وليها الكريمة، تفضل بمطالعة الدردشة التنسيقية الهادئة على اليمين للترحيب وتقديم أسرتك الكريمة باحترام تمهيدي راقٍ.
                              </p>
                            </div>
                          ) : (
                            <div className="space-y-4">
                              {/* Groom Pledge - UNLOCK SECURITY PUSH FOR MAXIMUM TRUST */}
                              {!groomPledged ? (
                                <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-250 p-5 rounded-3xl shadow-inner text-right space-y-4">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xl">📜</span>
                                    <h5 className="font-cairo font-black text-xs text-amber-955">ميثاق الشرف والوقار والنزاهة للرجال</h5>
                                  </div>
                                  
                                  <p className="text-[11px] font-tajawal text-slate-600 leading-relaxed">
                                    احتراماً لوقار البيوت وخصوصية الأخت الكريمة وأبيها الفاضل، نلزمك بالمصادقة على العهود الأخلاقية التالية لعرض رقم والدها وتسهيل التنسيق:
                                  </p>

                                  <div className="space-y-2 text-[10.5px] font-tajawal text-slate-700 bg-white/60 p-3 rounded-2xl border border-amber-100">
                                    <div className="flex items-start gap-1.5">
                                      <span className="text-amber-600 font-bold">١.</span>
                                      <p>أتعهد بالاتصال بالولي في الأوقات اللائقة أخلاقياً واجتماعياً (بعد العصر أو العشاء).</p>
                                    </div>
                                    <div className="flex items-start gap-1.5">
                                      <span className="text-amber-600 font-bold">٢.</span>
                                      <p>أتعهد بتعريف نفسي بوضوح للولي المنسق فروع من كوني الخاطب المهذب من منصة "توافق".</p>
                                    </div>
                                    <div className="flex items-start gap-1.5">
                                      <span className="text-amber-600 font-bold">٣.</span>
                                      <p>أتعهد بعدم تداول أو مشاركة هذا الرقم مطلقاً وحفظ كرامة وخصوصية أصحاب البيت.</p>
                                    </div>
                                  </div>

                                  <button
                                    onClick={() => {
                                      setGroomPledged(true);
                                      showToast('✓ تم قبول العهد والميثاق بنجاح! تم كشف تفاصيل الولي وفتح قنوات الاتصال المباشرة.', 'success');
                                    }}
                                    className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-cairo font-black text-xs rounded-xl shadow-md transition-all scale-100 active:scale-97 cursor-pointer text-center"
                                  >
                                    أوافق وأتعهد بميثاق الشرف والمروءة (كشف الأرقام)
                                  </button>
                                </div>
                              ) : (
                                <div className="space-y-4">
                                  {/* Luxury Unlocked Card containing contact details */}
                                  <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border border-blue-200 p-5 rounded-3xl shadow-md relative overflow-hidden">
                                    <div className="absolute top-2 left-2 text-2xl opacity-10">🛡️</div>
                                    <span className="text-[9.5px] text-blue-800 bg-blue-100 border border-blue-200/50 px-2 py-0.5 rounded-md font-cairo font-bold mb-3 inline-block">
                                      تم كشف البيانات بموجب ميثاق الشرف الموقّع من طرفك
                                    </span>

                                    <div className="space-y-2.5">
                                      <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-100">
                                        <span className="text-slate-400 font-cairo text-xs">صلة قرابة الولي للتواصل:</span>
                                        <span className="font-cairo font-black text-xs text-indigo-900 bg-indigo-50 px-2.5 py-0.8 rounded-lg">{contactForm.role}</span>
                                      </div>

                                      <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-slate-100">
                                        <span className="text-slate-400 font-cairo text-xs">رقم هاتف الولي:</span>
                                        <span className="font-mono font-bold text-sm text-slate-800 tracking-wider bg-slate-50 px-3 py-1 rounded-lg select-all border border-slate-150">{contactForm.phone}</span>
                                      </div>

                                      <div className="bg-white p-2.5 rounded-xl border border-slate-100">
                                        <span className="text-slate-400 font-cairo text-[10px] block mb-1">توجيه الأخت بخصوص الاتصال:</span>
                                        <p className="font-tajawal text-[11px] text-slate-600 p-1.5 rounded bg-slate-50 italic">"{contactForm.extra || 'لا توجد ملاحظات مخصصة'}"</p>
                                      </div>
                                    </div>

                                    {/* Action Links: Clickable Calls and Custom prefilled Templates */}
                                    <div className="grid grid-cols-2 gap-2 mt-4 pt-1">
                                      <button
                                        onClick={() => {
                                          navigator.clipboard.writeText(contactForm.phone);
                                          setCopied(true);
                                          showToast('✓ حصلت على هاتف الولي بنجاح!', 'success');
                                          setTimeout(() => setCopied(false), 2000);
                                        }}
                                        className="py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-cairo font-bold text-[11px] rounded-xl flex items-center justify-center gap-1 cursor-pointer shadow-sm transition-all"
                                      >
                                        <Check className="w-4 h-4 text-emerald-400" />
                                        {copied ? 'تم النسخ!' : 'نسخ الرقم'}
                                      </button>

                                      <a
                                        href={`https://wa.me/${contactForm.phone.replace(/^0/, '966')}?text=${encodeURIComponent(
                                          `السلام عليكم ورحمة الله وبركاته، عمت صباحاً بكل خير وفضل يا عمي الفاضل.. أدعى المتقدم الخلوق لخطبة كريمتكم الفاضلة عن طريق منصة توافق الشرعية المعتمدة. يسعدني تبادل الحديث الهاتفي والتنسيق لمعرفة حضراتكم وقراءة الفاتحة ببركة الله.`
                                        )}`}
                                        target="_blank"
                                        referrerPolicy="no-referrer"
                                        className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-[11px] rounded-xl flex items-center justify-center gap-1 cursor-pointer shadow-sm text-center transition-all"
                                      >
                                        <span>رمز الواتساب 💬</span>
                                      </a>
                                    </div>
                                    <p className="text-[9.5px] font-tajawal text-slate-400 mt-2 text-center leading-none">
                                      💡 ننصحك بمبادرة الولي برسالة وقار عبر الواتساب أولاً لتهيئة الاتصال الهاتفي!
                                    </p>
                                  </div>

                                  {maleSubmitted ? (
                                    <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl text-xs font-tajawal text-slate-700 text-right">
                                      <h5 className="font-cairo font-black text-slate-800 mb-1">تم توثيق رد أهل المتقدم للربط:</h5>
                                      <p className="italic text-slate-600 bg-white p-2.5 rounded-lg border border-slate-100">"{maleResponse}"</p>
                                    </div>
                                  ) : (
                                    <div className="space-y-3 pt-3 border-t border-slate-100 text-right">
                                      <label className="text-xs font-cairo font-bold text-slate-700 block">اكتب ردك وتأكيد نية اتصال والدك بوجهة الكرام:</label>
                                      <textarea
                                        value={maleResponse}
                                        onChange={(e) => setMaleResponse(e.target.value)}
                                        placeholder="مثال: أهلاً بكم، سيتواصل والدي الكريم مع والدك الفاضل للتنسيق والتشرف بمعرفتكم يوم الخميس القادم بإذن الله من الرقم 055xxxxxxx"
                                        rows={3}
                                        className="w-full p-3 text-xs text-navy-900 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500 font-tajawal"
                                      />
                                      <button
                                        onClick={handleMaleSubmitConfirmation}
                                        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-cairo font-black text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                                      >
                                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                        تأكيد وإرسال رد الأهل للربط الرسمية
                                      </button>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Right Column: Complete Chat sandbox */}
                    <div className="lg:col-span-7 bg-white rounded-3xl border border-cream-250 shadow-soft overflow-hidden flex flex-col h-[460px]">
                      {/* Chat Header */}
                      <div className="bg-slate-10 border-b border-cream-200 px-5 py-3.5 flex items-center justify-between text-right flex-shrink-0">
                        <div className="flex items-center gap-2.5">
                          <div className="relative">
                            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-700 flex items-center justify-center font-cairo font-nine font-black text-xs border border-amber-500/20">
                              {partner.nickname[0]}
                            </div>
                            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white" />
                          </div>
                          <div>
                            <span className="block font-cairo font-black text-sm text-slate-900 leading-none">{partner.nickname}</span>
                            <span className="block text-[10px] text-slate-400 font-tajawal mt-1 flex items-center gap-1 leading-none">
                              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              دردشة تواصل مجانية ومؤمنة
                            </span>
                          </div>
                        </div>

                        <span className="text-[10px] bg-slate-100 text-slate-600 font-cairo font-extrabold px-3 py-1.5 rounded-xl border border-slate-200">
                          مراقبة للخصوصية والآداب 🛡️
                        </span>
                      </div>

                      {/* Chat Messages */}
                      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/40">
                        {messages.map((m) => {
                          const isMe = m.sender === 'user';
                          const isSys = m.sender === 'system';
                          const isMed = m.sender === 'mediator';

                          if (isSys) {
                            return (
                              <div key={m.id} className="flex justify-center">
                                <div className="bg-amber-50/70 border border-amber-250/50 rounded-2xl px-4 py-2 text-center text-[10px] text-amber-900 font-tajawal max-w-sm leading-relaxed">
                                  {m.text}
                                </div>
                              </div>
                            );
                          }

                          if (isMed) {
                            return (
                              <div key={m.id} className="flex items-start gap-2 max-w-lg">
                                <div className="w-8 h-8 rounded-xl bg-navy-900 text-white flex items-center justify-center text-[9.5px] font-cairo font-black flex-shrink-0 shadow-inner">
                                  أخصائي
                                </div>
                                <div className="bg-navy-900 text-slate-100 rounded-2xl rounded-tr-none p-3.5 text-[11.5px] font-tajawal leading-relaxed shadow-sm">
                                  <span className="block font-cairo font-black text-[10px] text-amber-400 mb-1">الوسيط الأخصائي للمنصة:</span>
                                  {m.text}
                                </div>
                              </div>
                            );
                          }

                          return (
                            <div key={m.id} className={`flex ${isMe ? 'justify-start' : 'justify-end'}`}>
                              <div className={`max-w-md rounded-2xl p-3.5 text-xs font-tajawal leading-relaxed shadow-sm ${
                                isMe
                                  ? 'bg-amber-500 text-white rounded-tl-none'
                                  : 'bg-white border border-slate-200 text-navy-800 rounded-tr-none'
                              }`}>
                                <span className="block font-cairo font-extrabold text-[9px] mb-1 opacity-70">
                                  {isMe ? 'أنت' : partner.nickname}
                                </span>
                                <div className="whitespace-pre-line">{m.text}</div>
                              </div>
                            </div>
                          );
                        })}

                        {isTyping && (
                          <div className="flex justify-end">
                            <div className="bg-white border border-slate-150 rounded-xl rounded-tr-none px-4 py-2.5 text-xs text-slate-400 font-tajawal flex items-center gap-1.5 shadow-sm">
                              <span>يكتب الطرف الآخر الآن</span>
                              <span className="inline-flex gap-0.5"><span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" /><span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" /><span className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" /></span>
                            </div>
                          </div>
                        )}
                        <div ref={chatEndRef} />
                      </div>

                      {/* Presets and Inputs */}
                      <div className="p-2 border-t border-cream-100 bg-cream-50/35 flex flex-wrap gap-1.5 justify-end">
                        <span className="text-[9.5px] font-cairo text-slate-400 self-center ml-2">عبارات سريعة:</span>
                        {STAGE4_QUICK_REPLIES.map((pm, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSendPreset(pm)}
                            className="bg-white hover:bg-cream-50 text-[10px] text-slate-700 px-3 py-1.5 rounded-xl border border-slate-200 font-tajawal transition-colors cursor-pointer"
                          >
                            {pm}
                          </button>
                        ))}
                      </div>

                      {/* Chat input form */}
                      <div className="p-3 border-t border-cream-200 bg-white flex items-center gap-2 flex-shrink-0 pb-safe">
                        <input
                          type="text"
                          value={chatInput}
                          onChange={(e) => setChatInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                          placeholder="اكتب رسالة للتعارف بالمعروف..."
                          className="flex-1 p-3 text-xs text-navy-900 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-amber-400 font-tajawal text-right"
                        />
                        <button
                          onClick={handleSendMessage}
                          className="w-10 h-10 rounded-xl bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center transition-colors shadow-sm cursor-pointer"
                        >
                          <Send className="w-4.5 h-4.5 transform rotate-180" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Agreement Trigger Button for Phase 2 complete */}
                  <div className="p-6 bg-amber-500/5 rounded-3xl border border-amber-500/10 text-center space-y-4 max-w-2xl mx-auto mt-6">
                    <p className="text-xs font-tajawal text-slate-700 leading-relaxed">
                      بمجرد تبادل التفاصيل الرسمية بين العائلتين وتوافق عائلتيكما تواصلاتهم، يرجى الضغط على زر الاتفاق والموافقة بالخدمة أدناه فوراً للدخول في ترتيبات النظرة الشرعية المباركة وتحديث حالة السعي.
                    </p>

                    <button
                      onClick={handleSetAgreed}
                      disabled={!(contactForm.submitted && (maleSubmitted || simRole === 'female'))}
                      className={`px-8 py-4 rounded-xl font-cairo font-black text-xs shadow-md transition-all flex items-center gap-2 mx-auto cursor-pointer ${
                        contactForm.submitted && (maleSubmitted || simRole === 'female')
                          ? 'bg-gradient-to-r from-amber-550 to-orange-550 hover:from-amber-600 hover:to-orange-600 text-white hover:translate-y-[-2px]'
                          : 'bg-slate-2 text-slate-400 border border-slate-200 cursor-not-allowed'
                      }`}
                    >
                      <Handshake className="w-5 h-5 text-amber-300 animate-pulse" />
                      <span>تم الاتفاق وتلقي معلومات التواصل الرسمي 🤝</span>
                    </button>
                    {!(contactForm.submitted && (maleSubmitted || simRole === 'female')) && (
                      <p className="text-[10px] text-slate-400 font-tajawal italic">
                        * يرجى إرسال معلومات الاتصال للولي الأخت وتأكيد الطرف الآخر لكشف تفعيل زر الاتفاق بالكامل.
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* ======================= PHASE 3: النظرة الشرعية والوفاق ======================= */}
              {currentStep === 3 && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  <div className="md:col-span-8 space-y-5">
                    {/* Banner informational */}
                    <div className="bg-white rounded-3xl p-5 border border-indigo-150 text-right space-y-3 shadow-soft">
                      <h4 className="font-cairo font-black text-sm text-indigo-950 flex items-center gap-1.5">
                        <Users className="w-5.5 h-5.5 text-indigo-600" />
                        المرحلة الثالثة: متابعة النظرة الشرعية وتوافق الآراء العائلية
                      </h4>
                      <p className="text-xs font-tajawal text-slate-700 leading-relaxed">
                        تهانينا الكريمة على تبادل الأرقام الرسمية؛ تتم النظرة الشرعية واللقاء التنسيقي بمباركة مبارك من المنصة. نأمل منكما تسجيل رأيكما الشرعي الصادق والأمين حول نتيجة اللقاء الشرعي لمتابعة إجراءات الملكة أو تسوية واسترجاع المستحقات.
                      </p>
                    </div>

                    {/* مجدول اللقاء والنظرة الشرعية الثنائي التفاعلي - Dynamic Arabesque Scheduler */}
                    <div className="bg-white rounded-3xl p-6 border border-amber-200/80 shadow-md space-y-4 text-right relative overflow-hidden">
                      <div className="absolute top-0 left-0 bg-amber-500/10 text-amber-700 font-cairo font-bold text-[9px] px-3 py-1 rounded-bl-2xl">
                        مجدول اللقاء الأسري 📅
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-cairo font-black text-sm text-navy-950 flex items-center gap-1.5">
                          <Clock className="w-4.5 h-4.5 text-amber-500" />
                          تنسيق موعد ومكان النظرة الشرعية المباركة
                        </h4>
                        <p className="text-[11px] font-tajawal text-slate-500">
                          بموجب تبادل معلومات الأرقام الرسمية، تفضلوا بتوثيق الموعد المقترح للقاء النظرة الشرعية وجدولته لإنشاء بطاقة الدعوة الرسمية وتسهيل الربط.
                        </p>
                      </div>

                      {appCreated ? (
                        <div className="bg-gradient-to-br from-amber-50/70 to-orange-50/45 border-2 border-double border-amber-300 p-5 rounded-2.5xl text-xs font-tajawal space-y-3 shadow-sm relative">
                          <span className="absolute top-2 left-2 text-2xl opacity-10">🕌</span>
                          <strong className="font-cairo text-xs text-amber-900 block border-b border-amber-200/50 pb-2">بطاقة دعوة النظرة الشرعية المقررة:</strong>
                          <div className="space-y-2 text-slate-700">
                            <div className="flex justify-between items-center bg-white/75 p-2 rounded-xl">
                              <span className="font-cairo text-[11px] text-slate-400">اليوم والتاريخ:</span>
                              <span className="font-cairo font-black text-xs text-slate-800">{appDate}</span>
                            </div>
                            <div className="flex justify-between items-center bg-white/75 p-2 rounded-xl">
                              <span className="font-cairo text-[11px] text-slate-400">الوقت المحدد:</span>
                              <span className="font-mono font-bold text-xs text-slate-800">{appTime}</span>
                            </div>
                            <div className="flex justify-between items-center bg-white/75 p-2 rounded-xl">
                              <span className="font-cairo text-[11px] text-slate-400">مكان اللقاء العائلي:</span>
                              <span className="font-tajawal text-xs text-slate-800">{appLocation}</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2 pt-2">
                            <button
                              onClick={() => {
                                const inviteText = `السلام عليكم ورحمة الله وبركاته.. بفضل الله وتنسيق منصة توافق، تم تحديد موعد اللقاء العائلي المبارك وقرار النظرة الشرعية يوم [${appDate}] الساعة [${appTime}] في [${appLocation}]. نتشرف بلقائكم الميمون بارك الله في خطاكم 💮`;
                                navigator.clipboard.writeText(inviteText);
                                showToast('✓ تم نسخ نص الدعوة لتبادلها عبر الواتساب!', 'success');
                              }}
                              className="py-2 bg-amber-550 hover:bg-amber-600 text-white font-cairo font-bold text-[10.5px] rounded-xl flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-sm text-center"
                            >
                              <span>نسخ دعوة واتساب 📱</span>
                            </button>
                            <button
                              onClick={() => {
                                setAppCreated(false);
                                updateDetails(req.id, { appointmentCreated: false });
                              }}
                              className="py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-cairo font-bold text-[10.5px] rounded-xl flex items-center justify-center gap-1 cursor-pointer transition-colors border border-slate-200 text-center"
                            >
                              <span>تحديث الموعد</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3 bg-slate-50 p-4 rounded-2.5xl border border-slate-150">
                          <div className="grid grid-cols-2 gap-3 text-right">
                            <div className="space-y-1">
                              <label className="text-[10px] font-cairo font-bold text-slate-600">التاريخ المقترح:</label>
                              <input
                                type="date"
                                value={appDate}
                                onChange={(e) => setAppDate(e.target.value)}
                                className="w-full p-2 text-xs text-slate-800 bg-white rounded-xl border border-slate-200 focus:outline-none focus:border-amber-400 font-tajawal text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-cairo font-bold text-slate-600">الوقت التقديري:</label>
                              <input
                                type="time"
                                value={appTime}
                                onChange={(e) => setAppTime(e.target.value)}
                                className="w-full p-2 text-xs text-slate-800 bg-white rounded-xl border border-slate-200 focus:outline-none focus:border-amber-400 font-tajawal text-center"
                              />
                            </div>
                          </div>
                          
                          <div className="space-y-1 text-right">
                            <label className="text-[10px] font-cairo font-bold text-slate-600">المكان والمجلس المقترح:</label>
                            <input
                              type="text"
                              value={appLocation}
                              onChange={(e) => setAppLocation(e.target.value)}
                              placeholder="مثال: مجلس والد الأخت الكريمة بالملز، الرياض"
                              className="w-full p-2.5 text-xs text-slate-800 bg-white rounded-xl border border-slate-200 focus:outline-none focus:border-amber-400 font-tajawal text-right"
                            />
                          </div>

                          <button
                            onClick={() => {
                              setAppCreated(true);
                              updateDetails(req.id, {
                                appointmentDate: appDate,
                                appointmentTime: appTime,
                                appointmentLocation: appLocation,
                                appointmentCreated: true
                              });
                              showToast('✓ تم إنشاء وتوثيق كود بطاقة موعد النظرة الشرعية بنجاح!', 'success');
                            }}
                            className="w-full py-2.5 bg-navy-900 hover:bg-navy-850 text-white font-cairo font-black text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <Calendar className="w-4 h-4 text-amber-400" />
                            إصدار بطاقة دعوة اللقاء الشرعي وتوثيق الجدول
                          </button>
                        </div>
                      )}
                    </div>

                    {/* التحديث اللحظي المشترك ومقارنة الموافقة */}
                    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-soft space-y-5">
                      <h4 className="font-cairo font-black text-sm text-navy-950 pb-2.5 border-b border-slate-100 flex items-center gap-1.5">
                        <Heart className="w-5 h-5 text-amber-500" />
                        نظام تتبع حالة القبول والائتلاف الثنائي (Mutual Confirmation)
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Your decision card */}
                        <div className={`p-4 rounded-2xl border text-right space-y-3 ${
                          userSharia === 'yes'
                            ? 'bg-emerald-50/60 border-emerald-200'
                            : userSharia === 'no'
                              ? 'bg-rose-50/60 border-rose-200'
                              : 'bg-slate-50 border-slate-200'
                        }`}>
                          <span className="text-[10px] font-bold font-cairo bg-white p-1.5 rounded-lg border text-slate-600 leading-none">رأيك وقرارك الشرعي</span>
                          <p className="text-xs font-tajawal text-slate-700">
                            حالة قرارك: {userSharia === 'yes' ? <strong className="text-emerald-700">تم تأكيد القبول والحمد لله 👍</strong> : userSharia === 'no' ? <strong className="text-rose-600">تم تسجيل الاعتذار بالمعروف</strong> : 'بانتظار تحديد رأيك'}
                          </p>

                          {userSharia === 'none' ? (
                            <div className="flex gap-2.5 pt-1">
                              <button
                                onClick={() => handleShariaAnswer('yes')}
                                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs shadow-sm transition-all cursor-pointer flex items-center justify-center gap-1"
                              >
                                <ThumbsUp className="w-4 h-4" /> القبول والوفاق 👍
                              </button>
                              <button
                                onClick={() => handleShariaAnswer('no')}
                                className="flex-1 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-150 font-cairo font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1"
                              >
                                <ThumbsDown className="w-4 h-4" /> عدم حدوث نصيب
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setUserSharia('none');
                                updateDetails(req.id, { userShariaChoice: 'none' });
                              }}
                              className="text-[10px] font-cairo font-bold text-slate-500 hover:text-navy-900 underline cursor-pointer"
                            >
                              تعديل الرأي والقرار الشرعي
                            </button>
                          )}
                        </div>

                        {/* Partner decision card */}
                        <div className={`p-4 rounded-2xl border text-right space-y-3 ${
                          partnerSharia === 'yes'
                            ? 'bg-emerald-50/60 border-emerald-200'
                            : partnerSharia === 'no'
                              ? 'bg-rose-50/60 border-rose-200'
                              : 'bg-slate-50 border-slate-200'
                        }`}>
                          <span className="text-[10px] font-bold font-cairo bg-white p-1.5 rounded-lg border text-slate-700 leading-none">قرار الطرف الآخر ({partner.nickname})</span>
                          <p className="text-xs font-tajawal text-slate-705">
                            حالة قراره: {partnerSharia === 'yes' ? <strong className="text-emerald-700">أكد القبول والموافقة المبدئية 👍</strong> : partnerSharia === 'no' ? <strong className="text-rose-600">اعتذر عن الموافقة بالمعروف</strong> : 'قيد المراجعة والتباحث...'}
                          </p>

                          {partnerSharia === 'none' && (
                            <div className="text-[10px] text-amber-800 bg-amber-50/70 p-2 rounded-xl">
                              🔍 بانتظار إعلان الطرف الآخر لقراره. (اضغط "محاكاة رد الطرف الآخر" للاختبار!)
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* لوحة الفشل لمسار الرفض والاعتذار بالمعروف واللطف */}
                    {(userSharia === 'no' || partnerSharia === 'no') && (
                      <div className="bg-rose-50 rounded-3xl p-5 border border-rose-150 space-y-4 text-right">
                        <div className="flex items-start gap-3">
                          <Ban className="w-6 h-6 text-rose-500 flex-shrink-0 mt-0.5" />
                          <div className="space-y-1">
                            <h4 className="font-cairo font-black text-sm text-rose-950">لوحة الاعتذار بالمعروف وسياسة التواصل الذكية بالمنصة</h4>
                            <p className="text-xs font-tajawal text-rose-900 leading-relaxed">
                              عوضكم الله خيراً، والحمد لله على كل حال. الزواج توافق واختيار والائتلاف قد لا يتم في ملف ويعوضكم الله في ملف قادم. نسأل الله لكم النصيب الأبرك.
                            </p>
                          </div>
                        </div>

                        {userSharia === 'no' && (
                          <div className="space-y-3 pt-3 border-t border-rose-150/50">
                            <label className="text-xs font-cairo font-bold text-rose-900 block">لطفاً، شاركنا سبب الاعتذار والتحفظ (سرّي للأرشفة والتنسيق):</label>
                            <input
                              type="text"
                              value={shariaReason}
                              onChange={(e) => setShariaReason(e.target.value)}
                              placeholder="مثال: عدم تقارب تطلعات العيش أو السكن، شروط خاصة بأوقات عمل الطرفين..."
                              className="w-full p-3 text-xs bg-white text-rose-950 rounded-xl border border-rose-200 focus:outline-none"
                            />
                            <button
                              onClick={handleDismissWithGrace}
                              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs transition-colors cursor-pointer shadow-sm"
                            >
                              إرسال وحفظ كود الاعتذار اللطيف واسترجاع العربون
                            </button>
                            <p className="text-[10px] text-rose-800 block leading-normal">
                              ★ تماشياً مع سياسة "تواصل تيسير"، سيتم توثيق الاعتذار عاجلاً لإبلاغ الطرف الآخر بالمعروف واللطف، وإرجاع مستحقات العربود لحسابك بالمنصة فوراً.
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* لوحة النجاح والتهئنة الرائعة في حال ائتلاف القلوب والموافقة */}
                    {userSharia === 'yes' && partnerSharia === 'yes' && (
                      <div className="bg-gradient-to-br from-[#fdfbf7] to-[#effbf3] rounded-3xl p-6 border-2 border-emerald-300 text-center space-y-4.5 relative overflow-hidden shadow-md">
                        <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-l from-emerald-500 to-amber-550" />
                        <div className="w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200 shadow-sm">
                          <Heart className="w-8 h-8 text-emerald-500 fill-emerald-500 animate-pulse" />
                        </div>

                        <div className="space-y-2">
                          <h4 className="font-cairo font-black text-lg text-emerald-900">ألف مبروك! توافقت الرؤية وحصل القبول المبارك 🎉🌸</h4>
                          <p className="text-xs font-tajawal text-slate-700 leading-relaxed max-w-lg mx-auto">
                            "ألف مبروك! الله يجمع بينكما على خير ويرزقكما المودة والرحمة ويبارك لكما 🌸✨"
                            نبارك للأخت الكريمة وللأخ الفاضل هذا الانسجام الجميل والتفاوض المحتشم، ونأمل لكم حياة زوجية مبهجة ملؤها الرضا والتوفيق.
                          </p>
                        </div>

                        <button
                          onClick={handleGoToPhase4}
                          className="px-8 py-3.5 bg-navy-900 hover:bg-navy-850 text-white rounded-2xl font-cairo font-black text-xs shadow-lg transition-all hover:translate-y-[-2px] cursor-pointer flex items-center gap-1.5 mx-auto"
                        >
                          المتابعة لخطوة عقد القران المبارك وتوثيقه
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Right Column: Tips & Guidelines */}
                  <div className="md:col-span-4 bg-white rounded-3xl p-5 border border-cream-205 space-y-4">
                    <h5 className="font-cairo font-bold text-xs text-navy-950 pb-2 border-b border-cream-100 flex items-center gap-1">
                      <HelpCircle className="w-4.5 h-4.5 text-indigo-500" />
                      إرشادات اللقاء العائلي
                    </h5>
                    <ul className="text-[10.5px] font-tajawal text-slate-600 space-y-2.5 list-disc list-inside text-right">
                      <li>احرصوا على حضور أولياء الأمور بالتنسيق في الموعد واليوم المتفق عليه.</li>
                      <li>التزموا بالصدق وتوضيح الشروط الأساسية (السكن، العمل، الحقوق).</li>
                      <li>النظرة الشرعية حق ديني كفله الشرع لتأكيد الراحة النفسية.</li>
                      <li className="text-amber-700 font-bold">في حال الاعتذار، حافظوا على الخصوصية والمشاعر ويتم تفعيل سياسة حفظ الحقوق لسلامة الجميع.</li>
                    </ul>
                  </div>
                </div>
              )}

              {/* ======================= PHASE 4: عقد القران وتوثيق الفرحة ======================= */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  {/* Banner information */}
                  <div className="text-center py-4 max-w-xl mx-auto space-y-2">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-white flex items-center justify-center mx-auto border border-white shadow-lg animate-bounce">
                      <Sparkles className="w-10 h-10 text-amber-200" />
                    </div>
                    <h3 className="font-cairo font-black text-2xl text-navy-950 leading-tight">
                      الخطوة الرائعة والختامية: ميثاق الزواج والملكة السعيدة!
                    </h3>
                    <p className="text-xs font-tajawal text-slate-500 max-w-sm mx-auto">
                      بفضل من الله ومنّه وتيسير السعي الميمون بمنصة معاً توافق، نعيش فرحة كبرى ونتبادل التهاني الطيبة.
                    </p>
                  </div>

                  {/* سؤال الملكة وعقد القران */}
                  {!nikahConfirmed ? (
                    <div className="bg-white rounded-3xl p-6 border border-cream-200 text-center max-w-xl mx-auto space-y-4 shadow-soft">
                      <h4 className="font-cairo font-black text-base text-navy-900">سؤال الملكة الرسمي لتوثيق العهد</h4>
                      <p className="text-xs font-tajawal text-slate-650 max-w-md mx-auto leading-relaxed">
                        هل تم بفضل وتيسير من الله لقاء الأهل وعقد قران ومباركة هذا الزفاف الميمون؟ شاركنا هذا السعي لنبارك وننشر الفرح والمساعي بنجاح.
                      </p>
                      <button
                        onClick={handleConfirmMarriage}
                        className="px-10 py-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-black text-xs shadow-md transition-colors animate-pulse cursor-pointer flex items-center gap-1.5 mx-auto"
                      >
                        <CheckCircle2 className="w-5 h-5 text-emerald-255" />
                        نعم، تم عقد القران (الملكة) ولله الحمد والمنة! 🎉
                      </button>
                    </div>
                  ) : (
                    // Contract Wedding completed views & final payment
                    <div className="space-y-6">
                      {!finalFeesPaid ? (
                        // سداد بقية الرسوم والوفاء بالحقوق
                        <div className="bg-white rounded-3xl p-6 border-2 border-amber-300 max-w-md mx-auto space-y-5 text-right shadow-md">
                          <span className="inline-block text-[10px] font-cairo font-black text-amber-800 bg-amber-50 px-2.5 py-1 rounded-md">
                            تصفية مستحقات العهد والمنصة
                          </span>
                          <h4 className="font-cairo font-black text-base text-navy-900 leading-tight">سداد رسوم التوفيق والخدمات الختامية</h4>
                          <p className="text-xs font-tajawal text-slate-650 leading-relaxed">
                            تتشارك المنصة خدمات كشف قنوات تواصل، وتوثيق السعي والمتابعة اللطيفة. يُرجى سداد المبلغ المتبقي لرمز التوفيق المبارك.
                          </p>

                          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs font-tajawal space-y-2">
                            <div className="flex justify-between items-center text-slate-500">
                              <span>سداد العربون السابق (دفعة الجدية)</span>
                              <span className="font-bold font-mono">500 ريال</span>
                            </div>
                            <div className="flex justify-between items-center text-slate-900 font-bold">
                              <span>المبلغ المتبقي للرسوم الختامية</span>
                              <span className="text-amber-700 font-mono">1,000 ريال</span>
                            </div>
                            <div className="border-t border-slate-200/80 pt-2 flex justify-between items-center font-black text-navy-950 font-cairo">
                              <span>القيمة الإجمالية للخدمة</span>
                              <span className="font-bold font-mono">1,500 ريال</span>
                            </div>
                          </div>

                          <button
                            onClick={handlePayRemainingFees}
                            className="w-full py-4 bg-gradient-to-r from-amber-600 to-orange-500 hover:from-amber-700 hover:to-orange-600 text-white font-cairo font-black text-xs rounded-xl shadow-md transition-all active:scale-97 cursor-pointer flex items-center justify-center gap-2"
                          >
                            <CreditCard className="w-4.5 h-4.5" />
                            تسوية متبقي رسوم السعي بـ 1000 ريال
                          </button>
                        </div>
                      ) : (
                        // اكتمال الطلب بالكامل ووثيقة التهنئة الحية الشاعرية
                        <div className="space-y-6">
                          {/* Success tag text */}
                          <div className="p-4 rounded-2xl bg-emerald-100 text-emerald-800 text-xs font-bold text-center font-cairo max-w-sm mx-auto flex items-center gap-1.5 justify-center">
                            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                            <span>اكتمال الطلب بالكامل ومكلل بالنجاح والتوفيق 🏆🎉</span>
                          </div>

                          {/* وثيقة تهنئة إلكترونية رسمية ممتازة */}
                          <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="bg-[#faf6eb] border-8 border-double border-amber-600 rounded-3xl p-6.5 max-w-xl mx-auto shadow-xl relative overflow-hidden"
                            style={{ backgroundImage: 'radial-gradient(ellipse at center, rgba(250,246,235,1) 0%, rgba(240,230,210,1) 100%)' }}
                          >
                            {/* Decorative golden ornaments */}
                            <div className="absolute top-3 right-3 left-3 bottom-3 border border-amber-600/30 rounded-2xl pointer-events-none" />
                            <div className="absolute top-5 right-5 w-8 h-8 border-t-2 border-r-2 border-amber-600/50" />
                            <div className="absolute top-5 left-5 w-8 h-8 border-t-2 border-l-2 border-amber-600/50" />
                            <div className="absolute bottom-5 right-5 w-8 h-8 border-b-2 border-r-2 border-amber-600/50" />
                            <div className="absolute bottom-5 left-5 w-8 h-8 border-b-2 border-l-2 border-amber-600/50" />

                            <div className="space-y-4 text-center">
                              <span className="block font-cairo font-black text-amber-800 text-xs tracking-widest uppercase">وثيقة وميثاق مباركة ميمونة</span>
                              
                              <h4 className="font-cairo font-nine font-black text-xl text-navy-950 mt-1">عقد نكاح وتوفيق بالخير والبركة 💍🤍</h4>
                              
                              <p className="text-[11.5px] font-tajawal text-slate-700 leading-relaxed italic max-w-md mx-auto">
                                "بفضل وتوفييق من الله العلي القدير، نرفع بأجمل معاني التهاني والتبريكات المروئية المكللة بمحبة ومودة لجميل ائتلاف العائلتين بالمنصة."
                              </p>

                              {/* Couples calligraphic display */}
                              <div className="py-4 flex items-center justify-center gap-8 border-y border-amber-600/10 max-w-sm mx-auto">
                                <div>
                                  <span className="block text-[10px] font-tajawal text-slate-400">العروس</span>
                                  <span className="font-cairo font-black text-base text-rose-600 mt-1 block">
                                    {simRole === 'female' ? user.profile?.nickname || 'الأخت الكريمة' : partner.nickname}
                                  </span>
                                </div>
                                <Heart className="w-5 h-5 text-amber-500 fill-amber-500 animate-pulse" />
                                <div>
                                  <span className="block text-[10px] font-tajawal text-slate-400">الزوج</span>
                                  <span className="font-cairo font-black text-base text-blue-700 mt-1 block">
                                    {simRole === 'male' ? user.profile?.nickname || 'الأخ الفاضل' : partner.nickname}
                                  </span>
                                </div>
                              </div>

                              <p className="text-[10px] font-tajawal text-slate-500">
                                بارك الله لكما، وبارك عليكما، وجمع بينكما في خير وسعادة دائمين.
                              </p>

                              <div className="pt-3 max-w-xs mx-auto flex justify-between items-center text-[9px] font-mono text-slate-400 border-t border-amber-600/5">
                                <span>الرقم المرجعي: TW {req.id}</span>
                                <span>إدارة منصة تواصل وتوافق</span>
                              </div>
                            </div>
                          </motion.div>

                          {/* طلب التقييم والتعليق الختامي لحفظ فرحتهم */}
                          <div className="bg-white rounded-3xl p-6 border border-cream-205 max-w-lg mx-auto text-right space-y-4 shadow-soft">
                            <h4 className="font-cairo font-black text-xs text-navy-850 border-b border-cream-100 pb-2.5">
                              مشاركتنا لتقييم تجربتك التنسيقية وتخليد فرحتكم
                            </h4>

                            {/* Stars bar */}
                            <div className="space-y-1.5">
                              <label className="text-[11px] font-tajawal text-slate-400 block">تقييمك لجودة وتنسيق المنسقة الشرعية:</label>
                              <div className="flex gap-2 justify-center" dir="ltr">
                                {[1, 2, 3, 4, 5].map((starVal) => (
                                  <button
                                    key={starVal}
                                    onClick={() => setRating(starVal)}
                                    className="p-1 cursor-pointer transition-transform hover:scale-115 text-slate-200"
                                  >
                                    <Star className={`w-8 h-8 ${
                                      rating >= starVal
                                        ? 'text-amber-500 fill-amber-500'
                                        : 'text-slate-200'
                                    }`} />
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-[11px] font-tajawal text-slate-400 block">أضف انطباعك بكلمة طيبة لوحة الشرف (اختياري):</label>
                              <textarea
                                value={reviewText}
                                onChange={(e) => setReviewText(e.target.value)}
                                placeholder="دعواتك وكلماتك الطيبة هي أكبر مشجع للمنسقة المتابعة للملف ونشر البشائر..."
                                rows={3}
                                className="w-full text-xs font-tajawal p-3 rounded-xl border border-cream-200 bg-white focus:outline-none focus:border-amber-400"
                              />
                            </div>

                            <button
                              onClick={handleSaveEvaluation}
                              className="w-full py-3.5 rounded-xl bg-navy-900 hover:bg-navy-850 text-white font-cairo font-bold text-xs transition-all cursor-pointer shadow-sm active:scale-98 text-center block"
                            >
                              إرسال وحفظ التقييم المبارك والتهجئة
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                </div>
              )}

            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
