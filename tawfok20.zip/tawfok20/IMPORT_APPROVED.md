# Import approved

The user approved importing the Tawasol/Tawfok marriage platform archive from GitHub and running it here using its existing localStorage data approach without adding a new database layer.
